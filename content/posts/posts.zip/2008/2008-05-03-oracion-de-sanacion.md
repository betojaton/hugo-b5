---
title: ORACION DE SANACION
author: admin

date: 2008-05-03T00:18:39+00:00
url: /2008/oracion-de-sanacion/
tags: [Oraciones]

---
**Le dice la Santísima Virgen:** 

**Vicente hijo mío decid esta oración y dadlas a tus hermanos.**

Señor Jesús, ven a sanarme, sáname de los recuerdos, de mi pasado que tanto dolor causan en mi alma, sáname Jesús de esos recuerdos y experiencias dolorosas que no me dejan avanzar y entregarme plenamente a Ti, sáname Jesús del dolor, sáname de la angustia y de la desesperación y que sepa Jesús con tu ayuda caminar firmemente, con fortaleza, con la fuerza que me da tú SACRATISIMO CORAZON.

Jesús acompáñame en éste camino, guíame Jesús, que no me aparte de Ti  y si vuelvo a caer en la oscuridad del pecado que vuelva Ti prontamente, que me entregue sin temor y confiadamente a tus brazos, porque sé que tú Jesús estas presto a socorrerme.

**Amén. Gloria al SAGRADO CORAZON DE JESUS**

**Predícalo hijo mío.**