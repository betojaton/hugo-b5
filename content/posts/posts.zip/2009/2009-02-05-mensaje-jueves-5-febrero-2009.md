---
title: Mensaje, jueves 5 febrero 2009
author: admin

date: 2009-02-05T23:27:49+00:00
url: /2009/mensaje-jueves-5-febrero-2009/
thumbnail: /images/pies-caminando-1.jpg
tags: [Mensajes 2009]

---
**_Hora 18.14_  
Le dice la Santísima Virgen a Vicente:**

<img decoding="async" src="https://mariadelasantafe.org.ar/images/foto-ostia.jpg" alt="foto-ostia" class="alignright size-full wp-image-4128" /> 

> “Hijos míos. Benditos y amados hijos míos. La estrella de mi pecho os ilumina, la estrella que está en mi corazón os ilumina y os guía en este camino. Debéis confiar en la madre profundamente, en mi presencia, en mis palabras y en que en el momento justo  
> Dios os dará la respuesta.  
> Vosotros hijitos míos escucháis a la Madre, comprendéis el mensaje de la Madre. Hay otros hijos que no escuchan a la Madre y que no comprenden mis mensajes. Muchos hijos que en el mundo entero, habiendo escuchado mis palabras se apartaron de mi lado. Llamo hoy nuevamente a todos los hijos a una conversión definitiva. Llamo a todos los corazones a encontrarse definitivamente con Jesús, a buscar a Jesús, a buscarlo en la sagrada eucaristía. Llamo a todos los hijos a buscar la luz y la verdad y a apartarse de toda guerra y división. Hijitos, cada una de mis palabras debe ser meditada y comprendida profundamente en vuestro corazón. Vosotros sois mi grupo. Vosotros sois mis hijos predilectos de mi corazón inmaculado. Vosotros estáis entro de mi corazón de madre y escucho vuestros corazones y recibo vuestras peticiones que luego las presento a Jesús y Jesús al Padre. Comprended mi mensaje hoy y meditad profundamente. Meditad, meditad, meditad mis palabras.”

**_Hora : 18.17_  
Le dice Jesús a Vicente:**

<img decoding="async" src="https://mariadelasantafe.org.ar/images/pies-caminando.jpg" alt="pies-caminando" class="alignright size-full wp-image-4132" /> 

> “Hermanos míos. Benditos y amados hermanos míos. Os hablo de amor y de verdad. Os hablo de paz y de sinceridad. Os hablo de verdad y al mundo entero hablo de mi verdad. A todos los corazones hablo de mi verdad, para que la humanidad comprenda definitivamente que el camino de la libertad está en la verdad, que el camino de la vida eterna está en mi sacratísimo corazón. Cuanta piedras, cuantas barreras, cuantos obstáculos pone el hombre a mi paz.  
> Quiero llegar a todas las almas porque mi divina misericordia se derrama en todas las almas. El hombre no podrá destruir ni dispersar porque mi sacratísimo corazón os ilumina, os fortalece, os enriquece. Hoy quizás no comprendáis mis palabras pero prontamente sabréis a que me refiero. Y vosotros que sois testigos de mis palabras, que sois testigos de mi presencia, comunicad al mundo y a vuestros hermanos que mi amor es inextinguible, que mi amor es eterno, que mi amor es para todos. Comunicadlo. Anunciadlo a todos vuestros hermanos. Comunicadlo sin temor a todos los hombres por igual. Os amo profundamente, os amo eternamente, os amo para siempre. Meditad, meditad, meditad mis palabras.
> 
> Os bendigo en el nombre del Padre, del Hijo y del Espíritu Santo. Amén”<footer>Leed Salmo 60.</footer> 

_Hora de finalización: 18.20_