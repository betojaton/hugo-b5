---
title: Mensaje, 9 de Febrero, 2009
author: admin

date: 2009-02-09T12:02:09+00:00
url: /2009/mensaje-9-febrero-2009/
thumbnail: /images/img-santo-domingo-guzman.jpg
tags: [Mensajes 2009]
---
**Hora: 18.21  
Le dice Jesús a Vicente:**  
<img decoding="async" src="https://mariadelasantafe.org.ar/images/foto-arroyo.jpg" alt="foto-arroyo" class="alignright size-full wp-image-4146" /> 

> “Hermanos míos. Benditos y amados hermanos míos. Escuchad las palabras de mi Santísima Madre y Madre de todos vosotros. Escuchad y meditad cada una de mis palabras, os hablo de amor, de mi presencia, de mi divina misericordia. Buscad mi corazón, buscad verdaderamente mis caminos, porque en mis caminos hay paz, en mis caminos hay amor, en mis caminos hay verdad. Hay tantas almas y corazones errados que andan dispersos en el mundo buscando solamente el bien material, los placeres pasajeros, los placeres efímeros que conducen a la muerte eterna. Os vengo a hablar de mi profundísimo amor hacia vosotros, de mi eterno amor. Os vengo a traer en cada uno de mis mensajes y de mis presencias todo mi amor y aun así mucho no lo comprendéis, aun así muchos aun todavía no os entregáis a mí totalmente y como lo desea mi sacratísimo corazón. Mis palabras son verdad, son enseñanzas. Estoy aquí verdaderamente presente con mis sacratísimas llagas que sangran por los pecados del mundo, que sangran abundantemente, que sangran y cubren a cada uno de vosotros. Estoy aquí con los brazos abiertos, para abrazaros, para cobijaros, para daros el consuelo. No titubeéis, no dudéis y esperad y confiad siempre en mis palabras y que todo se dará en su justo tiempo y en su justa medida. Mis caminos no son los caminos vuestros, mis caminos no son los caminos en que a veces vosotros transitáis. Mis caminos son verdaderos caminos de paz, mis caminos son verdaderos caminos de verdad, mis caminos son verdaderos caminos que conducen a la vida eterna.  
> Os hablo permanentemente de mi amor, porque os quiero reconfortar con mi amor, porque os vengo a sanar con mi amor, porque os vengo a fortalecer con mi amor. Amor eterno, amor infinito, amor que no tiene límites, amor que sana, amor que hace reverdecer hasta las plantas más secas, hasta la tierra más reseca, hasta el río más seco. Amor eterno, amor inconmensurable que no tiene límites. Os amo profundamente. Creedlo así. Meditad, meditad, meditad mis palabras.  
> Os bendigo en el nombre del Padre, del Hijo y del Espíritu Santo. Amén”<footer>Leed Salmo 75</footer>