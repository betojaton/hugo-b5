---
title: Nacimiento San Juan Bautista
author: admin

date: 2018-05-31T09:16:56+00:00
url: /nacimiento-san-juan-bautista/
thumbnail: /images/img-sanjuan-bautista-nacimiento.jpg

tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-sanjuan-bautista-nacimiento-1.jpg" alt="img-sanjuan-bautista-nacimiento" class="alignright size-medium wp-image-4494" />**24 de Junio**  
Este es el único santo al cual se le celebra la fiesta el día de su nacimiento.

San Juan Bautista nació seis meses antes de Jesucristo (de hoy en seis meses &#8211; el 24 de diciembre &#8211; estaremos celebrando el nacimiento de nuestro Redentor, Jesús).