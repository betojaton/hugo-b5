---
title: Santo Domingo de Guzmán
author: admin

date: 2018-08-08T17:41:00+00:00
url: /santo-domingo-de-guzman/
tags: [Destacada]

---
## 08 de Agosto &#8211; Santo Domingo de Guzmán

<img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2000/12/img-santo-domingo-guzman.jpg" alt="img-santo-domingo-guzman" class="alignright size-full wp-image-4697" /> Domingo significa: “Consagrado al Señor&#8221;.El fundador de los Padres Dominicos, que son ahora 6,800 en 680 casas en el mundo, nació en Caleruega, España, en 1171. Su madre, Juana de Aza, era una mujer admirable en virtudes y ha sido declarada Beata. Lo educó en la más estricta formación religiosa.  
El gran fundador le dio a sus religiosos unas normas que les han hecho un bien inmenso por muchos siglos. Por ejemplo estas:  
Primero contemplar, y después enseñar. O sea: antes dedicar mucho tiempo y muchos esfuerzos a estudiar y meditar las enseñanzas de Jesucristo y de su Iglesia, y después sí dedicarse a predicar con todo el entusiasmo posible.  
Predicar siempre y en todas partes. Santo Domingo quiere que el oficio principalísimo de sus religiosos sea predicar, catequizar, tratar de propagar las en señanzas católicas por todos los medios posibles. Y él mismo daba el ejemplo: donde quiera que llegaba empleaba la mayor parte de su tiempo en predicar y enseñar catecismo.  
La experiencia le había demostrado que las almas se ganan con la caridad. Por eso todos los días pedía a Nuestro Señor la gracia de crecer en el amor hacia Dios y en la caridad hacia los demás y tener un gran deseo de salvar almas. Esto mismo recomendaba a  
sus discípulos que pidieran a Dios constantemente.