---
title: Miércoles de Ceniza
author: admin

date: 2018-01-31T23:31:11+00:00
url: /miercoles-ceniza/
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2018/01/img-miercoles-ceniza.jpg" alt="img-miercoles-ceniza" class="alignright size-full wp-image-4336" />Con la imposición de las cenizas, se inicia una estación espiritual particularmente relevante para todo cristiano que quiera prepararse dignamente para vivir el Misterio Pascual, es decir, la Pasión, Muerte y Resurrección del Señor Jesús.

Este tiempo vigoroso del Año Litúrgico se caracteriza por el mensaje bíblico que puede ser resumido en una sola palabra: &#8220;metanoeiete&#8221;, es decir &#8220;Convertíos&#8221;. Este imperativo es propuesto a la mente de los fieles mediante el rito austero de la imposición de ceniza, el cual, con las palabras &#8220;Convertíos y creed en el Evangelio&#8221; y con la expresión &#8220;Acuérdate que eres polvo y al polvo volverás&#8221;, invita a todos a reflexionar acerca del deber de la conversión, recordando la inexorable caducidad y efímera fragilidad de la vida humana, sujeta a la muerte.

La conversión no es, en efecto, sino un volver a Dios, valorando las realidades terrenales bajo la luz indefectible de su verdad.