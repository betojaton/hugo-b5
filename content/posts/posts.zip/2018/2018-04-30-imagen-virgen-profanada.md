---
title: Imagen de la Virgen profanada es retirada para restaurarla
author: admin

date: 2018-04-30T22:50:18+00:00
abstract: '<iframe width="560" height="315" src="https://www.youtube.com/embed/TXZrV7PzzYQ" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>'
url: /imagen-virgen-profanada/
  - Noticias

---
