---
title: INMACULADA CONCEPCIÓN
author: admin

date: 2018-12-10T14:15:18+00:00
url: /inmaculada-concepcion/
thumbnail: /images/img-inmaculada-concepcion-3.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-inmaculada-concepcion-2.jpg" alt="img-inmaculada-concepcion" class="alignright size-medium wp-image-4816" />**8 de Diciembre**

> “Declaramos, pronunciamos y definimos que la doctrina que sostiene que la Santísima Virgen María, en el primer instante de su concepción, fue por singular gracia y privilegio de Dios omnipotente en previsión de los méritos de Cristo Jesús, Salvador del género humano, preservada inmune de toda mancha de culpa original, ha sido revelada por Dios, por tanto, debe ser firme y constantemente  
> creída por todos los fieles.  
> **&#8220;Dogma proclamado por el Papa Pío IX, el 8 de diciembre de 1854, en la Bula Ineffabilis Deus.**