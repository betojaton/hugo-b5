---
title: Fiesta de la Divina Misericordia
author: admin

date: 2018-03-10T17:32:44+00:00
url: /fiesta-divina-misericordia-2018-2/
thumbnail: /images/fiesta-divina-misericordia-1.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/fiesta-divina-misericordia.jpg" alt="fiesta-divina-misericordia" class="alignright size-medium wp-image-4406" />La Fiesta de la Divina Misericordia tiene como fin principal hacer llegar a los corazones de cada persona el siguiente mensaje:

> Dios es Misericordioso y nos ama a todos &#8230; &#8220;y cuanto más grande es el pecador, tanto más grande es el derecho que tiene a Mi misericordia&#8221;<footer>(Diario, 723).</footer> 

Con el fin de celebrar apropiadamente esta festividad, se recomienda rezar la Coronilla y la Novena a la Divina Misericordia; confesarse &#8211; para la cual es indispensable realizar primero un buen examen de conciencia-, y recibir la Santa Comunión el día de la Fiesta de la Divina Misericordia