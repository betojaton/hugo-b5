---
title: 31 de Mayo de 2018 – Visitación de la Virgen María
author: admin

date: 2018-05-09T19:54:20+00:00
url: /31-mayo-visitacion-virgen-maria/
thumbnail: /images/img-visitacion-virgen.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-visitacion-virgen-1.jpg" alt="img-visitacion-virgen" class="alignright size-medium wp-image-4461" />Luego que María Santísima oyó del ángel Gabriel que su prima Isabel también esperaba un hijo, sintióse iluminada por el Espíritu Santo y comprendió que debería ir a visitar a aquella familia y ayudarles y llevarles las gracias y bendiciones del Hijo de Dios que se había encarnado en Ella. San Ambrosio anota que fue María la que se adelantó a  
saludar a Isabel puesto que es la Virgen María la que siempre se adelanta a dar demostraciones de cariño a quienes ama.