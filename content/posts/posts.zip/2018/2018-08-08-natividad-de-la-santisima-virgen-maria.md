---
title: Natividad de la  Santísima Virgen María
author: admin

date: 2018-08-08T19:55:46+00:00
url: /natividad-de-la-santisima-virgen-maria/
thumbnail: /images/img-fiesta-natividad-virgen-maria-1.jpg

tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-fiesta-natividad-virgen-maria.jpg" alt="img-fiesta-natividad-virgen-maria" class="alignright size-full wp-image-4694" />La Iglesia recuerda el día del nacimiento de la Virgen María cada 8 de setiembre. El Evangelio no nos da datos del nacimiento de María, pero hay varias tra- diciones. Algunas, considerando a María descen- diente de David, señalan su nacimiento en Belén. Otra corriente griega y armenia, señala Nazareth como cuna de María.

La celebración de la fiesta de la Natividad de la Santísima Virgen María, es conocida en Oriente desde el siglo VI. Fue fijada el 8 de septiembre, día con el que se abre el año litúrgico bizantino, el cual se cierra con la Dormición, en agosto. En Occidente fue introducida hacia el siglo VII y era celebrada con una procesión letanía, que terminaba en la Basílica de Santa  
María la Mayo