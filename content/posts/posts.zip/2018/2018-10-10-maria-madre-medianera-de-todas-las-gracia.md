---
title: María, Madre y Medianera de todas las Gracia.
author: admin

date: 2018-10-10T15:05:58+00:00
url: /maria-madre-medianera-de-todas-las-gracia/
thumbnail: /images/papa-virgen.jpg

tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/papa-virgen-1.jpg" alt="papa-virgen" class="alignright size-thumbnail wp-image-4772" />**7 de Noviembre**  
Cristo es el único mediador entre Dios y los hombres porque Él solo, con su muerte, logró la reconciliación perfecta con Dios, pero dice Santo Tomás que 

> también a otros podemos llamarlos mediadores por cuanto cooperan a la unión de los hombres con Dios.

A María se la llama Medianera o Mediadora desde muy antiguo. Este título se le reconoce en documentos oficiales de la Iglesia y ha sido acogido en la liturgia, introduciéndose en 1921 una fiesta dedicada a María Medianera de todas las gracias.