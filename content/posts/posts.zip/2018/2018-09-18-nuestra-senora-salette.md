---
title: Nuestra Señora de La Salette
author: admin

date: 2018-09-18T20:55:05+00:00
url: /nuestra-senora-salette/
thumbnail: /images/img-sra-salette.jpg

tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-sra-salette-1.jpg" alt="img-sra-salette" class="alignright size-medium wp-image-4725" />**19 DE SEPTIEMBRE**

## Nuestra Señora de La Salette

El 19 de septiembre de 1846, apareció la Santísima Virgen, sobre la montaña de La Salette, (Francia), a dos jóvenes pastorcitos, Melania Calvat y Maximino Giraud.

Primeramente les confió un mensaje público; después a Maximino sólo, un secreto; luego a Melania un mensaje que podría publicar en 1858.