---
title: Fiesta del Inmaculado Corazón de la Virgen María
author: admin

date: 2018-05-31T09:10:11+00:00
url: /fiesta-del-inmaculado-corazon-de-la-virgen-maria-2/
tags: [Destacada]

---
**9 de Junio**

<img decoding="async" class="alignright size-medium wp-image-4492" src="https://mariadelasantafe.org.ar/wp-content/uploads/2002/12/img-inmaculado-corazon-maria-368x205.jpg" alt="img-inmaculado-corazon-maria" /> María, Madre de Jesús y nuestra, nos señala hoy su Inmaculado Corazón.

Un corazón que arde de amor divino, que rodeado de rosas blancas nos muestra su pureza total y que atravesado por una espada nos invita a vivir el sendero del dolor alegría.

La Fiesta de su Inmaculado Corazón nos remite de manera directa y misteriosa al Sagrado Corazón de Jesús. Y es que en María todo nos dirige a su Hijo. Los Corazones de Jesús y María están maravillosamente unidos en el tiempo y la eternidad&#8230;