---
title: Fiesta de la Presentación del Señor
author: admin

date: 2018-01-01T13:39:01+00:00
url: /fiesta-presentacion-senor/
tags: [Destacada]

---
## 02 de Febrero &#8211; Fiesta de la Presentación del Señor

<img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2018/01/img-fiesta-presentacion-senior-368x204.jpg" alt="" class="alignright size-medium wp-image-4323" />  
Aunque esta fiesta del 2 de febrero cae fuera del tiempo de navidad, es una parte integrante del relato de navidad. Es una chispa de fuego de navidad, es una epifanía del día cuadragésimo. Navidad, epifanía, presentación del Señor son tres paneles de un tríptico litúrgico.

San Lucas narra el hecho en el capítulo 2 de su evangelio. Obedeciendo a la ley mosaica, los padres de Jesús llevaron a su hijo al templo cuarenta días después de su nacimiento para presentarlo al Señor y hacer una ofrenda por él.