---
title: San Francisco de Asís
author: admin

date: 2018-09-18T21:03:55+00:00
abstract: |
  **4 DE OCTUBRE**<br>
  Nació en Asís (Italia), en el año 1182. Después de una juventud disipada en diversiones, se convirtió, renunció a los bienes paternos y se entregó de lleno a Dios. Dio a sus seguidores unas sabias normas, que luego fueron aprobadas por la Santa Sede.
url: /san-francisco-de-asis-2/
tags: [Destacada]

---
**4 DE OCTUBRE**  
Nació en Asís (Italia), en el año 1182. Después de una juventud disipada en diversiones, se convirtió, renunció a los bienes paternos y se entregó de lleno a Dios. Dio a sus seguidores unas sabias normas, que luego fueron aprobadas por la Santa Sede.  
<img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2013/03/img-san-frascisco-asis-368x205.jpg" alt="img-san-frascisco-asis" class="alignright size-medium wp-image-4720" />