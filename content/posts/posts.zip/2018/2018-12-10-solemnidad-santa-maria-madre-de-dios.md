---
title: SOLEMNIDAD SANTA MARÍA MADRE DE DIOS
author: admin

date: 2018-12-10T14:38:06+00:00
url: /solemnidad-santa-maria-madre-de-dios/
thumbnail: /images/img-solemnidad-maria-madre-1.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-solemnidad-maria-madre.jpg" alt="img-solemnidad-maria-madre" class="alignright size-medium wp-image-4819" />**1 de Enero**  
“El hombre ya no está solo; ya no es huérfano, sino que es hijo para siempre. El año se abre con esta novedad. Y nosotros la proclamamos diciendo: ¡Madre de Dios! Es el gozo de saber que nuestra soledad ha sido derrotada.  
Es la belleza de sabernos hijos amados, de conocer que no nos podrán quitar jamás esta infancia nuestra. Es reconocerse en el Dios frágil y niño que está en los brazos de su Madre y ver que para el Señor la humanidad es preciosa y sagrada.  
Por lo tanto, servir a la vida humana es servir a Dios, y que toda vida, desde la que está en el seno de la madre hasta que es anciano, la que sufre y está enferma, también la que es incómoda y hasta repugnante, debe ser acogida, amada y ayudada.  
(Papa Francisco, Homilía en la Solemnidad de Santa María, Madre de Dios, 2018).  
La Solemnidad de Santa María, Madre de Dios, es una fiesta de la Iglesia en honor a la Santísima Virgen Maríaen su rol de la maternidad de Jesucristo el Señor, Hijo de Dios. María juega un rol muy importante en el Misterio de la Encarnación, convirtiéndose en madre de la segunda persona de la SantísimaTrinidad.