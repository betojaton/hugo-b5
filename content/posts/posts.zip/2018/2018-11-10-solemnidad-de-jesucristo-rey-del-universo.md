---
title: Solemnidad de Jesucristo Rey del Universo
author: admin

date: 2018-11-10T13:41:05+00:00
url: /solemnidad-de-jesucristo-rey-del-universo/
thumbnail: /images/img-cristo-rey-universo-3.jpg
tags: [Destacada]

---
<img decoding="async" class="size-medium wp-image-4791 alignright" src="https://mariadelasantafe.org.ar/images/img-cristo-rey-universo-2.jpg" alt="img-cristo-rey-universo" />La celebración de la Solemnidad de Nuestro Señor Jesucristo, Rey del Universo, cierra el Año Litúrgico en el que se ha meditado sobre todo el misterio de su vida, su predicación y el anuncio del Reino de Dios.

Durante el anuncio del Reino, Jesús nos muestra lo que éste significa para nosotros como Salvación, Revelación y Reconciliación ante la mentira mortal del pecado que existe en el mundo. Jesús responde a Pilatos cuando le pregunta si en verdad Él es el Rey de los judíos: &#8220;Mi Reino no es de este mundo. Si mi Reino fuese de este mundo mi gente habría combatido para que no fuese entregado a los judíos; pero mi Reino no es de aquí&#8221; (Jn 18, 36). Jesús no es el Rey de un mundo de miedo, mentira y pecado, Él es el Rey del Reino de Dios que trae y al que nos conduce.

Cristo Rey anuncia la Verdad y esa Verdad es la luz que ilumina el camino amoroso que Él ha trazado, con su Vía Crucis, hacia el Reino de Dios. &#8220;Si, como dices, soy Rey. Yo para esto he nacido y para esto he venido al mundo: para dar testimonio de la verdad. Todo el que es de la verdad escucha mi voz.&#8221;(Jn 18, 37) Jesús nos revela su misión reconciliadora de anunciar la verdad ante el engaño del pecado. Así como el demonio tentó a Eva con engaños y mentiras para que fuera desterrada, ahora Dios mismo se hace hombre y devuelve a la humanidad la posibilidad de regresar al Reino, cuando cual cordero se sacrifica amorosamente en la cruz.

Esta fiesta celebra a Cristo como el Rey bondadoso y sencillo que como pastor guía a su Iglesia peregrina hacia el Reino Celestial y le otorga la comunión con este Reino para que pueda transformar el mundo en el cual peregrina.

La posibilidad de alcanzar el Reino de Dios fue establecida por Jesucristo, al dejarnos el Espíritu tu Santo que nos concede las gracias necesarias para lograr la Santidad y transformar el mundo en el amor. Ésa es la misión que le dejo Jesús a la Iglesia al establecer su Reino.  
Se puede pensar que solo se llegará al Reino de Dios luego de pasar por la muerte pero la verdad es que el Reino ya está instalado en el mundo a través de la Iglesia que peregrina al Reino Celestial. Justamente con la obra de Jesucristo, las dos realidades de la Iglesia -peregrina y celestial- se enlazan de manera definitiva, y así se fortalece el peregrinaje con la oración de los peregrinos y la gracia que reciben por medio de los sacramentos. &#8220;Todo el que es de la verdad escucha mi voz.&#8221;(Jn 18, 37) Todos los que se encuentran con el Señor, escuchan su llamado a la Santidad y emprenden ese camino se convierten en miembros del Reino de Dios.

&#8220;Por ellos ruego; no ruego por el mundo, sino por los que tu me has dado, porque son tuyos; y todo lo mío es tuyo y todo lo tuyo es mío; y yo he sido glorificado en ellos. Yo ya no estoy en el mundo, pero ellos si están en el mundo, y yo voy a ti. Padre santo, cuida en tu nombre a los que me has dado, para que sean uno como nosotros&#8230;No te pido que los retires del mundo, sino que los guarde del Maligno. Ellos no son del mundo, como yo no soy del mundo. Santifícalos en la verdad: tu palabra es verdad.&#8221; (Jn 17, 9-11.15-17)

Ésta es la oración que recita Jesús antes de ser entregado y manifiesta su deseo de que el Padre nos guarde y proteja. En esta oración llena de amor hacia nosotros, Jesús pide al Padre para que lleguemos a la vida divina por la cual se ha sacrificado: &#8220;Padre santo, cuida en tu nombre a los que me has dado, para que sean uno como nosotros.&#8221; Y pide que a pesar de estar en el mundo vivamos bajo la luzdelaverdad dela Palabra de Dios.

Así Jesucristo es el Rey y elPastor del Reino de Dios, que sacándonos de las tinieblas, nos guía y cuida en nuestro camino hacia la comunión plena con Dios Amor.