---
title: Restauración Virgen Maria de la Santa Fe
author: admin

date: 2018-07-13T13:07:09+00:00
abstract: '[ngg_images source="galleries" container_ids="28" display_type="photocrati-nextgen_basic_imagebrowser" ajax_pagination="0" order_by="pid" order_direction="DESC" returns="included" maximum_entity_count="500"]'
url: /restauracion-virgen-maria-de-la-santa-fe/

tags: [Notas]

---
<div class='ngg-imagebrowser default-view'
         id='ngg-imagebrowser-65820b5e741a0f494eb91619074996f6-448'
         data-nextgen-gallery-id="65820b5e741a0f494eb91619074996f6">
  <h3>
    restauracion-virgen-25
  </h3>
  
  <div id="ngg-image-0" class="pic" >
    <a href='https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-25.jpg'
           title=' '
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-25.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-25.jpg"
           data-image-id="384"
           data-title="restauracion-virgen-25"
           data-description=" "
           class="ngg-simplelightbox" rel="65820b5e741a0f494eb91619074996f6"> <img title='restauracion-virgen-25'
                 alt='restauracion-virgen-25'
                 src='https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-25.jpg' /> </a>
  </div>
  
  <div class='ngg-imagebrowser-nav'>
    <div class='back'>
      <a class='ngg-browser-prev'
                   id='ngg-prev-357'
                   href='https://mariadelasantafe.org.ar/restauracion-virgen-maria-de-la-santa-fe/nggallery/image/restauracion-virgen-01?type=hugo/'> <i class="fa fa-chevron-left" aria-hidden="true"></i> </a>
    </div>
    
    <div class='next'>
      <a class='ngg-browser-next'
                   id='ngg-next-383'
                   href='https://mariadelasantafe.org.ar/restauracion-virgen-maria-de-la-santa-fe/nggallery/image/restauracion-virgen-24?type=hugo/'> <i class="fa fa-chevron-right" aria-hidden="true"></i> </a>
    </div>
    
    <div class='counter'>
      Image 1 De 28
    </div>
    
    <div class='ngg-imagebrowser-desc'>
      <p>
      
    </div>
  </div>
</div>

<div class="ngg-galleryoverview ngg-slideshow"
	 id="ngg-slideshow-44cbe33e0c8acd4fe26719811f17fef9-2882248180"
     data-gallery-id="44cbe33e0c8acd4fe26719811f17fef9"
     style="max-width: 368px; max-height: 240px;">
  <div id="ngg-image-0" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-25.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-25.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-25.jpg"
           data-image-id="384"
           data-title="restauracion-virgen-25"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='384'
                 title=""
                 alt="restauracion-virgen-25"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-25.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-1" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-24.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-24.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-24.jpg"
           data-image-id="383"
           data-title="restauracion-virgen-24"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='383'
                 title=""
                 alt="restauracion-virgen-24"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-24.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-2" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-23.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-23.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-23.jpg"
           data-image-id="382"
           data-title="restauracion-virgen-23"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='382'
                 title=""
                 alt="restauracion-virgen-23"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-23.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-3" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-22.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-22.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-22.jpg"
           data-image-id="381"
           data-title="restauracion-virgen-22"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='381'
                 title=""
                 alt="restauracion-virgen-22"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-22.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-4" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-21.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-21.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-21.jpg"
           data-image-id="380"
           data-title="restauracion-virgen-21"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='380'
                 title=""
                 alt="restauracion-virgen-21"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-21.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-5" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-20.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-20.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-20.jpg"
           data-image-id="379"
           data-title="restauracion-virgen-20"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='379'
                 title=""
                 alt="restauracion-virgen-20"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-20.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-6" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-19.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-19.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-19.jpg"
           data-image-id="378"
           data-title="restauracion-virgen-19"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='378'
                 title=""
                 alt="restauracion-virgen-19"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-19.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-7" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-18.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-18.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-18.jpg"
           data-image-id="377"
           data-title="restauracion-virgen-18"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='377'
                 title=""
                 alt="restauracion-virgen-18"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-18.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-8" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-17.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-17.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-17.jpg"
           data-image-id="376"
           data-title="restauracion-virgen-17"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='376'
                 title=""
                 alt="restauracion-virgen-17"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-17.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-9" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-16.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-16.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-16.jpg"
           data-image-id="375"
           data-title="restauracion-virgen-16"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='375'
                 title=""
                 alt="restauracion-virgen-16"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-16.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-10" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-15.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-15.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-15.jpg"
           data-image-id="374"
           data-title="restauracion-virgen-15"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='374'
                 title=""
                 alt="restauracion-virgen-15"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-15.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-11" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-14.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-14.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-14.jpg"
           data-image-id="373"
           data-title="restauracion-virgen-14"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='373'
                 title=""
                 alt="restauracion-virgen-14"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-14.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-12" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-13.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-13.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-13.jpg"
           data-image-id="372"
           data-title="restauracion-virgen-13"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='372'
                 title=""
                 alt="restauracion-virgen-13"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-13.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-13" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-12.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-12.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-12.jpg"
           data-image-id="371"
           data-title="restauracion-virgen-12"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='371'
                 title=""
                 alt="restauracion-virgen-12"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-12.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-14" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-11.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-11.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-11.jpg"
           data-image-id="370"
           data-title="restauracion-virgen-11"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='370'
                 title=""
                 alt="restauracion-virgen-11"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-11.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-15" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-10.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-10.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-10.jpg"
           data-image-id="369"
           data-title="restauracion-virgen-10"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='369'
                 title=""
                 alt="restauracion-virgen-10"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-10.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-16" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-09.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-09.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-09.jpg"
           data-image-id="368"
           data-title="restauracion-virgen-09"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='368'
                 title=""
                 alt="restauracion-virgen-09"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-09.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-17" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-08.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-08.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-08.jpg"
           data-image-id="367"
           data-title="restauracion-virgen-08"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='367'
                 title=""
                 alt="restauracion-virgen-08"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-08.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-18" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-07.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-07.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-07.jpg"
           data-image-id="366"
           data-title="restauracion-virgen-07"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='366'
                 title=""
                 alt="restauracion-virgen-07"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-07.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-19" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-06.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-06.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-06.jpg"
           data-image-id="365"
           data-title="restauracion-virgen-06"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='365'
                 title=""
                 alt="restauracion-virgen-06"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-06.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-20" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-05.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-05.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-05.jpg"
           data-image-id="364"
           data-title="restauracion-virgen-05"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='364'
                 title=""
                 alt="restauracion-virgen-05"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-05.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-21" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-04.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-04.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-04.jpg"
           data-image-id="363"
           data-title="restauracion-virgen-04"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='363'
                 title=""
                 alt="restauracion-virgen-04"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-04.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-22" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-03a.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-03a.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-03a.jpg"
           data-image-id="362"
           data-title="restauracion-virgen-03a"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='362'
                 title=""
                 alt="restauracion-virgen-03a"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-03a.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-23" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-03.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-03.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-03.jpg"
           data-image-id="361"
           data-title="restauracion-virgen-03"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='361'
                 title=""
                 alt="restauracion-virgen-03"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-03.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-24" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-02b.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-02b.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-02b.jpg"
           data-image-id="360"
           data-title="restauracion-virgen-02b"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='360'
                 title=""
                 alt="restauracion-virgen-02b"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-02b.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-25" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-02a.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-02a.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-02a.jpg"
           data-image-id="359"
           data-title="restauracion-virgen-02a"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='359'
                 title=""
                 alt="restauracion-virgen-02a"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-02a.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-26" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-02.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-02.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-02.jpg"
           data-image-id="358"
           data-title="restauracion-virgen-02"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='358'
                 title=""
                 alt="restauracion-virgen-02"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-02.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
  
  <div id="ngg-image-27" class="ngg-gallery-slideshow-image" style="height:240px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-01.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-01.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/thumbs/thumbs_restauracion-virgen-01.jpg"
           data-image-id="357"
           data-title="restauracion-virgen-01"
           data-description=""
           class="ngg-simplelightbox" rel="44cbe33e0c8acd4fe26719811f17fef9"> <img data-image-id='357'
                 title=""
                 alt="restauracion-virgen-01"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/restauracion-virgen/restauracion-virgen-01.jpg"
                 style="max-height: 220px;" /> </a>
  </div>
</div>