---
title: Rosario de la Liberacion
author: admin

date: 2018-05-31T09:33:06+00:00
url: /rosario-de-la-liberacion/
thumbnail: /images/img-rosario-liberacion-1.jpg

tags: [Oraciones]

---
<!--a href="https://issuu.com/mariadelastafe/docs/rosario_de_liberaci_n" target="_blank" rel="noopener" class="btn btn-primary btn-block">
<img decoding="async" src="https://mariadelasantafe.org.ar/images/pdf-flat-1.png" alt="icon-pdf" class="alignnone size-thumbnail wp-image-3709" style="width:42px; height:42px;" /> Descarga una version en .pdf para leer o imprimir…</a>

<img decoding="async" class="size-medium wp-image-4522 alignright img-thumbnail" src="https://mariadelasantafe.org.ar/images/img-rosario-liberacion.jpg" alt="img-rosario-liberacion" srcset="https://mariadelasantafe.org.ar/images/img-rosario-liberacion.jpg 219w, https://mariadelasantafe.org.ar/images/img-rosario-liberacion.jpg 78w, https://mariadelasantafe.org.ar/images/img-rosario-liberacion-534x1024.jpg 534w, https://mariadelasantafe.org.ar/images/img-rosario-liberacion.jpg 679w" sizes="(max-width: 219px) 100vw, 219px">



<h2 style="text-align: center;">Padre Nuestro</h2>




<p style="text-align: center;">Padre nuestro,  que estás en el cielo,  santiﬁcado sea tu Nombre;  venga a nosotros tu reino;  hágase tu voluntad en la tierra como en el cielo.
Danos hoy nuestro pan de cada día; perdona nuestras ofensas,  como también nosotros perdonamos a los que nos ofenden;  no nos dejes caer en la tentación, y líbranos del mal.
Amén.



<p style="text-align: center;">**Que Dios me Bendiga
Que Dios me Ilumine
Que Dios me Guíe**






<hr>





<h2 style="text-align: center;">Gloria</h2>




<p style="text-align: center;">Gloria al Padre, y al Hijo, y al Espíritu Santo.
Como era en el principio, ahora y siempre, por los siglos de los siglos.
Amén






<hr>





<h2 style="text-align: center;">La Salve</h2>




<p style="text-align: center;">Dios te salve,  Reina y Madre de misericordia, vida, dulzura y esperanza nuestra.
Dios te salve.
A Tí clamamos los desterrados hijos de Eva, a Tí suspiramos, gimiendo y llorando en este valle de lágrimas.
Ea, pues, Señora Abogada Nuestra,  vuelve a nosotros tus ojos misericordiosos,  y después de este destierro, muéstranos a Jesús, fruto bendito de tu vientre.
Oh, clemente, oh piadosa, oh dulce Virgen María.
Ruega por nosotros, Santa Madre de Dios,  para que seamos dignos de alcanzar las promesas de Nuestro Señor Jesucristo.
Amén.



<hr>





<h2 style="text-align: center;">Ave María</h2>




<p style="text-align: center;">Dios te salve María llena eres de gracia el Señor es contigo;
bendita tú eres entre todas las mujeres,
y bendito es el fruto de tu vientre, Jesús.
Santa María, Madre de Dios,  ruega por nosotros, pecadores,
ahora y en la ahora de nuestra muerte.
Amén.



<hr>





<h2 style="text-align: center;">El Credo</h2>




<p style="text-align: center;">Creo en Dios, Padre Todopoderoso,  Creador del cielo y de la tierra.
Creo en Jesucristo, su único Hijo, Nuestro Señor, que fue concebido por obra y gracia del Espíritu Santo,  nació de Santa María Virgen,  padeció bajo el poder de Poncio Pilato fue cruciﬁcado, muerto y sepultado,  descendió a los inﬁernos,  al tercer día resucitó de entre los muertos, subió a los cielos y está sentado a la derecha de Dios, Padre todopoderoso.
Desde allí ha de venir a juzgar a vivos y muertos.
Creo en el Espíritu Santo,  la santa Iglesia católica,  la comunión de los santos,  el perdón de los pecados,  la resurrección de la carne y la vida eterna.
Amén.



<hr>





<h2 style="text-align: center;">ORACION A SAN MIGUEL ARCANGEL</h2>


**24-04-2009
**Oración a San Miguel Arcángel:


<blockquote> “Decid Hijos Míos ésta Oración en todo momento y en toda necesidad:  San Miguel Arcángel Príncipe de la Milicia Celestial, deﬁéndenos de los ataques, deﬁéndenos de las asechanzas del maligno, cúbrenos con la espada de tu poder, cúbrenos con la espada poderosa, para defendernos y protegernos permanentemente.  San Miguel Arcángel forma una barrera para que el maligno no pueda atravesar y no pueda invadir nuestros corazones, nuestras mentes, nuestro espíritu. San Miguel Arcángel protégenos de los males espirituales, de los males físicos, protégenos, cúbrenos y fortalece nuestra voluntad para no caer en la tentación, danos fortaleza San Miguel Arcángel.
Amén.”</blockquote>





<hr>





<h2 style="text-align: center;">ORACIÓN POR LA PATRIA</h2>




<p style="text-align: center;">Jesucristo, Señor de la historia, te necesitamos. Nos sentimos heridos y agobiados. Precisamos tu alivio y fortaleza.
Queremos ser nación,  una nación cuya identidad sea la pasión por la verdad  y el compromiso por el bien común.  Danos la valentía de la libertad  de los hijos de Dios  para amar a todos sin excluir a nadie, privilegiando a los pobres y perdonando a los que nos ofenden, aborreciendo el odio y construyendo la paz. Concédenos la sabiduría del diálogo  y la alegría de la esperanza que no defrauda. Tú nos convocas. Aquí estamos, Señor, cercanos a María, que desde Luján nos dice: ¡Argentina! ¡Canta y camina!
Jesucristo, Señor de la historia, te necesitamos.
Amén.!-->