---
title: Jueves Santo
author: admin

date: 2018-03-10T15:41:57+00:00
url: /jueves-santo/
thumbnail: /images/img-jueves-santo-2.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-jueves-santo-3.jpg" alt="img-jueves-santo" class="aligncenter size-medium wp-image-4369" />

La liturgia del Jueves Santo es una invitación a profundizar concretamente en el misterio de la Pasión de Cristo, ya que quien desee seguirle tiene que sentarse a su mesa y, con máximo recogimiento, ser espectador de todo lo que aconteció &#8220;en la noche en que iban a entregarlo&#8221;. Y por otro lado, el mismo Señor Jesús nos da un testimonio idóneo de la vocación al servicio del mundo y de la Iglesia que tenemos todos los fieles cuando decide lavarle los pies a  
sus discípulos.

> La Santa Misa es entonces la celebración de la Cena del Señor en la cuál Jesús, un día como hoy, la víspera de su pasión, &#8220;mientras cenaba con sus discípulos tomó pan&#8230;&#8221; (Mt 28, 26).

> Él quiso que, como en su última Cena, sus discípulos nos reuniéramos y nos acordáramos de Él bendiciendo el pan y el vino: &#8220;Hagan esto en memoria mía&#8221;  
> (Lc 22,19).