---
title: Presentación en el Templo de la niña Santa María
author: admin

date: 2018-11-10T13:45:32+00:00
url: /presentacion-en-el-templo-de-la-nina-santa-maria/
thumbnail: /images/img-presentacion-virgen-maria-3.jpg
tags: [Destacada]

---
<img decoding="async" class="size-medium wp-image-4790 alignright" src="https://mariadelasantafe.org.ar/images/img-presentacion-virgen-maria-2.jpg" alt="img-presentacion-virgen-maria" />Hoy, celebramos junto con toda la Iglesia, la Presentación en el Templo de la niña Santa María.

Es en una antigua y piadosa tradición que encontramos los orígenes de esta fiesta mariana que surge en el escrito apócrifo lla­mado &#8221;Protoevangelio de Santiago&#8221;. Este relato cuenta que cuando la Virgen María era muy niña sus padres San Joaquín y Santa Ana la llevaron al templo de Jerusa­lén y allá la dejaron por un tiempo, junto con otro grupo de niñas, para ser instruida muy cuidadosamente respecto a la religión y a todos los deberes para con Dios.

Históricamente, el inicio de esta celebra­ción fue la dedicación de la Iglesia de San­ta María la Nueva en Jerusalén en el año  
543. Estas fiestas se vienen conmemoran­do en Oriente desde el siglo VI, inclusive el emperador Miguel Comeno cuenta sobre esto en una Constitución de 1166.

Más adelante, en 1372, el canciller en la corte del Rey de Chipre, habiendo sido enviado a Aviñón, en calidad de embaja­dor ante el Papa Gregorio XI, le contó la magnificencia con que en Grecia celebra­ban esta fiesta el 21 de noviembre. El Papa entonces la introdujo en Aviñón, y Sixto V la impuso a toda la Iglesia.