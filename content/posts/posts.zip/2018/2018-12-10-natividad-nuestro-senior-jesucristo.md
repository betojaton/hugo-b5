---
title: NATIVIDAD DE NUESTRO SEÑOR JESUCRISTO
author: admin

date: 2018-12-10T14:19:26+00:00
url: /natividad-nuestro-senior-jesucristo/
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2000/12/img-natividad-senior-jesucristo-368x220.jpg" alt="img-natividad-senior-jesucristo" class="alignright size-medium wp-image-4817" />**25 de Diciembre**  
Venerables Hermanos, amados hijos:

> Natividad del Señor, fiesta de paz. Pueden rebuscarse otras resonancias del gran misterio para expresar la plenitud de la gracia, que en estos días alegra a todo el que cree en Jesucristo: ya no se sale de aquel tema.  
> Este es el anuncio de Belén: gloria de Dios, paz verdadera e invitación a que la voluntad humana corresponda a don tan grande.