---
title: La Iglesia Católica conmemora el Martirio de San Juan Bautista
author: admin

date: 2018-08-08T19:39:10+00:00
url: /la-iglesia-catolica-conmemora-el-martirio-de-san-juan-bautista/
thumbnail: /images/img-san-juan-bautista-1.jpg

tags: [Destacada]

---
## 29 de Agosto

<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-san-juan-bautista.jpg" alt="img-san-juan-bautista" class="alignright size-full wp-image-4696" />  
&#8230;quien murió decapitado por anunciar y denunciar la verdad. Juan Bautista es el único santo en la Iglesia a quien se le celebra su nacimiento (24 de junio) y su muerte por medio del martirio.