---
title: NUESTRA SEÑORA DE GUADALUPE
author: admin

date: 2018-12-10T14:17:35+00:00
url: /nuestra-senora-de-guadalupe/
thumbnail: /images/img-sr-guadalupe-1.jpg
tags: [Destacada]

---
12 de Diciembre

## NUESTRA SEÑORA DE GUADALUPE

<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-sr-guadalupe.jpg" alt="img-sr-guadalupe" class="alignright size-medium wp-image-4820" />