---
title: Nuevo Video
author: admin

date: 2018-11-21T08:48:39+00:00
abstract: |
  <h2>¡La Navidad esta Cercana!</h2>
  <iframe width="100%" height="315" src="https://www.youtube.com/embed/ILSDC-8lNiE" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
url: /video-la-navidad-esta-cercana/
tags: [Notas]

---
