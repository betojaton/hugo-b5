---
title: Nuestra Señora de los Dolores
author: admin

date: 2018-09-18T20:52:00+00:00
abstract: |
  **15 de Septiembre**<br>
  Por dos veces durante el año, la Iglesia conmemora los dolores de la Santísima Virgen que es el de la Semana de la Pasión y también hoy, 15 de setiembre.
url: /nuestra-senora-dolores/
tags: [Destacada]

---
**15 de Septiembre**  
<img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2013/03/img-sra-dolores-368x204.jpg" alt="img-sra-dolores" class="alignright size-medium wp-image-4722" /> Por dos veces durante el año, la Iglesia conmemora los dolores de la Santísima Virgen que es el de la Semana de la Pasión y también hoy, 15 de setiembre. La primera de estas conmemoraciones es la más antigua, puesto que se instituyó en Colonia y en otras partes de Europa en el siglo XV y cuando la festividad se extendió por toda la Iglesia, en 1727, con el nombre de los Siete Dolores, se mantuvo la referencia original de la Misa y del oficio de la Crucifixión del Señor.

En la Edad Media había una devoción popular por los cinco gozos de la Virgen Madre, y por la misma época se complementó esa devoción con otra fiesta en honor a sus cinco dolores durante la Pasión. Más adelante, las penas de la Virgen María aumentaron a siete, y no sólo comprendieron su marcha hacia el Calvario, sino su vida entera. A los frailes servitas, que desde su fundación tuvieron particular devoción por los sufrimientos de María, se les autorizó para que ce- lebraran una festividad en memoria de los Siete Dolores, el tercer domingo de setiembre de todos los años.