---
title: Solemnidad de la Asunción de la Virgen María
author: admin

date: 2018-08-08T19:24:06+00:00
url: /solemnidad-de-la-asuncion-de-la-virgen-maria-2-2/
thumbnail: /images/img-asuncion-virgen-maria-2.jpg

tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-asuncion-virgen-maria-1.jpg" alt="img-asuncion-virgen-maria" class="alignright size-full wp-image-4692" />La fiesta de la Asunción de la Santísima Virgen María, se celebra en toda la Iglesia el 15 de agosto. Esta fiesta tiene un doble objetivo: La feliz partida de Ma- ría de esta vida y la asunción de su cuerpo al cielo.

“En esta solemnidad de la Asunción contemplamos a María: ella nos abre a la esperanza, a un futuro lleno de alegría y nos enseña el camino para alcanzarlo: acoger en la fe a su Hijo; no perder nunca la amistad con él, sino dejarnos iluminar y guiar por su Pa- labra; seguirlo cada día, incluso en los momentos en que sentimos que nuestras cruces resultan pesadas. María, el arca de la alianza que está en el santuario del cielo, nos indica con claridad luminosa que estamos en camino hacia nuestra verdadera Casa, la comunión de alegría y de paz con Dios”. Homilía de Benedicto XVI (2010)

El dogma de la Asunción se refiere a que la Madre de Dios, luego de su vida terrena fue elevada en cuerpo y alma a la gloria celestial.

El misterio de la Asunción de la Santísima Virgen María al Cielo nos invita a hacer una pausa en la agitada vida que llevamos para reflexionar sobre el sentido de nuestra vida aquí en la tierra, sobre nuestro fin último: la Vida Eterna, junto con la SantísimaTrinidad, la Santísima Virgen María y los Angeles y Santos del Cielo. El saber que María ya está en el Cielo gloriosa en cuerpo y alma, como se nos ha prometido a aquéllos que hagamos la Voluntad de Dios, nos renueva la esperanza en nuestra futura inmortalidad y felicidad perfecta para siempre.