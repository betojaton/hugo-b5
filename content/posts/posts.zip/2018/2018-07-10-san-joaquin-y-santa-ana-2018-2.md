---
title: San Joaquín y Santa Ana
author: admin

date: 2018-07-10T22:01:44+00:00
url: /san-joaquin-y-santa-ana-2018-2/
thumbnail: /images/img-san-joaquin-santana-1.jpg

tags: [Destacada]

---
## 26 de Julio

<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-san-joaquin-santana.jpg" alt="img-san-joaquin-santana" class="alignnone size-full wp-image-4601" /> El protoevangelio de Santiago cuenta que los vecinos de Joaquín se burlaban de él porque no tenía hijos. Entonces, el santo se retiró cuarenta días al desierto a orar y ayunar, en tanto que Ana (cuyo nombre significa Gracia) &#8220;se quejaba en dos quejas y se lamentaba en dos lamentaciones&#8221;. Un ángel se le apareció y le dijo: &#8220;Ana, el Señor ha escuchado tu oración: concebirás y darás a luz. Del fruto de tu vientre se hablará en todo el mundo&#8221;. 

A su debido tiempo nació María, quien sería la Madre de Dios. Esta narración se parece mucho a la de la concepción y el nacimiento de Samuel, cuya madre se llamaba también Ana (I Reyes, I). Los primeros Padres de la Iglesia oriental veían en ello un paralelismo. En realidad, se puede hablar de paralelismo entre la narración de la concepción de Samuel y la de Juan Bautista, pero en el caso presente la semejanza es tal, que se trata claramente de una imitación.