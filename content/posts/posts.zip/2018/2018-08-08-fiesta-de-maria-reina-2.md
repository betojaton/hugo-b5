---
title: Fiesta de María Reina
author: admin

date: 2018-08-08T19:30:07+00:00
url: /fiesta-de-maria-reina-2/
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2000/12/img-fiesta-maria-reina.jpg" alt="img-fiesta-maria-reina" class="alignright size-full wp-image-4693" />&#8220;La Virgen Inmaculada &#8230; asunta en cuerpo y alma a la gloria celestial fue ensalzada por el Señor como Reina universal, con el fin de que se asemejase de for- ma más plena a su Hijo, Señor de señores y vencedor del pecado y de la muerte&#8221;.

En 1954 el Papa Pío XII, instituyó la fiesta Litúrgica del Reinado de María al coronar a la Virgen en Santa María la Mayor, Roma. En esta ocasión el Papa también promulgó el documento principal del Magisterio acerca de la dignidad y realeza de Maria, la Encíclica Ad coeli Reginam (Oct 11, 1954).