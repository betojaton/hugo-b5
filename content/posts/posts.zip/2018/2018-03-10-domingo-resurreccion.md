---
title: Domingo de Resurrección
author: admin

date: 2018-03-10T17:25:58+00:00
url: /domingo-resurreccion/
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2018/03/domingo-resurreccion-368x200.jpg" alt="domingo-resurreccion" class="alignright size-medium wp-image-4403" />

El Domingo de Resurrección es el día en que incluso la iglesia más pobre se reviste de sus mejores ornamentos, es la cima del año litúrgico. Es el aniversario del triunfo de Cristo. Es la feliz conclusión del drama de la Pasión y la alegría inmensa que sigue al dolor. Y un dolor y gozo que se funden pues se refieren en la historia al acontecimiento más importante de la humanidad: la redención y liberación del pecado de la humanidad por el Hijo de Dios.