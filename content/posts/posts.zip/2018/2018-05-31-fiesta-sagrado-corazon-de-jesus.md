---
title: Fiesta Sagrado Corazón de Jesús
author: admin

date: 2018-05-31T08:59:07+00:00
url: /fiesta-sagrado-corazon-de-jesus/
thumbnail: /images/img-promesas-sagrado-corazon-jesus.jpg

tags: [Destacada]

---
**<img decoding="async" class="alignright size-medium wp-image-4493" src="https://mariadelasantafe.org.ar/images/img-promesas-sagrado-corazon-jesus-1.jpg" alt="img-promesas-sagrado-corazon-jesus" />Viernes 8 de Junio**

  1. A las almas consagradas a mi Corazón, les daré las gracias necesarias para su estado.
  2. Daré la paz a las familias.
  3. Las consolaré en todas sus aflicciones.
  4. Seré su amparo y refugio seguro durante la vida, y principalmente en la hora de la muerte
  5. Derramaré bendiciones abundantes sobre sus empresas
  6. Los pecadores hallarán en mi Corazón la fuente y el océano infinito de la misericordia
  7. Las almas tibias se harán fervorosas
  8. Las almas fervorosas se elevarán rápidamente a gran perfección
  9. Bendeciré las casas en que la imagen de mi Sagrado Corazón esté expuesta y sea honrada.
 10. Daré a los sacerdotes la gracia de mover los corazones empedernidos
 11. Las personas que propaguen esta devoción, tendrán escrito su nombre en mi Corazón y jamás será borrado de él.
 12. A todos los que comulguen nueve primeros viernes de mes continuos, el amor omnipotente de mi Corazón les concederá la gracia de la perseverancia final.