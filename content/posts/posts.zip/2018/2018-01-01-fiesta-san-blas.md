---
title: Fiesta de San Blas
author: admin

date: 2018-01-01T13:43:14+00:00
url: /fiesta-san-blas/
thumbnail: /images/img-san-blas.jpg
tags: [Destacada]

---
## 3 de Febrero &#8211; Fiesta de San Blas, patrono de enfermedades de la garganta y laringólogos

<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-san-blas-1.jpg" alt="img-san-blas" class="alignright size-medium wp-image-4324" />  
San Blas, médico y Obispo de Sebaste, Armenia, era conocido por obtener curaciones milagrosas con su intercesión. Cierto día salvó a un niño que se ahogaba por una espina de pescado que se le había trabado en la garganta. De aquí la costumbre de bendecir las gargantas el día de su fiesta, 3 de febrero.