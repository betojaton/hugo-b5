---
title: San Pedro y San Pablo, Solemnidad
author: admin

date: 2018-05-31T09:19:55+00:00
url: /san-pedro-y-san-pablo-solemnidad/
thumbnail: /images/img-solemnidad-sanpedro-sanpablo.jpg

tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-solemnidad-sanpedro-sanpablo-1.jpg" alt="img-solemnidad-sanpedro-sanpablo" class="alignright size-medium wp-image-4495" />Cada 29 de junio, en la solemnidad de San Pedro y San Pablo, apóstoles, recordamos a estos grandes testigos de Jesucristo y, a la vez, hacemos una solemne confesión de fe en la Iglesia una, santa, católica y apostólica. 

Ante todo es una fiesta de la catolicidad.