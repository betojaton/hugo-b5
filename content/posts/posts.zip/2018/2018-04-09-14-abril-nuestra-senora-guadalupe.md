---
title: 14 de Abril – NUESTRA SEÑORA DE GUADALUPE
author: admin

date: 2018-04-09T16:29:55+00:00
url: /14-abril-nuestra-senora-guadalupe/
thumbnail: /images/basilica-guadalupe-1.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/basilica-guadalupe.jpg" alt="basilica-guadalupe" class="alignright size-full wp-image-4420" />  
La fiesta patronal de la basílica se festeja 15 días después de Pascua.