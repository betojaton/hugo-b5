---
title: 3 de Junio de 2018 – Fiesta del Corpus Christi
author: admin

date: 2018-05-09T20:00:20+00:00
url: /3-junio-2018-fiesta-corpus-christi/
thumbnail: /images/img-solemnidad-corpus.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-solemnidad-corpus-1.jpg" alt="img-solemnidad-corpus" class="alignright size-medium wp-image-4460" />Un milagro eucarístico del siglo XIII fue el origen de la Fiesta del Corpus Christi, que la Iglesia celebra el  
jueves siguiente a la Solemnidad de la Santísima Trinidad; aunque en algunos países las Iglesias locales deciden trasladarla para el domingo por una cuestión pastoral.

En esta solemnidad la Iglesia tributa a la Eucaristía un culto público y solemne de adoración, gratitud y amor, siendo la procesión del Corpus Christi una de las más importantes en toda la Iglesia Universal.