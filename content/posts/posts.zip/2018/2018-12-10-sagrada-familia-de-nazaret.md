---
title: SAGRADA FAMILIA DE NAZARET
author: admin

date: 2018-12-10T14:24:14+00:00
url: /sagrada-familia-de-nazaret/
thumbnail: /images/img-sagrada-flia-nazaret-1.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-sagrada-flia-nazaret.jpg" alt="img-sagrada-flia-nazaret" class="alignright size-medium wp-image-4818" />**30 de Diciembre**  
Hoy se celebra la fiesta de la Sagrada Familia y la Iglesia nos invita a mirar a José, María y al Niño Jesús, quienes desde un principio tuvieron que enfrentar peligros y el exilio a Egipto, pero demostrando que siempre el amor puede más que la muerte. Ellos son reflejo de la Trinidad y modelo de toda familia.  
La fiesta de la Sagrada Familia, que se celebra dentro de la Octava de Navidad, es una celebración que motiva a profundizar en el amor familiar, examinar la propia situación del hogar y buscar soluciones que ayuden al papá, la mamá y los hijos a ser cada vez más como la Familia de Nazaret.  
La vida familiar no puede reducirse a los problemas de pareja, dejando de lado los valores trascendentes, ya que la familia es signo del diálogo Dios – hombre. Padres e hijos deben estar abiertos a la Palabra y a la escucha, sin olvidar la importancia de la oración familiar que une con fuerza a los integrantes de la familia.  
San Juan Pablo II recomendaba mucho el rezo del Santo Rosario dentro de las familias y tenía muy presente aquella frase que dice: “la familia que reza unida, permanece unida&#8221;.