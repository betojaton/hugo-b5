---
title: Fiesta de Nuestra Señora de los Milagros
author: admin

date: 2018-05-09T19:37:10+00:00
url: /fiesta-nuestra-senora-milagros/
thumbnail: /images/img-nuestra-sra-milagro.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-nuestra-sra-milagro-1.jpg" alt="img-nuestra-sra-milagro" class="alignright size-full wp-image-4456" />El **9 de mayo se celebrará la Fiesta de Nuestra Señora de los Milagros Advocación** que se venera en el Santuario de los padres jesuitas, ubicado en San Martín y General López.

Se recuerda el Sudor Milagroso de la Virgen, ocurrido el 9 de mayo de 1636, en el templo que la Compañía de Jesús había levantado en la primitiva Santa Fe, en Cayastá.