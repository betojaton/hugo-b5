---
title: Cuerpo y Sangre de Cristo
author: admin

date: 2017-05-30T19:38:57+00:00
url: /cuerpo-sangre-cristo/
thumbnail: /images/img-solemnidad-corpus-christi.jpg
tags: [Destacada]

---
> Jn 6, 51-58: Mi carne es verdadera comida, y mi sangre es verdadera bebida.

Yo soy el pan vivo bajando del cielo. Quien coma de este pan vivirá siempre. El pan que yo doy para la vida del mundo es mi carne. Los judíos se pusieron a discutir: ¿Cómo puede este darnos de comer (su) carne? Les con-tentó Jesús: Les aseguro que si no comen la carne y beben la sangre del Hijo del Hombre, no tendrán vida en ustedes. Quien como me carne y bebe mi sangre tiene vida eterna y yo lo resucitaré el último día. Mi carne es verdadera comida y mi sangre es verdadera bebida. quien come mi carne y bebe mi sangre habita en mí y yo en él. Como el Padre que me envió vive y yo vivo por el Padre, así quien me come vivirá por mí. Este es el pan bajado del cielo y no es como el que comieron sus padres, y murieron. Quien come este pan vivirá por siempre.