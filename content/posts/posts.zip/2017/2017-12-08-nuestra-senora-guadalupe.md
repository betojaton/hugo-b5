---
title: '12 de Diciembre: Nuestra Señora de Guadalupe'
author: admin

date: 2017-12-08T23:36:50+00:00
url: /nuestra-senora-guadalupe/
thumbnail: /images/img-nuestra-sra-guadalupe-1.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-nuestra-sra-guadalupe.jpg" alt="img-nuestra-sra-guadalupe" class="alignright size-medium wp-image-4301" />&#8220;Un sábado 9 de diciembre, el indio Juan Diego, recién convertido a la fe católica, se dirigió al templo para oír Misa. Al pie de un cerro pequeño llamado Tepeyac vio una nube blanca y resplandeciente y oyó que lo llamaban por su nombre. Vio a una hermosa Señora quien le dijo ser &#8220;la siempre Virgen María Madre de Dios&#8221; y le pidió que fuera donde el Obispo para pedirle que en aquel lugar se le construyera un templo. Juan Diego se dirigió a la casa del obispo Fray Juan de Zumárraga y le contó todo lo que había sucedido. El obispo oyó con admiración el relato del indio y le hizo muchas preguntas, pero al final no le creyó.

De regresó a su pueblo Juan Diego se encontró de nuevo con la Virgen María y le explicó lo ocurrido. La Virgen le pidió que al día siguiente fuera nuevamente a hablar con el obispo y le repitiera el mensaje. Esta vez el obispo, luego de oír a Juan Diego le dijo que debía ir y decirle a la Señora que le diese alguna señal que probara que era la Madre de Dios y que era su voluntad que se le construyera un templo. De regreso, Juan Diego halló a María y le narró los hechos. La Virgen le mandó que volviese al día siguiente al mismo lugar pues allí le daría la señal. Al día siguiente Juan Diego no pudo volver al cerro pues su tío Juan Bernardino estaba muy enfermo. La madrugada del 12 de diciembre Juan Diego marchó a toda prisa para conseguir un sacerdote a su tío pues se estaba muriendo. Al llegar al lugar por donde debía encontrarse con la Señora prefirió tomar otro camino para evitarla. De pronto María salió a su encuentro y le preguntó a dónde iba. El indio avergonzado le explicó lo que ocurría. La Virgen dijo a Juan Diego que no se preocupara, que su tío no moriría y que ya estaba sano.

Entonces el indio le pidió la señal que debía llevar al obispo. María le dijo que subiera a la cumbre del cerro donde halló rosas de Castilla frescas y poniéndose la tilma, cortó cuantas pudo y se las llevó al obispo.

Una vez ante Monseñor Zumarraga Juan Diego desplegó su manta, cayeron al suelo las rosas y en la tilma estaba pintada con lo que hoy se conoce como la imagen de la Virgen de Guadalupe.