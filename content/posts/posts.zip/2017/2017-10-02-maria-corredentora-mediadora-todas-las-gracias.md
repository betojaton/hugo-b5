---
title: María es corredentora, mediadora de todas las gracias
author: admin

date: 2017-10-02T22:34:28+00:00
url: /maria-corredentora-mediadora-todas-las-gracias/
thumbnail: /images/img-maria-medianera.jpg
tags: [Destacada]

---
A María se la llama Medianera o Mediadora desde muy antiguo. Este título se le reconoce en documentos oficiales de la Iglesia y ha sido acogido en la liturgia, introduciéndose en 1921 una fiesta dedicada a María Medianera de todas las gracias.