---
title: Virgen de la Candelaria
author: admin

date: 2017-01-11T12:04:39+00:00
url: /virgen-de-la-candelaria/
thumbnail: /images/img-virgencandelaria-1.jpg
tags: [Destacada]

---
### Fiesta de la presentación del Señor.

#### Purificación de María. Virgen de la Candelaria

<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-virgencandelaria.jpg" alt="Virgen Candelaria" class="alignright size-full wp-image-3936" />  
**Papa Francisco:**  
Hoy celebramos la fiesta de la Presentación de Jesús en el templo. En esta fecha se celebra también la Jornada de la vida consagrada. La Iglesia y el mundo necesitan este testimonio del amor y de la misericordia de Dios. Los consagrados, los religiosas, las religiosas son el testimonio de que Dios es bueno y misericordioso.  
_(02-02-2014)_