---
title: Transfiguración de ­Jesús
author: admin

date: 2017-07-02T00:46:03+00:00
url: /transfiguracion-jesus/
thumbnail: /images/img-transfiguracion-senor.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-transfiguracion-senor-1.jpg" alt="img-transfiguracion-senor" class="alignleft size-full wp-image-4131" />Fiesta, nuestro Señor mostró su gloria a tres de sus apóstoles en el monte Tabor, 6 de agosto Narra el santo Evangelio (Lc. 9, Mc. 6, Mt. 10) que unas semanas antes de su Pasión y Muerte, subió Jesús a un monte a orar, llevando consigo a sus tres discípulos predilectos, Pedro, Santiago y Juan. Y mientras oraba, su cuerpo se transfiguró. Sus vestidos se volvieron más blancos que la nieve,y su rostro más resplandeciente que el sol. Y se aparecieron Moisés y Elías y hablaban con El acerca de lo que le iba a suceder próximamente en Jerusalén.

Pedro, muy emocionado exclamó: -Señor, si te parece, hacemos aquí tres campamentos, uno para Ti, otro para Moisés y otro para Elías.  
Pero en seguida los envolvió una nube y se oyó una voz del cielo que decía: &#8220;Este es mi Hijo muy amado, escuchadlo&#8221;.

El Señor llevó consigo a los tres apóstoles que más le demostraban su amor y su fidelidad. Pedro que era el que más trabajaba por Jesús; Juan, el que tenía el alma más pura y más sin pecado; Santiago, el más atrevido y arriesgado en declararse amigo del Señor, y que sería el primer apóstol en derramar su sangre por nuestra religión. Jesús no invitó a todos los apóstoles, por no llevar a Judas, que no se merecía esta visión. Los que viven en pecado no reciben muchos favores que Dios concede a los que le permanecen fieles.

Se celebra un momento muy especial de la vida de Jesús: cuando mostró su gloria a tres de sus apóstoles. Nos dejó un ejemplo sensible de la gloria que nos espera en el cielo.