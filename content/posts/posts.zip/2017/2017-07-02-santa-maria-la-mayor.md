---
title: Santa María La Mayor
author: admin

date: 2017-07-02T00:43:14+00:00
url: /santa-maria-la-mayor/
thumbnail: /images/img-santamaria-lamayor.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-santamaria-lamayor-1.jpg" alt="img-santamaria-lamayor" class="alignleft size-full wp-image-4130" />Dedicación de la basílica de Santa María, en Roma, construida en el monte Esquilino, que el papa Sixto III ofreció al pueblo de Dios como recuerdo del Concilio de Efeso, en el que la Virgen María fue saludada como Madre de Dios (c. 434).

Es la iglesia más antigua dedicada en Occidente a la Virgen María y uno de los templos más visitados de Roma y de toda la cristiandad.