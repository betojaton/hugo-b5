---
title: Nuevos Audios
author: admin

date: 2017-10-30T12:42:14+00:00
abstract: |
  <h2>Audios del Año 2010</h2>
  <iframe scrolling="no" id="hearthis_at_user_81205-8785265" width="100%" height="350" src="https://hearthis.at/set/81205-8785265/embed/" frameborder="0" allowtransparency></iframe>
  <a href="https://mariadelasantafe.org.ar/audiosyvideos/audios/" class="btn btn-primary">Escucha otros audios...</a>
draft: true
url: /?p=384
tags: [Mensajes 2007]
---
## Audios del Año 2010

  
[Escucha otros audios&#8230;][1]{.btn.btn-primary}

 [1]: https://mariadelasantafe.org.ar/audiosyvideos/audios/