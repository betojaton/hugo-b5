---
title: Nuestra Señora del Pilar, patrona de la hispanidad
author: admin

date: 2017-10-02T22:17:16+00:00
url: /nuestra-senora-del-pilar-patrona-hispanidad/
thumbnail: /images/img-nuestra-senora-pilar.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-nuestra-senora-pilar-1.jpg" alt="nuestra-senora-pilar" class="aligncenter size-full wp-image-4214" />

Cuenta la Tradición que el Apóstol Santiago viajó a España para predicar el Evangelio y que la Virgen María se le apareció en un pilar, mientras ella aún vivía en Tierra Santa. De allí es que surge la advocación de Nuestra Señora del Pilar que se celebra cada 12 de octubre.

Era el año 40 d.c. y San Santiago, en una noche de profunda oración a orillas de río Ebro, vio a la Madre de Jesús, quien le pidió que se le edificase ahí una Iglesia con el altar en derredor al pilar.