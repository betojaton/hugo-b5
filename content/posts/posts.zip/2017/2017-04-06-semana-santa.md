---
title: Semana Santa
author: admin

date: 2017-04-06T13:18:36+00:00
url: /semana-santa/
thumbnail: /images/img-semana-santa.jpg
tags: [Destacada]

---
## ¿Por qué la Semana Santa cambia de fecha cada año?

<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-semana-santa-1.jpg" alt="img-semana-santa" class="alignright size-full wp-image-4025" />  
El Año litúrgico se fija a partir del ciclo lunar, es decir, no se ciñe estrictamente al año calendario  
El Año litúrgico no se ciñe estrictamente al año calendario, sino que varía de acuerdo con el ciclo lunar.  
Cuenta la historia, que la noche en la que el pueblo judío salió de Egipto, había luna llena y eso les permitió prescindir de las lámparas para que no les descubrieran los soldados del faraón.  
Los judíos celebran este acontecimiento cada año en la pascua judía o &#8220;Pesaj&#8221;, que siempre concuerda con una noche de luna llena, en recuerdo de los israelitas que huyeron de Egipto pasando por el Mar Rojo.  
Podemos estar seguros, por lo tanto, de que el primer Jueves Santo de la historia, cuando Jesús celebraba la Pascua judía con su discípulos, era una noche de luna llena.  
Por eso, la Iglesia fija el Jueves Santo en la luna llena que se presenta entre el mes de marzo y abril y tomando esta fecha como centro del Año litúrgico, las demás fechas se mueven en relación a esta y hay algunas fiestas que varían de fecha una o dos semanas.