---
title: San Joaquín y Santa Ana, patronos de los abuelos
author: admin

date: 2017-07-02T00:41:05+00:00
url: /san-joaquin-santa-ana-patronos-abuelos/
thumbnail: /images/img-sanjoaquin-santanana.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-sanjoaquin-santanana-1.jpg" alt="img-sanjoaquin-santanana" class="aligncenter size-full wp-image-4129" />

Cada 26 de julio se celebra en la Iglesia Católica la fiesta de los padres de la Santísima Virgen María y abuelos de Jesús, San Joaquín y Santa Ana.

Ambos santos, llamados patronos de los abuelos, fueron personas de profunda fe y confianza en Dios; y los encargados de educar en el camino de la fe a su hija María, alimentando en ella el amor hacia el Creador y preparándola para su misión.

Benedicto XVI, un día como hoy en 2009, resalto -a través de las figuras de San Joaquín y Santa Ana-, la importancia del rol educativo de los abuelos, que en la familia “son depositarios y con frecuencia testimonio de los valores fundamentales de la vida”.

En el 2013, cuando el Papa Francisco se encontraba en Río de Janeiro (Brasil) por la Jornada Mundial de la Juventud Río 2013, y coincidiendo su estadía con esta fecha, destacó que “los santos Joaquín y Ana forman parte de esa larga cadena que ha transmitido la fe y el amor de Dios, en el calor de la familia, hasta María que acogió en su seno al Hijo de Dios y lo dio al mundo, nos los ha dado a nosotros. ¡Qué precioso es el valor de la familia, como lugar privilegiado para transmitir la fe!”