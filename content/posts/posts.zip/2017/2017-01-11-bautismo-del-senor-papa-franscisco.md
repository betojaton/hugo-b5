---
title: Bautismo del Señor (Papa Franscisco)
author: admin

date: 2017-01-11T12:07:50+00:00
url: /bautismo-del-senor-papa-franscisco/
thumbnail: /images/img-fiestadelsenior-1.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-fiestadelsenior.jpg" alt="Fiesta de Presentacion del Señor" class="alignright size-medium wp-image-3931" />El Bautista ve ante sí a un hombre que hace la fila con los pecadores para hacerse bautizar, incluso sin tener necesidad. Un hombre que Dios mandó al mundo como cordero inmolado.  
En el NuevoTestamento el término “cordero” se le encuentra en más de una ocasión, y siempre en relación a Jesús. Esta imagen del cordero podría asombrar. En efecto, un animal que no se caracteriza ciertamente por su fuerza y robustez se carga en sus propios hombros un peso tan inaguantable. La masa enorme del mal es quitada y llevada por una criatura débil y frágil, símbolo de obediencia, docilidad y amor indefenso, que llega hasta el sacrificio de sí mismo. El cordero no muestra las garras o los dientes ante cualquier ataque, sino que soporta y es dócil. Y así es  
Jesús. Así es Jesús, como un cordero.  
_(19-01-2014)_