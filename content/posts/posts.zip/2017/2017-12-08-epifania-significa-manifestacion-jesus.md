---
title: Epifanía significa “manifestación”. Jesús se da a conocer.
author: admin

date: 2017-12-08T23:39:46+00:00
url: /epifania-significa-manifestacion-jesus/
thumbnail: /images/img-epifania-senor.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-epifania-senor-1.jpg" alt="img-epifania-senor" class="alignright size-medium wp-image-4289" />Aunque Jesús se dio a conocer en diferentes momentos a diferentes personas, la Iglesia celebra como epifanías tres eventos:  
Su Epifanía ante los Reyes Magos (Mt 2, 1-12)  
Su Epifanía a San Juan Bautista en el Jordán  
Su Epifanía a sus discípulos y comienzo de Su vida pública con el milagro en Caná.  
La Epifanía que más celebramos en la Navidad es la primera.

La Epifanía es una de las fiestas litúrgicas más antiguas, más aún que la misma Navidad. Comenzó a celebrarse en Oriente en el siglo III y en Occidente se la adoptó en el curso del IV. Epifanía, voz griega que a veces se ha usado como nombre de persona, significa &#8220;manifestación&#8221;, pues el Señor se reveló a los paganos en la persona de los magos.