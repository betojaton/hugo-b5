---
title: '8 de diciembre: ¡Feliz Solemnidad de la Inmaculada Concepción!'
author: admin

date: 2017-12-08T23:29:10+00:00
url: /feliz-solemnidad-inmaculada-concepcion/
thumbnail: /images/img-inmaculada-concepcion.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-inmaculada-concepcion-1.jpg" alt="img-inmaculada-concepcion" class="alignright size-medium wp-image-4291" />Cada 8 de diciembre la Iglesia celebra la Inmaculada Concepción de la Santísima Virgen María. El dogma de fe según el cual la Madre de Jesús fue preservada del pecado desde el momento de su concepción. Es decir, desde el instante en que comenzó su vida humana.

A mediados del siglo XIX, el Papa Pío IX, después de recibir numerosos pedidos de obispos y fieles de todo el mundo, ante más de 200 cardenales, obispos, embajadores y miles de fieles católicos, declaró con su bula “Ineffabilis Deus” 

> “Que la doctrina que sostiene que la Beatísima Virgen María fue preservada inmune de toda mancha de la culpa original en el primer instante de su concepción por singular gracia y privilegio de Dios omnipotente, en atención a los méritos de Cristo Jesús, Salvador del género humano, está revelada por Dios y debe ser por tanto firme y constantemente creída por todos los fieles&#8230;