---
title: Fieles difuntos
author: admin

date: 2017-10-02T22:31:12+00:00
url: /fieles-difuntos/
thumbnail: /images/img-fieles-difuntos.jpg
tags: [Destacada]

---
### Memoria litúrgica, 2 de noviembre

<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-fieles-difuntos-1.jpg" alt="fieles-difuntos" class="alignleft size-full wp-image-4211" /> La tradición de rezar por los muertos se remonta a los primeros tiempos del cristianismo, en donde ya se honraba su recuerdo y se ofrecían oraciones y sacrificios por ellos.  
Cuando una persona muere ya no es capaz de hacer nada para ganar el cielo; sin embargo, los vivos sí podemos ofrecer nuestras obras para que el difunto alcance la salvación.  
Con las buenas obras y la oración se puede ayudar a los seres queridos a conseguir el perdón y la purificación de sus pecados para poder participar de la gloria de Dios.  
A estas oraciones se les llama sufragios. El mejor sufragio es ofrecer la Santa Misa por los difuntos.