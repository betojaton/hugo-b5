---
title: Fiesta de la Cátedra de San Pedro.
author: admin

date: 2017-02-06T16:50:49+00:00
url: /fiesta-de-la-catedra-de-san-pedro/
thumbnail: /images/bn-fiesta-de-la-catedra-de-sanpedro-1.jpg
tags: [Destacada]

---
### 22 de Febrero: La Iglesia celebra la Fiesta de la Cátedra de San Pedro. 

<img decoding="async" src="https://mariadelasantafe.org.ar/images/bn-fiesta-de-la-catedra-de-sanpedro.jpg" alt="bn-fiesta-de-la-catedra-de-sanpedro" class="alignnone size-full wp-image-3949" />  
Cada 22 de febrero, la Iglesia celebra la Fiesta de la Cátedra de San Pedro, una ocasión importante que se remonta al siglo IV y que rinde homenaje al primado y autoridad del Apóstol Pedro, el primer Papa de la Iglesia.