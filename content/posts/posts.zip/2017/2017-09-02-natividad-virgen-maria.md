---
title: Natividad de la VIRGEN MARÍA
author: admin

date: 2017-09-02T14:29:51+00:00
url: /natividad-virgen-maria/
thumbnail: /images/img-fiesta-natividad.jpg
tags: [Destacada]

---
## 8 de Septiembre

<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-fiesta-natividad-1.jpg" alt="img-fiesta-natividad" class="alignright size-medium wp-image-4180" /> La Iglesia recuerda el día del nacimiento de la Virgen María cada 8 de setiembre. El Evangelio no nos da datos del nacimiento de María, pero hay varias tradiciones. Algunas, considerando a María descendiente de David, señalan su nacimiento en Belén. Otra corriente griega y armenia, señala Nazareth como cuna de María.  
La celebración de la fiesta de la Natividad de la Santísima Virgen María, es conocida en Oriente desde el siglo VI. Fue fijada el 8 de septiembre, día con el que se abre el año litúrgico bizantino, el cual se cierra con la Dormición, en agosto. En Occidente fue introducida hacia el siglo VII y era celebrada con una procesión-letanía, que terminaba en la Basílica de Santa María la Mayor.

<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-exaltacion-cruz-1.jpg" alt="img-exaltacion-cruz" class="alignright size-full wp-image-4178" /> La Iglesia en este día celebra la veneración a las reliquias de la cruz de Cristo en Jerusalén, tras ser recuperada de manos de los persas por el emperador Heráclito. Según manifiesta la historia, al recuperar el precioso madero, el emperador quiso cargar una cruz, como había hecho Cristo a través de la ciudad, pero tan pronto puso el madero al hombro e intentó entrar a un recinto sagrado, no pudo hacerlo y quedó paralizado. El patriarca Zacarías que iba a su lado le indicó que todo aquel esplendor imperial iba en desacuerdo con el aspecto humilde y doloroso de Cristo cuando iba cargando la cruz por las calles de Jerusalén. Entonces el emperador se despojó de su atuendo imperial, y con simples vestiduras, avanzó sin dificultad seguido por todo el pueblo hasta dejar la cruz en el sitio donde antes era venerada. Los fragmentos de la santa Cruz se encontraban en el cofre de plata dentro del cual se los habían llevado los persas, y cuando el patriarca y los clérigos abrieron el cofre, todos los fieles veneraron las reliquias con mucho fervor, incluso, su produjeron muchos milagros.