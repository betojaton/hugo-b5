---
title: Solemnidad de la Anunciación
author: admin

date: 2017-02-28T21:05:06+00:00
url: /solemnidad-de-la-anunciacion/
thumbnail: /images/solemnidad-asuncion.jpg
tags: [Destacada]

---
## 25 de Marzo

Esta gran fiesta tomó su nombre de la buena nueva anunciada por el Arcángel Gabriel a la Santísima Virgen María, referente a la Encarnación del Hijo de Dios. Era el propósito divino dar al mundo un Salvador, al pecador una víctima de propiciación, al virtuoso un modelo, a esta doncella –que debía permanecer virgen- un Hijo y al Hijo de Dios una nueva naturaleza humana capaz de sufrir el dolor y la muerte, afín de que El pudiera satisfacer la justicia de Dios por nuestras transgresiones.  
El mundo no iba a tener un Salvador hasta que Ella hubiese dado su consentimiento a la propuesta del ángel. Lo dio y he aquí el poder y la eficacia de su Fíat. En ese momento, el misterio de amor y misericordia prometido al género humano miles de años atrás, predicho por tantos profetas, deseado por tantos santos, se realizó sobre la tierra. En ese instante el alma de Jesucristo producida de la nada empezó a gozar de Dios y a conocer todas las cosas, pasadas, presentes y futuras; en ese momento Dios comenzó a tener un adorador infinito y el mundo un mediador omnipotente y, para la realización de este gran misterio, solamente María es acogida para cooperar con su libre consentimiento.