---
title: Cristo Rey del Universo
author: admin

date: 2017-11-04T15:15:25+00:00
url: /cristo-rey-universo/
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2017/11/img-cristo-rey-universo.jpg" alt="cristo-rey-universo" class="aligncenter size-full wp-image-4258" />

“Yo soy Rey. Para esto nací, para esto vine al mundo, para ser testigo de la Verdad&#8221; (Jn 18, 36-37). Con la Solemnidad de Cristo Rey, la Iglesia Católica concluye el Año Litúrgico recordando a los fieles y al mundo que nadie y ninguna ley está por encima de Dios.

La Solemnidad fue instituida por el Papa Pío XI en 1925 y celebra a Cristo como el Rey bondadoso y sencillo que como pastor guía a su Iglesia peregrina hacia el Reino Celestial y le otorga la comunión con este Reino para que pueda transformar el mundo en el cual peregrina.

La posibilidad de alcanzar el Reino de Dios fue establecida por Jesucristo, al dejarnos el Espíritu Santo que nos concede las gracias necesarias para lograr la Santidad y transformar el mundo en el amor. Ésa es la misión que le dejó Jesús a la Iglesia al establecer su Reino.