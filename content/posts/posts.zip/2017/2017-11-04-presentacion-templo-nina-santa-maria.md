---
title: Presentación en el Templo de la niña Santa María.
author: admin

date: 2017-11-04T15:04:51+00:00
url: /presentacion-templo-nina-santa-maria/
thumbnail: /images/img-presentacion-virgen-maria-1.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-presentacion-virgen-maria.jpg" alt="mg-presentacion-virgen-maria" class="aligncenter size-full wp-image-4250" />  
Es en una antigua y piadosa tradición que encontramos los orígenes de esta fiesta mariana que surge en el escrito apócrifo llamado &#8220;Protoevangelio de Santiago&#8221;. Este relato cuenta que cuando la Virgen María era muy niña sus padres San Joaquín y Santa Ana la llevaron al templo de Jerusalén y allá la dejaron por un tiempo, junto con otro grupo de niñas, para ser instruida muy cuidadosamente respecto a la religión y a todos los deberes para con Dios.

### Oración por la Presentación de la Virgen María

> Santa Madre María, tú que desde temprana edad te consagraste al Altísimo, aceptando desde una libertad poseída el servirle plenamente como templo inmaculado, tú que confiando en tus santos padres, San Joaquín y Santa Ana, respondiste con una obediencia amorosa al llamado de Dios Padre, tú que ya desde ese momento en el que tus padres te presentaron en el Templo percibiste en tu interior el profundo designio de Dios Amor; enséñanos Madre Buena a ser valientes seguidores de tu Hijo, anunciándolo en cada momento de nuestra vida desde una generosa y firme respuesta al Plan de Dios. 

Amén.