---
title: Fátima Indulgencia
author: admin

date: 2017-05-07T21:56:21+00:00
url: /fatima-indulgencia/
thumbnail: /images/img-fatima-indulgencia-1.jpg
tags: [Destacada]

---
Así puedes obtener indulgencia plenaria por 100 años de Virgen de Fátima  
<img decoding="async" class="alignright size-full wp-image-4074" src="https://mariadelasantafe.org.ar/images/img-fatima-indulgencia.jpg" alt="img-fatima-indulgencia" /> 

FÁTIMA, 29 Nov. 16 / 05:01 pm (ACI).- Por los 100 años de las apariciones de la Virgen de Fátima en Portugal, el Papa Francisco ha decidido conceder la indulgencia plenaria durante todo el Año Jubilar que comenzó el 27 de noviembre y terminará el 26 de noviembre de 2017.

Para obtener las indulgencias plenarias los fieles deben cumplir primero con condiciones habituales: confesarse, comulgar y rezar por las intenciones del Santo Padre.

  1. Peregrinar al Santuario
  2. Ante cualquier imagen de la Virgen de Fátima en todo el mundo  
    La segunda forma se aplica para “los fieles piadosos que visitan con devoción una imagen de Nuestra Señora de Fátima expuesta solemnemente a la veneración pública en cualquier templo, oratorio o local adecuado en los días de los aniversarios de las apariciones, el 13 de cada mes desde mayo hasta octubre (de 2017), y participen allí devotamente en alguna celebración u oración en honor de la Virgen María”.
  3. Ancianos y enfermos  
    La tercera forma de obtener una indulgencia se aplica a las personas que por la edad, enfermedad u otra causa grave estén impedidos de movilizarse.

Pueden rezar ante una imagen de la Virgen de Fátima y deben unirse espiritualmente en las celebraciones jubilares en los días de las apariciones, los días 13 de cada mes, entre mayo y octubre de 2017.

> Además tienen que “ofrecer con confianza a Dios misericordioso, a través de María, sus oraciones y dolores o los sacrificios de su propia vida”.