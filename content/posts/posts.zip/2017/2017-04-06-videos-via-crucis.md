---
title: 'Videos del Via Crucis'
author: admin

date: 2017-04-06T11:37:12+00:00
draft: true
url: /2017/videos-via-crucis
thumbnail: /images/hqdefault.jpg
tags: [Destacada]

---
<div class="col-md-4">
  <a href="https://www.youtube.com/UaG1CUUd1y8" target="_blank" rel="noopener"><img decoding="async" src="https://mariadelasantafe.org.ar/images/hqdefault.jpg" alt="Captura Video" class="img-responsive" /></a> 
  
  <h4>
    Via Crucis &#8211; 1ra. Parte
  </h4>
</div>

<div class="col-md-4">
  <a href="https://www.youtube.com/5SCrItB2ssI" target="_blank" rel="noopener"><img decoding="async" src="https://mariadelasantafe.org.ar/images/hqdefault-1.jpg" alt="Captura Video" class="img-responsive" /></a> 
  
  <h4>
    Via Crucis &#8211; 2da. Parte
  </h4>
</div>

<div class="col-md-4">
  <a href="https://www.youtube.com/uoGlhbdSGBU" target="_blank" rel="noopener"><img decoding="async" src="https://mariadelasantafe.org.ar/images/hqdefault-2.jpg" alt="Captura Video" class="img-responsive" /></a> 
  
  <h4>
    Via Crucis &#8211; 3ra. y Ultima Parte
  </h4>
</div>