---
title: Domingo de Resurrección
author: admin

date: 2017-04-06T12:42:14+00:00
url: /domingo-resurreccion-vigilia-pascual/
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2017/04/img-domingo-resurreccion.jpg" alt="img-domingo-resurreccion" class="alignright size-full wp-image-4022 img-responsive" />El Domingo de Resurrección o Vigilia Pascual es el día en que incluso la iglesia más pobre se reviste de sus mejores ornamentos, es la cima del año litúrgico. Es el aniversario del triunfo de Cristo. Es la feliz conclusión del drama de la Pasión y la alegría inmensa que sigue al dolor. Y un dolor y gozo que se funden pues se refieren en la historia al acontecimiento más importante de la humanidad: la redención y liberación del pecado de la humanidad por el Hijo de Dios.