---
title: 1er Domingo de Adviento
author: admin

date: 2017-11-04T15:31:58+00:00
url: /1er-domingo-adviento/
thumbnail: /images/img-corona-adviento-1.jpg
tags: [Destacada]

---
## 3 de diciembre

<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-corona-adviento.jpg" alt="corona-adviento" class="aligncenter size-full wp-image-4261" /> 

El Adviento es el comienzo del Año Litúrgico, empieza el domingo más próximo al 30 de noviembre y termina el 24 de diciembre. Son los cuatro domingos anteriores a la Navidad y forma una unidad con la Navidad y la Epifanía.

El término &#8220;Adviento&#8221; viene del latín adventus, que significa venida, llegada. El color usado en la liturgia de la Iglesia durante este tiempo es el morado. Con el Adviento comienza un nuevo año litúrgico en la Iglesia.

El sentido del Adviento es avivar en los creyentes la espera del Señor.