---
title: San José Esposo de María y Padre Virginal de Jesús
author: admin

date: 2017-02-28T19:55:23+00:00
url: /san-jose-esposo-maria-padre-virginal-jesus/
thumbnail: /images/sanjose.jpg
tags: [Destacada]

---
Modelo de padre y esposo, patrón de la Iglesia universal, de los trabajadores, de infinidad de comunidades religiosas y de la buena muerte.  
A San José Dios le encomendó la inmensa responsabilidad y privilegio de ser esposo de la Virgen María y custodio de la Sagrada Familia. Es por eso el santo que más cerca esta de Jesús y de la Stma. Virgen María.  
Nuestro Señor fue llamado &#8220;hijo de José&#8221; (Juan 1:45; 6:42; Lucas 4:22) el carpintero (Mateo 12:55).