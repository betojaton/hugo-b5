---
title: Dedicación de las basílicas de los santos Pedro y Pablo.
author: admin

date: 2017-11-04T14:57:02+00:00
url: /dedicacion-basilicas-santos-pedro-pablo/
thumbnail: /images/img-dedicacion-basilicas.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-dedicacion-basilicas-1.jpg" alt="" class="aligncenter size-full wp-image-4243" />

Según la tradición, el martirio de San Pedro tuvo lugar en los jardines de Nerón en el Vaticano, donde se construyó el Circo de Calígula y se afirma que fue sepultado cerca de ahí. Algunos autores sostienen que, en el año 258, se trasladaron temporalmente las reliquias de San Pedro y San Pablo a una catacumba poco conocida llamada San Sebastián a fin de evitar una profanación, pero años después, las reliquias fueron trasladadas al lugar en que se hallaban antes. En el año 323, Constantino comenzó a construir la basílica de San Pedro sobre el sepulcro del Apóstol. Permaneció idéntica por dos siglos, y poco a poco los Papas fueron estableciendo junto a ella, al pie de la colina Vaticana, su residencia, tras el destierro de Aviñón. En 1506, el Papa Julio II inauguró la nueva Basílica proyectada por Bramante. La construcción duró 120 años. La nueva basílica de San Pedro, tal como se ve hoy, fue consagrada por Urbano VIII el 18 de noviembre de 1626, y el altar mayor fue construido sobre el sepulcro de Pedro. El martirio de San Pablo tuvo lugar a unos 11 kilómetros del de San Pedro, en Aquae Salviae (actualmente Tre Fontane), en la Vía Ostiense. El cadáver fue sepultado a tres kilómetros de ahí, en la propiedad de una dama llamada Lucina. La gran Iglesia de San Pablo Extramuros fue construida principalmente por el emperador Teodosio I y el Papa San León Magno. En 1823 fue consumida por un incendio. Se reconstruyó, haciendo una imitación de la anterior y fue consagrada por el Papa Pío IX el 10 de diciembre de 1854, pero la fecha de su conmemoración se celebra en este día, como lo hace notar el Martirologio.