---
title: La grandeza de Dios y la dignidad del hombre (Salmo 8)
author: admin

date: 2017-10-02T20:56:00+00:00
url: /la-grandeza-dios-y-dignidad-hombre/
tags: [Notas]

---
  1. Del maestro de coro. Con la cítara de Gat. Salmo de David.
  2. ¡Señor, nuestro Dios, qué admirable es tu Nombre en toda la tierra! Quiero adorar tu majestad sobre el cielo:
  3. con la alabanza de los niños y de los más pequeños, erigiste una fortaleza contra tus adversarios para reprimir al enemigo y al rebelde.
  4. Al ver el cielo, obra de tus manos, la luna y la estrellas que has creado:
  5. ¿qué es el hombre para que pienses en él, el ser humano para que lo cuides?
  6. Lo hiciste poco inferior a los ángeles, lo coronaste de gloria y esplendor;
  7. le diste dominio sobre la obra de tus manos, todo lo pusiste bajo sus pies:
  8. todos los rebaños y ganados, y hasta los animales salvajes;
  9. &nbsp;&nbsp;las aves del cielo, los peces del mar y cuanto surca los senderos de las aguas.
 10. ¡Señor, nuestro Dios, qué admirable es tu Nombre en toda la tierra!