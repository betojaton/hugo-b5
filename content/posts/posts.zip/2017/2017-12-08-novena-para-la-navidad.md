---
title: Novena para la navidad
author: admin

date: 2017-12-08T17:29:22+00:00
abstract: |
  <h3>Mensaje de Maria de la Santa Fe, 12 Diciembre 2000</h3>
  <blockquote>Dulce Salvador, Jesús mío que vienes a nosotros para traernos la paz, el amor y la gracia, que te preparemos el corazón para ser fieles a ti y que te recibamos como tú te lo mereces. Haz de nuestro corazón la cuna para que tú nazcas en ella.
  Amén.
  </blockquote>
  Rezad esta oración con el Santísimo Rosario. Amén. Amén.
url: /novena-para-la-navidad/
thumbnail: /images/nido-jesus.jpg
tags: [Mensajes 2000]

---
### Mensaje de Maria de la Santa Fe, 12 Diciembre 2000

> Dulce Salvador, Jesús mío que vienes a nosotros para traernos la paz, el amor y la gracia, que te preparemos el corazón para ser fieles a ti y que te recibamos como tú te lo mereces. Haz de nuestro corazón la cuna para que tú nazcas en ella.  
> Amén. 

Rezad esta oración con el Santísimo Rosario. Amén. Amén.