---
title: Miércoles, 8 de abril 2015
author: admin

date: 2015-04-08T19:28:30+00:00
url: /miercoles-8-de-abril-2015/
thumbnail: /images/virgen-hblando-gente-1.jpg
tags: [Mensaje tags:
	- Mensajes Presencia]

---
<img decoding="async" class="alignright size-medium wp-image-2950 img-circle" src="https://mariadelasantafe.org.ar/images/virgen-hblando-gente.jpg" alt="virgen-hablando-gente" />

> **Dice la Santísima Virgen:**  
> “Benditos y amados hijos Míos, ésta Madre está presente con vosotros desde que habéis comenzado el Santo Rosario, ésta Madre estaba presente, está presente con vosotros, porque ésta Madre viene a consolaros, viene a sacar la tristeza de los corazones doloridos, viene a ayudaros a vosotros a que sigáis caminando.  
> Estoy aquí hijitos Míos concediendo gracia, sobre gracia a cada uno de vosotros y a todos los hijos del mundo entero. Ésta Madre necesita de todos los hijos, ésta Madre quiere la unidad de todos los hijos, por eso insisto tanto en la oración, insisto y pido a Mis hijos el rezo del Santo Rosario.  
> Hijos seguid Mis palabras maternales y tomaos de Mi Manto Celestial, porque en él, en Mi Manto Celestial encontrareis consuelo y protección. No temáis, María de la Santa Fe está con todos los hijos. La Madre, ésta Madre está con todos los hijos.  
> Meditad. Meditad. Meditad Mis palabras.”

<img decoding="async" class="alignright size-medium wp-image-2949 img-circle" src="https://mariadelasantafe.org.ar/images/jesus-golpeando-puerta.jpg" alt="jesus-golpeando-puerta" /> 

> **Dice la Jesús:**  
> “Hermanos Míos, benditos y amados hermanos Míos, abrid vuestras manos y recibid Mi Sacratísimo Corazón y llevadlo a vuestro corazón. Sentid Mi presencia, Mi amor y Mi Divina Misericordia en vosotros.  
> Os amo a todos y pido una entrega de todos los corazones hacia Mí, pido una entrega de la humanidad hacia Mí. Que Mis hermanos, que Mis hijos vuelvan hacia Mí. Que la humanidad por entero escuche Mi voz, Mis palabras y salga de la oscuridad del pecado.  
> Os invito a todos, os llamo a todos, os pido a todos, debéis vivir en la paz, debéis sentir Mi paz en vosotros y transmitirla al mundo entero, ofrecer la paz y el amor. Extended la mano a los hermanos necesitados a los que sufren, a los que lloran, a los que están angustiados y desconsolados, extended vuestro corazón hacia vuestros hermanos, dad amor, ofreced el amor, trabajad por la paz y por el amor, y vivid en la verdad cada día de vuestras vidas.  
> Sed, iluminad al mundo con vuestra verdad, y no dejéis jamás que los profetas engañadores se apoderen de vuestro corazón.  
> Os amo y derramo Mi Preciosísima Sangre sobre cada uno de vosotros, Mí Preciosísima Sangre que libera, que fortalece, que os hace totalmente libres.  
> Que ya nadie dude de Mi presencia, que ya nadie dude de Mis palabras, palabras de amor, de verdad y de misericordia.  
> Os amo, os amo, os amo. Venid a Mí si estáis agobiados, si estáis cansados, si estáis doloridos, en Mi Sacratísimo Corazón encontrarais la paz, la paz verdadera y eterna.  
> Meditad. Meditad. Meditad Mis palabras. Os bendigo en el nombre del Padre y del Hijo y del Espíritu Santo.”