---
title: 'Secretaría Social  “Angel Gallardo” – Comuna de Monte Vera'
author: admin

date: 2015-07-25T22:35:22+00:00
url: /secretaria-social-angel-gallardo-comuna-de-monte-vera/
thumbnail: /images/id-3128.jpg
tags: [Colaboraciones]

---
25/07/2015, 29/05/2012

<img decoding="async" class="ngg_displayed_gallery mceItem" src="https://mariadelasantafe.org.ar/images/id-3128.jpg" alt="" data-mce-placeholder="1" />