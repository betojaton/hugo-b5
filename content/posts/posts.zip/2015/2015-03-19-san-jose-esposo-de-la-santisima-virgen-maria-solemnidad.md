---
title: 'San José Esposo de la Santísima Virgen María [Solemnidad]'
author: admin

date: 2015-03-19T15:21:33+00:00
url: /san-jose-esposo-de-la-santisima-virgen-maria-solemnidad/
thumbnail: /images/sanjose-ninio.jpg
tags: [Noticias]

---
En el Plan Reconciliador de Dios, San José tuvo un papel esencial: Dios le encomendó la gran responsabilidad y privilegio de ser el padre adoptivo del Niño Jesús y de ser esposo virginal de la Virgen María. San José, el santo custodio de la Sagrada Familia, es el santo que más cerca está de Jesús y de la Santísima de la Virgen María.

Su vida sencilla y humilde se entrecruzaba con su silencio integral, que no significa mero mutismo, sino el mantener todo su ser encauzado a cumplir el Plan de Dios. San José, patrono de la vida interior, nos enseña con su propia vida a orar, a amar, a sufrir, a actuar rectamente y a dar gloria a Dios con toda nuestra vida.