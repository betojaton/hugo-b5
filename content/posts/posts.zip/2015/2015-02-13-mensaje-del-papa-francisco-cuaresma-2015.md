---
title: Mensaje del Papa Francisco – Cuaresma 2015
author: admin

date: 2015-02-13T15:03:09+00:00
url: /2015/mensaje-del-papa-francisco-cuaresma-2015/
thumbnail: /images/papa-francisco02-1.jpg
tags: [Noticias]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/papa-francisco02.jpg" alt="papa-francisco" width="100%" height="428" class="aligncenter size-large wp-image-2770" />

**Queridos hermanos y hermanas:**

La Cuaresma es un tiempo de renovación para la Iglesia, para las comunidades y para cada creyente. Pero, sobre todo, es un”tiempo de gracia” (2 Co 6,2). Dios no nos pide nada que no nos haya dado antes: “Nosotros amemos al Señor porque Él nos amó primero” (1 Jn 4,19). Él no es indiferente a nosotros. Está interesado en cada uno de nosotros, nos conoce por nuestro nombre, nos cuida y nos busca cuando lo dejamos. Cada uno de nosotros le interesa; su amor le impide ser indiferente a lo que nos sucede. Pero ocurre que cuando estamos bien y nos sentimos a gusto, nos olvidamos de los demás (algo que Dios no hace jamás), no nos interesan sus problemas, ni sus sufrimientos, ni las injusticias que padecen… Entonces nuestro corazón cae en la indiferencia: yo esto relativamente bien y a gusto, y me olvido de quienes no están bien. Esa actitud egoísta, de indiferencia, ha alcanzado hoy una dimensión mundial, hasta tal punto que podemos hablar de globalización de la indiferencia. Se trata de un malestar que tenemos que afrontar como cristianos.

Cuando el pueblo de Dios se convierte a su amor, encuentra las respuestas a las preguntas que la historia le plantea continuamente. Uno de los desafíos más urgentes sobre lo que quiere detenerme en este mensaje es el de la globalización de la indiferencia.

La indiferencia hacia el prójimo y hacia Dios es una tentación real también para los cristianos. Por eso, necesitamos oír en cada Cuaresma el grito de los profetas que levantan su voz y nos despiertan.

> “Fortaleced vuestros corazones” (St 5,8): Mensaje del Papa Francisco para la Cuaresma 2015

Dios no es indiferente al mundo, sino que lo ama hasta el punto de dar a su propio Hijo por la salvación de cada hombre. En la encarnación, en la vida terrena, en la muerte y en la resurrección del Hijo de Dios, se abre definitivamente la puerta entre Dios y el hombre, entre el cielo y la tierra. Y la Iglesia es como la mano que tiene abierta esta puerta mediante la proclamación de la Palabra, la celebración de los sacramentos, el testimonio de la fe que actúa por la caridad (cf Ga 5, 6). Sin embargo, el mundo tiende a cerrarse en sí mismo y a cerrar la puerta a través de la cual Dios entra en el mundo y el mundo entra en Él. Así, la mano, que es la Iglesia, nunca debe sorprenderse si es rechazada, aplastada o herida.

El pueblo de Dios, por tanto, tiene necesidad de renovación, para no ser indiferente y para no cerrarse en sí mismo. Querría proponeros tres pasajes para meditar acerca de esta renovación.

1.- “Si un miembro sufre, todos sufren con él” (1 Co 12,26)- La Iglesia.

La caridad de Dios que rompe esa cerrazón mortal en sí mismos nos la ofrece la Iglesia con sus enseñanzas y, sobre todo, con su testimonio. Sin embargo, solo se puede testimoniar lo que antes de ha experimentado. El cristiano es aquel que permite que Dios lo revista de su bondad y de su misericordia, que lo revista de Cristo para llegar a ser como Él, siervo de Dios y de los hombres. Nos lo recuerda la liturgia del Jueves Santo con el rito del lavatorio de los pies. Pedro no quería que Jesús le lavase los pies, pero después entendió que Jesús no quería ser solo un ejemplo de cómo debemos lavarnos los pies unos a otros. Ese servicio solo lo puede hacer quien antes se ha dejado lavar los pies por Cristo. Solo estos tienen parte con Él (Jn 13, 8) y así pueden servir al hombre.

La Cuaresma es un tiempo oportuno para dejarnos servir por Cristo y así llegar a ser como Él. Esto sucede cuando escuchamos la Palabra de Dios y cuando recibimos los sacramentos, en particular, la eucaristía. En ella, nos convertimos en lo que recibimos: el cuerpo de Cristo. En él no hay lugar para la indiferencia, que tan a menudo parece tener tanto poder en nuestros corazones. Quien es de Cristo pertenece a uno solo cuerpo y en Él no se es indiferente hacia los demás. “Si un miembro sufre, todos sufren con él; y si un miembro es honrado, todos se alegran con él” (1 Co 12, 26).

La Iglesia es communio sanctorum porque en ella participan los santos, pero a su vez porque es comunión de cosas santas: el amor de dios que se nos reveló en Cristo y con todos sus dones. Entre estos está también la respuesta de cuantos se dejan tocar por ese amor. En esta comunión de los santos y en esta participación en las cosas santas, nadie posee solo para sí mismo, sino que lo es tiene es para todos. Y puesto que estamos unidos en Dios, podemos hacer algo también por quienes están lejos, por aquellos a quienes no podríamos llegar solo con nuestras fuerzas porque con ellos y por ellos rezamos a Dios para que todos nos abramos a su obra de salvación.

2.- “¿Dónde está tu hermano?” (Gn 4, 9) – Las parroquias y las comunidades

Lo que hemos dicho para la Iglesia universal es necesario traducirlo en la vida de las parroquias y comunidades. En estas realidades eclesiales, ¿se tiene la experiencia de que formamos parte de un solo cuerpo?, ¿un cuerpo que recibe y comparte lo que Dios quiere donar?, ¿un cuerpo que conoce a sus miembros más débiles, más pobres y pequeños, y se hace cargo de ellos?, ¿o nos refugiamos en un amor universal que se compromete con los que están lejos en el mundo, pero olvida al Lázaro sentado delante de su propia puerta cerrada? (cf. Lc 16, 19-31).

Para recibir y hacer fructificar plenamente lo que Dios nos da es preciso superarlos confines de la Iglesia visible en dos direcciones.

En primer lugar, uniéndonos a la Iglesia del cielo en la oración. Cuando la Iglesia terrenal ora, se instaura una comunión de servicio y de bien mutuos que llega ante Dios. Junto con los santos, que encontraron su plenitud en Dios, formamos parte de la comunión en la cual el amor vence a la indiferencia. La Iglesia del cielo no es triunfante porque ha dado la espalda a los sufrimientos del mundo y goza en solitario. Los santos ya contemplan y gozan, gracias que, con la muerte y resurrección de Jesús, vencieron definitivamente la indiferencia, la dureza del corazón y el odio. Hasta que esta victoria del amor no inunde todo el mundo, los santos caminan con nosotros, todavía peregrinos. Santa Teresita de Lisieux, doctora de la Iglesia, escribía convencida de que la alegría en el cielo por la victoria del amor crucificado no es plena mientras haya un solo hombre en la tierra que sufra y gima: “Cuanto mucho con no permanecer inactiva en el cielo, mi deseo es seguir trabajando para la Iglesia y para las almas” (Carta 254, 17 de julio de 1897).

También nosotros participamos de los méritos y de la alegría de los santos, así como ellos participan de nuestra lucha y de nuestro deseo de paz y de reconciliación. Su alegría por la victoria de Cristo resucitado es para nosotros motivo de fuerza para superar tantas formas de indiferencia y de dureza de corazón.

Por otra parte, toda la comunidad cristiana está llamada a cruzar el umbral que la pone en relación con la sociedad que la rodea, con los pobres y los alejados. La Iglesia por naturaleza es misionera, no debe quedarse replegada en sí misma, sino que es enviada a todos los hombres.

Esta misión es el testimonio paciente de Aquel que quiere llevar toda la realidad y cada hombre al Padre. La misión es lo que el amor no puede callar. La Iglesia sigue a Jesucristo por el camino que la lleva a cada hombre, hasta los confines de la tierra (cf. Hch 1,8). Así podemos ver en nuestro prójimo al hermano y a la hermana por quienes Cristo murió y resucitó. Lo que hemos recibido, lo hemos recibido también para ellos. E, igualmente, lo que estos hermanos poseen es un don para la Iglesia y para toda la humanidad.

Queridos hermanos y hermanas, ¡cuánto deseo que los lugares en los que manifiesta la Iglesia, en particular nuestras parroquias y nuestras comunidades, lleguen a ser islas de misericordia en medio de la indiferencia!

3.- “¡Fortaleced vuestros corazones!” (St 5, 8)- La persona creyente.

También como individuos tenemos la tentación de la indiferencia. Estamos saturados de noticias e imágenes tremendas que nos narran el sufrimiento humano y, al mismo tiempo, sentimos toda nuestra incapacidad para intervenir. ¿Qué podemos hacer para no dejarnos absorber por esta espiral de horror y de impotencia?

En primer lugar, podemos orar en la comunión de la Iglesia terrenal y celestial. No olvidemos la fuerza de la oración de tantas personas. La iniciativa 24 horas para el Señor, que deseo que se celebre en toda la Iglesia –también a nivel diocesano-, en los días 13 y 14 de marzo, es expresión de esta necesidad de la oración.

En segundo lugar, podemos ayudar con gestos de caridad, llegando tanto a las personas cercanas como a las lejanas, gracias a los numerosos organismos de caridad de la Iglesia. La Cuaresma es un tiempo propicio para mostrar el interés por el otro, con un signo concreto, aunque sea pequeño, de nuestra participación en la misma humanidad.

Y, en tercer lugar, el sufrimiento del otro constituye una llamada a la conversión, porque la necesidad del hermano me recuerda la fragilidad de mi vida, la dependencia de Dios y de los hermanos. Si pedimos humildemente la gracia de Dios y aceptamos los límites de nuestras posibilidades, confiaremos en las infinitas posibilidades que nos reserva el amor de Dios. Y podremos resistir a la tentación diabólica que nos hace creer que nosotros solos podemos salvar al mundo y a nosotros mismos.

Para superar la indiferencia y nuestras pretensiones de omnipotencia, quiero pedir a todos en este tiempo de Cuaresma sed viva como una formación del corazón, como dijo Benedicto XVI (Deus caritas est, 31). Tener un corazón misericordioso no significa tener un corazón débil.

Quien desea ser misericordioso necesita un corazón fuerte, firme, cerrado al tentador, pero abierto a Dios. Un corazón que se deje impregnar por el Espíritu y guiar por los caminos del amor que nos llevan a los hermanos y a las hermanas. En definitiva, un corazón pobre, que conoce sus propias pobrezas y lo da todo por el otro.

Por esto, queridos hermanos y hermanas, deseo orar con vosotros a Cristo en esta Cuaresma: “Fac cor nostrum secundum Cor tuum”: “Haz nuestro semejante al tuyo” (Súplica de las Letanías al Sagrado Corazón de Jesús). De este modo, tendremos un corazón fuerte y misericordioso, vigilante y generoso, que no se deje encerrar en sí mismo y no caiga en el vértigo de la globalización de la indiferencia.

Con este deseo, aseguro mi oración para que todo creyente y toda comunidad eclesial recorra provechosamente el itinerario cuaresmal, y os pido que recéis por mí. Qué el Señor os bendiga y la Virgen os guarde.

FRANCISCO