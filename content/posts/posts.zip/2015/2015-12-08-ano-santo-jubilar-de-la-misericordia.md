---
title: 'Año Santo Jubilar  de la Misericordia'
author: admin

date: 2015-12-08T15:22:48+00:00
url: /ano-santo-jubilar-de-la-misericordia/
thumbnail: /images/misericordioso-como-padre.jpg
tags: [Destacada]

---
<img decoding="async" class="alignright size-full wp-image-3155" src="https://mariadelasantafe.org.ar/images/misericordioso-como-padre-1.jpg" alt="misericordioso-como-padre" />8 de diciembre 2015,  
solemnidad de la Inmaculada  
Concepción  al 20 de noviembre de 2016,  
(Domingo de Nuestro Señor  
Jesucristo Rey del Universo):  
Año Santo Jubilar de la Misericordia  
de Dios proclamado por el Santo Padre  
Papa Francisco.