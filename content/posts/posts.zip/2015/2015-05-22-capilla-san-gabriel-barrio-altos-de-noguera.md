---
title: Capilla San Gabriel, Barrio Altos de Noguera
author: admin

date: 2015-05-22T15:21:57+00:00
url: /capilla-san-gabriel-barrio-altos-de-noguera/
thumbnail: /images/id-2984.jpg
tags: [Colaboraciones]

---
Entrega de donaciones recibidas en el campito por parte de los peregrinos que asisten el día 8 de cada mes. El día viernes 22 de mayo de 2015, se entregaron en la Capilla San Gabriel, Barrio Altos de Noguera, Capilla que depende de la Parroquia Nuestra Señora de Pompeya.

<img decoding="async" class="ngg_displayed_gallery mceItem" src="https://mariadelasantafe.org.ar/images/id-2984.jpg" alt="" data-mce-placeholder="1" />