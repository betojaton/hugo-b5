---
title: Viernes, 24 de Abril 2015
author: admin

date: 2015-04-24T10:14:29+00:00
url: /viernes-24-de-abril/
thumbnail: /images/corazon-jesus-en-mano-drch-1.jpg
tags: [Mensajes 2015]

---
<img decoding="async" class="alignright size-full wp-image-777 img-responsive img-circle" src="https://mariadelasantafe.org.ar/wp-content/uploads/2003/09/virgen_corazon.png" alt="virgen_corazon" />Por la noche le dice la **Santísima Virgen a Vicente**, siendo las 23:10 hs.

> Vicente hijo mío: Muchas almas están desbarrancándose, están en el abismo, muchas aún caminan sobre el precipicio y no han caído, por eso Mi deseo de Madre y Mi ardiente súplica, es que Mis hijos continúen en permanente oración, que Mis hijos no abandonen jamás la oración, pido a todos los corazones, a cada uno de Mis hijos, que continuéis esforzándoos cada día y que mantengáis encendida la luz de Cristo Jesús, Mi Hijo Amadísimo en vuestros corazones, confiad en el Señor y jamás dudéis de su Providencia amorosa.  
> Meditad Mi Profundísimo Mensaje.  
> Amén. Gloria a Cristo Jesús  
> Hazlo conocer a todos tus hermanos.<footer>
> 
> <cite title="Leed">Leed; Marcos: C 12, V 7 &#8211; Mateo: C 7, V 21</cite></footer> 
<img decoding="async" class="alignright size-full wp-image-2933 img-responsive img-circle" src="https://mariadelasantafe.org.ar/images/corazon-jesus-en-mano-drch.jpg" alt="corazon-jesus-en-mano-drch" /> **Le dice Jesús a Vicente, hermano mío:**

> ¿Aún hay corazones que dudan de Mi tags:
	- Mensajes Presencia?  
> ¿Aun hay almas que rechazan Mi Amor?  
> ¿Aun hay corazones extraviados que escapan a Mi Divina Misericordia?  
> Oh género humano, cuando comprenderás Mi amor, cuando llegarás a conocer este amor que ofrece Mi Sacratísimo Corazón a todos por igual.  
> Vengo a hablaros de Mi amor, a enseñaros Mi amor, a demostraros Mi presencia junto a vosotros.  
> La luz de Mi Corazón es para todos, “no le cerréis vosotros las puertas” a los corazones que buscan ardientemente Mi Luz.  
> Meditad este Mensaje  
> Amén. Gloria a Dios Mi Padre.  
> Predícalo a todos tus hermanos.<footer>
> 
> <cite title="Leed">Leed. 1ra. de Juan: C 3, V 2 al 9</cite></footer>