---
title: Domingo 8 de marzo, 2015
author: admin

date: 2015-03-08T19:21:33+00:00
url: /domingo-8-de-marzo-2015/
thumbnail: /images/santisima-virgen-corazon-1.jpg
tags: [Mensaje tags:
	- Mensajes Presencia]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/santisima-virgen-corazon.jpg" alt="santisima-virgen-corazon" class="alignright size-full wp-image-2912 img-responsive img-circle" />  
**Dice la Santísima Virgen:** 

> “Hijos Míos benditos y amados hijos Míos, ésta Madre viene del cielo, viene hacia los hijos, viene a cobijar a los hijos, a proteger a todos los hijos.  
> Ésta Madre desciende del cielo para pedir a cada hijo la oración, para suplicar e implorar a toda la humanidad la oración.  
> Ésta Madre hace descender sobre vosotros, en este día, una lluvia de rosas sobre cada uno de vosotros, sobre vuestras familias, sobre todas las comunidades.  
> Ésta Madre desciende del cielo para llevar a cada hijo el amor de Jesús, para que cada hijo encuentre a Jesús por el camino que es ésta Madre.  
> Mi Corazón Inmaculado es el puente hacia Jesús, Mi Corazón Inmaculado es el camino directo a Jesús, por eso os pido hijos Míos que recéis, y mucho, que recéis por vuestra nación, que recéis por aquellos corazones que hoy están tan sumergidos en el odio y en la división, os invito a rezar, esa es vuestra tarea , rezad todos los días y así tendréis paz en vuestro corazón.  
> Meditad. Meditad. Meditad Mis palabras.”

<img decoding="async" src="https://mariadelasantafe.org.ar/images/jesus-corazon-pecho.jpg" alt="jesus-corazon-pecho" class="alignright size-full wp-image-2911 img-responsive img-circle" /> **Dice la Jesús:** 

> “Hermanos Míos benditos y amados hermanos Míos, buscad siempre Mi luz, buscad y seguid Mi luz, no miréis las luces pasajeras del mundo, mirad la luz de Mi Sacratísimo Corazón, mirad profundamente la luz de amor que irradia Mi Sacratísimo Corazón.  
> Haceos pequeños, sencillos, humildes y saboread de Mis palabras, sentid Mis palabras en lo profundo de vuestro corazón, aquí estoy para daros fuerzas, aquí estoy para enseñaros el camino, aquí estoy para mostraros Mi camino, seguid Mis pasos y cada uno tome su cruz, seguid Mis pasos, seguid Mi camino y tendréis paz en vuestro corazón.  
> Vivíd y trabajad para sembrar la paz en el mundo.  
> Vivíd y trabajad para sembrar el amor en el mundo.  
> Buscad Mi luz. Sentíd la presencia de Mi luz,  
> transmitid vosotros Mi luz , a todas las almas.  
> Os amo a todos, os amo, jamás lo olvideís. Os amo.  
> Meditad. Meditad. Meditad Mis palabras  
> Os bendigo en el nombre del Padre y del Hijo y del Espíritu Santo. Amen”