---
title: Indulgencias
author: admin

date: 2015-12-07T15:26:26+00:00
url: /indulgencias/
tags: [Destacada]

---
Para vivir y obtener la indulgencia los fieles están llamados a realizar una breve peregrinación hacia la “Puerta Santa”, abierta en la Catedral Metropolitana, Basílica de Guadalupe, Iglesia del Carmen y en las cuatro basílicas papales en Roma. Es importante que este Momento este unido, ante todo, al Sacramento de la Reconciliación y a la celebración de la santa Eucaristía, con una reflexión sobre la misericordia, acompañado con la oración por el Santo Padre y por sus intenciones.