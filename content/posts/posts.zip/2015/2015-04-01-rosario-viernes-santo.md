---
title: Viernes Santo – Rezo del Rosario
author: admin

date: 2015-04-01T14:18:12+00:00
url: /rosario-viernes-santo/
thumbnail: /images/jesus-crucificado-maria-y-personas-miran.jpg
tags: [Noticias]

---
> “La Virgen junto a la cruz nos recuerda su inquebrantable firmeza y su extraordinaria valentía para afrontar los padecimientos. En el drama del Calvario a María la sostiene la fe.”

**Acompañemos a María y a Jesús durante el viernes Santo rezando durante las 24 horas el Santo Rosario.** 

<p class="text-center">
  <button type="button" class="btn btn-primary btn-xs" data-toggle="modal" data-target="#myModal">Registrate ingresando al formulario.</button>
