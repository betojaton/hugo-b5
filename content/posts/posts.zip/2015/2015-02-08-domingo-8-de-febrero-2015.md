---
title: Domingo 8 de febrero, 2015
author: admin

date: 2015-02-08T19:00:19+00:00
url: /domingo-8-de-febrero-2015/
thumbnail: /images/dibujo-virgen-maria-1.png
audio:
  - https://soundcloud.com/mariadelasantafe/presencia-campito-08-marzo-2015
tags: [Mensaje tags:
	- Mensajes Presencia]

---
**Dice la Santísima Virgen:**  
“Hijos Míos, benditos y amados hijos Míos, nuevamente esta Madre os da gracias a cada uno de ustedes, porque estáis aquí, porque habéis llegado a los pies de ésta Madre, ésta Madre os agradece.  
<img decoding="async" src="https://mariadelasantafe.org.ar/images/dibujo-virgen-maria.png" alt="dibujo-virgen-maria" class="alignright size-full wp-image-2868 img-rounded img-responsive" />  
Quiero que habrais vuestras manos y recibais el rosario que esta Madre lleva en sus manos, recibi este rosario y llevadlo a vuestro corazón y os pido hijitos Míos que todos los días receis en familia, en comunidad, en todo momento receis el rosario y pedi mucho en estos tiempos dificiles, la paz para el mundo, la paz para tantas familias desunidas, la paz para tantos corazones atormentados, hijos escuchad a María que os viene a hablar de parte del Señor, escuchad a esta Madre que os viene a conducir a cada uno de vosotros hacia el Corazón de Jesus, hacia Cristo Jesus, Mi Hijo Amadisimo.

Meditad cada palabra, no la paseis por alto.Meditadlas profundisimamente en vuestro corazon y ponedlas en practica, no busqueis la oscuridad, no busqueis las tinieblas del pecado, vivid hijitos Mios en la Luz de la Gracia, de la verdad, del amor y de la paz.

Trabajad por la paz, por la verdad y el amor y sed una verdadera comunidad, una autentica comunidad.  
Meditad. Meditad. Meditad Mis palabras.”

**Dice la Jesús:**  
“Hermanos míos, benditos y amados hermanos míos os amo a todos, os amo profundisimamente y os entrego Mi Sacratisimo Corazón, Mi purisimo corazón, traspasado y herido por amor  
Veo a la humanidad doliente, veo a la humanidad por caminos equivocados, veo al hombre tan alejado de Mí y sigo volcando en el mundo Mi amor y Mi Divina Misericordia para que todos las almas se salven, para que todos los corazones se salven.

Vosotros sois Mis soldados, vosotros debeis trabajar profundamente para salvar almas, no guardeis para vosotros los tesoros que os entrega Mi Sacratisimo Corazón, llevad al mundo Mis palabras, buscad a las almas que estan perdidas, buscad a las almas que estan equivocadas, buscad, predicad, sed misioneros de Mi amor, de Mis palabras y de Mi presencia en esta tierra Santa y Bendita, Santa Fe la nueva Jerusalen, Argentina el nuevo Israel.  
Haced florecer en vuestros corazones Mis palabras, Y no dudeis jamas de Mi amor Eterno, para cada uno de vosotros, os amo, os amo, os amo. Jamas lo dudeis.

Meditad, Meditad, Meditad Mis palabras os bendigo, en el nombre del Padre y del Hijo y del Espiritu Santo Amen.”