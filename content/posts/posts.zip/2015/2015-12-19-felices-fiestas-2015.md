---
title: Felices Fiestas 2015
author: admin

date: 2015-12-19T16:17:49+00:00
abstract: |
  <iframe src="https://mariadelasantafe.org.ar/navidad2015/index.html" width="100%" height="400" frameborder="0" scrolling="no"></iframe>
  
  “Hijos Míos:
  Rezad esta oración y preparad una novena para la Navidad: Dulce Salvador, Jesús mío que vienes a nosotros para traernos la paz, el amor y la gracia, que te preparemos el corazón para ser fieles a ti y que te recibamos como tú te lo mereces. Haz de nuestro corazón la cuna para que tú nazcas en ella. Amén. Amén.”
url: /felices-fiestas-2015/
tags: [Destacada]

---
“Hijos Míos:  
Rezad esta oración y preparad una novena para la Navidad: Dulce Salvador, Jesús mío que vienes a nosotros para traernos la paz, el amor y la gracia, que te preparemos el corazón para ser fieles a ti y que te recibamos como tú te lo mereces. Haz de nuestro corazón la cuna para que tú nazcas en ella. Amén. Amén.”