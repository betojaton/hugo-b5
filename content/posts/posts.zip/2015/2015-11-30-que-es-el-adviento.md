---
title: ¿Qué es el Adviento?
author: admin

date: 2015-11-30T13:02:50+00:00
url: /que-es-el-adviento/
thumbnail: /images/AdvientoEspera_171115.jpg
tags:
  - Home [Noticias]

---
El **Adviento** es el comienzo del Año Litúrgico, empieza el domingo más próximo al 30 de noviembre y termina el 24 de diciembre. Son los cuatro domingos anteriores a la Navidad y forma una unidad con la **Navidad y la Epifanía**.

El término &#8220;**Adviento**&#8221; viene del latín adventus, que significa **venida**, **llegada**. El color usado en la liturgia de la Iglesia durante este tiempo es el morado. Con el Adviento comienza un nuevo año litúrgico en la Iglesia.

El sentido del **Adviento** es avivar en los creyentes la **espera del Señor**.

&nbsp;