---
title: Pediatría – Hospital J.B. Iturraspe
author: admin

date: 2015-09-17T23:00:10+00:00
url: /pediatria-hospital-iturraspe/
thumbnail: /images/id-3093.jpg
tags: [Colaboraciones]

---
17/09/2015, 07/07/2015, 10/03/2015, 13/03/2014, 28/08/2013, 12/07/2013 ,25/01/13, 03/08/2012, 12/07/2012 (Entrega de Calefactor a Gas para Sala de Pediatría), 13/06/2012 (Incluye colaboración Sala de Peditría del Hospital) , 22/09/2009, 16/02/2010, 26/05/2010, 12/10/2010, 23/05/2011, 30/11/2011

<img decoding="async" class="ngg_displayed_gallery mceItem" src="https://mariadelasantafe.org.ar/images/id-3093.jpg" alt="" data-mce-placeholder="1" style="margin-bottom: 40px;" />