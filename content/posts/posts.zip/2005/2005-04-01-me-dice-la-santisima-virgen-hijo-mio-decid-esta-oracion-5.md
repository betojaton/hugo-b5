---
title: 'Me dice la Santísima Virgen: Hijo mío, decid esta oración.'
author: admin

date: 2005-04-01T00:09:27+00:00
url: /2005/me-dice-la-santisima-virgen-hijo-mio-decid-esta-oracion-5/
thumbnail: /images/Avirgen-copia-1.png
tags: [Oraciones]

---
<img decoding="async" loading="lazy" class="alignright size-medium wp-image-747" title="Avirgen copia" src="https://mariadelasantafe.org.ar/images/Avirgen-copia-207x300.png" alt="Avirgen copia" width="207" height="300" />Madre mía ayúdame, Madre del Cielo tú que me escuchas atiende mis ruegos, te pido por los enfermos, los del cuerpo, los del alma, te pido por los que sufren, por los agoviados y perseguidos, te pido por mi hogar, por mi pueblo, por mi patria, te pido por todos aquellos que están lejos del verdadero camino y no conocen tu amor de Madre.

Madre que visitas, que amparas a nuestro pueblo, escúchanos, te lo pedimos con nuestro corazón.

**Amén. Amén. Predica esta oración hijo mío.**