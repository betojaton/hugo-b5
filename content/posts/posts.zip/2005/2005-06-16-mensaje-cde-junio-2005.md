---
title: Mensaje, 16 de Junio 2005
author: admin

date: 2005-06-16T14:31:12+00:00
url: /2005/mensaje-cde-junio-2005/
tags: [Mensajes 2005]

---
**Dice la Santísima Virgen María:**

> Hijo mío: Cuantas lágrimas derramo por esos hijos que no siguen el camino de la gracia, por esos hijos que solo siguen tras los pasos del enemigo, por esas almas encerradas y encarceladas a sus vicios que hoy desconocen por completo la existencia del Señor, Soy Madre y me desvelo angustiadamente por los hijos que viven sus días en el descontrol, en la lujuria total, las almas están ciegas y seducidas hábilmente por Satanás, el príncipe de la mentira, las almas desconocen pues la existencia del Señor y desconocen también su auténtico camino, hijos, hoy como Madre quiero pediros a todos, a todos, deseo dirigiros Mi palabra, obispos, sacerdotes, seminaristas, religiosas, a todos, esforzaos pues día a día, os pido vuestra tarea y colaboración total para con la obra del Señor, vuestra oración, vuestra penitencia es valiosa, es importante y Dios Nuestro Señor recibe con gratitud estos actos de misericordia que ofrecéis por las almas y la conversión de los pecadores, es necesario que las almas entregadas totalmente al servicio del Señor comprendan hoy la urgencia del tiempo que estáis viviendo, la hora crucial que el mundo vive, no podéis quedaros dormidos e inertes, tenéis que trabajar arduamente, veis los lobos vestidos con piel de cordero, cuantas almas han arrastrado para sus rediles de mentira y de engaño, no dudéis pues un instante de que esta Madre os acompañará constantemente hasta el final de los tiempos, que esta madre estará a vuestro lado en todo momento y hasta en los momentos más cruciales que debe enfrentar la humanidad, esta humanidad que debe despertar antes de que sea demasiado tarde.  
> Secad pues hijitos míos Mis lágrimas que derramo por no ser escuchada y atendida como lo deseo, tenéis pues una tarea, cumplidla.  
> Meditad todos unidos Mi profundo Mensaje.  
> Amén. Gloria al Altísimo.<footer>Leed: Génesis C 17, V 9 y 10. &#8211; Éxodo C 21, V 14.</footer>