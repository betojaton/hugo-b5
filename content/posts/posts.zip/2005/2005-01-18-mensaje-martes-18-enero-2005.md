---
title: Mensaje, Martes 18 Enero, 2005
author: admin

date: 2005-01-18T15:59:40+00:00
url: /2005/mensaje-martes-18-enero-2005/
tags: [Mensajes 2005]

---
### Me dice la Santísima Virgen: {#me-dice-la-santisima-virgen.wp-block-heading}

<p class="has-drop-cap">
  Hijo míos: Benditos y amados hijos míos. Os doy gracias a cada uno de vosotros, a los que estáis aquí. A los que no han podido llegar. Doy gracias, a todos mis hijos. Porque todos respondéis a la Madre. Porque todos abrid las puertas del corazón a las palabras de la Madre.<br />¡Hijitos míos! ¡Avanzad con la Madre! Porque la Madre está a vuestro lado. Porque la Madre os conduce. Y en ningún momento os desampara. En ningún momento os deja a la deriva. ¡Hijitos míos! Mantened siempre, siempre encendida la llama de la fe y la esperanza. ¡Recordad! Que debéis ser testigos ante el mundo. Ser testimonio, ser auténticos testimonios ante el mundo y ante vuestros hermanos.<br />¡Avanzad! Porque tenéis las puertas abiertas. Porque tenéis este camino, que la Madre os muestra. Mis Palabras, son para vosotros. ¡Mis Palabras, son para todos los hijos del mundo! para toda la humanidad, que debe mirar nuevamente hacia la verdad, hacia la luz hacia, la paz. La humanidad, día a día se hunde. Día a día, se hunde en el fango del pecado. ¡En la oscuridad y en la tinieblas!<br />¡Hijitos! ¡Rezad! Por la conversión de tantos pecadores. ¡Rezad! Por las almas viles e insensibles. ¡Rezad! Y ofreced sacrificio, día a día por la conversión de todos los pecadores.<br />Meditad, Meditad, Meditad Mis Palabras.


### Me dice Jesús: {#me-dice-jesus.wp-block-heading}

Hermanos míos: Benditos y amados hermanos míos. Os ofrezco Mi paz. Os ofrezco Mi amor, os ofrezco el Bálsamo, de Mi Divina Misericordia, para sanar vuestro corazón, para sanar vuestras heridas. Para fortaleceros, para guiaros, por éste camino, por éste sendero.  
¡Hermanos míos, todos estáis, todos estáis! En éste camino. Hermanos míos, que en vuestras manos, que en vuestro corazón, brille la luz. Brille eternamente Mi luz. Que en vuestro corazón reine eternamente Mi amor. Porque Mi amor, os sana. Porque Mi amor os fortaleza. Porque Mi amor os enriquece.  
Meditad, Meditad, Meditad Mis Palabras.

_Leed: Ezequiel C 32, v 1 al 6._

<blockquote class="wp-block-quote">
  <p>
    Os Bendigo en el Nombre del Padre y del Hijo y del Espíritu Santo, Amén.
  
</blockquote>

<p class="has-text-align-center has-medium-font-size">
  ───── ⋆⋅☆⋅⋆ ─────
