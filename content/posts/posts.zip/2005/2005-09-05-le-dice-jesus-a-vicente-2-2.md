---
title: 'Le dice Jesús a Vicente:'
author: admin

date: 2005-09-05T02:22:05+00:00
url: /2005/le-dice-jesus-a-vicente-2-2/
tags: [Oraciones]

---
<p id="internal-source-marker_0.28540860351012654">
  **Hermano Mío:**<br /> Digo a todos los corazones en Mi Sacratísimo corazón está la paz y la verdad, quiero reinar en las familias y en los hogares, deseo que en las familias, en los hogares reine Mi Sacratísimo Corazón, pues, Mi Sacratísimo Corazón os trae la paz y la verdad, Mi Sacratísimo Corazón os trae consuelo. **Entronizad imágenes de Mi &nbsp;Sacratísimo Corazón en vuestros hogares, en vuestras familias** y no dejéis que los ídolos falsos y profetas falsos ganen terreno donde debe reinar solamente Mi Sagrado Corazón. Que Mis hermanos, pues, atiendan a Mi pedido que hago a todas las almas.


Meditad Mi profundísimo mensaje.

Amén. Gloria a Dios Mi Padre.

Leed: 1º Juan C 3 V 12

Hazlo a conocer hijo a tus hermanos.