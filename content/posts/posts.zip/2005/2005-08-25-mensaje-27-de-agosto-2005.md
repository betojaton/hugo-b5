---
title: Mensaje, 27 de Agosto 2005
author: admin

date: 2005-08-25T14:36:50+00:00
abstract: |
  **Me dice Jesús:**
  <img src="https://mariadelasantafe.org.ar/wp-content/uploads/2016/08/img-corazones-llama-enmano.jpg" alt="img-corazones-llama-enmano" class="alignright size-full wp-image-3663" />
  <blockquote>Vicente hermano mío: Digo a tus hermanos, descubrid la fragancia de Mi Sacratísimo Corazón, descubrid este amor que regalo a las almas, descubrid este camino poderoso y de luz al cual os invito para que por el transitéis, dejad que sea Mi luz, la luz del Buen Pastor la que os conduzca y no voces falsas, voces engañosas y perversas que solo desean la muerte para vuestras almas, dejad que sea Mi voz, Mi suave voz la que guíe vuestras vidas, vuestros actos, vuestros pensamientos.
  Disfrutad pues de Mi amor, de Mi presencia y de Mi paz.
  Meditad Mi Profundísimo Mensaje.
  Amén. Gloria a Dios Mi Padre.
  
  <footer>Leed: Ezequiel: C 11, V 7. - Mateo: C 8, V 13. - Marcos: C 12, V 19.</footer></blockquote>
  
  Predícalo hijo mío a todos tus hermanos.
url: /2005/mensaje-27-de-agosto-2005/
thumbnail: /images/img-corazones-llama-enmano-1.jpg
tags: [Mensajes 2005]

---
**Me dice Jesús:**  
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-corazones-llama-enmano.jpg" alt="img-corazones-llama-enmano" class="alignright size-full wp-image-3663" /> 

> Vicente hermano mío: Digo a tus hermanos, descubrid la fragancia de Mi Sacratísimo Corazón, descubrid este amor que regalo a las almas, descubrid este camino poderoso y de luz al cual os invito para que por el transitéis, dejad que sea Mi luz, la luz del Buen Pastor la que os conduzca y no voces falsas, voces engañosas y perversas que solo desean la muerte para vuestras almas, dejad que sea Mi voz, Mi suave voz la que guíe vuestras vidas, vuestros actos, vuestros pensamientos.  
> Disfrutad pues de Mi amor, de Mi presencia y de Mi paz.  
> Meditad Mi Profundísimo Mensaje.  
> Amén. Gloria a Dios Mi Padre.<footer>Leed: Ezequiel: C 11, V 7. &#8211; Mateo: C 8, V 13. &#8211; Marcos: C 12, V 19.</footer> 

Predícalo hijo mío a todos tus hermanos.