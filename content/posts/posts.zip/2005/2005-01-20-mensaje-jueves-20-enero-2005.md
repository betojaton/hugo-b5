---
title: Mensaje | Jueves 20 de Enero, 2005
author: admin

date: 2005-01-20T16:22:22+00:00
url: /2005/mensaje-jueves-20-enero-2005/
tags: [Mensajes 2005]

---
### Me dice la Santísima Virgen:
 {#me-dice-la-santisima-virgen.wp-block-heading}

<p class="has-drop-cap">
  Hijo míos: Benditos y amados hijos míos. Os doy gracias nuevamente, por vuestra respuesta. Os bendigo a vosotros. Bendigo a esos hijos que no han podido llegar y a esos hijos que están en camino, para compartir con vosotros, para estar junto a vosotros en ésta Santa Obra.<br />Muchas veces sentís el agobio. Muchas veces sentís el cansancio. Muchas veces sentís el desgano y la falta de voluntad para seguir, para perseverar, para luchar. Pero debéis acordaros, hijitos míos, de cada una de Mis Palabras. Y debéis recordar que la Madre está a vuestro lado. ¡Qué la Madre conoce vuestro corazón! Que la Madre, ésta Madre, ve vuestro corazón. Vuestro corazón, tantas veces, tan dolorido, tan angustiado.<br />¡Recordad hijitos míos! Que todo aquí en la tierra, que todo es pasajero. Y que el camino, que el camino verdadero, es el que lleva a la vida eterna y está en Cristo Jesús, Mi hijo Amadísimo. Y como Madre, os conduzco a cada uno de vosotros en el camino de la verdad, en el camino de la luz, en el camino de la paz.<br />¡Hijitos míos! ¡Abrid vuestras manos! Recibid el Rosario de Mis manos. Recibid Mi Inmaculado Corazón y llevadlo a vuestro corazón. Para que allí, donde están Mis regalos, donde están los tesoros, crezcas, produzcan, iluminen a vuestros hermanos.<br />¡Hijitos! ¡Hijitos míos! Dad ejemplo. Sed testimonios verdaderos ante vuestros hermanos. ¡No temáis! ¡No temáis a los hombres! No temáis a la lucha. ¡Perseverad! ¡Estad! ¡Compartid! Y aunque sintáis el peso y el cansancio, recordad, que María, que María os cubre a todos con su Manto Celestial. Que os cubro a todos, con Mi Manto Celestial.<br />Todos sois verdaderamente iguales para ésta Madre. ¡Todos estáis dentro de Mi Inmaculado Corazón! ¡Todos tenéis una tarea! Cada cual su tarea, su misión, su labor que cumplir. ¡No os sintáis pues! Indefensos. ¡No os sintáis incapaces! De realizar y de llevar a cabo la tarea. Cada cual cumpla, su tarea y a su debido tiempo.<br />Meditad, Meditad, Meditad Mis Palabras.




### Me dice Jesús: {#me-dice-jesus.wp-block-heading}

Hermanos míos: Recibid Mi Divina Misericordia. Recibid el Bálsamo de Mis Sacratísimas Llagas. Recibid Mi Preciosísima Sangre. Que derramo en vosotros, que derramo sobre el mundo entero, que derramo sobre la humanidad por completo.  
Hermanos míos, estáis caminando. ¡Hermanos míos! estáis en la verdad. ¡Hermanos nos míos! Estáis trabajando, verdaderamente y junto a mi Santa Iglesia. ¡Hermanos míos! En vuestro corazón, están las palabras de Mi Santísima Madre y Madre de todos vosotros. En vuestro corazón están mis palabras, palabras que debéis meditar. Palabras, que debéis día a día comprended, palabras, que debéis profundizar, día a día, minuto a minuto, hora tras hora.  
¡Hoy es el tiempo de escuchar! ¡Hoy es el tiempo, de que el mundo conozca mi llamado! ¡Hoy es el tiempo! ¡Hoy son los días! ¡Ya han llegado! ¡Qué el mundo escuche pues! ¡Qué el mundo atienda pues! Que la humanidad vuelva a la verdad. Vuelva a la gracia, vuelva al auténtico camino. No son mis palabras, no son mis mensajes algo para guardar. ¡No son para silenciar! ¡Son! Para todos los hombres. El que pueda entender, que entienda.  
Hoy, ahora en éste tiempo, hay muchos lobos. ¡Hay muchas alimañas! ¡Hay muchas serpientes venenosas! ¡Muchos pastores! Que engañan, que seducen a las almas. ¡Poned pues, una barrera! ¡Poned pues, una muralla! En ésta Santa Nación. ¡Poned pues y defended! Lo que he puesto en vuestras manos, en todos vosotros.  
Meditad, Meditad, Meditad Mis Palabras.

_Leed: Juan C 15, v 8 y 9 &#8211; Juan C16, v1 al 7_

<blockquote class="wp-block-quote">
  <p>
    Os Bendigo en el Nombre del Padre y del Hijo y del Espíritu Santo, Amén.
  
</blockquote>