---
title: Martes 3 de agosto, 2004
author: admin

date: 2004-08-03T15:15:37+00:00
url: /2004/martes-3-de-agosto-2004/
thumbnail: /images/foto-mensaje-octubre3-1.png
tags: [Mensajes 2004]

---
**<img decoding="async" class="alignright size-medium wp-image-3065" src="https://mariadelasantafe.org.ar/images/foto-mensaje-octubre3.png" alt="foto-mensaje-03agosto2004" />Me dice Jesús:** 

> Hermano mio: Las almas deben dar lugar a Mí Amor, las almas no pueden dejar pasar desapercibido hoy Mí llamado, los corazones deben llegar a Mí encuentro, los hombres deben descubrir el camino que os ofrece Mi Sacratísimo Corazón.  
> Hoy la humanidad rebelde, terca rechaza al verdad, rechaza la mano de Misericordia que os brindo, rechaza la verdad y se sumerge cada vez más en el abismo del pecado en el abismo del fuego eterno, la humanidad busca la oscuridad y rechaza la luz de Mí Amor.  
> Estáis a tiempo, volved pues al verdadero camino y dejad la idolatría, la pasividad, dejad los engaños y falsedades y no seáis hipócritas, no seáis oscuros y sed verdadera luz, sed verdaderos faros en el mundo, Mi Divina Misericordia, Mí Amor, Mí Paz son para todos los hombres, recibidlo pues, aceptadlo pues.  
> Meditad mi profundísimo mensaje.  
> Amén. Gloria a Dios Mi Padre.  
> Predicalo hijo mio al mundo entero.<footer>Leed: Ester C 3, V 9, Juan C 20, V 5, Lucas C 16, V 23.</footer> 

**Dice la Santísima Virgen María:** 

> Hijos míos: Deposito en vuestras manos una tarea ardua, deposito en vuestras manos una misión que debéis llevar a cabo, deposito como Madre en cada uno de mis hijos una misión para estos tiempos, para estos días, para estas horas, nadie debe quedar excluido, nadie debe quedar lejano de Mi llamando de Madre, llamado que hago a todos los hombres, llamando que es universal, llamado que debe ser atendido por todos mis hijos.  
> La Madre peregrina con sus hijos, la Madre evangeliza a sus hijos, la Madre enseña a sus hijos el camino que lleva a la vida eterna, Cristo Jesús, Mi Hijo Amadísimo.  
> Pido, insisto, suplico, a cada corazón una respuesta, ya no podéis ignorar, ya no podéis negar la intervención de la Madre en este suelo Santo y bendito, en esta nación que debe volver a sus fuentes, a sus raíces, a sus principios morales que hoy tristemente y lamentablemente están siendo oscurecidos y olvidados por todos mis hijos.  
> Abrid el corazón, abrid vuestros ojos y no permitáis que el enemigo gane pues más terreno en esta tierra donde María ha puesto sus pies, donde María ha puesto su esperanza, donde María ha puesto su morada, dejad de lado las divergencias, dejad de lado el que os dirán y trabajad con empeño, con esfuerzo, con esmero por dar y predicar al mundo el mensaje de Mariía hacia todos sus hijos, son los días de la Madre con sus hijos, son mis días, es Mi Misión hoy llamar, socorrer, atender a cada uno de Mis hijos, vengo y deseo que sean reconocidos Mis derechos de Madre, Mis derechos de Reina y Soberana y Patrona de todo este Bendito lugar, María está con vosotros, recibid a María, creed en María que os habla a todos por igual.  
> Meditad Mi profundísimo Mensaje.  
> Amén. Gloria al Sagrado Corazón de Jesús.  
> Predícalo Hijo mío al mundo entero.<footer>Leed:
> 
>  
> Daniel: C3,V 1 al 12.  
> Judit: C 11, V 9 al 13.  
> Lucas: C 7, V 17 al 22.  
> Mateo: C 6, V 12.  
> Juan: C 9, V 16 y 17.  
> Lucas: C 14, V 10 y 11.  
> Apocalipsis: C 14. V 5 al 7.  
> Efesios: C 2, V 1 al 6.  
> Marcos: C 8, V 18 y 19.  
> Lucas: C 7, V 1 al 6.</footer>