---
title: Mensaje, 4 de Abril, 2004
author: admin

date: 2004-04-04T14:43:17+00:00
abstract: |
  **Me dice Jesús:**
  <blockquote>Hermanos míos: Os ofrezco Mi amor, os ofrezco Mi Divina Misericordia, os ofrezco Mi paz, paz para vuestros corazones, paz para vuestras comunidades, paz para que encontréis el verdadero camino que os conduce a la vida eterna, Mi Cuerpo y Mi Sangre.
  Abrid de par en par las puertas de vuestro corazón para que Mi luz os transforme, os modele y derrita el hielo que tantas veces hay en el.
  Dad lugar en vuestro corazón a Mi amor, a Mi paz y a Mi verdad.
  Meditad Mi profundísimo Mensaje.
  Amén. Gloria a Dios Mi Padre.
  <footer>Leed: 1ra. Timoteo: C 5, V 10 y 11.</footer></blockquote>
  Predícalo hijo mío al mundo entero.
  
  **Me dice la Santísima Virgen:**
  <img class="alignright size-full wp-image-3610" src="https://mariadelasantafe.org.ar/wp-content/uploads/2016/07/caliz-luminoso.jpg" alt="caliz-luminoso" />
  <blockquote>Hijo mío: Digo a todos tus hermanos, no dejéis que avancen sobre vuestros corazones el temor, las dudas, los cuestionamientos, no dejéis que avance la incertidumbre, el desaliento, el descontrol, no dejéis que vuestro corazón sea amalgamado y perturbado por los placeres y trivialidades del mundo en que estáis hoy viviendo, así como el hombre ha avanzado en su afán materialista y pervertido así han crecido y se han incrementado los innumerables y horrorosos pecados que llenan la copa, que rebasan la copa de la ira del Señor.
  Hoy deben pues Mis hijos, todos debéis estar alertas, prevenidos, preparados para que dispongáis vuestro corazón a la batalla, para que preparéis vuestro corazón y os fortalezcáis en la oración y con el Cuerpo y la Sangre de Cristo Jesús, Mi Hijo Amadísimo...</blockquote
url: /2004/mensaje-4-de-abril-2004/
thumbnail: /images/caliz-luminoso.jpg
tags: [Mensajes 2004]

---
**Me dice Jesús:**

> Hermanos míos: Os ofrezco Mi amor, os ofrezco Mi Divina Misericordia, os ofrezco Mi paz, paz para vuestros corazones, paz para vuestras comunidades, paz para que encontréis el verdadero camino que os conduce a la vida eterna, Mi Cuerpo y Mi Sangre.  
> Abrid de par en par las puertas de vuestro corazón para que Mi luz os transforme, os modele y derrita el hielo que tantas veces hay en el.  
> Dad lugar en vuestro corazón a Mi amor, a Mi paz y a Mi verdad.  
> Meditad Mi profundísimo Mensaje.  
> Amén. Gloria a Dios Mi Padre.<footer>Leed: 1ra. Timoteo: C 5, V 10 y 11.</footer> 

Predícalo hijo mío al mundo entero.

**Me dice la Santísima Virgen:**  
<img decoding="async" class="alignright size-full wp-image-3610" src="https://mariadelasantafe.org.ar/images/caliz-luminoso-1.jpg" alt="caliz-luminoso" /> 

> Hijo mío: Digo a todos tus hermanos, no dejéis que avancen sobre vuestros corazones el temor, las dudas, los cuestionamientos, no dejéis que avance la incertidumbre, el desaliento, el descontrol, no dejéis que vuestro corazón sea amalgamado y perturbado por los placeres y trivialidades del mundo en que estáis hoy viviendo, así como el hombre ha avanzado en su afán materialista y pervertido así han crecido y se han incrementado los innumerables y horrorosos pecados que llenan la copa, que rebasan la copa de la ira del Señor.  
> Hoy deben pues Mis hijos, todos debéis estar alertas, prevenidos, preparados para que dispongáis vuestro corazón a la batalla, para que preparéis vuestro corazón y os fortalezcáis en la oración y con el Cuerpo y la Sangre de Cristo Jesús, Mi Hijo Amadísimo.  
> Nadie debe quedar a la espera sino que todos debéis sentiros llamados, todos debéis comprometeros más con Dios, Nuestro Señor, que llama, que pide, que espera respuesta de cada uno de sus hijos.  
> Estoy como Madre junto a cada uno de mis hijos, llamo como Madre y veo escasas respuestas de los corazones hacia Mis pedidos urgentes, imprescindibles para toda la humanidad.  
> La densa nube de tanta oscuridad, de tanto pecado ha cubierto toda la faz de la tierra y las almas y los corazones se mimetizan con esta nube que siembra Satanás, que siembra el adversario para desbarrancar y arrebatar a las almas de Mi lado, para apartar a las almas del verdadero camino y del auténtico Rebaño donde está Cristo Jesús, Mi Hijo Amadísimo, donde se encuentra esta Madre.  
> Hago Mi llamado como Madre hecho en tantas de Mis manifestaciones al mundo, Lourdes, Fátima, San Nicolás, La Salette, Medjugori, como Madre estoy desde siempre con mis hijos, deseo pues ya en este tiempo invariablemente una respuesta de los corazones, de todas las almas, la quietud del corazón debe ser reemplazada por el obrar y el trabajar, dejad de lado la pereza, dejad de lado el desgano y la desconfianza y aprended en profundidad el significado de Mis palabras y de Mis llamados de Madre al mundo entero.  
> Meditad Mi profundísimo Mensaje.  
> Amén. Gloria al Altísimo.<footer>Leed: Hechos: C 12, V 6 al 10. &#8211; Mateo: C 11, V 5 al 16. &#8211; Lucas: C 14, V 13 al 15. &#8211; Juan: C 9, V 7 al 10. &#8211; Juan: C 18, V 7 y 8. &#8211; Lucas: C 16, V 1 al 7.</footer> 

Predícalo hijo mío al mundo entero.

_**“&#8230; Hago Mi llamado como Madre**_  
<figure id="attachment_3614" aria-describedby="caption-attachment-3614" style="width: 277px" class="wp-caption alignleft"><img decoding="async" loading="lazy" class="wp-image-3614 size-full" src="https://mariadelasantafe.org.ar/images/img-virgenes-1.jpg" alt="img-virgenes" width="277" height="258" /><figcaption id="caption-attachment-3614" class="wp-caption-text">hecho en tantas de Mis manifestaciones al mundo, Lourdes, Fátima, San Nicolás, La Salette, Medjugori, como Madre estoy desde siempre con mis hijos&#8230;”</figcaption></figure>