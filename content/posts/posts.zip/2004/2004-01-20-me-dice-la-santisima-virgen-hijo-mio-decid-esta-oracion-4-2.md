---
title: 'Me dice la Santísima Virgen: Hijo mío: decid esta oración:'
author: admin

date: 2004-01-20T00:02:30+00:00
url: /2004/me-dice-la-santisima-virgen-hijo-mio-decid-esta-oracion-4-2/
tags: [Oraciones]

---
“Madre mía ayúdame, en esta dificultad, en esta situación recurro a ti, necesito de tu presencia, de tu auxilio, sé que me escuchas y recurro confiadamente a ti, porque encomiendo a tu Inmaculado Corazón todas mis necesidades, se de tu amor grandioso, de tu amor hacia cada uno de nosotros, inspíramos el ser siempre fieles, siempre dóciles a la voluntad de Dios, Nuestro Señor&#8221;.

**Amén. Gloria al Altísimo. Predica esta oración hijo mío al mundo entero.**

 ****