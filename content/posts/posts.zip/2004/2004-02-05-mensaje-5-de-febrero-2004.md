---
title: Mensaje, 5 de Febrero, 2004
author: admin

date: 2004-02-05T10:01:31+00:00
abstract: |
  **Me dice la Santísima Virgen:**
  <img src="https://mariadelasantafe.org.ar/wp-content/uploads/2004/02/mano-rezando.jpg" alt="mano-rezando" class="alignright size-full wp-image-3986" /><blockquote>Hijo mío: Cuantas almas viven en el vacío, en la incredulidad, muchas almas están aferradas a sus placeres y divagaciones, hay corazones oscurecidos, en completa oscuridad porque no desean recibir la luz que os trae, Dios, Nuestro Señor.
  Veo angustiada como Madre ver correr a mis hijos, ver a tantos de mis hijos caminar en tanta maldad, destruir los buenos ejemplos y sembrar tanta maldad.
  Veo como Madre que en muchos lugares mis llamados y advertencias no han sido escuchadas a tiempo.
  Deseo pues que la humanidad responda, que las almas y corazones comprometidos hoy respondan a Mi urgente y desesperado llamado.
  El mundo está pendiente de un hilo finísimo y aquí tenéis a la Madre que os lo anuncia, que os lo previene a todos vosotros.
  Meditad Mi profundísimo Mensaje.
  Amén. Gloria a Cristo Jesús.
  <footer>**Leed:** 1er libro Macabeos: C 5, V 9 al 10. - Juan: C 6, V 8.</footer></blockquote>
  Predícalo hijo mío al mundo entero.
url: /2004/mensaje-5-de-febrero-2004/
thumbnail: /images/manos-jesus-corazon-espina-1.jpg
tags: [Mensajes 2004]

---
**Me dice la Santísima Virgen:**  
<img decoding="async" src="https://mariadelasantafe.org.ar/images/mano-rezando.jpg" alt="mano-rezando" class="alignright size-full wp-image-3986" /> 

> Hijo mío: Cuantas almas viven en el vacío, en la incredulidad, muchas almas están aferradas a sus placeres y divagaciones, hay corazones oscurecidos, en completa oscuridad porque no desean recibir la luz que os trae, Dios, Nuestro Señor.  
> Veo angustiada como Madre ver correr a mis hijos, ver a tantos de mis hijos caminar en tanta maldad, destruir los buenos ejemplos y sembrar tanta maldad.  
> Veo como Madre que en muchos lugares mis llamados y advertencias no han sido escuchadas a tiempo.  
> Deseo pues que la humanidad responda, que las almas y corazones comprometidos hoy respondan a Mi urgente y desesperado llamado.  
> El mundo está pendiente de un hilo finísimo y aquí tenéis a la Madre que os lo anuncia, que os lo previene a todos vosotros.  
> Meditad Mi profundísimo Mensaje.  
> Amén. Gloria a Cristo Jesús.<footer>
> 
> **Leed:** 1er libro Macabeos: C 5, V 9 al 10. &#8211; Juan: C 6, V 8.</footer> 
Predícalo hijo mío al mundo entero.

<img decoding="async" src="https://mariadelasantafe.org.ar/images/manos-jesus-corazon-espina.jpg" alt="manos-jesus-corazon-espina" class="alignright size-full wp-image-3990" /> **Me dice Jesús:**

> Hermano mío: Caminad en la luz y en la gracia, caminad en la verdad, caminad junto a Mi Sacratísimo Corazón, hoy la humanidad rechaza y anula la verdad, hoy la humanidad reboza de maldad y odio, hoy la humanidad está sumergida por completo en el fango del mal, de la destrucción, del pecado.  
> Despertad del letargo, de las sombras del mal, despertad y mirad la luz de Mi Sacratísimo Corazón que llama a las almas, que llama a los corazones, que urge a mis hermanos una respuesta, un si sincero y definitivo hacia Mi Sacratísimo Corazón.  
> Despertad pues aún estáis a tiempo.  
> Meditad Mi profundísimo Mensaje.  
> Amén. Gloria a Dios Mi Padre.<footer>Leed: Lucas: C 5, V 18.</footer> 

Predícalo hermano mío al mundo entero.

<img decoding="async" src="https://mariadelasantafe.org.ar/images/rosario-moviendose.jpg" alt="rosario-moviendose" class="alignright size-full wp-image-3987" /> 

### 05 de Febrero de 2004 (16 y 25 hs)

> Hijo mío: Deben mis hijos multiplicar la oración, deben mis hijos responder a mis pedidos, la humanidad no desea escuchar, no desea atender Mi pedido y es que hoy llamo para pediros, para rogaros que escuchéis a la Madre.  
> El Santo Rosario es arma poderosa, el Santo Rosario es arma contra los planes de Satanás, el Santo Rosario desbarata todo plan, todo plan macabro y oscuro de tanto gobernantes.  
> Que este país, que esta nación Santa y bendita quede unidad en sus corazones en una sola y gran oración, el Santo Rosario, rezad para que los corazones florezcan a la verdad que os trae la Madre, rezad para que los jóvenes sumergidos en el sexo, en la droga, en el alcohol vislumbren a tiempo la luz de Dios, Nuestro Señor.  
> Rezad para que las familias que aún permanecen en pie sean pues difusoras de este modelo que el mundo debe recibir y aceptar.  
> Aquí tenéis a la Madre que os escucha, que os atiende, que os pide, que solamente os pide no paséis inadvertido este Mi pedido.  
> Meditad Mi profundísimo Mensaje.  
> Amén. Gloria a Cristo Jesús.<footer>Leed: Tobías: C 12, V 2 al 17. &#8211; Juan: C 12, V 5 al 20. &#8211; Mateo: C 8, V 1 al 33.</footer> 

Predícalo hijo mío al mundo entero.