---
title: Mensaje, 2 de Octubre, 2004
author: admin

date: 2004-10-02T18:04:02+00:00
url: /2004/mensaje-2-de-octubre-2004/
thumbnail: /images/foto-jesus-envos-confio-1.jpg
tags: [Mensajes 2004]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/foto-jesus-envos-confio.jpg" alt="foto-jesus-envos-confio" class="alignright size-full wp-image-3480" />**Me dice la Santísima Virgen:**

> Hijo mío: Todos los días debéis encontrar al Señor, los corazones deben encaminarse hacia la luz y la verdad, la humanidad debe comprender hoy la urgencia de Mis palabras de Madre, la humanidad debe descubrir el camino auténtico que lleva a la vida eterna, Cristo Jesús, Mi Hijo Amadísimo.  
> Hoy es el tiempo, estos son los días que no debéis dejar pasar de lado, que los hijos escuchen, que los hijos comprendan, que los hijos se acerquen a la luz y a la verdad, que Mis hijos hoy den la respuesta al Señor, la respuesta que el Señor espera de todos vosotros.  
> Meditad Mi profundísimo Mensaje.  
> Amén. Gloria al Altísimo.<footer>Leed: Daniel: C 5, V 12 y 13.</footer> 

Predícalo hijo mío al mundo entero.