---
title: 'Hijo mío: decid esta oración.'
author: admin

date: 2004-10-28T00:07:02+00:00
url: /2004/hijo-mio-decid-esta-oracion/
thumbnail: /images/apertuMaria-1.png
tags: [Oraciones]

---
<img decoding="async" loading="lazy" class="alignright size-full wp-image-775" title="maria nene" src="https://mariadelasantafe.org.ar/images/apertuMaria.png" alt="maria nene" width="250" height="362" />Madre enséñanos a caminar, Madre Guíanos por el camino preparado por tu amor, el camino que nos lleva y nos acerca a Jesús, Madre que veamos la luz y que toda tienibla se aparte de nuestro corazón y de nuestra mente.

Madre que tu amor nos cubra, que tu amor nos fortalezca, que tu amor nos haga dócil verdaderamente.

**Amén. Gloria al Señor. Predica esta oración hijo mío al mundo entero.**