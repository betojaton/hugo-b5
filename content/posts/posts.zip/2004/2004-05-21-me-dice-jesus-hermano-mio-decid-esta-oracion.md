---
title: 'Me dice Jesús: Hermano mío: decid esta oración:'
author: admin

date: 2004-05-21T00:05:53+00:00
url: /2004/me-dice-jesus-hermano-mio-decid-esta-oracion/
thumbnail: /images/jesus_grande-1.png
tags: [Oraciones]

---
<img decoding="async" loading="lazy" class="alignright size-full wp-image-742" title="jesus_grande" src="https://mariadelasantafe.org.ar/images/jesus_grande.png" alt="jesus_grande" width="282" height="388" />Jesús, ven a mí ,sana Señor las heridas de mi corazón, Señor hazme dócil a tu voluntad, Jesús condúceme, guíame y aparta de mis pasos, aparta de mi camino las piedras que me impiden llegar totalmente a ti, Señor ayúdame, consuélame y fortaléceme para servirte por siempre.

**Amén. Amén. Predica hijo mío esta oración al mundo entero.**