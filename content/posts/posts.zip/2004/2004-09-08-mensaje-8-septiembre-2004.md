---
title: Mensaje, 8 Septiembre, 2004
author: admin

date: 2004-09-08T23:31:53+00:00
abstract: |
  **Hijo mío: Rezad esta oración**
  <em>Ven Espíritu Santo, guíame, instrúyeme, ven Espíritu Santo a iluminar y a poner tu luz donde hay confusión, donde hay desesperanza, donde hay tanta oscuridad.
  Ven espíritu Santo, ven a darnos tu luz, guíanos consuélanos, instrúyenos.
  Amén. Gloria.
  </em>
  Predica esta oración hijo mío al mundo entero.
  **Dice la Santísima Virgen María:**
  <img src="https://mariadelasantafe.org.ar/wp-content/uploads/2016/04/foto-msj-08set2004.png" alt="foto-msj-08set2004" class="alignright size-full wp-image-3475" /><blockquote>Hijos Míos: Cuantas madres desconocen el valor de la vida, cuantas mujeres, cuantos hombres realmente no sienten temor de Dios cuando comenten abortos, crímenes tan horrendos, tan oscuros a los ojos del Señor, cuantos niños caen verdaderamente cruelmente asesinados del vientre de sus madres que con total libertad, que con total despreocupación comenten crueles abortos, crueles y perversos crímenes.
  Hijos que vuestra respuesta al Señor no se haga esperar, que vuestra entrega, vuestra obediencia, vuestra inmolación constante no se haga esperar...<blockquote>
url: /2004/mensaje-8-septiembre-2004/
thumbnail: /images/foto-msj-08set2004-1.png
tags: [Mensajes 2004]

---
**Hijo mío: Rezad esta oración**  
_Ven Espíritu Santo, guíame, instrúyeme, ven Espíritu Santo a iluminar y a poner tu luz donde hay confusión, donde hay desesperanza, donde hay tanta oscuridad.  
Ven espíritu Santo, ven a darnos tu luz, guíanos consuélanos, instrúyenos.  
Amén. Gloria.  
_  
Predica esta oración hijo mío al mundo entero.

**Dice la Santísima Virgen María:**

<img decoding="async" src="https://mariadelasantafe.org.ar/images/foto-msj-08set2004.png" alt="foto-msj-08set2004" class="alignright size-full wp-image-3475" /> 

> Hijos Míos: Cuantas madres desconocen el valor de la vida, cuantas mujeres, cuantos hombres realmente no sienten temor de Dios cuando comenten abortos, crímenes tan horrendos, tan oscuros a los ojos del Señor, cuantos niños caen verdaderamente cruelmente asesinados del vientre de sus madres que con total libertad, que con total despreocupación comenten crueles abortos, crueles y perversos crímenes.  
> Hijos que vuestra respuesta al Señor no se haga esperar, que vuestra entrega, vuestra obediencia, vuestra inmolación constante no se haga esperar.  
> Tenéis que dar pues testimonio y luchar por los que Dios Nuestro Señor ha puesto en vuestra manos, por la tarea que os ha encomendado tan fielmente, Dios Nuestro Señor espera de cada uno una respuesta, fuisteis realmente llamados, fuisteis realmente llamados por el Señor para colaborar en la extensión de su Reino.  
> Digo a cada uno de mis hijos, la tarea es agotadora, más debéis saber que la Madre del Cielo no se separa de vuestro lado, que la Madre os guía, que la Madre os anuncia, que la Madre os señala cual es el camino.  
> Veis hijitos míos como se esparce la mentira por doquier, gobernantes fríos e incrédulos que sólo tienen en su corazón la sed de poseer, de abarcar y tener mucho más, veis cuantos jóvenes son arrastrados a la droga y al alcohol porque el enemigo, Satanás es astuto y se vale de corazones entregados a él para sembrar el mal y el pecado por todas las naciones.  
> Cuantos almas hijitos míos, cuantas almas desconocen hoy la existencia de esta Madre, cuantos corazones desconocen verdaderamente la presencia de Dios Nuestro Señor que llama e invita a cada uno a la conversión.  
> Son tiempos de gran confusión, de mucha frialdad, de mucho odio y tenéis pues que llevar a cabo una gran misión que no podéis dejar pasar de lado.  
> El llamado es para todos los hijos, la tarea para todos los corazones, que hoy pues corazones, muchas almas sientan la voz de la Madre que os llama a todos, Argentina país Santo y Bendito, despierta, reverdece, crece, pues ha recibido de parte de Dios, Nuestro Señor una porción generosa.  
> Pido y ruego que me escuchéis en este día, en estos tiempos.  
> Meditad Mi profundísimo mensaje entre vosotros.  
> Amén. Bendito y alabado Sea el Nombre del Señor.<footer>Leed: Jeremías: C 31, V 1 al 14. &#8211; Isaías: C 55, V10. &#8211; Lamentaciones: C3, V 5 al 10. &#8211; Ester C 4, V8. &#8211; Mateo: C 22, V 19 y 20. <footer>