---
title: Mensaje 9 de abril, 2004
author: admin

date: 2004-04-09T14:15:18+00:00
abstract: |
  <img src="https://mariadelasantafe.org.ar/wp-content/uploads/2016/01/foto-sentados-368x309.jpg" alt="foto-sentados" class="alignright size-medium wp-image-3315 img-circle" />**Luego me dice la Santísima Virgen:**
  <blockquote>
  Hijo mío: Cuanto se le exige a los sacerdotes y cuan pocas son las almas que oran por ellos, cuanto se desea tener la asistencia del sacerdote y pocas almas son las que ofrecen su sacrificios y mortificaciones por ellos.
  Cada uno de mis hijos debe poner empeño y voluntad y orar por los sacerdotes, para que cada uno de ellos sean santos y verdaderamente dóciles al Señor, el enemigo, Satanás rodea hábilmente a su alrededor, da vueltas como fiera para atacar a su presa y mis hijos aún no tomáis conciencia de esta verdad.
url: /2004/mensaje-9-de-abril-2004/
thumbnail: /images/foto-sentados-1.jpg
tags: [Mensajes 2004]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/foto-sentados-1.jpg" alt="foto-sentados" class="alignright size-medium wp-image-3315 img-circle" />**Luego me dice la Santísima Virgen:**

> Hijo mío: Cuanto se le exige a los sacerdotes y cuan pocas son las almas que oran por ellos, cuanto se desea tener la asistencia del sacerdote y pocas almas son las que ofrecen su sacrificios y mortificaciones por ellos.  
> Cada uno de mis hijos debe poner empeño y voluntad y orar por los sacerdotes, para que cada uno de ellos sean santos y verdaderamente dóciles al Señor, el enemigo, Satanás rodea hábilmente a su alrededor, da vueltas como fiera para atacar a su presa y mis hijos aún no tomáis conciencia de esta verdad.  
> Pues, hoy como Madre pido la oración por los ministros de la Santa Iglesia, por su fortaleza, por su perseverancia para que sean auténtico ejemplo de la gracia recibida por manos del Señor.  
> No hagáis división y más bien orad por los sacerdotes, porque el sacerdote representa a Cristo Jesús, Mi Hijo Amadísimo.  
> Aumentad pues la oración por cada uno de ellos, para que con valor y amor reciban a todos los que hacia ellos acuden.  
> Meditad Mi profundísimo Mensaje.  
> Amén Gloria al Altísimo.  
> Leed: Génesis: C 11, V 6 al 10.  
> Levítico: C 9, V 7.  
> Números: C 12, V 10.  
> Juan: C 13, V 21.