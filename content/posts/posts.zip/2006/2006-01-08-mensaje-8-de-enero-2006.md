---
title: Mensaje, 8 de Enero, 2006
author: admin

date: 2006-01-08T14:02:13+00:00
url: /2006/mensaje-8-de-enero-2006/
tags: [Mensajes 2006]

---
**Dice la Santísima Virgen:**

> Hijos míos: Abrid vuestro corazón a la luz del Señor y no os dejéis engañare por propuestas falsas, no dejéis que vuestros corazones queden atrapados hoy en el frenesí que el mundo vive, hoy vosotros debéis predicar y anunciar a todas las naciones que el amor del Señor es Eterno, que su Misericordia es Eterna y que el Señor espera a  
> cada uno de sus hijos.  
> Hijos míos, descubrid en cada una de Mis palabras de madre todo el amor profundísimo de Mi Inmaculado Corazón.  
> Meditad Mi Mensaje.  
> Amén. Gloria a Cristo Jesús.<footer>Leed: Mateo: C 12, V 27 y 28.</footer> 

Predícalo hijo mío al mundo entero.

> Dice Jesús:  
> Hermano mío: Digo a todos tus hermanos, la  
> fragancia de Mi Sacratísimo Corazón, el perfume de Mi Sacratísimo Corazón os lo ofrezco a  
> todos por igual, os doy Mi amor en abundancia  
> porque deseo la salvación de todas las almas, porque deseo que los corazones busquen el refugio y  
> el consuelo de Mi Sacratísimo Corazón.  
> Apartad de vuestro corazón las dudas, los temores, la incertidumbre y tened plena confianza en  
> cada una de Mis palabras, abrid el paso, abrid  
> las puertas porque a todos os estoy esperando.  
> Meditad Mi Profundísimo Mensaje.  
> Amén. Gloria a Dios Mi Padre.<footer>Leed: Mateo: C 1, V 25.</footer> 

Predícalo hijo mío al mundo entero.