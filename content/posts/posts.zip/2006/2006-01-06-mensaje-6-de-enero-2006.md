---
title: Mensaje, 6 de Enero, 2006
author: admin

date: 2006-01-06T13:53:27+00:00
url: /2006/mensaje-6-de-enero-2006/
thumbnail: /images/img-msj01ene2006a.jpg
tags: [Mensajes]

---
**Dice la Santísima Virgen:**

> Hijo mío: Quiero que todos mis hijos se acerquen hacia Mi Manto Celestial, quiero y deseo que los corazones escuchen la voz de esta Madre, quiero que la humanidad comprenda hoy el significado urgente de Mis palabras, quiero que todos mis hijos se encaminen hacia Cristo Jesús, Mi Hijo Amadísimo y abandonen la frivolidad,  
> la idolatría, la oscuridad.  
> Recibid el mensaje de esta Madre y dadlo a conocer al mundo entero.  
> Son los tiempos de la Madre con cada uno de sus hijos.  
> Meditad Mi Profundísimo Mensaje.  
> Amén. Gloria a Cristo Jesús.<footer>Leed: Lucas: C 12, V 9.</footer> 

<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-escucharlavozdelsenior.jpg" alt="Escuchar la voz del Señor" class="alignright size-full wp-image-3930" />  
Predícalo hijo mío al mundo entero

**Dice Jesús:**

> Vicente hermano mío: Hablo a todos los corazones, a todas las almas porque quiero borrar el hielo, porque deseo borrar la frialdad y sembrar todo Mi amor en las almas, porque deseo tener cabida en todos los corazones, porque deseo tener lugar en los corazones.  
> Abrid las puertas a Mi voz, a Mi llamado, a Mi verdadero amor y a Mi eterna verdad.  
> Meditad Mi Profundísimo Mensaje.  
> Amén. Gloria a Dios Mi Padre.<footer>Leed: Juan: C 2, V 12 y 13.</footer> 

Predícalo hijo mío al mundo entero.