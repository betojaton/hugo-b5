---
title: Viernes 8 de Febrero en el “Campito”
date: 2013-02-08T14:30:45+00:00
url: /2013/viernes-8-febrero-en-el-campito
tags: [Mensaje, Mensajes Presencia]
---
**Dice Jesús:**  
“Hermanos míos, benditos y amados hermanos míos, os entrego Mi Sacratísimo Corazón, Mi Paz y Mi Amor, os doy Mi Verdad para que todos viváis en la verdad y así seréis auténticamente libres, os doy Mi Sacratísimo Corazón, porque en el está la paz para todos vosotros.  
Derramo Mi Divina Misericordia en todo el mundo, en todas las almas. La humanidad debe volver a Mí, y confiar en Mí. La humanidad debe volver a Mi Ley, y apartarse de las tinieblas del pecado, de la oscuridad del pecado.

La humanidad encontrará la auténtica paz cuando vuelva a Mí definitivamente. ¡Confiad, confiad, confiad! y creed en Mi tags:
	- Mensajes Presencia, en ésta tags:
	- Mensajes Presencia auténtica. Os revelo a través de Mis Palabras todo Mi Amor y toda Mi Paz.

Pongo Mis Manos sobre vuestras cabezas, para liberaros, fortaleceros y daros la paz. Ya no debe existir la división en los corazones, sino la unidad, la paz ,la concordia.  
Vengo a reunir a las ovejas, ¡a todas las ovejas! vosotros sois Mis ovejas y estáis en Mi rebaño. Yo estoy con vosotros en la barca, entonces ¡a qué teméis! Estoy con vosotros en la barca, ¡no temáis!, no temáis a las tormentas, a las pruebas y tribulaciones. ¡AQUÍ ESTOY CON VOSOTROS CONSEDIÉNDOOS MI DIVINA MISERICORDIA PARA QUE SEÁIS FUERTES, SOLDADOS FUERTES Y NO COVARDES!

Confiad en Mí. Aceptad Mis Palabras, y dejad que os conduzca por este camino, por este sendero, por este tiempo de la historia.  
¡Aquí estoy! Os doy nuevamente Mi Paz, a vosotros que sois Mis Hermanos y que sois Mis Hijos. Doy a todo el mundo la paz. Ofrezco al mundo la paz, que el mundo reciba hoy Mi Paz, Mi auténtica Paz. Creed. Creed. Creed.

Os amo. Os amo. Os amo profundamente a todos. Os amo. No dudéis de Mi Amor hacia vosotros. Os amo eternamente y vuelco Mi Preciosísima sangre en cada uno de vosotros. Confiad profundamente en Mí. Confiad y no dudéis jamás de Mi tags:
	- Mensajes Presencia entre vosotros.

Meditad. Meditad. Meditad Mis Palabras.

Os bendigo en el Nombre del Padre, y del Hijo, y del Espíritu Santo.”

[Escuchar el Mensaje][1]{.audio}

 [1]: /wp-content/themes/mdstafe2013/audio/2013/08-02-2013.mp3 "Audio del 08-02-2013"