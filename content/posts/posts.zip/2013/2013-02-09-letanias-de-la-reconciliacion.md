---
title: Letanías de la Reconciliación
author: admin

date: 2013-02-09T13:02:58+00:00
url: /2013/letanias-de-la-reconciliacion/
thumbnail: /images/image01-1.jpg
tags: [Notas]

---
<img decoding="async" loading="lazy" class="alignright size-full wp-image-1707" alt="image01" src="https://mariadelasantafe.org.ar/images/image01.jpg" width="317" height="449" />Por mi pecado, te pido perdón. **¡Señor Ten piedad!**  
Por mis palabras hirientes hacia los otros. **¡Señor Ten piedad!**  
Por mi falta de confianza en tu amor. **¡Señor Ten piedad!**  
Por mis críticas hacia mi prójimo. ** ¡Señor Ten piedad!**  
Por mi resentimiento hacia quienes me hacen sufrir. **¡Señor Ten piedad!**  
Por mi egoísmo que me hace buscar primero mi interés. **¡Señor Ten piedad!**  
Por mi indiferencia hacia el sufrimiento de los otros. **¡Señor Ten piedad!**  
Por mis infidelidades a las promesas que te hice. **¡Señor Ten piedad!**  
Por el odio que dejo habitar en mi corazón. **¡Señor Ten piedad!**  
Por negarme a perdonar a los que me hicieron daño. **¡Señor Ten piedad!**  
Por los sentimientos de venganza que dejan huella en mi alma. **¡Señor Ten piedad!**  
Por mis reacciones de violencia ante cualquier contrariedad. **¡Señor Ten piedad!**  
Por mi falta de misericordia en mis juicios hacia los otros. **¡Señor Ten piedad!**  
Por el miedo hacia lo que me puedas pedir. **¡Señor Ten piedad!**  
Por haber preferido a menudo mi voluntad a la tuya. **¡Señor Ten piedad!**  
Por los malos deseos que agitan mi imaginación. **¡Señor Ten piedad!**  
Por cerrar mi corazón a los que me piden mi amor. **¡Señor Ten piedad!**  
Por ésta tendencia al mal en la que me complazco. **¡Señor Ten piedad!**  
Por mi falta de entusiasmo para orar. **¡Señor Ten piedad!**  
Por haber aprovechado a menudo la ofrenda de tu vida sobre la cruz. **¡Señor Ten piedad!**  
Por mi pereza a servir a mis hermanos. **¡Señor Ten piedad!**  
Por encerrarme en mí mismo separándome de los otros. **¡Señor Ten piedad!**  
Por esos malos deseos y pensamientos malsanos que ofenden tu amos. **¡Señor Ten piedad!**  
Por toda mi ingratitud hacia ti. **¡Señor Ten piedad!**  
Por reusar reconciliarme contigo y con mis hermanos. **¡Señor Ten piedad!**  
Por mis complicidades con los engaños del maligno. **¡Señor Ten piedad!**  
Por el orgullo que a menudo impregna mis actos, aún los buenos. **¡Señor Ten piedad!**  
Por haber preferido muchas veces la mentira a la verdad. **¡Señor Ten piedad!**  
Por haber permanecido sordo a los gritos de ayuda de los pobres. **¡Señor Ten piedad!  
** Por haber acaparado fácilmente tantas cosas para mí y haber dado tan poco de mí mismo. **¡Señor Ten piedad!**  
Por la rebeldía contra Dios que habita en mi corazón. **¡Señor Ten piedad!**  
Por el miedo al juicio de los otros sobre mí. **¡Señor Ten piedad!**  
Por no haber testimoniado en mi vida la esperanza que hay en ti. **¡Señor Ten piedad!**  
Por haber creído tan poco que tú eres la resurrección y la Vida. **¡Señor Ten piedad!**