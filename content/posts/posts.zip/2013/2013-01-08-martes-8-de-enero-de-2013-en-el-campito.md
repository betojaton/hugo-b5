---
title: Martes 8 de enero, 2013 en el “Campito”
date: 2013-01-08T12:31:43+00:00
url: /2013/martes-8-enero-2013-en-el-campito/
thumbnail: /images/image05-1.jpg
tags: 
  - Mensajes
  - Mensajes Presencia

---
**Dice la Santísima Virgen:**  
“Hijos míos benditos y amados hijos míos, llegad siempre a esta Madre, acudid a esta Madre, porque la Madre es puente hacia Jesús. Buscad en Mis brazos maternales todas las respuestas, buscad en el ROSARIO todas las respuestas.

<figure id="attachment_1710" aria-describedby="caption-attachment-1710" style="width: 390px" class="wp-caption alignright"><img decoding="async" loading="lazy" class=" wp-image-1710" alt="image05" src="https://mariadelasantafe.org.ar/images/image05.jpg" width="390" height="252" /><figcaption id="caption-attachment-1710" class="wp-caption-text">“Veneramos a Nuestra Madre del Cielo, bajo la advocación de la Inmaculada de Garay, hasta que se realice la Imagen de ‘María de la Santa Fe”</figcaption></figure>

Agradezco vuestra presencia, y os bendigo en forma especial, y bendigo a todos esos hijos que por un motivo u otro no han podido llegar, Mi corazón de Madre esta con todos los hijos, Mi corazón de madre se abre para todos los hijos y Mi Manto Celestial os cubre en forma especial.

Debéis mirar Mi corazón de Madre que tantas veces, que muchas veces, que innumerables veces esta cubierto de espinas, muchas espinas y os pido a vosotros que con vuestra oración, que con vuestros buenos actos y vuestras obras de caridad saquéis las espinas de Mi corazón.

LLORO ABUNDANTEMENTE POR LOS HIJOS QUE SIGUEN EL CAMINO EQUIVOCADO Y EXTRAVIADO, QUE SIGUEN EL CAMINO DEL MAL QUE SE ALEJAN DE MIS BRAZOS MATERNALES PARA SEGUIR EL CAMINO DE LA OSCURIDAD Y DEL PECADO, EL CAMINO QUE CONDUCE AL ABISMO ETERNO, SOLAMENTE EN JESÚS, EN CRISTO JESÙS MI HIJO AMADÍSIMO ESTA LA SALVACIÓN, NO EN OTROS CAMINOS QUE NO SON LOS VERDADEROS, QUE SON CAMINOS DE MUERTE Y OSCURIDAD, POR ESO ACUDID A LA MADRE Y SIEMPRE TOMAOS DE MIS MANOS PARA QUE AVANZEIS POR ESTE CAMINO.

Veo mucho dolor, en muchos corazones, tristeza, mucho dolor, esta Madre esta aquí para consolaros, para ayudaros y para deciros que el amor del Señor esta presente con vosotros que el amor y la misericordia del Padre se derrama sobre todo los hijos.

Vosotros sois privilegiados, aprovechad estos momentos, vivid estos momentos tan especiales con la Madre.

El cielo desciende a la tierra, para bendeciros y concederos las gracias que estáis necesitando, Mis palabras maternales son para vosotros y para el mundo entero, que el mundo las conozca, que el mundo en definitiva ya cambie de la vida de pecado a la vida de gracia, que Mis hijos escuchen, atiendan y pongan en practica Mis palabras.

Solamente os pido, rezad mucho el Santo Rosario, todos los días con mucha fuerza y veréis cuantos caminos comienzan a abrirse, cuantas puertas comienzan a derribarse, veréis y seréis testigos de todas Mis palabras.

Meditad. Meditad. Meditad Mis palabras.”

<p dir="ltr">
  **<img decoding="async" loading="lazy" class="alignright size-full wp-image-1707" alt="image01" src="https://mariadelasantafe.org.ar/images/image01.jpg" width="317" height="449" />Dice Jesús:<br /> **“Hermanos míos, benditos y amados hermanos míos. ABRO MI CORAZÓN PARA BENDECIROS, DERRAMO MI PRECIOSÍMA SANGRE PARA FORTALECEROS, DEBÉIS SER SOLDADOS FUERTES Y NO COBARDES Y LUCHAR EN EL MUNDO, PORQUE VUELCO MI AMOR Y MI DIVINA MISERICORDIA EN VOSOTROS, EN VUESTRAS FAMILIAS, PORQUE OS ESCUCHO Y OS  VEO Y ATIENDO A VUESTRAS PETICIONES.


<p dir="ltr">
  Estoy aquí demostrando Mi amor a las almas, demostrando Mi amor a todos los corazones del mundo, a los que creen y a los que no creen, a los que aceptan y a los que rechazan Mi presencia, a todos demuestro Mi amor y Mi Divina Misericordia que no se extingue, que es infinita y cae en todas las almas. Vengan pues todas las almas a Mi, todos los corazones lleguen en definitiva hacia Mi Sacratísimo Corazón donde esta la paz verdadera, la paz que sana y fortalece, la paz que destruye las enfermedades, tantas veces físicas y espirituales, gozad de Mi paz, disfrutad  de Mi paz, vivid en paz, todos los días de vuestra vida.


<p dir="ltr">
  No juzguéis jamás, para no ser juzgados. Consolad a los que sufren, socorred a los enfermos, asistid a los desvalidos, dad la mano a los que sufren, y tanto, en el mundo, para eso os convoqué, para eso os llame, para que deis testimonio de Mis palabras con vuestros hermanos, con todos Mis  hermanos, para que llevéis Mi amor a las almas que lo necesitan, a los corazones que lo necesitan,


<p dir="ltr">
  Ya es el momento, ya es la hora, ya es el tiempo de que las almas conozcan Mi presencia, acepten Mis palabras y se conviertan definitivamente y salgan de la oscuridad para vivir en la luz, en la luz de la gracia.


<p dir="ltr">
  En este momento, a esta hora derramo Mi Preciosísima Sangre sobre vosotros y pongo Mis manos sanadoras en vuestras cabezas para daros Mi calor, Mi fuerza y Mi paz, para daros todo Mi amor


<p dir="ltr">
  Ya el mundo no debe juzgar Mis palabras, ya la humanidad no debe juzgar Mis palabras, todos debéis  llegar a Mí y sentir Mí presencia Misericordiosa en lo profundo de vuestro corazón,


<p dir="ltr">
  Aquí estoy porque soy mis ovejas y os vengo a conducir por las verdes praderas de Mi Sacratísimo Corazón, donde encontrareis el agua de vida eterna para calmar vuestra sed, vuestra sed de justicia, vuestra sed en lo profundo de vuestro corazón.


<p dir="ltr">
  Escuchad Mis palabras, sentid Mi presencia que llega para sanar y liberar, para fortalecer, para enriquecer, creed en Mis palabras, sed mensajeros de Mi amor en el mundo entero.


<p dir="ltr">
  OS AMO, OS AMO, OS AMO INFINITAMENTE a todos, ETERNAMENTE a todos.


<p dir="ltr">
  Meditad. Meditad. Meditad Mis palabras.


<b id="internal-source-marker_0.3702675097156316">Os bendigo en el nombre del Padre, y del Hijo y del Espíritu Santo. Amén.”</b>

[Escuchar el Mensaje][1]{.audio}

 [1]: /wp-content/themes/mdstafe2013/audio/2013/08-01-2013.mp3 "Audio del 08-01-2013"