---
title: Sábado 8 de Junio, 2013
date: 2013-06-08T15:25:15+00:00
url: /2013/sabado-8-junio-2013/
audio:
  - /wp-content/themes/mdstafe2013/audio/2013/08-06-2013.mp3
fecha-audio:
  - 08-06-2013
tags:
  - Mensajes 2013
  - Mensajes Presencia

---
**Dice la Santísima Virgen:** “Hijos míos, Benditos y amados hijos míos aquí nuevamente la Madre se manifiesta con vosotros, nuevamente vengo desde el cielo a traeros el mensaje del Señor para que todos vosotros caminéis en la luz y llevéis la luz a todas las almas, para que haya una conversión definitiva en todos los corazones y toda la humanidad viva en la verdad, se entregue a la verdad y sean testigos de la verdad.

La Madre se manifiesta con todos los hijos y a todos vosotros Mí manto celestial los cubre, a vosotros y a vuestra familias.

La Madre ama a todos los hijos y por todos los hijos se desvela y ningún hijo queda lejano a ésta Madre, porque la Madre va en auxilio de todos sus hijos.

Vosotros estáis aquí con la Madre y quiero que llevéis Mí palabra maternal a todos los corazones, a los enfermos, a los tristes, a los desamparados, a los ancianos, a los niños, a todos llevad Mí palabra maternal. Invitad a los hijos, a todos Mis hijos a la oración, no dejéis de rezar nunca, vosotros debéis rezar, por la paz, por la unidad de las familias, por la paz del mundo, por la paz de todos los corazones.

Rezad mucho el Santo Rosario todos los días y veréis que la paz va ganando terreno en los corazones. Luchad y trabajad por la paz y seguid a esta Madre que os conduce a todos hacia Cristo Jesús Mi Hijo Amadísimo.

Rezad mucho os los pide Mí Inmaculado Corazón.

Meditad. Meditad. Meditad Mis palabras.”

**Dice Jesús:** “Hermanos míos, benditos y amados hermanos míos, os entrego Mí Sacratísimo Corazón, en vuestras manos, abrid vuestras manos, recibid Mí Sacratísimo Corazón y llevadlo a vuestro corazón, sentid Mí presencia, Mí amor y Mí paz dentro de vosotros, sentid la luz de Mi Divina Misericordia que os va transformando, que os va modelando.

Aquí estoy con vosotros, aquí estoy con Mí Divina Misericordia, derramando a manos llenas en el mundo entero, derramando Mí paz sobre todas las almas, en Mí corazón hallareis la paz, en Mí corazón hallareis la verdad y el consuelo, no os sintáis tristes, ni agobiados, no os sintáis indignos.

Sentid Mí presencia con vosotros, os vengo a hablar de Mí amor y a reunir en un solo rebaño, porque todos sois mis ovejas, todos estáis junto a Mí y yo soy el Buen Pastor que os vengo a conducir.  
Llegad a Mí si estáis agobiados, llegad a Mí en todo momento y percibid el bálsamo de Mis Sacratísimas Llagas, el bálsamo que es Mí Preciosísima Sangre, que en éste momento derramo en vosotros para sanaros, fortaleceros y liberaros.

Confiad en Mí, confiad, no dudéis, confiad y sed fieles a Mis palabras, sed fieles a Mí llamado, sed fieles a Mí amor, estoy aquí, os conduzco y todos vosotros estáis en la barca.
Junto a Mí, no dudéis de Mis palabras. Creed en Mis palabras y llegad a Mí.

Os amo, os amo profundisimamente, os amo.

Meditad. Meditad. Meditad Mis palabras.

Os bendigo en el nombre del Padre y del Hijo y del Espíritu Santo. Amén.”