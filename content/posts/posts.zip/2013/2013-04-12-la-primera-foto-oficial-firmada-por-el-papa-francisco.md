---
title: Foto del Papa Francisco
author: admin

date: 2013-04-12T12:27:31+00:00
abstract: '<a class="thickbox" href="https://mariadelasantafe.org.ar/wp-content/uploads/2013/04/foto-firmada-papa-franscisco.jpg"><img class="alignleft size-full wp-image-1795" alt="foto-firmada-papa-franscisco" src="https://mariadelasantafe.org.ar/wp-content/uploads/2013/04/foto-firmada-papa-franscisco.jpg" width="368" height="auto" /></a><h4>La primera foto oficial firmada por el Papa Francisco</h4>'
url: /2013/la-primera-foto-oficial-firmada-por-el-papa-francisco/
thumbnail: /images/foto-firmada-papa-franscisco-1.jpg
tags: [Notas]

---
#### [<img decoding="async" loading="lazy" class="alignleft  wp-image-1795" alt="foto-firmada-papa-franscisco" src="https://mariadelasantafe.org.ar/images/foto-firmada-papa-franscisco.jpg" width="456" height="672" />][1]{.thickbox}La primera foto oficial firmada por el Papa Francisco

VATICANO, 21 Mar. 13 / 11:47 am (<a href="http://www.aciprensa.com/" target="_self" rel="noopener"><b>ACI/EWTN Noticias</b></a>).- Hoy se dio a conocer la primera foto oficial firmada por el Papa Francisco, que ha sido difundida por las redes sociales.

En esta fotografía se ve al Papa con su habitual vestimenta blanca, la [cruz][2] pectoral y con su sonrisa sencilla.

Al pie de la imagen, se lee &#8220;Francisco, 13 de marzo de 2013&#8221;. Con su nombre y la fecha de su elección como sucesor de San Pedro, el humilde rostro del &#8220;Papa del pueblo&#8221;, como algunos han comenzado a llamarle, recorre el mundo.

En sus primeros días en el Vaticano, el Santo Padre no ha dejado de sorprender al mundo con su sencillez: [anduvo en bus con los demás cardenales][3], como uno más; [llamó personalmente a la casa general de los jesuitas][4] en Roma, a su [vendedor de periódico en Buenos Aires][5] y a los [jóvenes que en una vigilia rezaban por él el 19 de marzo cuando celebró la Misa de inicio de su pontificado][6].

El Papa Francisco también ha dado una serie de mensajes claros al mundo: a los periodistas les recordó que la [Iglesia no tiene una naturaleza política sino profundamente espiritual][7], a los [cardenales][8] les recordó que si no confesamos a Cristo &#8220;la cosa no va&#8221;; y a todos no ha dejado de pedir que recen por él.

Nota Original: [http://www.aciprensa.com/noticias/vaticano-presenta-primera-foto-oficial-del-papa-francisco-64000/#.UWv_][9]

 [1]: https://mariadelasantafe.org.ar/images/foto-firmada-papa-franscisco.jpg
 [2]: http://www.aciprensa.com/Catecismo/lacruz.htm
 [3]: http://www.aciprensa.com/noticias/el-papa-francisco-sigue-usando-el-autobus-91931/
 [4]: http://www.aciprensa.com/noticias/el-papa-francisco-sorprende-a-portero-de-los-jesuitas-con-llamada-telefonica-56164
 [5]: http://www.aciprensa.com/noticias/francisco-llama-y-sorprende-a-su-vendedor-de-periodico-en-buenos-aires-40253/
 [6]: http://www.aciprensa.com/noticias/papa-francisco-a-jovenes-en-argentina-cuidense-los-unos-a-los-otros-51111/
 [7]: http://www.aciprensa.com/noticias/papa-francisco-a-periodistas-la-iglesia-no-es-de-naturaleza-politica-sino-espiritual-21285/
 [8]: http://www.aciprensa.com/Cardenales
 [9]: http://www.aciprensa.com/noticias/vaticano-presenta-primera-foto-oficial-del-papa-francisco-64000/#.UWv_ "Ver Nota original"