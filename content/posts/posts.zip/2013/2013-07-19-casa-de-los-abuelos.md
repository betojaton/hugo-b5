---
title: Casa de los Abuelos
author: admin

date: 2013-07-19T20:39:03+00:00
url: /2013/casa-de-los-abuelos/
thumbnail: /images/id-2043.jpg
tags: [Colaboraciones]

---
18/10/2013 (Anexo &#8220;Amor y Esperanza&#8221;), 19/07/2013

<img decoding="async" class="ngg_displayed_gallery mceItem" alt="" src="https://mariadelasantafe.org.ar/images/id-2043.jpg" />