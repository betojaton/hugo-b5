---
title: Hogar Amor y Esperanza – Asoc. Mutual Ley 5110
author: admin

date: 2013-03-06T00:33:55+00:00
url: /2013/hogar-amor-y-esperanza-asociacion-mutual-ley-5110/
tags: [Colaboraciones]

---
##### 05/03/2013, 20/07/2010, 12/10/2010

<!-- default-view.php -->

<div
	class="ngg-galleryoverview default-view "
	id="ngg-gallery-1baf22975ff44c438412bd6706bb6c8f-1">
  <!-- Thumbnails -->
  
  <div id="ngg-image-0" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-amor/hogar_amor_y_esperanza01.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-amor/hogar_amor_y_esperanza01.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-amor/thumbs/thumbs_hogar_amor_y_esperanza01.jpg"
               data-image-id="64"
               data-title="hogar_amor_y_esperanza01"
               data-description=""
               data-image-slug="hogar_amor_y_esperanza01"
               class="ngg-simplelightbox" rel="1baf22975ff44c438412bd6706bb6c8f"> <img
                    title="hogar_amor_y_esperanza01"
                    alt="hogar_amor_y_esperanza01"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-amor/thumbs/thumbs_hogar_amor_y_esperanza01.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-1" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-amor/hogar-amoryesperanza-01.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-amor/hogar-amoryesperanza-01.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-amor/thumbs/thumbs_hogar-amoryesperanza-01.jpg"
               data-image-id="210"
               data-title="hogar-amoryesperanza-01"
               data-description=""
               data-image-slug="hogar-amoryesperanza-01"
               class="ngg-simplelightbox" rel="1baf22975ff44c438412bd6706bb6c8f"> <img
                    title="hogar-amoryesperanza-01"
                    alt="hogar-amoryesperanza-01"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-amor/thumbs/thumbs_hogar-amoryesperanza-01.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-2" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-amor/hogar-amoryesperanza-02.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-amor/hogar-amoryesperanza-02.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-amor/thumbs/thumbs_hogar-amoryesperanza-02.jpg"
               data-image-id="211"
               data-title="hogar-amoryesperanza-02"
               data-description=""
               data-image-slug="hogar-amoryesperanza-02"
               class="ngg-simplelightbox" rel="1baf22975ff44c438412bd6706bb6c8f"> <img
                    title="hogar-amoryesperanza-02"
                    alt="hogar-amoryesperanza-02"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-amor/thumbs/thumbs_hogar-amoryesperanza-02.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-3" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-amor/hogar-amoryesperanza-03.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-amor/hogar-amoryesperanza-03.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-amor/thumbs/thumbs_hogar-amoryesperanza-03.jpg"
               data-image-id="212"
               data-title="hogar-amoryesperanza-03"
               data-description=""
               data-image-slug="hogar-amoryesperanza-03"
               class="ngg-simplelightbox" rel="1baf22975ff44c438412bd6706bb6c8f"> <img
                    title="hogar-amoryesperanza-03"
                    alt="hogar-amoryesperanza-03"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-amor/thumbs/thumbs_hogar-amoryesperanza-03.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <br style="clear: both" /> <!-- Pagination -->
  
  <div class='ngg-clear'>
  </div>
</div>