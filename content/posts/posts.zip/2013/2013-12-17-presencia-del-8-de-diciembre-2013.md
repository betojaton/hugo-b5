---
title: Domingo 8 de diciembre, 2013
date: 2013-12-17T15:07:03+00:00
url: /2013/presencia-domingo-8-diciembre-2013/
thumbnail: /images/corazon-jesus-luminoso-1.jpg
audio:
  - /wp-content/themes/mdstafe2013/audio/2013/08-12-2013.mp3
fecha-audio:
  - 08-12-2013
tags: [Mensajes, Mensajes Presencia]

---
![Corazon de Jesus](/images/corazon-jesus-luminoso.jpg)

**Dice la Santísima Virgen:** Hijos míos: gracias por estar nuevamente junto a la Madre. Gracias por seguir a esta Madre, por llegar a los brazos de ésta Madre. La Madre que es puente hacia Jesús, camino directo hacia Jesús.

Veo hijitos míos, vuestros corazones, vuestras necesidades y peticiones. No debéis afligiros y debéis confiar en la tags:
	- Mensajes Presencia Maternal de María, que viene a hablar a los hijos de la oración; que viene a pedir a todos los hijos la oración.

¡Hijitos míos! ¡Hijitos amadísimos! ¡Aquí está la Madre! esta Madre que os viene a socorrer que viene a levantar vuestro corazón, vuestro espíritu, que viene a daros fuerza para que sigáis el camino de Jesús; para que no abandonéis y nunca bajéis los brazos, frente a las dificultades.

Tomad cada uno vuestra cruz, y seguid el camino de Jesús; seguid al Buen Pastor que es Cristo Jesús Mi Hijo Amadísimo, que está dando a toda la humanidad, los rayos de Su Divina Misericordia, para que todos los hijos, todos los corazones, vuelvan hacia la paz, hacia la verdad, hacia la caridad.

Rezad **TODOS LOS DÍAS EL SANTÍSIMO ROSARIO**, y pedid la unidad en las familias, la paz en los corazones, la paz en las conciencias. Rezad y pedid mucho, pedid la luz del Espíritu Santo, para todas las decisiones que debáis tomar en vuestro camino.

Meditad. Meditad. Meditad Mis Palabras.

**Dice Jesús:** Hermanos Míos; benditos y amados hermanos míos, os abrazo a todos, os abrazo y pongo Mi Sacratísimo Corazón en vuestro corazón, para daros la paz, para daros el consuelo, para serenar vuestro espíritu. Os abrazo en forma especial, y derramo a manos llenas mi amor en vosotros y en el mundo entero.

Aún hoy ¡hay tantas almas que rechazan mi amor!¡ hay tantos corazones que prefieren los caminos tortuosos del mundo ¡y se apartan de mi lado, se apartan de mi amor, se apartan de mi verdad.

Llamo a mis ovejas a todas las ovejas, convoco a todos los corazones. Llamo a mis hermanos y quiero una definitiva conversión. Os doy todos los medios, os doy todas las posibilidades; ¡No rechacéis jamás Mi Mano Misericordiosa! ¡No rechacéis jamás este amor que cae en forma abundantes sobre vosotros!

Os amo. Os amo. Os amo; **porque sois Mis hermanos, porque sois Mis hijos.** ¡Os amo infinitamente y pongo Mis Manos en vuestras cabezas, para sanaros y liberaros! Para que sintáis en lo profundo de vuestro corazón, mi Real tags:
	- Mensajes Presencia.

¡No os sintáis indignos! Sois Mis ovejas y os llamé a cada uno de vosotros por vuestros nombres, para estar hoy junto a Mí, AQUÍ, a Mi lado. Os llamé, os busqué, os busqué por toda la tierra, os llamé por vuestros nombres, y no debéis dudar jamás de mi amor hacia vosotros.

Os doy Mi Paz, os concedo Mi Paz, os doy Mi Amor, trabajad por el amor, por la paz, por la verdad.

**¡Que ya terminen las guerras, las divisiones! ¡Que ya termine el odio! ¡Que ya termine definitivamente la competencia y reine la verdad, el amor, la caridad!**

Sed humildes, haceos pequeños y permaneced junto a Mí en la barca y en Mi rebaño.

¡Benditos seáis vosotros que estáis escuchando Mis Palabras!.

¡Benditos seáis vosotros que estáis recibiendo Mi Bendición!

¡Benditos seáis vosotros que abrís el corazón para meditar en cada una de Mis Palabras!

¡**Aquí estoy**, no lo dudéis! Os doy nuevamente Mi Paz.

Os amo. Os amo. Os amo. Seguid Mi Camino. Seguid Mis Pasos. Seguid Mis Palabras.

Meditad. Meditad. Meditad Mis Palabras.

Os bendigo en el Nombre del Padre y del Hijo, y del Espíritu Santo. Amén.