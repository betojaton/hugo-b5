---
title: Domingo 8 de Septiembre de 2013 en el “Campito”
author: admin

date: 2013-09-08T16:06:42+00:00
abstract: |
  **Dice la Santísima Virgen: **
  
  “Hijos Míos; benditos y amados hijos Míos, abro Mis Brazos para recibiros a todos vosotros, abro Mis Brazos para cobijaros en ellos y daros el consuelo y la serenidad para vuestros corazones.
  
  <img class="alignright size-full wp-image-2067" alt="paloma-virgen-arrodillada" src="https://mariadelasantafe.org.ar/wp-content/uploads/2013/10/paloma-virgen-arrodillada.jpg" width="189" height="267" />
  Aquí está la Madre con todos los hijos y toda la humanidad debe responder a mi pedido: oración, la oración de cada día, los hijos, Mis hijos deben volcarse cada día a la oración y suplicar y pedir la paz, la paz para todos los corazones.
  
  La Madre, ésta Madre llora abundantemente, ésta Madre llora cuando los hijos están divididos, cuando los corazones están separados, cuando toda la humanidad está separada, por guerras inútiles. Mis lágrimas caen sobre la faz de la tierra y quiero que todos mis hijos vean Mis lágrimas y tengan compasión de mi dolor maternal.
  
  Mi Corazón Inmaculado está cubierto de espinas por eso os pido hijitos Míos, rezad, rezad mucho, haced penitencias y sacrificios y buscad siempre la luz de Cristo Jesús Mi
  
  Hijo Amadísimo.
  
  Aquí estoy ayudándoos, aquí estoy acompañándoos a cada uno de vosotros, nunca digáis que Dios no os escucha, el Señor siempre está atento a las necesidades de todos sus hijos. Esperad y confiad en el Señor, esperad y confiad en Su Divina Providencia,
  
  Hijitos míos, escuchad a ésta Madre y haced conocer todas Mis Palabras.
  
  Meditad. Meditad. Meditad Mis Palabras.”
url: /2013/domingo-8-de-septiembre-de-2013-en-el-campito/
thumbnail: /images/paloma-virgen-arrodillada-1.jpg
audio:
  - /wp-content/themes/mdstafe2013/audio/2013/08-09-2013.mp3
fecha-audio:
  - 08-09-2013
tags: [Mensajes 2013]

---
<img decoding="async" loading="lazy" class="alignright size-full wp-image-2067" alt="paloma-virgen-arrodillada" src="https://mariadelasantafe.org.ar/images/paloma-virgen-arrodillada.jpg" width="189" height="267" />

**Dice la Santísima Virgen:** 

“Hijos Míos; benditos y amados hijos Míos, abro Mis Brazos para recibiros a todos vosotros, abro Mis Brazos para cobijaros en ellos y daros el consuelo y la serenidad para vuestros corazones.

Aquí está la Madre con todos los hijos y toda la humanidad debe responder a mi pedido: oración, la oración de cada día, los hijos, Mis hijos deben volcarse cada día a la oración y suplicar y pedir la paz, la paz para todos los corazones.

La Madre, ésta Madre llora abundantemente, ésta Madre llora cuando los hijos están divididos, cuando los corazones están separados, cuando toda la humanidad está separada, por guerras inútiles. Mis lágrimas caen sobre la faz de la tierra y quiero que todos mis hijos vean Mis lágrimas y tengan compasión de mi dolor maternal.

Mi Corazón Inmaculado está cubierto de espinas por eso os pido hijitos Míos, rezad, rezad mucho, haced penitencias y sacrificios y buscad siempre la luz de Cristo Jesús Mi

Hijo Amadísimo.

Aquí estoy ayudándoos, aquí estoy acompañándoos a cada uno de vosotros, nunca digáis que Dios no os escucha, el Señor siempre está atento a las necesidades de todos sus hijos. Esperad y confiad en el Señor, esperad y confiad en Su Divina Providencia,

Hijitos míos, escuchad a ésta Madre y haced conocer todas Mis Palabras.

Meditad. Meditad. Meditad Mis Palabras.”

&nbsp;

**Dice Jesús:** 

“Hermanos Míos, benditos y amados hermanos míos, hoy nuevamente vuelco Mi Preciosísima Sangre sobre vosotros, vuelco Mi Amor y Mi Divina Misericordia, no estáis solos, Mi Corazón Sacratísimo os guía, Mi Corazón Sacratísimo os bendice.  
Aquí estoy para daros Mi paz, para que viváis en la paz, para que sintáis en lo profundo de vuestro corazón, Mi tags:
	- Mensajes Presencia, sois Mis ovejas, que estáis en Mi rebaño. Sois Mis ovejas y vengo a conduciros a todos, vengo a conduciros a todos, vengo a conduciros en el camino de la verdad y de la unidad. Confiad en Mí cada día.  
Rezad y pedid y no dejéis de lado Mi camino, seguid Mis pasos, seguid la Luz de Mi Divina Misericordia, seguid caminando junto a Mí, y no temáis, porque siempre estoy con vosotros, siempre estoy en la barca, junto a cada uno de vosotros.

Mi amor se vuelca en éste momento, Mi amor, Mi paz, Mi verdad, os amo a todos os amo profundísimamente y todos estáis dentro de Mi Sacratísimo Corazón.  
Venid a Mí si estáis agobiados, si estáis cansados, si tenéis dolor, tristeza, angustia; estoy aquí para daros la fuerza, para daros a cada uno de vosotros la fuerza, para que sigáis caminando, junto a Mí, por éste camino verdadero, por éste camino de Dios y de paz.

El mundo necesita de vuestras palabras, de vuestro ejemplo, de vuestro SI, el mundo necesita de cada uno de vosotros, necesita el mundo de vuestras manos, de vuestro corazón, de vuestra entrega.

Hay tantas almas, y tantos corazones que no conocen esta verdad, que no perciben ésta realidad, que están sumergidos en las tinieblas. Id hacia el mundo, ayudad a los hermanos, dad el corazón a vuestros hermanos, no neguéis el corazón a ninguno de vuestros hermanos.  
Sed humildes, sencillos, trabajadores, haceos pequeños, y vais a comprender cada una de Mis palabras. Os amo a todos hijitos Míos, os amo a todos hermanitos Míos, confiad profundamente en Mí, recibid los rayos de Mi Divina Misericordia, percibid Mi presencia junto a vosotros.  
Pongo Mis manos de Sanación, sobre vuestras cabezas, Mis manos, para sanaros, fortaleceros y daros toda la fuerza; para que seáis liberados y trabajéis todos por Mi Santa Obra.

Estoy aquí, en esta tierra, Santa, en ésta tierra Bendita. Estoy aquí, todos debéis venir a Mí, todos debéis llegar a Mí.”Meditad. Meditad. Meditad Mis palabras. Os bendigo, en el nombre del Padre y del Hijo y del Espirita Santo. Amén”