---
title: Mensajes Presencias de Jesús y “Maria de la Santa Fe”
date: 2013-05-08T19:34:38+00:00
url: /2013/presencias-de-jesus-y-maria-de-la-santa-fe
---
<div class="ngg-galleryoverview ngg-slideshow"
	 id="ngg-slideshow-c83bbe933b543cded797bb680a9a654c-3790521050"
     data-gallery-id="c83bbe933b543cded797bb680a9a654c"
     style="max-width: 750px; max-height: 500px;">
  <div id="ngg-image-0" class="ngg-gallery-slideshow-image" style="height:500px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/presencia-08-05-13/2013-05-010.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/presencia-08-05-13/2013-05-010.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/presencia-08-05-13/thumbs/thumbs_2013-05-010.jpg"
           data-image-id="220"
           data-title="2013-05-010"
           data-description=""
           class="ngg-simplelightbox" rel="c83bbe933b543cded797bb680a9a654c"> <img data-image-id='220'
                 title=""
                 alt="2013-05-010"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/presencia-08-05-13/2013-05-010.jpg"
                 style="max-height: 480px;" /> </a>
  </div>
  
  <div id="ngg-image-1" class="ngg-gallery-slideshow-image" style="height:500px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/presencia-08-05-13/2013-05-011.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/presencia-08-05-13/2013-05-011.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/presencia-08-05-13/thumbs/thumbs_2013-05-011.jpg"
           data-image-id="221"
           data-title="2013-05-011"
           data-description=""
           class="ngg-simplelightbox" rel="c83bbe933b543cded797bb680a9a654c"> <img data-image-id='221'
                 title=""
                 alt="2013-05-011"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/presencia-08-05-13/2013-05-011.jpg"
                 style="max-height: 480px;" /> </a>
  </div>
  
  <div id="ngg-image-2" class="ngg-gallery-slideshow-image" style="height:500px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/presencia-08-05-13/2013-05-016.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/presencia-08-05-13/2013-05-016.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/presencia-08-05-13/thumbs/thumbs_2013-05-016.jpg"
           data-image-id="222"
           data-title="2013-05-016"
           data-description=""
           class="ngg-simplelightbox" rel="c83bbe933b543cded797bb680a9a654c"> <img data-image-id='222'
                 title=""
                 alt="2013-05-016"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/presencia-08-05-13/2013-05-016.jpg"
                 style="max-height: 480px;" /> </a>
  </div>
  
  <div id="ngg-image-3" class="ngg-gallery-slideshow-image" style="height:500px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/presencia-08-05-13/2013-05-017.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/presencia-08-05-13/2013-05-017.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/presencia-08-05-13/thumbs/thumbs_2013-05-017.jpg"
           data-image-id="223"
           data-title="2013-05-017"
           data-description=""
           class="ngg-simplelightbox" rel="c83bbe933b543cded797bb680a9a654c"> <img data-image-id='223'
                 title=""
                 alt="2013-05-017"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/presencia-08-05-13/2013-05-017.jpg"
                 style="max-height: 480px;" /> </a>
  </div>
  
  <div id="ngg-image-4" class="ngg-gallery-slideshow-image" style="height:500px">
    <a href="https://mariadelasantafe.org.ar/wp-content/gallery/presencia-08-05-13/dsc06911-001.jpg"
           title=""
           data-src="https://mariadelasantafe.org.ar/wp-content/gallery/presencia-08-05-13/dsc06911-001.jpg"
           data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/presencia-08-05-13/thumbs/thumbs_dsc06911-001.jpg"
           data-image-id="224"
           data-title="dsc06911-001"
           data-description=""
           class="ngg-simplelightbox" rel="c83bbe933b543cded797bb680a9a654c"> <img data-image-id='224'
                 title=""
                 alt="dsc06911-001"
                 src="https://mariadelasantafe.org.ar/wp-content/gallery/presencia-08-05-13/dsc06911-001.jpg"
                 style="max-height: 480px;" /> </a>
  </div>
</div>