---
title: Lunes 8 de Julio, 2013
date: 2013-07-08T12:28:32+00:0
url: /2013/lunes-8-julio-2013/
thumbnail: /images/maria-madre-de-dios-1.jpg
audio:
  - /wp-content/themes/mdstafe2013/audio/2013/08-07-2013.mp3
fecha-audio:
  - 07-07-2013
tags: [Mensaje 2013, Mensajes Presencia]

---
**<img decoding="async" loading="lazy" class="alignright size-medium wp-image-1377" alt="maria-madre-de-dios" src="https://mariadelasantafe.org.ar/images/maria-madre-de-dios-300x236.jpg" width="300" height="236" />Dice la Santísima Virgen:** 

“Hijos míos, benditos y amados hijos míos, nuevamente esta Madre agradece vuestra presencia, nuevamente esta Madre se manifiesta junto a vosotros.

No debéis temer porque la Madre, con su Manto Celestial, os cuida y os protege a cada uno de vosotros. Estáis en Mí regazo Maternal y Mí Corazón Inmaculado es el puente, el medio, para que todos lleguéis a Cristo Jesús Mí Hijo Amadísimo.

No bajéis los brazos, jamás dejéis hijitos míos que la tristeza se adueñe de vuestro corazón, no dejéis que el maligno os perturbe, por eso Mí insistencia maternal a que todos recéis, todos los días el Santo Rosario, estaréis protegidos de los planes macabros de Satanás. Rezad hijos míos, rezad y abrid vuestro corazón siempre a Mis palabras y Mis enseñanzas maternales, así conoceréis en profundidad a Cristo Jesús Mi Hijo Amadísimo, así conoceréis todo el amor del Señor para cada uno de vosotros.

Estáis en esta tierra Santa y Bendita, estáis junto a la Madre y la Madre permanece a vuestro lado siempre. Os entrego en vuestras manos al Niñito Jesús, pongo en vuestras manos al Niñito Jesús y llevadlo a vuestro corazón y allí recordareis todos los días de vuestras vidas cada una de Mis palabras.

Sentid el perfume de Mis rosas, que son las gracias que esta Madre os concede a cada uno de vosotros. Rezad. Rezad. Rezad, y fortaleced el corazón, sed fuertes y nuca bajéis los brazos en la lucha. Meditad. Meditad. Meditad Mis palabras”.

&nbsp;

**Dice Jesús:** 

“Hermanos míos, benditos y amados hermanos míos. Mi Sacratísimo Corazón os bendice. Mi Sacratísimo Corazón derrama su misericordia en vosotros. Sentid vosotros Mí presencia.

Sentid que Mi amor está sobre vosotros, que Mí paz llega a vosotros, para que todos seáis mensajeros de la paz, testigos de Mí paz, trabajadores de la paz. Os hablo de Mí amor, de Mí infinita Misericordia para con el mundo entero.

Os hablo de éste amor que os sana, os libera, os cura de vuestro pasado.

Olvidad el pasado, vivid éste presente y sentid como Mis manos de sanación se posan sobre vosotros.

<img decoding="async" loading="lazy" class=" wp-image-1366 alignleft" alt="mano" src="https://mariadelasantafe.org.ar/images/FeRFV8DTw58a.jpg" width="193" height="240" /> 

Sentid que Mis palabras llegan a lo profundo de vuestro corazón para que así deis fruto y en abundancia. Seguid Mí camino, tomad vuestra cruz, seguid Mis pasos, seguid a Mí lado, no me abandonéis, seguid junto a Mí.

Seguid todos los días de vuestra vida.

Os amo profundamente. Os amo que ya nadie dude de Mí presencia, de Mí amor y de Mí infinita misericordia para con el mundo entero.

Meditad. Meditad. Meditad Mis palabras.

Os bendigo en el nombre del Padre y del Hijo y del Espíritu Santo. Amén”