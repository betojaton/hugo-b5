---
title: Gracias Peregrinos por sus Colaboraciones!
author: admin

date: 2013-01-25T22:08:50+00:00
url: /2013/gracias-peregrinos-por-sus-colaboraciones/
tags: [Notas]

---
El día 25 de Enero visitamos Pediatría del Hospital Iturraspe y se entregó todas las [colaboraciones recibidas][1].

 [1]: https://mariadelasantafe.org.ar/archives/432 "Pediatría – J.B. Iturraspe"