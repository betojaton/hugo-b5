---
title: '8 de Diciembre  Fiesta de la Inmaculada Concepción de la Virgen María'
author: admin

date: 2013-12-07T20:05:25+00:00
url: /2013/8-de-diciembre-fiesta-de-la-inmaculada-concepcion-de-la-virgen-maria/
thumbnail: /images/maria-con-angeles-1.jpg
tags: [Notas]

---
<img decoding="async" loading="lazy" src="https://mariadelasantafe.org.ar/images/maria-con-angeles.jpg" alt="maria-con-angeles" width="368" height="276" class="alignright size-medium wp-image-2169" />En una pequeña gruta en el pueblito de Lourdes, en Francia, la Virgen se le apareció a una niña diciéndole: &#8220;Yo soy la Inmaculada Concepción&#8221;. 

Era el año 1858… 

Pero… ¿Qué significa la Inmaculada Concepción? Esta expresión alude a que la Virgen María fue preservada del pecado desde el primer instante de su existencia humana. Dios, por la Inmaculada Concepción de María, preparó para su Hijo una morada digna de él.