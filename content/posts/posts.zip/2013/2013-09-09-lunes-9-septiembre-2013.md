---
title: Lunes, 9 de Septiembre 2013
author: admin

date: 2013-09-09T20:25:01+00:00
url: /2013/lunes-9-septiembre-2013/
thumbnail: /images/foto-virgen-campito@2x-1.jpg
tags: [Mensajes]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/foto-virgen-campito@2x.jpg" alt="foto-virgen-campito" class="alignright size-full wp-image-4962" />**Dice la Santísima Virgen.**

> Hijos Míos; benditos y amados hijos Míos; esta Madre viene nuevamente hacia vosotros. Gracias, porque respondéis a Mi llamado. Gracias, porque estáis caminando junto a ésta Madre, y no os apartáis de Mi lado. Como Madre vengo a guiar a todos Mis hijos del mundo, a todos los corazones, a toda la humanidad. Vengo a guiar, a las almas consagradas, a Mis hijos predilectos, a los consagrados, y a vosotros, que también son hijos predilectos; y que tenéis un lugar importante dentro de la Santa Iglesia. La Madre está presente, para señalar a las almas, el rumbo, para indicar el rumbo, a todos los corazones. Cuántas veces sentís el peso y el cansancio. Cuántas veces sentís el agobio y el desgano; en esos momentos de prueba, de tentación, donde el maligno comienza a rondar a vuestro alrededor. En esos momentos, recurrid a la oración. Pedid la luz al Espíritu Santo, invocad al Espíritu Santo; y rezad, para que paséis adelante por la prueba, para que paséis hacia delante cruzando las espinas y las piedras. Hoy nuevamente os hago un regalo, abrid todos vuestras manos y allí en vuestras manos, pongo al Niñito Jesús en vuestras manos. Allí está y a vuestro corazón debéis llevarlo. Allí, en el corazón debéis recordar todas y cada una de mis palabras. Sentid en el corazón, la tags:
	- Mensajes Presencia de Jesús, la tags:
	- Mensajes Presencia de ésta Madre. Sentid, este amor profundísimo que Jesús siente por vosotros y que esta Madre siente por vosotros, por todos los hijos del mundo, por toda la humanidad; ya que vengo como Madre a hablar a todos los hijos, a toda la humanidad. A todos los hijos de toda raza, de todo credo, porque Mi Mensaje es para todos los hijos. Y todos son hijos de ésta Madre: católicos, musulmanes, mahometanos, hindúes, ateos. ¡Todos son hijos de ésta Madre! Todos los hijos de todas las religiones, son Mis hijos; y hacia ellos también va todo Mi amor. ¡Hijos! ¡Hijos Míos! ¡Hijitos amadísimos! No perdáis las Esperanzas, no perdáis la Fe. Manteneos uníos en la oración. Ahora, en estos tiempos, en estos crueles momentos para la humanidad, mantened vuestra oración, que ninguna distracción del mundo, os perturbe, os distraiga del camino al cual fuisteis todos llamados, fuisteis convocados, desde toda la eternidad. Dios Nuestro Señor, pensó en vosotros, pensó en vuestra tarea y en vuestra misión, en este momento de la historia. Ésta es vuestra misión, esta es vuestra tarea, este es el momento para cada uno de vosotros; por eso estad mucho más cerca, mucho más unidos a esta Santa Obra, mucho más comprometidos, los que estáis aquí y los que no han podido llegar y aquellos hijos que llegarán. Todos más comprometidos, más decididos, más entregados. ¿Comprendéis Mis Palabras? Y así vosotros, que la estáis escuchando, de la misma manera que la escucháis, las escribís, también comunicadlas a los hermanos, vuestros hermanos que no han podido llegar por diferentes motivos y razones.  
> ¡Hijitos Míos! Cumplid bien vuestra tarea y llevadla a cabo.  
> Meditad. 

Meditad. Meditad Mis Palabras.

**Dice Jesús.**

><img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2000/12/img-sacerdotes-caliz@2x.jpg" alt="img-sacerdotes-caliz" class="alignright size-full wp-image-4969" /> Dice Jesús. Hermanos Míos; benditos y amados hermanos míos, vengo a serenar vuestro corazón, a calmar las aguas turbulentas de vuestro corazón, vengo a serenar vuestro espíritu, atormentado por el mundo y por tantos problemas que tantas veces os ahoga. Vengo a serenaos para que seáis faros de luz para las almas, para sigáis presentes en Mi Santa Obra, para que no despreciéis Mis Regalos y no desperdiciéis Mis Regalos que os he dado y he puesto en vuestro corazón; vengo a daros fuerza para que ya nadie dude de Mis Palabras, para que ya nadie dude de Mi tags:
	- Mensajes Presencia, y que todos vosotros seáis trabajadores, verdaderos trabajadores, para que tengáis fuerza, y no bajéis los brazos frente a tantas adversidades, que se os presentan. ¡Hermanos Míos! ¡Hijos Míos! ¡Mirad éste Corazón Traspasado! ¡Mirad Mi Santo Rostro! ¡Mirad Mis Ojos! En este momento, Mis Ojos que os miran a vosotros. ¡Mirad Mis Ojos, y encontrad la Paz! En Mis Ojos buscad la Paz. En Mi Corazón encontrad la Paz. Levantad vuestra mano derecha, en esa mano pondré Mi Mano, en esa mano pondré siempre Mi Mano para rescataros, para ayudaros, para socorreros, para sacaros del abismo, del pozo y de las tinieblas, donde muchas veces caéis, ¡caéis, por temor!¡caéis, por vergüenza!¡caéis, por el qué dirán! Caéis, porque no tenéis la suficiente fe, para creer en Mis Palabras y en Mi tags:
	- Mensajes Presencia. En vuestra mano derecha pongo Mi Mano, ¡En éste momento! Ahora, y me duele profundísimamente, Mi Corazón por aquellos hermanos míos que desprecian y rechazan éste momento de Gracia, éste momento en que me hago presente con vosotros, en que me manifiesto con vosotros. He llamado a Mis ovejas, las he buscado y las traigo, entonces, ¿por qué sois tan pocos? ¿Por qué? ¡Conozco el motivo! Lo conozco! Profundamente lo conozco! No hay escusas, escusas para Mí. ¡Tanto amor os doy! Tanto amor os entrego, y sin embargo hay muchas escusas que no puedo entender. ¡Levantad vuestro corazón! ¡Levantad vuestro espíritu! ¡Levantaos! Y confiad en Mí y no dudéis de Mi tags:
	- Mensajes Presencia jamás.  
> ¡El mundo está oscuro, entonces luchad vosotros y no perdáis la luz! Manteneos junto a Mí. Estad unidos, todos; todos unidos, todos.  
> Disfrutad de Mi tags:
	- Mensajes Presencia y de éste amor que os doy a todos; porque no os separo de mi lado, porque a todos os llevo dentro de Mi Sacratísimo Corazón.  
> ¡SOY EL PADRE, SOY EL HIJO, SOY EL ESPÍRITU SANTO!  
> Meditad. Meditad. Meditad Mis Palabras.<footer>Leed : Juan C 1, 2 al 5. &#8211; Juan C. 2, 3 y 4. &#8211; Juan C.16, 5 al 9.</footer> 

Os bendigo, en el Nombre del Padre, y del Hijo y del Espíritu Santo. Amén.