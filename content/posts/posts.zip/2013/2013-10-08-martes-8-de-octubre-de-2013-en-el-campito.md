---
title: Martes 8 de Octubre, 2013 en el “Campito”
date: 2013-10-08T22:03:46+00:00
url: /2013/martes-8-de-octubre-de-2013-en-el-campito/
abstract: Yo soy el camino y la verdad y la vida; nadie viene al Padre, sino por mi. --Juan 14:6
thumbnail: /images/mano-con-luz.jpg
audio:
  - /wp-content/themes/mdstafe2013/audio/2013/08-10-2013.mp3
fecha-audio:
  - 08-10-2013
tags: [Mensaje, Mensajes Presencia]

---
![Yo soy el camino y la verdad y la vida; nadie viene al Padre, sino por mi. --Juan 14:6--](/images/mano-con-luz.jpg)

**Dice la Santísima Virgen:** 

“Hijos míos, benditos y amados hijos míos, aquí está la Madre junto a vosotros, la Madre que se manifiesta con los hijos del mundo entero; hijos míos, abrid vuestras manos y recibid el Rosario de Mis manos, llevadlo a vuestro corazón, y sentid allí Mi presencia maternal. Sentid en vuestro corazón Mis palabras maternales.

Vengo a cumplir una tarea y una misión, conduciros a todos hacia Jesús, a cada uno de vosotros en forma especial, ya que manifiesto Mi amor de Madre con los hijos del mundo entero y estoy reuniendo a las ovejas, reuniendo a todas las ovejas en el rebaño de Cristo Jesús Mi Hijo Amadísimo.

Por eso hijitos míos, necesito de vuestras manos, de vuestra oración y que deis al mundo todas Mis palabras, porque quiero que todos los hijos encuentren el camino de la luz y de la salvación; que solamente están en Cristo Jesús Mi Hijo Amadísimo.

Los hijos no deben apartarse jamás de la Santa Iglesia, deben permanecer fieles en la Santa Iglesia. Hijos míos, escuchad a ésta Madre, que habla al mundo entero y que hace descender una lluvia de bendiciones sobre los hijos de ésta tierra Santa y Bendita, de esta Argentina, de ésta Nación Santa y Bendita; por eso os pido nuevamente vuestra oración, rezad mucho, rezad todos los días el Santo Rosario y pedid por esas almas que hoy no rezan, por esas almas que están en la oscuridad, por esos corazones que solamente conocen como medio de vida, el odio, la rivalidad, el engaño la difamación.

Rezad hijitos míos y permitid siempre que Mis palabras estén dentro de vuestros corazones. El mundo, hoy, el mundo está en una etapa muy dolorosa, en una etapa muy oscura, por eso la oración de todos Mis hijos en el mundo entero.

La Madre siempre estará a vuestro lado. La Madre siempre os cubrirá con su Manto Celestial, porque también vosotros sois Mis Hijos Predilectos y amadísimos porque me desvelo por cada uno de vosotros cuando estáis en tantas dificultades.

¡No temáis! ¡No temáis! ¡No temáis! Porque abro Mi Manto Celestial para cubriros, en forma especial a cada uno de vosotros.

¡Aquí está María!¡Aquí está la Madre, la Madre de la Santa Fe, que llama a todos los hijos de todas las naciones, para que Mis hijos vuelvan al camino del Señor.

Meditad. Meditad. Meditad Mis Palabras.”


**Dice Jesús:** 

“Hermanos míos; benditos y amados hermanos míos, os ofrezco nuevamente Mi paz, os señalo Mi camino, os muestro Mi camino, os doy Mi Corazón Sacratísimo, Traspasado y herido por amor, os doy Mi Divina Misericordia para que vosotros seáis misericordiosos, bondadosos y comprensivos; para que trabajéis por la paz, por la unidad, para que trabajéis día a día por la salvación de todas las almas.

Llevad al mundo Mi palabra de amor, Mi mensaje de amor, que el mundo conozca Mi presencia que la humanidad vuelva hacia Mi Sacratísimo Corazón para encontrar la paz definitiva.

¡Os amo a todos por igual! Os amo profundísimamente y os llevo a todos dentro de Mi Sacratísimo Corazón. En éstos momentos sano, libero y os doy las fuerzas para que sigáis avanzando en Mi camino. Corro todas las piedras y las espinas para que todos lleguéis a Mí, para que todos os entreguéis a Mi amor Misericordioso y a mi paz verdadera.

Os amo profundísimamente, vosotros que sois Mis ovejas, os amo, amo al mundo entero y a cada instante y a cada segundo estoy dando nuevas oportunidades a todos los hombres.

Vuelco Mi paz, Mi amor, Mi verdad en las almas y vosotros debéis ser trabajadores de la verdad, trabajadores del amor, trabajadores de la unidad.  
¡No os sintáis indignos! Aunque vosotros tantas veces me olvidéis, yo jamás os olvidaré, yo jamás os separaré de Mi lado, porque Mi corazón ama infinitamente, porque Mi corazón no separa, porque Mi corazón reúne y atrae a todas las almas hacia Mí.

Estoy sobre vosotros, estoy aquí y me manifiesto con vosotros. ¡Creed! ¡Creed! ¡Creed! y jamás dudéis de Mi amor hacia cada uno de vosotros.

Meditad. Meditad. Meditad Mis Palabras.

Os bendigo en el Nombre del Padre y del Hijo y del Espíritu Santo. Amén.”