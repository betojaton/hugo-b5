---
title: Jueves 8 de Agosto, 2013
date: 2013-08-08T22:42:15+00:00
url: /2013/jueves-8-de-agosto-de-2013/
thumbnail: /images/foto-virgen-corazon.jpg
audio:
  - /wp-content/themes/mdstafe2013/audio/2013/08-08-2013.mp3
fecha-audio:
  - 08-08-2013
tags: [Mensajes, Mensajes Presencia]

---
![](/images/foto-virgen-corazon.jpg)

**Dice la Santísima Virgen:** 

Hijos míos, benditos y amados hijos míos, no estéis tristes, aquí está la Madre que viene a consolaros de vuestras penas. No estéis tristes porque aquí está la Madre que a todos os cubre con su Manto Celestial.

Veo vuestros corazones, hijitos míos, y debéis acercaros sin temor a la Madre porque la Madre os viene a conducir a todos hacia Jesús, vengo a enseñaros el camino hacia Jesús. No estéis tristes alegrad vuestro corazón porque el Señor está junto a vosotros, porque el Señor se manifiesta con todos sus hijos del mundo entero.

Hijitos míos, acudid siempre hacia ésta Madre y sed todos partícipes en ésta Santa Obra. Trabajad todos en ésta Santa Obra porque estoy reuniendo como Madre a cada uno de mis hijos, llamando, convocando, atrayendo a los corazones, a todos los corazones para ésta Gran y Santa Obra.  
Debéis estar junto a la Madre y seguir este camino. Vivid todos vuestros días, en la verdad, en la humildad, en la caridad y sed auténticos mensajeros de la luz para el mundo entero.

Meditad. Meditad. Meditad Mis Palabras.

**Dice Jesús:** 

Hermanos míos benditos y amados hermanos míos, os muestro Mi Corazón traspasado y vuelco en vuestras almas Mi amor, vuelco Mi Divina Misericordia para cerrar las heridas, las profundas heridas que tenéis en vuestro corazón.

Aquí estoy junto a mis ovejas, aquí estoy y vosotros todos estáis en mi rebaño. Aquí estoy y os doy Mi paz, os entrego Mi paz, os ofrezco Mi paz, para que todos trabajéis por la paz, para que todos seáis obreros de la paz en el mundo entero, en este mundo tan convulsionado, tan oscurecido y tan apartado de la verdad.

Sed todos vosotros Mis mensajeros en el mundo, llevad a las almas Mis palabras de amor y consuelo, llevad al mundo Mi mensaje de amor, para que todos mis hermanos vivan en el amor, en la paz y en la verdad.

Hoy nuevamente pongo Mis manos sobre vosotros, sobre cada uno de vosotros y os doy la fuerza de Mi Sacratísimo Corazón, os doy el amor de Mi Sacratísimo Corazón, os doy la paz de Mi Sacratísimo Corazón. Sed fieles todos a Mi llamado, permaneced a Mi lado, no busquéis otros caminos que no son los verdaderos, permaneced a Mi lado, permaneced junto a Mí y sentid el latir de Mi Sacratísimo Corazón dentro de cada uno de vosotros. No dudéis jamás de Mi amor hacia cada uno de vosotros, porque todos sois iguales para Mí, no separo, no divido, no desuno a las almas, sino que reúno a todos los corazones y a todos mis hermanos en un mismo y único rebaño.

Aprended a ser humildes, sed pequeños, sencillos, obedientes y venid siempre hacia Mí porque a todos os espero con Mis brazos abiertos.

Os amo profundísimamente, os amo eternamente, os amo a todos por igual.

Meditad. Meditad. Meditad Mis Palabras.

Os bendigo en el Nombre del Padre, y del Hijo y del Espíritu Santo. 

Amén.