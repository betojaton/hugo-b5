---
title: Oración del Abandono
author: admin

date: 2013-07-16T00:53:22+00:00
abstract: |
  **Le dice Jesús a Vicente el 15 de Julio de 2013, la siguiente oración:**
  <h3>ORACION DEL ABANDONO</h3>
  <img class="alignright size-medium wp-image-1484" alt="jesus_corazon008" src="https://mariadelasantafe.org.ar/wp-content/uploads/2012/06/jesus_corazon008-223x300.jpg" width="223" height="300" />
  Me abandono en tus brazos Señor, para que Tú dispongas de mí.
  Me abandono en tus brazos Señor, para que Tú me conduzcas.
  Me abandono en tus brazos Señor, para que me lleves allí donde las almas me necesiten.
  Me abandono enteramente en tus brazos Señor, para hacer tú voluntad y seguir tus pasos para nunca jamás abandonarte, a pesar de las pruebas y de las cruces que hay en mi camino.
  
  <p><a href="https://mariadelasantafe.org.ar/oracion-del-abandono/" title="Ver Noticia Completa">Ver Nota Ampliada...</a>
url: /2013/oracion-del-abandono/
thumbnail: /images/jesus_corazon008-1.jpg

---
**Le dice Jesús a Vicente el 15 de Julio de 2013, la siguiente oración:**

### ORACION DEL ABANDONO

<img decoding="async" loading="lazy" class="alignright size-medium wp-image-1484" alt="jesus_corazon008" src="https://mariadelasantafe.org.ar/images/jesus_corazon008-223x300.jpg" width="223" height="300" />  
Me abandono en tus brazos Señor, para que Tú dispongas de mí.  
Me abandono en tus brazos Señor, para que Tú me conduzcas.  
Me abandono en tus brazos Señor, para que me lleves allí donde las almas me necesiten.  
Me abandono enteramente en tus brazos Señor, para hacer tú voluntad y seguir tus pasos para nunca jamás abandonarte, a pesar de las pruebas y de las cruces que hay en mi camino.  
Me abandono en tus brazos Señor, para que Tú puedas realizar tú obra dentro de mí.  
Me abandono en tus brazos Señor, para que Tú moldees mí corazón y hagas de éste corazón de piedra, un verdadero corazón de carne.  
Me abandono en tus brazos confiadamente.  
Me abandono en tus brazos esperando tus respuestas, esperando con paciencia tus respuestas, confiando plenamente en Ti, confiando absolutamente en Ti, que me responderás a su debido tiempo.  
Me abandono en tus brazos Señor, quiero ser totalmente tuyo, quiero estar totalmente a tú servicio y quiero ser instrumento de tu palabra, ser instrumento de tu amor y tu misericordia en el mundo entero.  
Me abandono totalmente en tus brazos Señor.  
Amén.