---
title: CENAELE – Centro de Apoyo al Enfermo de Leucemia
author: admin

date: 2013-12-21T00:32:28+00:00
url: /2013/centro-de-apoyo-al-enfermo-de-leucemia-cenaele/
tags: [Colaboraciones]

---
20/12/2013, 15/8/2013, 12/7/2013, 17/6/2013, 11/4/2013, 12/03/2013 (Entrega de Tapitas) , 01/11/2012 (Entrega de Tapitas), 13/08/2012, 12/07/2012(Entrega de Tapitas), 25/05/2012, 14/04/2012, 26/05/2010, 12/10/2010, 06/12/2010, 16/04/2011, 23/08/2011, 16/11/2011  
<!-- default-view.php -->

<div
	class="ngg-galleryoverview default-view "
	id="ngg-gallery-36e8993f65d4ae377f6fbba5df02bfef-1">
  <!-- Thumbnails -->
  
  <div id="ngg-image-0" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/mariadelasantafe-cenaele.JPG"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/mariadelasantafe-cenaele.JPG"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_mariadelasantafe-cenaele.JPG"
               data-image-id="32"
               data-title="cenaele"
               data-description=""
               data-image-slug="cenaele"
               class="ngg-simplelightbox" rel="36e8993f65d4ae377f6fbba5df02bfef"> <img
                    title="cenaele"
                    alt="cenaele"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_mariadelasantafe-cenaele.JPG"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-1" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/mariadelasantefe-cenaele2.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/mariadelasantefe-cenaele2.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_mariadelasantefe-cenaele2.jpg"
               data-image-id="33"
               data-title="cenaele2"
               data-description=""
               data-image-slug="cenaele2"
               class="ngg-simplelightbox" rel="36e8993f65d4ae377f6fbba5df02bfef"> <img
                    title="cenaele2"
                    alt="cenaele2"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_mariadelasantefe-cenaele2.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-2" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/cenaele_01.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/cenaele_01.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_cenaele_01.jpg"
               data-image-id="57"
               data-title="cenaele_01"
               data-description=""
               data-image-slug="cenaele_01"
               class="ngg-simplelightbox" rel="36e8993f65d4ae377f6fbba5df02bfef"> <img
                    title="cenaele_01"
                    alt="cenaele_01"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_cenaele_01.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-3" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/cenaele_02.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/cenaele_02.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_cenaele_02.jpg"
               data-image-id="58"
               data-title="cenaele_02"
               data-description=""
               data-image-slug="cenaele_02"
               class="ngg-simplelightbox" rel="36e8993f65d4ae377f6fbba5df02bfef"> <img
                    title="cenaele_02"
                    alt="cenaele_02"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_cenaele_02.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-4" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/cenaele_03.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/cenaele_03.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_cenaele_03.jpg"
               data-image-id="59"
               data-title="cenaele_03"
               data-description=""
               data-image-slug="cenaele_03"
               class="ngg-simplelightbox" rel="36e8993f65d4ae377f6fbba5df02bfef"> <img
                    title="cenaele_03"
                    alt="cenaele_03"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_cenaele_03.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-5" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/cam00616.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/cam00616.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_cam00616.jpg"
               data-image-id="294"
               data-title="cam00616"
               data-description=""
               data-image-slug="cam00616"
               class="ngg-simplelightbox" rel="36e8993f65d4ae377f6fbba5df02bfef"> <img
                    title="cam00616"
                    alt="cam00616"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_cam00616.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-6" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/cenaele_04.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/cenaele_04.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_cenaele_04.jpg"
               data-image-id="60"
               data-title="cenaele_04"
               data-description=""
               data-image-slug="cenaele_04"
               class="ngg-simplelightbox" rel="36e8993f65d4ae377f6fbba5df02bfef"> <img
                    title="cenaele_04"
                    alt="cenaele_04"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_cenaele_04.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-7" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/cenaele_05.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/cenaele_05.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_cenaele_05.jpg"
               data-image-id="61"
               data-title="cenaele_05"
               data-description=""
               data-image-slug="cenaele_05"
               class="ngg-simplelightbox" rel="36e8993f65d4ae377f6fbba5df02bfef"> <img
                    title="cenaele_05"
                    alt="cenaele_05"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_cenaele_05.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-8" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/cenaele_06.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/cenaele_06.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_cenaele_06.jpg"
               data-image-id="62"
               data-title="cenaele_06"
               data-description=""
               data-image-slug="cenaele_06"
               class="ngg-simplelightbox" rel="36e8993f65d4ae377f6fbba5df02bfef"> <img
                    title="cenaele_06"
                    alt="cenaele_06"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_cenaele_06.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-9" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/ceneale_12042012-01.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/ceneale_12042012-01.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_ceneale_12042012-01.jpg"
               data-image-id="110"
               data-title="ceneale_12042012-01"
               data-description=""
               data-image-slug="ceneale_12042012-01"
               class="ngg-simplelightbox" rel="36e8993f65d4ae377f6fbba5df02bfef"> <img
                    title="ceneale_12042012-01"
                    alt="ceneale_12042012-01"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_ceneale_12042012-01.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-10" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/ceneale_12042012-02.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/ceneale_12042012-02.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_ceneale_12042012-02.jpg"
               data-image-id="111"
               data-title="ceneale_12042012-02"
               data-description=""
               data-image-slug="ceneale_12042012-02"
               class="ngg-simplelightbox" rel="36e8993f65d4ae377f6fbba5df02bfef"> <img
                    title="ceneale_12042012-02"
                    alt="ceneale_12042012-02"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_ceneale_12042012-02.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-11" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/ceneale_12042012-03.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/ceneale_12042012-03.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_ceneale_12042012-03.jpg"
               data-image-id="112"
               data-title="ceneale_12042012-03"
               data-description=""
               data-image-slug="ceneale_12042012-03"
               class="ngg-simplelightbox" rel="36e8993f65d4ae377f6fbba5df02bfef"> <img
                    title="ceneale_12042012-03"
                    alt="ceneale_12042012-03"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_ceneale_12042012-03.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-12" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/dsc04221.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/dsc04221.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_dsc04221.jpg"
               data-image-id="113"
               data-title="dsc04221"
               data-description=""
               data-image-slug="dsc04221"
               class="ngg-simplelightbox" rel="36e8993f65d4ae377f6fbba5df02bfef"> <img
                    title="dsc04221"
                    alt="dsc04221"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_dsc04221.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-13" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/dsc04223.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/dsc04223.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_dsc04223.jpg"
               data-image-id="114"
               data-title="dsc04223"
               data-description=""
               data-image-slug="dsc04223"
               class="ngg-simplelightbox" rel="36e8993f65d4ae377f6fbba5df02bfef"> <img
                    title="dsc04223"
                    alt="dsc04223"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_dsc04223.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-14" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/dsc04634.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/dsc04634.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_dsc04634.jpg"
               data-image-id="122"
               data-title="dsc04634"
               data-description=""
               data-image-slug="dsc04634"
               class="ngg-simplelightbox" rel="36e8993f65d4ae377f6fbba5df02bfef"> <img
                    title="dsc04634"
                    alt="dsc04634"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_dsc04634.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-15" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/dsc04635.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/dsc04635.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_dsc04635.jpg"
               data-image-id="123"
               data-title="dsc04635"
               data-description=""
               data-image-slug="dsc04635"
               class="ngg-simplelightbox" rel="36e8993f65d4ae377f6fbba5df02bfef"> <img
                    title="dsc04635"
                    alt="dsc04635"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_dsc04635.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-16" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/cenaele-2.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/cenaele-2.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_cenaele-2.jpg"
               data-image-id="127"
               data-title="cenaele-2"
               data-description=""
               data-image-slug="cenaele-2"
               class="ngg-simplelightbox" rel="36e8993f65d4ae377f6fbba5df02bfef"> <img
                    title="cenaele-2"
                    alt="cenaele-2"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_cenaele-2.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-17" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/cenaele.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/cenaele.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_cenaele.jpg"
               data-image-id="128"
               data-title="cenaele"
               data-description=""
               data-image-slug="cenaele-3"
               class="ngg-simplelightbox" rel="36e8993f65d4ae377f6fbba5df02bfef"> <img
                    title="cenaele"
                    alt="cenaele"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_cenaele.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-18" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/cenaele3.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/cenaele3.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_cenaele3.jpg"
               data-image-id="129"
               data-title="cenaele3"
               data-description=""
               data-image-slug="cenaele3"
               class="ngg-simplelightbox" rel="36e8993f65d4ae377f6fbba5df02bfef"> <img
                    title="cenaele3"
                    alt="cenaele3"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_cenaele3.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-19" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/dsc05830-001.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/dsc05830-001.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_dsc05830-001.jpg"
               data-image-id="168"
               data-title="dsc05830-001"
               data-description=""
               data-image-slug="dsc05830-001"
               class="ngg-simplelightbox" rel="36e8993f65d4ae377f6fbba5df02bfef"> <img
                    title="dsc05830-001"
                    alt="dsc05830-001"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_dsc05830-001.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-20" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/dsc05831.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/dsc05831.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_dsc05831.jpg"
               data-image-id="169"
               data-title="dsc05831"
               data-description=""
               data-image-slug="dsc05831"
               class="ngg-simplelightbox" rel="36e8993f65d4ae377f6fbba5df02bfef"> <img
                    title="dsc05831"
                    alt="dsc05831"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_dsc05831.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-21" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/colaboracion_ceneale_120313_01.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/colaboracion_ceneale_120313_01.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_colaboracion_ceneale_120313_01.jpg"
               data-image-id="201"
               data-title="colaboracion_ceneale_120313_01"
               data-description=""
               data-image-slug="colaboracion_ceneale_120313_01"
               class="ngg-simplelightbox" rel="36e8993f65d4ae377f6fbba5df02bfef"> <img
                    title="colaboracion_ceneale_120313_01"
                    alt="colaboracion_ceneale_120313_01"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_colaboracion_ceneale_120313_01.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-22" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/colaboracion_ceneale_120313_02.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/colaboracion_ceneale_120313_02.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_colaboracion_ceneale_120313_02.jpg"
               data-image-id="202"
               data-title="colaboracion_ceneale_120313_02"
               data-description=""
               data-image-slug="colaboracion_ceneale_120313_02"
               class="ngg-simplelightbox" rel="36e8993f65d4ae377f6fbba5df02bfef"> <img
                    title="colaboracion_ceneale_120313_02"
                    alt="colaboracion_ceneale_120313_02"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_colaboracion_ceneale_120313_02.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-23" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/colaboracion_ceneale_120313_03.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/colaboracion_ceneale_120313_03.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_colaboracion_ceneale_120313_03.jpg"
               data-image-id="203"
               data-title="colaboracion_ceneale_120313_03"
               data-description=""
               data-image-slug="colaboracion_ceneale_120313_03"
               class="ngg-simplelightbox" rel="36e8993f65d4ae377f6fbba5df02bfef"> <img
                    title="colaboracion_ceneale_120313_03"
                    alt="colaboracion_ceneale_120313_03"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cenaele/thumbs/thumbs_colaboracion_ceneale_120313_03.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <br style="clear: both" /> <!-- Pagination -->
  
  <div class='ngg-navigation'>
    <span class='current'>1</span> <a class='page-numbers' data-pageid='2' href='https://mariadelasantafe.org.ar/centro-de-apoyo-al-enfermo-de-leucemia-cenaele/nggallery/page/2?type=hugo'>2</a> <a class='prev' href='https://mariadelasantafe.org.ar/centro-de-apoyo-al-enfermo-de-leucemia-cenaele/nggallery/page/2?type=hugo' data-pageid=2>&#9658;</a>
  </div>
</div>