---
title: Consagración del mundo al Inmaculado Corazón de María
author: admin

date: 2013-10-11T12:13:44+00:00
url: /2013/consagracion-del-mundo-al-inmaculado-corazon-de-maria/
thumbnail: /images/consagracion-amaria1-1.jpg

---
<figure id="attachment_2085" aria-describedby="caption-attachment-2085" style="width: 348px" class="wp-caption alignnone"><img decoding="async" loading="lazy" class=" wp-image-2085 " alt="consagracion-amaria1" src="https://mariadelasantafe.org.ar/images/consagracion-amaria1.jpg" width="350" height="330" /><figcaption id="caption-attachment-2085" class="wp-caption-text">

### Sábado, 12 de Octubre, a las 17 horas.

En la Plaza de San Pedro, el **Papa** presidirá una oración con motivo de la Jornada Mariana convocada en el Año de la Fe y recibirá a la imagen original de la **Virgen de Fátima**, que se halla en el Santuario del mismo nombre en Portugal y lleva engastada en la corona el proyectil que hirio al beato Juan Pablo II en el atentado del 13 de mayo de 1981.

### Domingo, 13 de Octubre, a las 10:30 horas.

En la Plaza de San Pedro, el **Santo Padre** celebrará la Misa en la Jornada Mariana y consagrará, ante la

#### Virgen de Fátima, el mundo al Corazón Inmaculado de María.

</figcaption></figure>