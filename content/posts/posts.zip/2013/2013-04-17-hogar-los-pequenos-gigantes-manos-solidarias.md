---
title: Hogar “Los Pequeños Gigantes Manos Solidarias”
author: admin

date: 2013-04-17T13:47:13+00:00
url: /2013/hogar-los-pequenos-gigantes-manos-solidarias/
thumbnail: /images/id-2062.jpg
tags: [Colaboraciones]

---
17/04/2013

<img decoding="async" class="ngg_displayed_gallery mceItem" alt="" src="https://mariadelasantafe.org.ar/images/id-2062.jpg" />