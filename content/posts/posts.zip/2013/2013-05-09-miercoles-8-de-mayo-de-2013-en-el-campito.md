---
title: Miércoles 8 de mayo, 2013 en el “Campito”
date: 2013-05-09T01:26:59+00:00
url: /2013/miercoles-8-mayo-2013-en-el-campito/
tags:
  - Mensajes
  - Mensajes Presencia
---
**Dice la Santísima Virgen:** “Hijos míos, benditos y amados hijos Míos responded a Mis llamados de Madre, responded a Mis pedidos, Aquí está la Madre que os vuelve a agradecer vuestra presencia, aquí está la Madre que os entrega su Inmaculado Corazón, a todos vosotros y al mundo entero para que por medio de Mi corazón todos lleguéis a Cristo Jesús Mi hijo amadísimo.

Rezad mucho en estos tiempos difíciles para toda la humanidad, rezad y confiad en el Señor que está junto a los hijos, que no abandona a sus hijos.

Hijitos míos abrid el corazón a Mis palabras y sentid la presencia de ésta Madre con cada uno de vosotros.

Estoy aquí acompañando y guiando a Mis hijos, llamando a una conversión total de los corazones, llamando a una conversión de vida de todos Mis hijos, para que todos viváis en la luz de la gracia y saquéis todo pecado de vuestro corazón.

Llegad hijitos míos por medio de ésta Madre al corazón de Jesús y vivid en paz todos los días de vuestra vida, vivid en paz y trabajad por la paz y sed mensajeros del amor en el mundo entero.

Sed humildes, sed verdaderamente humildes, y comprended, comprended Mis palabras maternales que os llama a una conversión definitiva. Sed fieles hijitos Míos al llamado que habéis recibido, sed fieles y escuchad con atención Mis pedidos maternales.

Meditad. Meditad. Meditad Mis palabras.”

  **Dice Jesús:** “Hermanos Míos, benditos y amados hermanos Míos. Vuelco Mi Preciosísima Sangre sobre vosotros, vuelco Mi amor en vosotros y Mi paz.

  Aquí estoy con vosotros y en todo lugar, manifestando Mi amor a las almas, manifestando Mi Divina Misericordia a todos los corazones.

  Os amo a todos por igual y todos estáis en Mi rebaño. Mi Corazón Sacratísimo busca a todas las ovejas, a todas por igual, las busca, las llama, las convoca y les da una nueva oportunidad.

 Confiad en Mi amor, confiad en Mis palabras. Confiad, confiad, os lo pide Mi Sacratísimo Corazón traspasado y herido por amor a todos vosotros.

  Que ya nadie dude de Mi presencia.

  No os sintáis indignos. Creed en Mi amor y en Mis palabras, y salid al mundo a llevar cada uno de Mis mensajes, de Mis anuncios, id al mundo, id a todas las naciones y que el mundo conozca Mi presencia, Mi amor y Mi Divina Misericordia.

  Que el mundo vuelva hacia Mí, que toda la humanidad vuelva hacia Mí, que todos los hombres vuelvan hacia Mí, y encontrarán la auténtica paz.

  Trabajad, trabajad, trabajad por el amor y por la paz. Trabajad todos los días de vuestras vidas por vuestros hermanos necesitados y dadles el amor de Mi Sacratísimo Corazón.

  No bajéis los brazos, no os canséis de seguir Mi camino, no os canséis de practicar el bien con las almas, no os canséis jamás de dar el corazón a todos vuestros hermanos.

  Os amo a todos por igual. Os amo profundísimamente, os amo eternamente.

  Abrid vuestras manos, recibid Mi Sacratísimo Corazón y llevadlo a vuestro corazón, sentid allí Mi presencia, sentid allí Mi paz, sentid allí Mi amor, sentid verdaderamente que cada una de Mis palabras resuenan en lo profundo de vuestros corazones.

  Os amo, nuevamente os digo, os amo, os amo, os amo.

  Tomad vuestra cruz y seguid Mis pasos.

  Meditad. Meditad. Meditad Mis palabras.

Os bendigo, en el nombre del Padre y del Hijo y del Espíritu Santo. Amén.”