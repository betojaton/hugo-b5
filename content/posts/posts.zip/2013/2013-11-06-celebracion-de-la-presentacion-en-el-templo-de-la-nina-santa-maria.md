---
title: Celebración de la Presentación en el Templo de la niña Santa María.
date: 2013-11-06T22:13:30+00:00
url: /2013/celebracion-presentacion-templo-ninia-santa-maria
thumbnail: /images/virgen-ninia-1.jpg
tags:
  - Notas
---

### 21 de Noviembre

> Cuando la Virgen María era muy niña sus padres San Joaquín y Santa Ana la llevaron al templo de Jerusalén y allá la dejaron por un tiempo, junto con otro grupo de niñas, para ser instruida muy cuidadosamente respecto a la religión y a todos los deberes para con Dios.

![Titulo Imagen](/images/virgen-ninia.jpg)

### Oración:

>  Santa Madre María,<br /> tú que desde temprana edad te consagraste al Altísimo,<br /> aceptando desde una libertad poseída<br /> el servirle plenamente como templo inmaculado,<br /> tú que confiando en tus santos padres,<br /> San Joaquín y Santa Ana,<br /> respondiste con una obediencia amorosa<br /> al llamado de Dios Padre,<br /> tú que ya desde ese momento<br /> en el que tus padres te presentaron en el Templo<br /> percibiste en tu interior el profundo designio de Dios Amor;<br /> enséñanos Madre Buena a ser valientes seguidores de tu Hijo,<br /> anunciándolo en cada momento de nuestra vida<br /> desde una generosa y firme respuesta al Plan de Dios.<br /> Amén
