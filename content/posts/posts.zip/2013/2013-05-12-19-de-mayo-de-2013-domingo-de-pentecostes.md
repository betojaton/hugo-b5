---
title: 19 de mayo, 2013 – Domingo de Pentecostés
author: admin

date: 2013-05-12T22:41:14+00:00
url: /2013/19-de-mayo-de-2013-domingo-de-pentecostes/
tags: [Notas]

---
Los cincuenta días pascuales y las fiestas de la Ascensión y Pentecostés, forman una unidad. No son fiestas aisladas de acontecimientos ocurridos en el tiempo, son parte de un solo y único misterio. 

Pentecostés es fiesta pascual y fiesta del Espíritu Santo. La Iglesia sabe que nace en la Resurrección de Cristo, pero se confirma con la venida del Espíritu Santo. Es hasta entonces, que los Apóstoles acaban de comprender para qué fueron convocados por Jesús; para qué fueron preparados durante esos tres años de convivencia íntima con Él. 

La Fiesta de Pentecostés es como el &#8220;aniversario&#8221; de la Iglesia. El Espíritu Santo desciende sobre aquella comunidad naciente y temerosa, infundiendo sobre ella sus siete dones, dándoles el valor necesario para anunciar la Buena Nueva de Jesús; para preservarlos en la verdad, como Jesús lo había prometido; para disponerlos a ser sus testigos; para ir, bautizar y enseñar a todas las naciones. 

Es el mismo Espíritu Santo que, desde hace dos mil años hasta ahora, sigue descendiendo sobre quienes creemos que Cristo vino, murió y resucitó por nosotros; sobre quienes sabemos que somos parte y continuación de aquella pequeña comunidad ahora extendida por tantos lugares; sobre quienes sabemos que somos responsables de seguir extendiendo su Reino de Amor, Justicia, Verdad y Paz entre los hombres.