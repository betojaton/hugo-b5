---
title: Viernes 8 de noviembre, 2013 en el “Campito”
date: 2013-11-08T19:48:01+00:00
url: /2013/viernes-8-de-noviembre-de-2013-en-el-campito/
thumbnail: /images/sagrado-corazon-de-jesus.jpg
audio:
  - /wp-content/themes/mdstafe2013/audio/2013/08-11-2013.mp3
fecha-audio:
  - 08-11-2013
tags: [Mensajes, Mensajes Presencia]

---
![](/images/flia-rezando.jpg)

“Hijos míos, benditos y amados hijos míos, nuevamente os doy gracias, porque respondéis a Mi llamado, porque acudís cada uno de vosotros a los brazos de esta Madre.

Mi Corazón Inmaculado os bendice a cada uno de vosotros y en forma especial, esta Madre se manifiesta con los hijos, con cada hijo, en cada hogar, en cada familia trayendo el mensaje del cielo, para la conversión de los corazones, Mis hijos deben llegar a la conversión ,Mis hijos, el mundo entero, deben llegar todos a la conversión y Mi llamado es insistente.  
Pido que Mis hijos se dediquen con más fuerza a la oración, que los hijos acudan a la oración, como puente, como puente para llegar a Jesús.

Hijos míos, hijitos míos no perdáis estos días tan valiosos, estas horas tan valiosas, el Señor os mira con misericordia y derrama en vosotros, abundantes gracias, que todos los hijos deben recibir. La humanidad debe comprender el camino; el camino en que está hoy al borde del abismo, al borde del abismo eterno y es como Madre, que pido y suplico a todo Mis hijos la oración, rezad mucho en vuestras familias, rezad mucho en la Santa  
Iglesia, rezad mucho hijitos míos como lo desea Mi Corazón Inmaculado.

¡No temáis, no temáis! porque la Madre está junto a vosotros y Mi Manto Celestial es la muralla que os cubre y os protege del enemigo, de Satanás, que rodea siempre para haceros perder del camino para tratar de desviaros del camino.

Aferraos vosotros a Mi Manto Celestial, aferraos a Mi Rosario, no perdáis la FE ni la esperanza y confiad cada día más en la presencia del Señor, que os atiende que os escucha que permanece con vosotros.

¡Confiad, confiad, confiad! Porque aquí está la Madre, vuestra Madre, María de la Santa Fe.

Meditad, Meditad, Meditad Mis Palabras.”

Dice Jesús: “Hermanos Míos, benditos y amados hermanos míos, abro las puertas de Mí Corazón a vosotros y derramo Mi Preciosísima Sangre, que os fortalece y os libera, abro las puertas de Mí Corazón donde brota todo Mí Amor hacia todos los hombres, este amor se derrama en la humanidad, cae a manos llenas, sobre todos los corazones, porque deseo que la humanidad, encuentre el camino de la salvación, que Mis hermanos encuentren el camino de la salvación.

Mi Amor no tiene precio, Mi amor no tiene límites, Mi Amor se derrama y pasa por las barreras del mundo, pasa por las puertas del mundo, Mi Amor lo abarca todo y llega hasta el último rincón de la tierra, sobre todos los corazones y en todas las almas. Mi Amor cae, en aquellos hermanos que están desesperados, en aquellos hermanos que están angustiados, Mi Amor cae en vosotros en una forma especial y os invita cada día a emprender el camino a retomar la marcha y a no mirar el pasado, sino este presente que os regala Mi Sacratísimo Corazón.

Sed buenos, sed misericordiosos, sed bondadosos y compasivos con vuestros hermanos, transmitid la Paz, sed mensajeros de Mi paz y llevad Mi paz a vuestras comunidades, llevad Mi paz y Mi amor, a vuestras comunidades. Mi paz no tiene límites, Mi paz os llega a vosotros y en forma especial para que se hagáis soldados fuertes y valerosos en Mi Santa Obra.  
En este momento paso sobre vosotros y con Mis manos poderosas toco vuestras cabezas, para daros fuerza, para daros el valor, para daros la paz.

Afrontad el camino cada día, dejad todas las luchas en el pasado y solamente trabajad y luchad, para extender Mi reino, Mi reino de amor, de justicia, de paz y de eterna verdad, sed valerosos y no cobardes, sed auténticos discípulos de Mi Sacratísimo Corazón, os amo a todos, os amo profundísimamente y os llevo a todos dentro de Mi Sacratísimo Corazón .Ya nadie dude de Mis palabras. Ya nadie rechace Mis palabras.”