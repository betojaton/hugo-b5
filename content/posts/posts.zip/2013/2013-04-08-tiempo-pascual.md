---
title: Tiempo Pascual
author: admin

date: 2013-04-08T12:49:03+00:00
abstract: |
  <a href="https://mariadelasantafe.org.ar/wp-content/uploads/2013/04/foto-tiempo-pascual.jpg" class="thickbox"><img class="size-medium wp-image-1811 alignnone" alt="foto-tiempo-pascual" src="https://mariadelasantafe.org.ar/wp-content/uploads/2013/04/foto-tiempo-pascual-368x276.jpg" width="368" height="276" /></a>
  
  El tiempo pascual comprende cincuenta días (en griego = "Pentecostés"), vividos y celebrados como un solo día: "los cincuenta días que median entre el domingo de la Resurrección hasta el domingo de Pentecostés se han de celebrar con alegría y júbilo, como si se tratara de un solo y único día festivo, como un gran domingo"...
url: /2013/tiempo-pascual/
thumbnail: /images/foto-tiempo-pascual-1.jpg
tags: [Notas]

---
[<img decoding="async" loading="lazy" class="size-medium wp-image-1811 alignnone" alt="foto-tiempo-pascual" src="https://mariadelasantafe.org.ar/images/foto-tiempo-pascual.jpg" width="368" height="276" />][1]

El tiempo pascual comprende cincuenta días (en griego = &#8220;Pentecostés&#8221;), vividos y celebrados como un solo día: &#8220;los cincuenta días que median entre el domingo de la Resurrección hasta el domingo de Pentecostés se han de celebrar con alegría y júbilo, como si se tratara de un solo y único día festivo, como un gran domingo&#8221; El tiempo pascual es el más fuerte de todo el año, que se inaugura en la Vigilia Pascual y se celebra durante siete semanas hasta Pentecostés. Es la Pascua (paso) de Cristo, del Señor, que ha pasado el año, que se inaugura en la Vigilia Pascual y se celebra durante siete semanas, hasta Pentecostés. Es la Pascua (paso) de Cristo, del Señor, que ha pasado de la muerte a la vida, a su existencia definitiva y gloriosa. Es la pascua también de la Iglesia, su Cuerpo, que es introducida en la Vida Nueva de su Señor por medio del Espíritu que Cristo le dio el día del primer Pentecostés.

 [1]: https://mariadelasantafe.org.ar/images/foto-tiempo-pascual.jpg