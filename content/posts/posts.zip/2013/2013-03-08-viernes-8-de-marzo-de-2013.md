---
title: Viernes 8 de marzo, 2013 en el “Campito”
date: 2013-03-08T13:19:23+00:0
url: /2013/viernes-8-marzo-2013/
thumbnail: /images/nino-sobre-nube-1.jpg
tags:
  - Mensajes 2013
  - Mensajes Presencia
---
<img decoding="async" loading="lazy" src="https://mariadelasantafe.org.ar/images/nino-sobre-nube.jpg" alt="niño-sobre-nube" width="197" height="260" class="alignright size-full wp-image-1833" />**Dice la Santísima Virgen:**  
“Hijos míos, benditos y amados hijos míos, os doy gracias nuevamente porque estáis junto a la Madre.  
Benditos seáis vosotros por estar escuchando a la Madre, benditos seáis vosotros porque abrís el corazón a Mis palabras, benditos seáis vosotros que acudís a los brazos de ésta Madre, buscando el consuelo y la respuesta a vuestras necesidades, benditos seáis todos vosotros porque tenéis el corazón limpio, tenéis el corazón abierto al Mensaje de María, de ésta Madre que se manifiesta al mundo entero: MARÍA DE LA SANTA FE, ésta Madre que llama constantemente a la conversión de todos los corazones en el mundo entero. 

Abrid vuestras manos recibid el ROSARIO de Mis manos, recibid al NIÑO JESÚS y llevadlo a vuestro corazón, y allí hijitos míos, en vuestro corazón, deben estar estos tesoros que vienen del cielo, para que día a día crezcáis en la Fe, en la fidelidad y en la caridad.

Como Madre, os vengo a enseñar y a mostrar el camino para que saquéis todas las dudas y temores del corazón y avancéis en la luz y en la verdad, socorriendo a las almas que están desesperadas, a los corazones que están angustiados, a tantos de Mis hijos que están en caminos equivocados.

El único camino es Cristo Jesús Mi Hijo Amadísimo, en Él encontráis la libertad, la libertad auténtica para todos vosotros.

Nuevamente gracias, nuevamente seáis benditos, por acudir a escuchar a la Madre, por estar con la Madre, por venir a los pies de ésta Madre para seguir mis consejos, mis llamados y cada uno de Mis Mensajes.

Llevad al mundo Mi palabra, llevad a todos vuestros hermanos Mis palabras, enseñad a rezar a las almas, enseñad a los corazones, buscad a las almas que están oprimidas y que están tan angustiadas.

No temáis, la Madre está con vosotros. Rezad. Rezad. Rezad todos los días el Santo Rosario para vencer los planes de Satanás. Rezad. Rezad. Rezad. 

Sed fuertes y no os sintáis indignos, sed fuertes y trabajad todos para esta Madre, a todos os llamo a trabajar, a todos, no cierro las puertas para nadie, porque ésta Madre quiere a todos los hijos, a todos los hijos por igual.  
Meditad. Meditad. Meditad Mis Palabras.”

**Dice Jesús:**  
“Hermanos míos, Benditos y amados hermanos míos, os amo a todos, os amo, os amo. No temáis, estoy con vosotros en la barca, estoy conduciendo la barca, y Mi Sacratísimo Corazón os bendice, Mi Sacratísimo Corazón os da la paz, la paz a vosotros y la paz al mundo entero.  
Que todas las almas confíen en Mí, que todos los corazones vuelvan a Mí, que la humanidad por entero, busque Mi Camino, busque la luz de Mi Sacratísimo Corazón.

Os amo, porque sois Mis ovejas y no separo a Mis ovejas, reúno a Mis ovejas, convoco a Mis ovejas en un mismo rebaño.  
Os amo infinitamente a todos, porque todos sois Mis hermanos y todos sois Mis hijos. Que nadie ponga barreras a Mi palabra, a Mi paso hacia las almas, porque voy hacia todos los corazones buscando a todas las almas.

Bendigo a los padres, a los hijos, bendigo a las familias, a los jóvenes, a los niños, bendigo a los ancianos, bendigo a todos por igual ya que todos estáis dentro de Mi Sacratísimo Corazón.

Entronizad en el mundo imágenes de MI SACRATÍSIMO CORAZÓN. Dad a las almas una palabra, una palabra de amor, una palabra de aliento.  
Que vuestros pies no queden detenidos, que vuestras bocas no queden cerradas. Dad a todas las almas lo que todos vosotros recibís gratuitamente desde el cielo y desde Mi Sacratísimo Corazón.

Hago descender en éste momento una lluvia de bendición para vosotros, para el mundo entero. Aquí estoy, dándoos Mis palabras, Mis enseñanzas y Mis advertencias.  
No dudéis de Mi tags:
	- Mensajes Presencia. Creed en Mí, acercaos a Mí y no temáis, porque estáis protegidos por mi Sacratísimo Corazón.

Os amo profundísimamente a todos. ¡Os amo! Y derramo Mi Preciosísima Sangre para daros la fuerza, para que estéis fortalecidos, para que jamás dudéis de Mi amor hacia cada uno de vosotros.

¡Os amo! ¡Os amo! ¡Os amo! Meditad. Meditad. Meditad Mis palabras.

Os bendigo, en el Nombre del Padre, y del Hijo, y del Espíritu Santo. Amén.”

[Escuchar el Mensaje][1]{.audio}

 [1]: /wp-content/themes/mdstafe2013/audio/2013/08-03-2013.mp3 "Audio del 08-03-2013"