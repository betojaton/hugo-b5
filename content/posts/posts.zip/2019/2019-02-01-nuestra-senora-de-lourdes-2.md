---
title: NUESTRA SEÑORA DE LOURDES
author: admin

date: 2019-02-01T23:12:34+00:00
url: /nuestra-senora-de-lourdes-2/
tags: [Destacada]

---
**11 de Febrero**  
<img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2019/02/img-nuestra-sra-de-lourdes-368x205.jpg" alt="img-nuestra-sra-de-lourdes" class="alignright size-medium wp-image-4891" /> El 11 de febrero de 1858, tres niñas, Bernadette Soubirous, de 14 años, su hermana Marie Toinete, de 11 y su amiga Jeanne Abadie, de 12 salieron de su casa en Lourdes para recoger leña. Camino al río Gave, pasaron por una gruta natural donde Bernadette escuchó un murmullo y divisó la figura de una joven vestida de túnica blanca, muy hermosa, ceñida por una banda azul y con un rosario colgado del brazo. Se acercó y comenzaron a rezar juntas, para luego desaparecer.  
Por un período de cinco meses, la Virgen se le apareció a la niña, en medio de multitudes que se acercaban para rezar y poder observar a la hermosa señora, pero la Virgen sólo se le aparecía a la niña. En reiteradas ocasiones, Bernadette fue víctima de desprecios y burlas por parte de las autoridades eclesiales y civiles de pueblo, pero la niña se mantuvo firme en su fe mariana sobre todo en el especial pedido que la Virgen le había encargado: la construcción de una capilla sobre la gruta y la realización de una procesión.  
Luego de la última aparición ocurrida en16 de julio, fiesta de Nuestra Señora del Carmen, Bernadette ingresó a la orden religiosa de las hermanas enfermeras, a la edad de 22 años, y permaneció allí hasta su muerte a los 34 años de edad.