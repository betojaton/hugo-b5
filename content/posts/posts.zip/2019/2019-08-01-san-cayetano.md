---
title: San Cayetano
author: admin

date: 2019-08-01T13:27:30+00:00
url: /san-cayetano/
tags: [Destacada]

---
 Este santo, muy popular entre los comerciantes y ganaderos porque los protege de muchos males, nació en 1480 en Vicenza, cerca de Venecia, Italia. Celebramos a San Cayetano de Thiene, el sacerdote italiano fundador de la Orden de Clérigos Regulares Teatinos, conocido como patrono del pan y del trabajo, muy querido por el Papa Francisco y millones de Argentinos.