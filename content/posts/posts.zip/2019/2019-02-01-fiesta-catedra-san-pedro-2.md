---
title: Fiesta de la Cátedra de San Pedro
author: admin

date: 2019-02-01T23:15:14+00:00
url: /fiesta-catedra-san-pedro-2/
thumbnail: /images/img-fiesta-catedra-sana-pedro.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-fiesta-catedra-sana-pedro-1.jpg" alt="img-fiesta-catedra-sana-pedro" class="alignright size-medium wp-image-4880" />**22 de Febrero**  
Hoy se celebra la festividad de la Cátedra de San Pedro, una ocasión solemne que se remonta al cuarto siglo y con la que se rinde homenaje y se celebra el primado y la autoridad de San Pedro.  
La palabra &#8220;cátedra&#8221; significa asiento o trono y es la raíz de la palabra catedral, la iglesia donde un obispo tiene el trono desde el que predica. Sinónimo de cátedra es también &#8220;sede&#8221; (asiento o sitial): la &#8220;sede&#8221; es el lugar desde donde un obispo gobierna su diócesis. Por ejemplo, la Santa Sede es la sede del obispo de Roma, el Papa.  
Todos los años en esta fecha, el altar monumental que acoge la Cátedra de San Pedro permanece iluminado todo el día con docenas de velas y se celebran numerosas misas desde la mañana hasta el atardecer, concluyendo con la misa del Capítulo de San Pedro.