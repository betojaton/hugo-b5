---
title: Oración de la Humildad de San José
author: admin

date: 2019-03-11T14:35:29+00:00
url: /oracion-humildad-san-jose/
thumbnail: /images/humildad-sanjose.jpg
tags: [Destacada]

---
<p style="text-align: center;">
  **Enséñanos, José**<br /> Cómo se es “no protagonista”<br /> Cómo se avanza sin pisotear,<br /> Cómo se colabora sin imponerse,<br /> Cómo se ama sin reclamar.


<p style="text-align: center;">
  **Dinos José**<br /> Cómo se vive siendo “número dos”,<br /> Cómo se hacen cosas fenomenales<br /> desde un segundo puesto.


<p style="text-align: center;">
  **Explícanos**<br /> Cómo se es grande sin exhibirse,<br /> Cómo se lucha sin aplauso,<br /> Cómo se avanza sin publicidad,<br /> Cómo se persevera y se muere uno<br /> sin esperanza de que le<br /> hagan un homenaje.
