---
title: Sagrado Corazón de Jesús
author: admin

date: 2019-06-06T16:21:51+00:00
url: /sagrado-corazon-de-jesus-2019/
tags: [Destacada]

---
 <img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2019/06/img-sagrado-corazon-jesus-jun2019-368x204.jpg" alt="img-sagrado-corazon-jesus-jun2019" class="alignright size-medium wp-image-5044" />La devoción al Corazón de Jesús ha existido des de los primeros tiempos de la Iglesia, cuando se meditaba en el costado y el Corazón abierto de Jesús, de donde salió sangre y agua. De ese Corazón nació la Iglesia y por ese Corazón se abrieron las puertas del Cielo. La devoción al Sagrado Co razón está por encima de otras devociones porque veneramos al mismo Corazón de Dios. Pero fue Jesús mismo quien, en el siglo diecisiete, en Paray-le-Monial, Francia, solicitó, a través de una humilde religiosa, que se estableciera definitiva y específicamente la devoción a su Sacratísimo Corazón. El 16 de junio de 1675 se le apareció Nuestro Señor y le mostró su Corazón a Santa Margarita María de Alacoque, quien escuchó a Nuestro Señor decir: 

> &#8220;He aquí el Corazón que tanto ha amado a los hombres, y en cambio, de la mayor parte de los hombres no recibe nada más que in gratitud, irreverencia y desprecio, en este sacramento de amor.&#8221; 

Con estas palabras Nuestro Señor mismo nos dice en qué consiste la devoción a su Sagrado Corazón. La devoción en sí está dirigida a la persona de Nuestro Señor Jesucristo y a su amor no correspondido, representado por su Corazón. Dos, pues son los actos esenciales de es ta devoción: amor y reparación. Amor, por lo mu-cho que Él nos ama. Reparación y desagravio, por las muchas injurias que recibe sobre todo en la Sagrada Eucaristía.