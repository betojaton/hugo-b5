---
title: 18 de Abril Jueves Santo
author: admin

date: 2019-04-09T20:38:44+00:00
url: /18-abril-jueves-santo/
tags: [Destacada]

---
**Jesús Instituye La Eucaristía:**

> “Jesús celebra su última cena y deja a sus apóstoles la misión, confiere el sacerdocio y la tarea de cele brar siempre la Eucaristía.”