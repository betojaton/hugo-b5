---
title: Maria, Madre y Mediadora de la Gracia
author: admin

date: 2019-10-08T18:08:16+00:00
url: /maria-madre-mediadora-gracia/
thumbnail: /images/img-maria-madre-mediadora-gracia-1.jpg
swift-performance:
  - 'a:0:{}'
fecha_nota:
  - 20191107
tags: [Destacada]

---
<a href="https://mariadelasantafe.org.ar/maria-madre-mediadora-gracia/img-maria-madre-mediadora-gracia/" rel="attachment wp-att-5232"><img decoding="async" src="https://mariadelasantafe.org.ar/images/img-maria-madre-mediadora-gracia.jpg" alt="" class="alignright size-full wp-image-5232" /></a>

> «Asociada por un vínculo estrecho e indisoluble a los misterios de la Encarnación y de la Redención &#8230;; creemos que la Santísima Madre de Dios, nueva Eva, Madre de la Iglesia, continúa en el cielo su misión maternal para con los miembros de Cristo, cooperando al nacimiento y al desarrollo de la vida divina en las al- mas de los redimidos».<footer> (Credo de Pablo VI, n. 15)</footer>