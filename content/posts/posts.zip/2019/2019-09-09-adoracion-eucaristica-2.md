---
title: ADORACIÓN EUCARÍSTICA
author: admin

date: 2019-09-09T14:55:34+00:00
url: /adoracion-eucaristica-2/
tags: [Destacada]

---
## ¿Por qué tener la Adoración Eucarística Perpetua?

¡JESUS LO DESEA!  
Porque Jesús te ama infinitamente, la alegría que le brindas a su Sagrado Corazón es ilimitada cuando pasas una hora con Él en el Santísimo Sacramento.  
En una aparición a santa Margarita María Alacoque Jesús le dijo estas conmovedoras palabras:  
“Tengo sed, una sed ardiente de ser amado por los hombres en el Santísimo Sacramento.”

¡JESÚS NOS DA SUS GRACIAS!  
<a href="https://mariadelasantafe.org.ar/adoracion-eucaristica-2/foto-caliz-iluminado/" rel="attachment wp-att-5156"><img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2019/09/foto-caliz-iluminado-368x276.jpg" alt="foto-caliz-iluminado" class="alignright size-medium wp-image-5156" /></a>Jesús permanece día y noche con nosotros en el Santísimo Sacramento llamándonos:“Vengan a mí todos los que están fatigados y agobiados, y yo os daré descanso.” (Mt 11, 28).

Jesús se queda con nosotros en el Santísimo Sacramento para darnos descanso de corazón, mente y espíritu por medio de sus gracias que nos animan, nos consuelan, nos fortalecen, nos guían y nos inspiran a poner toda nuestra confianza en su Sagrado Corazón. El poder de su amor desecha todo temor, toda duda, toda preocupación y ansiedad que podamos tener. 

En su carta encíclica Misterio y culto de la Eucaristía, el Papa Juan Pablo II dice: “La animación y robustecimiento del culto Eucarístico son una prueba de esa auténtica renovación que el con?cilio se ha propuesto y de la que es el punto central. 

La Iglesia y el mundo tienen una gran necesidad del culto Eucarístico. Jesús nos espera en este Sacramento de Amor. No escatimemos tiempo para ir a encontrarlo en la adoración, en la contemplación… No cese nunca nuestra adoración”. Esto es Adoración Eucarística Perpetua: ¡Adoración incesante!

¡TODOS PUEDEN PARTICIPAR!  
Todos pueden participar porque todos podemos hacerle compañía a Jesús por lo menos una hora por semana. Cualquier hora que escojamos será del agrado del Señor, pero le complace en especial los que hacen el sacrificio de acompañarlo en medio de la noche para que la adoración perpetua se haga realidad.

¡EL CAMINO A UNA VERDADERA RELACIÓN PERSONAL CON JESÚS!