---
title: Donaciones a la Cooperadora del Hospital Iturraspe
author: admin

date: 2019-08-16T18:24:25+00:00
url: /donaciones-cooperadora-hospital-iturraspe/
thumbnail: /images/foto-colaboraciones@2x-1.jpg
swift-performance:
  - 'a:0:{}'
fecha_nota:
  - 20190722
tags: [Destacada]

---
<a href="https://mariadelasantafe.org.ar/donaciones-cooperadora-hospital-iturraspe/foto-colaboraciones2x/" rel="attachment wp-att-5120"><img decoding="async" src="https://mariadelasantafe.org.ar/images/foto-colaboraciones@2x.jpg" alt="Colaboracion Hospital Iturraspe" class="alignright size-medium wp-image-5120" /></a>  
El día 22 de Julio, el Grupo de oración de la Santísima Virgen María, hizo entrega de las donaciones a la Cooperadora del Hospital Iturraspe y al Centro de Apoyo al Enfermo de Leucemia (CENAELE).