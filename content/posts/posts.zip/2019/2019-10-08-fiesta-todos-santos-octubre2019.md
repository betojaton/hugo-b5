---
title: Fiesta de todos los Santos
author: admin

date: 2019-10-08T17:50:24+00:00
url: /fiesta-todos-santos-octubre2019/
tags: [Destacada]

---
[<img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2000/12/img-fiesta-todos-santos.jpg" alt="fiesta-todos-santos" class="alignright size-full wp-image-5201" />][1]Para toda la Iglesia es una gran celebración porque hay gran fiesta en el cielo. Para nosotros es una gran oportunidad de agradecer todos los beneficios, todas las gracias que Dios ha derramado en personas que han vivido en esta tierra y que han sido como nosotros, con las mismas debilidades, y con las fortalezas que vienen del mismo Dios.  
Celebremos este día con un corazón agradecido, porque Dios ha estado grande con nosotros y estamos alegres.

 [1]: https://mariadelasantafe.org.ar/img-fiesta-todos-santos/