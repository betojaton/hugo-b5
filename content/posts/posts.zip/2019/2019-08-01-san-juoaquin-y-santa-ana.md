---
title: San Juoaquín y Santa Ana 
author: admin

date: 2019-08-01T13:19:36+00:00
url: /san-juoaquin-y-santa-ana/
thumbnail: /images/img-sanjoaquin-santana.jpg
swift-performance:
  - 'a:0:{}'
fecha_nota:
  - 20190726
tags: [Destacada]

---
El protoevangelio de Santiago cuenta que los vecinos de Joaquín se burlaban de él porque no tenía hijos. Entonces, el santo se retiró cuarenta días al desierto a orar y ayunar, en tanto que Ana (cuyo nombre significa Gracia) &#8220;se quejaba en dos quejas y se lamentaba en dos lamentaciones&#8221;. Un ángel se le apareció y le dijo: &#8220;Ana, el Señor ha escuchado tu oración: concebirás y darás a luz. Del fruto de tu vientre se hablará en todo el mundo&#8221;. A su debido tiempo nació María, quien sería la Madre de Dios. Esta narración se parece mucho a la de la conepción y el nacimiento de Samuel, cuya madre se llamaba también Ana ( I Reyes, I ). Los primeros Padres de la Iglesia oriental veían en ello un paralelismo. En realidad, se puede hablar de paralelismo entre la narración de la concepción de Samuel y la de Juan Bautista, pero en el caso presente la semejanza es tal, que se trata claramente de una imitación. 