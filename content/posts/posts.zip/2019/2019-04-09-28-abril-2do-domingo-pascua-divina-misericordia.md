---
title: 28 de Abril 2do. Domingo de Pascua La Divina Misericordia
author: admin

date: 2019-04-09T20:47:16+00:00
url: /28-abril-2do-domingo-pascua-divina-misericordia/
thumbnail: /images/img-fiesta-divina-misericordia@2x-1.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-fiesta-divina-misericordia@2x.jpg" alt="img-fiesta-divina-misericordia" class="alignright size-medium wp-image-4965" />“La humanidad no conseguirá la paz hasta que no se dirija con confianza a Mi misericordia&#8221; (Diario, 300)  
La Fiesta de la Divina Misericordia tiene como fin principal hacer llegar a los corazones de cada persona el siguiente mensaje: Dios es Misericordioso y nos ama a todos &#8230; &#8220;y cuanto más grande es el pecador, tanto más grande es el derecho que tiene a Mi misericordia&#8221; (Diario, 723).  
En este mensaje, que Nuestro Señor nos ha hecho llegar por medio de Santa Faustina, se nos pide que tengamos plena confianza en la Misericordia de Dios, y que seamos siempre misericordiosos con el prójimo a través de nuestras palabras, acciones y oraciones&#8230; &#8220;porque la fe sin obras, por fuerte que sea, es inútil&#8221; (Diario, 742).  
Con el fin de celebrar apropiadamente esta festividad, se recomienda rezar la Coronilla y la Novena a la Divina Misericordia; confesarse -para la cual es indispensable realizar primero un buen examen de conciencia, y recibir la Santa Comunión el día de la Fiesta de la Divina Misericordia.  
La Congregación para el Culto Divino y la Disciplina de los Sacramentos publicó el 23 de mayo del 2000 un decreto en el que se establece, por indicación de Juan Pablo II, la fiesta de la Divina Misericordia, que tendrá lugar el segundo domingo de Pascua. La denominación oficial de este día litúrgico será «segundo domingo de Pascua o de la Divina Misericordia».  
Ya el Papa lo había anunciado durante la canonización de Sor Faustina Kowalska, el 30 de abril: «En todo el mundo, el segundo domingo de Pascua recibirá el nombre de domingo de la Divina Misericordia. Una invitación perenne para el mundo  
cristiano a afrontar, con confianza en la benevolencia divina, las dificultades y las pruebas que esperan al genero humano en los años venideros».