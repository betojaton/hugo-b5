---
title: ADORACIÓN EUCARÍSTICA
author: admin

date: 2019-10-08T16:55:32+00:00
url: /adoracion-eucaristica-2019-2/
thumbnail: /images/foto-caliz-luminoso.jpg
swift-performance:
  - 'a:0:{}'
fecha_nota:
  - 20191008
tags: [Destacada]

---
## <a href="https://mariadelasantafe.org.ar/donaciones-cooperadora-hospital-iturraspe/foto-caliz-luminoso/" rel="attachment wp-att-5118"><img decoding="async" class="alignright size-medium wp-image-5118" src="https://mariadelasantafe.org.ar/images/foto-caliz-luminoso-1.jpg" alt="foto-caliz-luninoso" /></a>GUÍA PARA ADORADORES de las capillas de adoración perpetua.

  1. Adora a tu Señor en silencio. La adoración debe ser en silencio. No debemos temer al silencio. En el silencio del corazón puede hablar Dios. Es importante aprender a escucharlo. Además debemos respetar el diálogo íntimo y la oración de cada uno.
  2. Tu cita de honor con el Señor, tu Hora Santa, es una vez a la semana, pero recuerda, la adoración es perpetua, es para siempre. Esto, desde luego, no quiere decir que no puedas cambiar tu hora o tu día en el futuro. Sin embargo, lo que no debes hacer es no cumplir con tu hora y luego tomar otra a cambio. Recuerda que para que el Señor sea adorado sin interrupción es importante que cada uno honre su compromiso.
  3. Es fundamental la puntualidad (llegar 5 minutos antes) Primero por respeto al Señor y luego por respeto y caridad hacia el adorador anterior.
  4. El Señor no debe quedar nunca solo, bajo ningún concepto.
  5. En caso de no poder asistir a tu hora asignada comunícate de inmediato con tus compañeros de hora para asegurar que al menos uno de ellos esté presente ante el Santísimo Sacramento ya que tú estarás ausente. Nunca supongas que el otro o los otros compañeros de hora han de estar presentes porque lo mismo puede ocurrirles a los demás y ninguno se presenta quedando el Santísimo desatendido. Es necesario una confirmación verbal directa (no dejando un aviso en el contestador, mensaje de texto, ni e-mail).
  6. Si no tienes quién te cubra de tu mismo día y hora llama a un miembro de la misma hora de otro día y arregla con él un cambio de día. Otra forma de buscar quién cubra es llamar a alguno de la hora anterior o de la hora posterior. Tú harás lo mismo el día de mañana cuando esa persona no pueda concurrir.
  7. Si sigues sin encontrar sustituto puedes buscar personas que no estén anotadas (familiares, amigos etc.) pero antes las debes preparar. Se les debe explicar la Guía del Adorador y la Sustitución.
  8. Después de 4 o 5 llamadas no debería ser difícil conseguir un reemplazo. Si aún así no consigues un sustituto recién entonces llama al capitán de hora. La responsabilidad de cada adorador es conseguir el sustituto. Si no se obtienen resultados entonces el capitán de hora asegurará que el Santísimo Sacramento no quede desatendido. Si no has de poder asistir por más de una semana (vacaciones, etc.) es necesario que lo comuniques al coordinador de hora.
  9. Recuerda firmar el libro al llegar y antes de retirarte verifica que llegó el adorador de la hora siguiente.
 10. Si al terminar tu hora santa ves que nadie aparece para tomar la siguiente hora,debes comunicarte con el capitán de hora correspondiente quien tratará de encontrar el sustituto. Mientras tanto debes permanecer con el Santísimo Sacramento hasta que la situación se resuelva. Podrás también llamar a la persona que está en la hora subsiguiente a la de quien faltó para ver si puede llegar antes.
 11. Has de contar o tener acceso a una lista completa de los nombres y teléfonos de todos los miembros de la adoración perpetua (estará en el acceso a la capilla).
 12. Es importante que asistas a las reuniones que los coordinadores inviten porque así podrás conocer quiénes son los otros miembros de tu misma hora de distintos días (equipo de oración). Esto hará que el eventual proceso de sustitución sea más fácil.

> El mejor tiempo en la tierra, es aquel que pasamos con nuestro Mejor Amigo, Jesús, en el Santísimo Sacramento.  
> &#8220;Pasen un tiempo en silencio ante Su tags:
	- Mensajes Presencia dejando que el Espíritu hable a vuestros corazones: Basta ya; sabed que yo soy Dios. <footer>Sal 46 11</footer> 

> Donde yo esté, estará también mi servidor&#8217; <footer>Jn 12, 2</footer>