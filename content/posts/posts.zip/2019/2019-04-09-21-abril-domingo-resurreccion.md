---
title: 21 de Abril Domingo de Resurrección
author: admin

date: 2019-04-09T20:44:25+00:00
url: /21-abril-domingo-resurreccion/
thumbnail: /images/img-domingo-resurreccion@2x-1.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-domingo-resurreccion@2x.jpg" alt="img-domingo-resurreccion@2x" class="alignright size-medium wp-image-4964" />La Resurrección es una verdad fundamental del cristianismo. Cristo verdaderamente resucitó por el poder de Dios. No se trata de un fantasma, ni una mera fuerza de energía, ni de un cuerpo revivido como el de Lázaro que volvió a morir. La presencia de Jesús resucitado no se trata de alucinaciones por parte de los Apóstoles.  
Cuando decimos &#8220;Cristo vive&#8221; no estamos usando una manera de hablar, como piensan algunos, para decir que vive solo en nuestro recuerdo. La cruz, muerte y resurrección de Cristo son hechos históricos que sacudieron el mundo de su época y transformaron la historia de todos los siglos. Cristo vive para siempre con el mismo cuerpo con que murió, pero este ha sido transformado y glorificado (Cf. Cor.15:20, 35-45) de manera que goza de un nuevo orden de vida como jamás vivió un ser humano.