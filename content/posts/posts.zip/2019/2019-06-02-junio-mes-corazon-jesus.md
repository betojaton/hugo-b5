---
title: JUNIO – Mes del Corazón de Jesús
author: admin

date: 2019-06-02T15:10:25+00:00
abstract: '<iframe width="100%" height="315" src="https://www.youtube.com/embed/cn5bPqvQzwY" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>'
url: /junio-mes-corazon-jesus/
tags: [Destacada]

---
