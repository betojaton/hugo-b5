---
title: Santa Teresita del Niño Jesús
author: admin

date: 2019-09-10T14:51:20+00:00
url: /santa-teresita-nino-jesus/
tags: [Destacada]

---
Santa Teresa del Niño Jesús nació en la ciudad francesa de Alencon, el 2 de enero de 1873, sus padres ejemplares eran Luis Martin y Acelia María Guerin, ambos venerables. Murió en 1897, y en 1925 el Papa Pío XI la canonizó, y la proclamaría después patrona universal de las misiones.

La llamó «la estrella de mi pontificado», y definió como «un huracán de gloria» el movimiento universal de afecto y devoción que acompañó a esta joven carmelita. Proclamada &#8220;Doctora de la Iglesia&#8221; por el Papa Juan Pablo II el 19 de Octubre de 1997 (Día de las misiones).  
<a href="https://mariadelasantafe.org.ar/adoracion-eucaristica-2/img-santa-teresita-nino-jesus-2/" rel="attachment wp-att-5160"><img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2019/09/img-santa-teresita-nino-jesus-368x188.jpg" alt="img-santa-teresita-nino-jesus" class="aligncenter size-medium wp-image-5160" /></a>