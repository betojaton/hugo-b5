---
title: 19 de Abril Viernes Santo
author: admin

date: 2019-04-09T20:40:18+00:00
url: /19-abril-viernes-santo/
tags: [Destacada]

---
**La Muerte De Cristo En La Cruz:**

> “Jesús es crucificado y allí muere, la Virgen María al pie de la cruz contempla desconsolada ese triste espectáculo, en soledad llora Ella resignándose a la voluntad de Dios&#8221;.