---
title: Ángeles Custodios
author: admin

date: 2019-09-10T15:05:18+00:00
url: /angeles-custodios/
thumbnail: /images/img-fiesta-angeles-custodios.jpg
swift-performance:
  - 'a:0:{}'
fecha_nota:
  - 20191002
tags: [Destacada]

---
En el año 1608 el Sumo Pontífice extendió a toda la Iglesia universal la fiesta de los Ángeles Custodios y la colocó el día 2 de octubre.  
<a href="https://mariadelasantafe.org.ar/adoracion-eucaristica-2/img-fiesta-angeles-custodios/" rel="attachment wp-att-5158"><img decoding="async" src="https://mariadelasantafe.org.ar/images/img-fiesta-angeles-custodios-1.jpg" alt="img-fiesta-angeles-custodios" class="aligncenter size-medium wp-image-5158" /></a>