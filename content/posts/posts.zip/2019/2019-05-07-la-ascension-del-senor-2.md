---
title: La Ascensión del Señor
author: admin

date: 2019-05-07T18:39:21+00:00
url: /la-ascension-del-senor-2/
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2019/05/img-ascension-senior-368x394.jpg" alt="img-ascension-senior" class="alignright size-medium wp-image-5016" />  
A los cuarenta días después de la Resurrección habiendo instruido a sus Apóstoles sobre la nobilísima misión de establecer el Reino de Dios en el mundo, Jesús iba a subir al cielo, donde le esperaban las glorias celestiales. Bendijo a su querida Madre, a los Apóstoles y discípulos y se despidió de ellos. Una nube lo ocultó de sus miradas. Le acompañaban innumerables espíritus, los primeros frutos de la redención, que Él había sacado del Limbo. Las jerarquías angélicas salían al encuentro del Salvador del mundo. Al situarse junto al Padre, toda la corte celestial entonó un himno glorioso de alabanza, como el que oyó Juan en sus visiones: &#8220;Digno es el Cordero, que ha sido degollado, de recibir el poder y la riqueza, la sabiduría y la fuerza, la honra, la gloria y la alabanza&#8221; (Ap 5, 12). Jesús entró en los cielos para tomar posesión de su gloria.