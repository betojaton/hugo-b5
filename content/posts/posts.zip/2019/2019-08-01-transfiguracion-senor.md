---
title: La Transfiguración del Señor 
author: admin

date: 2019-08-01T13:25:54+00:00
url: /transfiguracion-senor/
thumbnail: /images/img-jesus-aparece-monatana.jpg
swift-performance:
  - 'a:0:{}'
fecha_nota:
  - 20190806
tags: [Destacada]

---
Esta fiesta recuerda la escena en que Jesús, en la cima del monte Tabor, se apareció vestido de gloria, hablando con Moisés y Elías ante sus tres discípulos preferidos, Pedro, Juan y Santiago.  
Tres discípulos preferidos, Pedro, Juan y Santiago. La fiesta de la Transfiguración del Señor se venía celebrando desde muy antiguo en las iglesias de Oriente y Occidente, pero el papa Calixto III, en 1457 la extendió a toda la cristiandad para conmemorar la victoria que los cristianos obtuvieron en Belgrado, sobre Mahomet II, orgulloso conquistador de Constantinopla y enemigo del cristianismo, y cuya noticia llegó a Roma el 6 de agosto.