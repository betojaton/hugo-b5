---
title: Nuestra Señora del Pilar
author: admin

date: 2019-10-08T17:38:02+00:00
url: /nuestra-senora-pilar-octubre2019/
tags: [Destacada]

---
[<img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2000/12/img-nuetsra-senora-pilar-368x206.jpg" alt="nuestra-senora-pilar" class="alignright size-medium wp-image-5202" />][1]La tradición de la Virgen del Pilar, tal como ha surgido de unos documentos del siglo XIII que se conservan en la catedral de Zaragoza, se remonta a la época inmediatamente posterior a la Ascensión de Jesucristo, cuando los apóstoles predicaban el Evangelio. Se dice que Santiago el Mayor había desembarcado en la Península por el puerto de Cartagena, lugar donde fundó la primera diócesis española, predicando desde entonces por diversos territorios del país.  
Los documentos dicen textualmente que Santiago, &#8220;llegó con sus nuevos discípulos a través de Galicia y de Castilla, hasta Aragón, donde está situada la ciudad de Zaragoza, en las riberas del Ebro. Allí predicó Santiago muchos días y, entre los muchos convertidos eligió como acompañantes a ocho hombres, con los cuales trataba de día del reino de Dios, y por la noche, recorría las riberas para tomar algún descanso&#8221;. En la noche del 2 de enero del año 40, Santiago se encontraba con sus discípulos junto al río Ebro cuando &#8220;oyó voces de ángeles que cantaban Ave María, Gratia Plena y vio aparecer a la Virgen Madre de Cristo, de pie sobre un pilar de mármol&#8221;.  
La Santísima Virgen, que aún vivía en carne mortal, le pidió al Apóstol que se le construyese allí una iglesia, con el altar en torno al pilar donde estaba de pie y prometió que &#8220;permanecerá este sitio hasta el fin de los tiempos para que la virtud de Dios obre portentos y maravillas por mi intercesión con aquellos que en sus necesidades imploren mi patrocinio&#8221;. Desapareció la Virgen y quedó ahí el pilar. El Apóstol Santiago y los ocho testigos del prodigio comenzaron inmediatamente a edificar una iglesia en aquel sitio y, antes de que estuviese terminada la Iglesia, Santiago ordenó presbítero a uno de sus discípulos para servicio de la misma, la consagró y le dio el título de Santa María del Pilar, antes de regresarse a Judea.  
Esta fue la primera iglesia dedicada en honor a la Virgen Santísima. 

 [1]: https://mariadelasantafe.org.ar/img-nuetsra-senora-pilar/