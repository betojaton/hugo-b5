---
title: 11 Puntos importantes sobre el Miercoles de Ceniza
author: admin

date: 2019-02-01T23:23:25+00:00
url: /11-puntos-importantes-sobre-el-miercoles-de-ceniza/
thumbnail: /images/img-miercoles-ceniza-3.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-miercoles-ceniza-2.jpg" alt="img-miercoles-ceniza" class="alignright size-medium wp-image-4896" />

### Lo que debes saber sobre el Miércoles de Ceniza 

Miércoles 6 de marzo; día en que comienza la Cuaresma, período de 40 días en el cual los cris voluntarias, la limosna, y los actos de caridad y misericordia, como preparación para celebrar la Pasión, Muerte y Resurrección de Jesucristo. 

En este día, en el que se practica el ayuno y la abstinencia de carne, se efectúa el rito de la imposición de la ceniza en la cabeza de los fieles. Se trata de las cenizas de los ramos de olivo del año anterior. 

> “El comienzo de los cuarenta días de penitencia, en el Rito romano, se caracteriza por el austero símbolo de las cenizas, que distingue la Liturgia del Miércoles de Ceniza. Propio de los antiguos ritos con los que los pecadores convertidos se sometían a la penitencia canónica, el gesto de cubrirse con ceniza tiene el sentido de reconocer la propia fragilidad y mortalidad, que necesita ser redimida por la misericordia de Dios.  
> Lejos de ser un gesto puramente exterior, la Iglesia lo ha conservado como signo de la actitud del corazón penitente que cada bautizado está llamado a asumir en el itinerario cuaresmal. Se debe ayudar a los fieles, que acuden en gran número a recibir la Ceniza, a que capten el significado interior que tiene este gesto, que abre a la conversión y al esfuerzo de la renovación pascual”

.