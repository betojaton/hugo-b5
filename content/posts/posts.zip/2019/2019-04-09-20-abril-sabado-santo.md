---
title: 20 de Abril Sábado Santo
author: admin

date: 2019-04-09T20:42:21+00:00
url: /20-abril-sabado-santo/
thumbnail: /images/img-sabado-santo@2x-1.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-sabado-santo@2x.jpg" alt="img-sabado-santo-2019" class="alignright size-medium wp-image-4968" />

> &#8220;Durante el Sábado santo la Iglesia permanece junto al sepulcro del Señor, meditando su pasión y su muerte, su descenso a los infiernos y esperando en oración y ayuno su resurrección.  
> Es el día del silencio: la comunidad cristiana vela junto al sepulcro. Callan las campanas y los instrumentos. Se ensaya el aleluya, pero en voz baja. Es día para profundizar. Para contemplar.  
> El altar está despojado. El sagrario, abierto y vacío.  
> La Cruz sigue entronizada desde ayer. Central, iluminada, con un paño rojo, con un laurel de victoria. Dios ha muerto. Ha querido vencer con su propio dolor el mal de la humanidad.