---
title: San Francisco de Asís
author: admin

date: 2019-09-13T10:04:47+00:00
url: /san-francisco-asis-oct2019-2/
tags: [Destacada]

---
Memoria de san Francisco, el cual, después de una juventud despreocupada, se convirtió a la vida evangélica en Asís, localidad de Umbría, en Italia, y encontró a Cristo sobre todo en los pobres y necesitados, haciéndose pobre él mismo. Instituyó los Hermanos Menores y, viajando, predicó el amor de Dios a todos y llegó incluso a Tierra Santa. Con sus palabras y actitudes mostró siempre su deseo de seguir a Cristo, y escogió morir recostado sobre la nuda tierra .  
<a href="https://mariadelasantafe.org.ar/nuestra-senora-rosario-oct2019/img-san-franscisco-asis-oct2019/" rel="attachment wp-att-5188"><img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2019/09/img-san-franscisco-asis-oct2019-368x199.jpg" alt="san-franscisco-asis-oct2019" class="aligncenter size-medium wp-image-5188" /></a>