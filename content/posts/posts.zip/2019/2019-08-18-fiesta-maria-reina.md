---
title: Fiesta de María Reina
author: admin

date: 2019-08-18T15:44:42+00:00
url: /fiesta-maria-reina/
tags: [Destacada]

---
<a href="https://mariadelasantafe.org.ar/donaciones-cooperadora-hospital-iturraspe/img-fiesta-maria-reina-2/" rel="attachment wp-att-5122"><img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2019/08/img-fiesta-maria-reina-368x205.jpg" alt="Imagen Maria Reina" class="alignright size-medium wp-image-5122" /></a>

### Santa María Reina

 Celebramos a Santa María Reina, la que comparte la vida y el amor de Cristo Rey  “Es una Reina que da todo lo que posee compartiendo, sobre todo, la vida y el amor de Cristo”, dijo San Juan Pablo II al referirse a la Virgen como Reina del Universo. La fiesta fue instituida por el Papa Pío.  En la Encíclica “Ad Caeli Reginam” (punto 15), que trata sobre la dignidad y realeza de María, se lee que “Cristo, el nuevo Adán, es nuestro Rey no sólo por ser Hijo de Dios, sino también por ser nuestro Redentor”.  “Así, según una cierta analogía, puede igualmente afirmarse que la Beatísima Virgen es Reina, no sólo por ser Madre de Dios, sino también por haber sido asociada cual nueva Eva al nuevo Adán”.  

Por su parte, el Papa Bendicto XVI mintras celebraba esta fiesta en el 2012 dijo que María “es Reina precisamente amándonos y ayudándonos en todas nuestras necesidades, es nuestra hermana y sierva humilde”. He aquí una de las tantas razones por las cuales el Papa Francisco ha twiteado este mes pequeñas oraciones de súplica a la Madre de Dios por la paz en el mundo y en especial por los cristianos en Medio Oriente. Como la del 14 de agosto que dice: “María, Reina de la paz, ayúdanos a erradicar el odio y a vivir en armonía”. O la del día siguiente, en la que pide a María, Reina del Cielo, que nos ayude a transformar el mundo según el designio de Dios.