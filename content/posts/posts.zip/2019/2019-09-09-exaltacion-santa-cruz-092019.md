---
title: Exaltación de la Santa Cruz
author: admin

date: 2019-09-09T15:13:48+00:00
url: /exaltacion-santa-cruz-092019/
tags: [Destacada]

---
<a href="https://mariadelasantafe.org.ar/adoracion-eucaristica-2/img-exaltacion-santa-cruz/" rel="attachment wp-att-5157"><img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2019/09/img-exaltacion-santa-cruz-368x205.jpg" alt="img-exaltacion-santa-cruz" class="alignright size-medium wp-image-5157" /></a>Hacia el año 320 la Emperatriz Elena de Constantinopla encontró la Vera Cruz, la cruz en que murió Nuestro Señor Jesucristo, La Emperatriz y su hijo Constantino hicieron construir en el sitio del descubrimiento la Basílica del Santo Sepulcro, en el que guardaron la reliquia.

Años después, el rey Cosroes II de Persia, en el 614 invadió y conquistó Jerusalén y se llevó la Cruz poniéndola bajo los pies de su trono como signo de su desprecio por el cristianismo. Pero en el 628 el emperador Heraclio logró derrotarlo y recuperó la Cruz y la llevó de nuevo a Jerusalén el 14 de septiembre de ese mismo año. Para ello se realizó una ceremonia en la que la Cruz fue llevada en persona por el emperador a través de la ciudad. Desde entonces, ese día quedó señalado en los calendarios litúrgicos como el de la Exaltación de la Vera Cruz