---
title: San Juan Pablo II
author: admin

date: 2019-10-08T17:43:45+00:00
url: /san-juan-pablo-ii-2/
tags: [Destacada]

---
[<img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2000/12/img-sanjuan-pabloII.jpg" alt="" class="alignright size-full wp-image-5203" />][1]San Juan Pablo II, jugó un papel importante en el surgimiento de este gran momento que la Iglesia junto a los jóvenes celebra, que es la Jornada Mundial de la Juventud; ya que fue dentro de su pontificado en donde surge esta iniciativa que ha trascendido y sigue trascendiendo con el transcurrir del tiempo. Te dejamos a continuación con algunas frases de este gran Santo, que nos motivan a animar y a confiar que Dios es perfecto en todo tiempo. 

> “Vosotros mis queridos amigos en el dolor, a través del sufrimiento descubriréis más fácilmente y nos enseñaréis a los demás a descubrir a Jesucristo, camino, verdad y vida. Mirad al Señor, varón de dolores, centrad vuestra atención en Jesús, que joven también como vosotros, con su muerte en la cruz hizo ver al hombre el valor, la reserva de energías para su tarea evangelizadora.”

>  “Quisiera que la juventud del mundo entero se acercase más a María &#8230; que los jóvenes tengan más confianza en ella y que confíen en ella la vida que se abre ante ellos”.

 [1]: https://mariadelasantafe.org.ar/img-sanjuan-pabloii/