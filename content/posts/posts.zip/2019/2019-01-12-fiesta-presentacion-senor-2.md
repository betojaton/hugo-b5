---
title: Fiesta de la Presentación del Señor
author: admin

date: 2019-01-12T15:08:59+00:00
url: /fiesta-presentacion-senor-2/
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2000/12/img-fiesta-presentacion-368x206.jpg" alt="img-fiesta-presentacion" class="alignright size-medium wp-image-4850" />**2 de Febrero**  
Dios cumple siempre sus promesas.  
Cuarenta días después del Nacimiento del Señor, fue presentado en elTemplo en obediencia a la Ley.  
Según ella, no había fecha para la presentación del niño, pero como la madre quedaba impura durante cuarenta días, y ni podía tocar nada santo ni acudir al santuario (Lv 12,2), durante ese tiempo no podía presentar al Niño en el Templo, como ordena el Exodo, 13,12: 

> “consagrarás a Dios todos los primogénitos”

Con esta fiesta se concluyen las solemnidades de la Encarnación del Verbo de Dios.