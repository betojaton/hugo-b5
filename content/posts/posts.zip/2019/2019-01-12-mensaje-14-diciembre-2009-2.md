---
title: Mensaje, 14 de Diciembre 2009
author: admin

date: 2019-01-12T14:54:45+00:00
url: /mensaje-14-diciembre-2009-2/
tags: [Notas]

---
**Me dice Jesús.**  
<img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2000/12/foto-caliz-368x298.jpg" alt="foto-caliz" class="alignright size-medium wp-image-4846" /> 

> **Hermanos míos:** benditos y amados hermanos míos. Vuelco nuevamente, Mi Preciosísima Sangre en vosotros. ¡Os doy el bálsamo! Para curar las heridas. ¡Os doy Mi Cuerpo y Mi Sangre! Para que así os fortalezcáis, frente a las pruebas y las tribulaciones. Os doy Mi Paz. ¡Cada día Mi Paz! Para fortalecer la paz de vuestro corazón. ¡Para fortaleceros a vosotros! ¡Mis ovejas! ¡Mis discípulos! ¡Mis apóstoles!  
> Os doy Mi Paz. ¡Para que vosotros transmitáis la paz a vuestros hermanos! Os envuelvo en Mi Amor. ¡Os envuelvo en Mi Divina Misericordia! Para transformaros, cada día. Para modelaros, cada día. Para haceros verdaderos soldados, de Mi Amor, en todas las naciones.  
> Hermanos míos. ¡Hijos míos! ¡Predilectos míos! ¡Escuchad Mi Voz! ¡Escuchad Mis Palabras! ¡Escuchad Mis Enseñanzas! Porque soy el Buen Pastor. Porque soy el Verdadero Pastor. ¡Qué os guío! ¡Qué os conduzco! ¡Qué os señalo, el auténtico camino!  
> ¡No temáis! Y avanzad. ¡No temáis! Y trabajad. ¡Avanzad junto a Mi Sacratísimo Corazón! ¡Avanzad junto a Mí! Y dejad de lado, tantos pasatiempos inútiles. Tantos pasatiempos vanos, que os aniquilan el corazón. ¡Qué os anulan el corazón! ¡Qué os entorpecen el corazón! ¡Disfrutad de Mi Amor! ¡Disfrutad de Mis tags:
	- Mensajes Presencia! ¡Todo el cielo está aquí en éste momento! Toda la corte celestial. ¡Está aquí, en éste momento!  
> ¡No dudéis jamás de Mi Amor hacia vosotros! ¡Todos estáis, en Mi Sacratísimo Corazón! ¡Todos sois mis ovejas! ¡Comportaos como ovejas! Verdaderamente ovejas blancas. ¡Trabajad pues! Para cuidar vuestra lana. Para que se mantenga blanca, radiante, pura. ¡Trabajad verdaderamente!  
> Para que en vuestro corazón brille la paz, la verdad y el amor.  
> ¡Os enseño, cada día! ¡Os muestro, cada día Mi Camino! Tomad Mi Camino. ¡El verdadero! ¡El auténtico! El camino que conduce a la vida eterna. ¡Tomad el camino de Mi Sacratísimo Corazón! ¡Tomad! El camino de Mi Paz, de Mi Verdad. El camino de Mi Divina Misericordia.  
> ¡Os amo! Pequeñas ovejitas mías. ¡Os amo! ¡Os amo! ¡Haceos humildes y servidores de los demás! Servidores auténticos, de todos vuestros hermanos.  
> Recibid, Mi Cuerpo. Recibid, Mi Sangre.  
> Meditad, Meditad, Meditad, Mis Palabras. <footer>Leed: Salmo 73 </footer> 

Os bendigo, en el Nombre del Padre y del Hijo y del Espíritu Santo, Amén.