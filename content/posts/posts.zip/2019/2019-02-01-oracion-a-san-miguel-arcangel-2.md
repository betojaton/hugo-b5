---
title: Oración a San Miguel Arcángel
author: admin

date: 2019-02-01T22:53:10+00:00
url: /oracion-a-san-miguel-arcangel-2/
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2019/02/estatua-miguel-arcangel-339x420.jpg" alt="estatua-miguel-arcangel" class="alignright size-medium wp-image-4877" />

### 24-04-2009

> Decid Hijos Míos ésta Oración en todo momento y en toda necesidad: San Miguel Arcángel Príncipe de la Milicia Celestial, defiéndenos de los ataques, defiéndenos de las asechanzas del maligno, cúbrenos con la espada de tu poder, cúbrenos con la espada poderosa, para defendernos y protegernos permanentemente. San Miguel Arcángel forma una barrera para que el maligno no pueda atravesar y no pueda invadir nuestros corazones, nuestras mentes, nuestro espíritu. San Miguel Arcángel protégenos de los males espirituales, de los males físicos, protégenos, cúbrenos y fortalece nuestra voluntad para no caer en la tentación, danos fortaleza San Miguel Arcángel. Amén.