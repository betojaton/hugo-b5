---
title: Consagración a la Virgen del Carmen
author: admin

date: 2019-08-01T13:11:25+00:00
url: /consagracion-virgen-carmen/
thumbnail: /images/img-consagracion-virgen-carmen.jpg
swift-performance:
  - 'a:0:{}'
fecha_nota:
  - 20190716
tags: [Destacada]

---
Memoria de la Bienaventurada Virgen María del Monte Carmelo, monte en el que Elías consiguió que el pueblo de Israel volviese a dar culto al Dios vivo y en el que, más tarde, algunos, buscando la soledad, se retiraron para hacer vida eremítica, dando origen con el correr del tiempo a una orden religiosa de vida contemplativa, que tiene como patrona y protectora a la Madre de Dios. A mediados del siglo XII, un grupo de devotos de Tierra Santa procedentes de Occidente -algunos creen que venían de Italia-, decidieron instalarse en el mismo valle que sus antecesores y escogieron como patrona a la Virgen María. Allí construyeron la primera iglesia dedicada a Santa María del Monte Carmelo. Desde su monasterio no quisieron crear una nueva forma de culto mariano, ni tampoco, el título de la advocación, respondía a una imagen en especial. Quisieron vivir bajo los aspectos marianos que salían reflejados en los textos evangélicos: maternidad divina, virginidad, inmaculada concepción y anunciación. Estos devotos que decidieron vivir en comunidad bajo la oración y la pobreza, fueron la cuna de la Orden de los Carmelitas, y su devoción a la Virgen permitió que naciera una nueva advocación: Nuestra Señora del Carmen.