---
title: Fiesta del Santo Nombre de María
author: admin

date: 2019-09-09T15:09:07+00:00
url: /fiesta-santo-nombre-maria-2-2/
thumbnail: /images/img-fiesta-santo-nombre-maria.jpg
swift-performance:
  - 'a:0:{}'
fecha_nota:
  - 20190912
tags: [Destacada]

---
La Iglesia celebra el Santísimo Nombre de la Madre de Dios que San Lucas señala en su Evangelio para veneración de todos los cristianos: “el nombre de la virgen era María” (Lc. 1, 27)  
<a href="https://mariadelasantafe.org.ar/adoracion-eucaristica-2/img-fiesta-santo-nombre-maria/" rel="attachment wp-att-5159"><img decoding="async" src="https://mariadelasantafe.org.ar/images/img-fiesta-santo-nombre-maria-1.jpg" alt="img-fiesta-santo-nombre-maria" class="aligncenter size-medium wp-image-5159" /></a>