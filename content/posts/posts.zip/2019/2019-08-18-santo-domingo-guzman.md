---
title: Santo Domingo de Guzmán 
author: admin

date: 2019-08-18T15:35:54+00:00
url: /santo-domingo-guzman/
thumbnail: /images/img-snato-domingo-guzman.jpg
swift-performance:
  - 'a:0:{}'
fecha_nota:
  - 20190808
tags: [Destacada]

---
Domingo significa: &#8220;Consagrado al Señor&#8221;.

El fundador de los Padres Dominicos, que son ahora 6.800 en 680 casas en el mundo, nació en Caleruega, España, en 1171.  
Su madre, Juana de Aza, era una mujer admirable en virtudes y ha sido declarada Beata.  
Lo educó en la más estricta formación religiosa.  
<a href="https://mariadelasantafe.org.ar/donaciones-cooperadora-hospital-iturraspe/img-snato-domingo-guzman/" rel="attachment wp-att-5123"><img decoding="async" class="size-medium wp-image-5123 alignleft" src="https://mariadelasantafe.org.ar/images/img-snato-domingo-guzman-1.jpg" alt="Imagen Santo Domingo de Guzman" /></a>