---
title: Santísima Trinidad
author: admin

date: 2019-06-06T16:10:03+00:00
url: /santisima-trinidad-16jun2019/
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2019/06/img-jesus-crucificado-piedra-368x312.jpg" alt="img-jesus-crucificado-piedra" class="alignright size-medium wp-image-5043" />El misterio de la Santísima Trinidad consiste en que Dios es uno solo y en Él hay tres Personas: Padre, Hijo y Espíritu Santo. El misterio de la Santísima Trinidad nos ha sido revelado por la Persona, palabras y acciones de Jesucristo. Después de haber hablado por los Profetas, Dios envió a su Hijo, Jesucristo, quien nos dio la Buena Nueva de la salvación. Este es el mensaje del Nuevo Testamento. Con sus palabras y acciones, y especialmente en su sagrada Persona, Jesús nos dio a conocer las más profundas verdades acerca de Dios. La Trinidad es el misterio más profundo.  Jesús nos ha revelado los secretos del Reino de los Cielos. La suprema de sus enseñanzas es el secreto de Dios mismo. Nos ha hablado de la vida de Dios.  
Nos enseñó que Dios, siendo uno solo, hay en El tres Personas iguales. Nos dijo sus nombres: Padre, Hijo y Espíritu Santo.