---
title: San Pío de Pietrelcina
author: admin

date: 2019-09-09T15:17:07+00:00
url: /san-pio-de-pietrelcina/
thumbnail: /images/san-pio-pietrelcina.jpg
swift-performance:
  - 'a:0:{}'
fecha_nota:
  - 20190923
tags: [Destacada]

---
<a href="https://mariadelasantafe.org.ar/adoracion-eucaristica-2/san-pio-pietrelcina/" rel="attachment wp-att-5163"><img decoding="async" src="https://mariadelasantafe.org.ar/images/san-pio-pietrelcina-1.jpg" alt="san-pio-pietrelcina" class="aligncenter size-medium wp-image-5163" /></a>

> “Oh Jesús, mi suspiro y mi vida, te pido que hagas de mí un sacerdote santo y una víctima perfecta”<footer>escribió una vez San Pío de Pietrelcina.</footer>