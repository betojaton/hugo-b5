---
title: Nuestra Señora de Itatí
author: admin

date: 2019-08-01T13:07:02+00:00
url: /nuestra-senora-itati/
tags: [Destacada]

---
 Hacia el año 1528 los franciscanos arrojaron la primera semilla evangélica en el distrito de Santa Ana, llamado también Reducción de Yaguarí.  Según la tradición la imagen de Itatí habría sido encontrada sobre una piedra (Itatí en guaraní significa &#8220;punta de piedra&#8221;) en el curso del alto Paraná, no lejos del puerto de Santa Ana, los franciscanos la llevaron a la reducción, pero la imagen desapareció dos veces y volvió al lugar donde había sido encontrada. En este sitio se le edificó definitivamente su iglesia. El Santuario se levanta en el pueblo de Itatí, a ori- llas del Alto Paraná y a 70 kilómetros de la ciudad de Corrientes, en la República Argentina.  El 16 de julio de 1900, la imagen de la Virgen de Itatí fue solemnemente coronada, el 3 de febrero de 1910, el Papa Pío X creó la Diócesis de Corrientes, su primero Obispo fue Monseñor Niella.  
El 23 de abril de 1918, la Virgen de Itatí, fue proclamada Patrona y protectora de la diócesis de Corrientes. Su fiesta se celebra el 9 de julio.