---
title: Mensaje, 30 diciembre, 2002
author: admin

date: 2002-12-30T15:34:11+00:00
url: /2002/mensaje-30-diciembre-2002/
thumbnail: /images/img-revelacion-jesus.jpg
tags: [Mensajes 2002]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/foto-caliz-ostia.jpg" alt="foto-caliz-ostia" class="alignright size-medium wp-image-4459" />**Me dice la Santísima Virgen:**

> Hijos míos: Quién está junto a Cristo Jesús, está en la luz, Cristo Jesús, Mi Hijo Amadísimo disipa las tinieblas, Cristo Jesús, Mi Hijo Amadísimo ilumina a todas las almas con su amor, da a todos los corazones su luz esplendorosa que renueva constantemente a todos mis hijos.  
> Mi deseo de Madre es acercar a todos mis hijos hacia esta luz que no tiene fin, hacia esta luz que es vida eterna, hacia esta luz que es Cristo Jesús, Mi Hijo Amadísimo.  
> Llamo a todos mis hijos, jóvenes, ancianos, niños, a todos como Madre dirijo Mi palabra, llamo porque deseo respuesta de todos los corazones, la Madre os busca, la Madre llama, la Madre desea prontas respuestas.  
> Meditad Mi profundísimo Mensaje.  
> Amén. Gloria a Cristo Jesús<footer>Leed: Carta Santiago: C 4, V 10 al 13.</footer> 

Predícalo hijo mío al mundo entero

**Me dice Jesús:**

> Hermanos míos: Cuantos jóvenes están atrapados en sus vicios, cuantos jóvenes caen seducidos hábilmente por pastores falsos, por profetas falsos que sólo predican muerte, que sólo predican mentiras, muchos jóvenes están aturdidos, enceguecidos, deslumbrados y obnubilados por luces falsas, por palabras triviales, por palabras llenas  
> de falsedad e hipocresía, muchos de los jóvenes están atrapados en la droga, en el placer, en el alcoholismo, en el robo, son redes que Satanás tiende, que el enemigo pone delante de ellos para atraparlos y cada vez más.  
> Hago a todos hoy un llamado urgente, llamo a todos vosotros, dirijo Mi llamado, Mi advertencia a todas las almas del mundo, a todos los corazones, trabajad, ayudad a los jóvenes, difundid a los jóvenes, predicad Mi amor a los jóvenes y no dejéis que ya más seductores del mal sigan apoderándose de ellos, tenéis las armas, los medios, tenéis las posibilidades, tenéis la fuerza que os da el amor de Mi Sacratísimo Corazón que os fortalece, que os ayuda constantemente.  
> Mis palabras no pueden quedar archivadas en un cajón como no puede quedar oculto Mi amor hacia todas las almas del mundo.  
> Meditad Mi profundísimo Mensaje.  
> Amén. Gloria a Dios Mi Padre.<footer>Leed: Isaías: C 12, V 4. &#8211; Isaías: C 21, V 7.- Mateo: C 18, V 12. &#8211; Juan: C 9, V 21 y 22. &#8211; Hebreos: C 11, V 12. &#8211; Lucas: C 7, V 23 y 24.</footer> 

Predícalo hermano mío al mundo entero