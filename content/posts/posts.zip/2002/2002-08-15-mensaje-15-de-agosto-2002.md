---
title: Mensaje, 15 de agosto 2002
author: admin

date: 2002-08-15T14:28:16+00:00
url: /2002/mensaje-15-de-agosto-2002/
tags: [Mensajes 2002]

---
**Dice la Santísima Virgen María:**

> Hijos Míos: La Madre está a vuestro lado, Mi Inmaculado Corazón abre el camino para que todos mis hijos lleguen a Cristo Jesús, Mi Hijo Amadísimo, Mi Inmaculado Corazón os cubre con su amor a todos los hijos de la tierra, a todos los hombres, a toda la humanidad.  
> Mi Amor de Madre no se extingue, Mi amor de Madre se propaga por todo el mundo, se derrama en todo el mundo porque deseo como Madre que cada uno de mis hijos lleguen a Cristo Jesús, Mi Hijo Amadísimo, buscad pues el camino que os propone la Madre, el camino verdadero y de la auténtica libertad, Cristo Jesús, Mi Hijo Amadísimo.  
> Meditad Mi profundísimo Mensaje.  
> Amén. Gloria a Cristo Jesús.

**Dice Jesús:**

> Hermano mío: Recibid Mi Paz, recibid Mi Amor, sentid Mi amor con vosotros, sentid Mi presencia con vosotros, dejad que os conduzca, dejad que os lleve desde Mi Sacratísimo Corazón, con Mi Sacratísimo Corazón que no cesa de amar a este mundo cruel, a este mundo despiadado, a este mundo ciego y rebelde.  
> Mi Sacratísimo Corazón os da la paz, la verdad, os da el amor y la verdadera libertad, porque Mi Sacratísimo Corazón es verdad, es auténtica paz para este mundo que vive en el engaño, en la mentira, en la idolatría.  
> Mi Sacratísimo Corazón es el camino, venid pues por este camino y entrad a la vida eterna.  
> Meditad Mi profundísimo Mensaje.  
> Amén. Gloria a Dios Mi Padre.<footer>Leed: Hechos: C 7, V 9. &#8211; Lucas : C 7, V 12. &#8211; Lucas: C 9, V 15.</footer> 

Predícalo hijo mío al mundo entero.