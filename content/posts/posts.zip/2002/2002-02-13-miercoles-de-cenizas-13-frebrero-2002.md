---
title: Miércoles de Cenizas, 13 de Febrero de 2002
author: admin

date: 2002-02-13T15:25:05+00:00
url: /2002/miercoles-de-cenizas-13-frebrero-2002/
thumbnail: /images/img-dibujo-miercolescenizas2002.png
tags: [Mensajes 2002]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-dibujo-miercolescenizas2002-1.png" alt="img-dibujo-miercolescenizas2002" class="alignright size-full wp-image-3350" />En la Parroquia San José de los Padres Agustinos.

**Dice la Santísima Virgen:**

> Hijo mío: Comenzad este tiempo de Cuaresma, este tiempo en que todos debéis acercaos hacia Cristo Jesús, Mi Hijo Amadísimo, donde Cristo Jesús os pide oración, conversión, donde Cristo Jesús os llama a vivir en el amor y en la verdad.  
> Esta Madre os llama a todos, esta Madre pide a todos sus hijos, oración penitencia y sacrificio.  
> Meditad Mi profundísimo Mensaje.  
> Amén. Gloria al Sagrado Corazón de Jesús.<footer>Leed: Mateo: C 18, V 7 al 9. &#8211; Mateo: C 19, V 5 y 6.</footer> 

Predícalo hijo mío al mundo entero.