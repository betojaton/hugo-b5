---
title: Mensaje, 31 de marzo de 2002
author: admin

date: 2002-03-31T20:14:36+00:00
abstract: |
  <h2>Domingo de Pascua de la Resurrección del Señor.</h2>
  **Dice la Santísima Virgen:**
  <img class="alignright wp-image-3462 size-medium" src="https://mariadelasantafe.org.ar/wp-content/uploads/2002/03/msj-31marzo2002-368x277.jpg" alt="Foto Jesus entre nubes" width="368" height="277" /><blockquote>Hijos míos: Mirad la luz de Cristo Jesús, seguid la luz que Cristo Jesús os trae, luz de salvación y liberación, porque Cristo Jesús ha resucitado para dar a todos la vida eterna.
  Vivid junto a Cristo Jesús, Mi Hijo Amadísimo, vivid con su Amor, en su paz, estad con Cristo Jesús porque quien con Cristo Jesús está, está en la vida de gracia.
  Mirad a Cristo Jesús, Mi Hijo Amadísimo y seguid su camino.
  Meditad Mi Profundísimo Mensaje.
  Amén. Gloria a Cristo Jesús.
  
  <footer>Leed: Lucas: C 17, V 7 y 8.</footer></blockquote>
  Predícalo hijo mío al mundo entero
url: /2002/mensaje-31-de-marzo-de-2002/
thumbnail: /images/msj-31marzo2002-1.jpg
tags: [Mensajes 2002]

---
## Domingo de Pascua de la Resurrección del Señor.

**Dice la Santísima Virgen:**  
<img decoding="async" loading="lazy" class="alignright wp-image-3462 size-medium" src="https://mariadelasantafe.org.ar/images/msj-31marzo2002.jpg" alt="Foto Jesus entre nubes" width="368" height="277" /> 

> Hijos míos: Mirad la luz de Cristo Jesús, seguid la luz que Cristo Jesús os trae, luz de salvación y liberación, porque Cristo Jesús ha resucitado para dar a todos la vida eterna.  
> Vivid junto a Cristo Jesús, Mi Hijo Amadísimo, vivid con su Amor, en su paz, estad con Cristo Jesús porque quien con Cristo Jesús está, está en la vida de gracia.  
> Mirad a Cristo Jesús, Mi Hijo Amadísimo y seguid su camino.  
> Meditad Mi Profundísimo Mensaje.  
> Amén. Gloria a Cristo Jesús.<footer>Leed: Lucas: C 17, V 7 y 8.</footer> 

Predícalo hijo mío al mundo entero.