---
title: 'Me dice Jesús:'
author: admin

date: 2002-05-17T20:24:59+00:00
url: /2002/me-dice-jesus-2/
tags: [Oraciones]

---
<div class="wp-block-image">
  <figure class="alignright"><img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2010/07/sagrado-corazon-de-jesus.png" alt="sagrado-corazon-de-jesus" class="wp-image-787" title="sagrado-corazon-de-jesus" /></figure>
</div>

Hermanos Míos, rezad así esta oración:

Sagrado Corazón de Jesús en ti confío, Sagrado Corazón de Jesús fuente de paz, derrama en nosotros el bálsamo de tu amor, el bálsamo de tu Divina Misericordia.

Sagrado Corazón de Jesús en ti confío.

Amén. Gloria al altísimo.

Predica esta oración hermano mío al mundo entero.