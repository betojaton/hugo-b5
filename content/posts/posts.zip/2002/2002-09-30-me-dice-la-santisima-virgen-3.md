---
title: 'Me dice la Santísima Virgen:'
author: admin

date: 2002-09-30T20:40:46+00:00
url: /2002/me-dice-la-santisima-virgen-3/
tags: [Oraciones]

---
Hijo mio, decid esta oración, orad así:

Sagrado Corazón de Jesús, paz inagotable, gracia que te derramas constantemente, ayúdanos, fortalécenos, cobíjanos en tu amor.

Sagrado Corazón de Jesús, guía mis pensamientos, guía mi corazón, para que sólo a ti llegue mi amor, para que por medio de tu Santísima Madre la Virgen María y Madre nuestra lleguemos todos a conocerte totalmente.

Sagrado Corazón de Jesús en ti confío. Amén. Amén.

Predica esta oración al mundo entero.