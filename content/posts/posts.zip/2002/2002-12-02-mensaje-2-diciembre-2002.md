---
title: Mensaje, 2 de Diciembre 2002
author: admin

date: 2002-12-02T08:44:12+00:00
url: /2002/mensaje-2-diciembre-2002/
thumbnail: /images/img-virgen-maria-corazon-1.jpg
tags: [Mensajes 2002]

---
**Me dice la Santísima Virgen:**

> Hijos míos: Mi Inmaculado Corazón desborda en amor hacia todos mis hijos, Mi Inmaculado Corazón es el camino para todos mis hijos, es el camino directo hacia Cristo Jesús, Mi Hijo Amadísimo.  
> La Madre está junto a vosotros, la Madre está llamándoos constantemente a la conversión, la Madre os da los medios para que todos lleguéis a Cristo Jesús, Mi Hijo Amadísimo.  
> Rezad el Santísimo Rosario, rezad constante mente porque así lo desea Mi Inmaculado Corazón, así lo desea Mi Purísimo Corazón, tened este escudo fortísimo, este arma poderosa para vuestros corazones, para vuestras almas, el mun- do debe reconocer y encontrar con urgencia el camino de la salvación, no perdáis las horas y este tiempo que recibís por la Misericordia del Señor.  
> Meditad Mi profundísimo Mensaje.  
> Amén. Gloria a Cristo Jesús.<footer>Leed: Hechos: C 15, V 7 al 10. Lucas: C 16, V 2 al 9. Mateo: C 20, V 3 al 17.</footer> 

Predícalo hijo mío al mundo entero.  
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-virgen-maria-corazon.jpg" alt="img-virgen-maria-corazon" class="alignright size-medium wp-image-4496" />  
**Me dice Jesús:**

> Hermanos míos: Mi Sacratísimo Corazón es paz, es amor, cuantas almas hoy rechazan este amor, cuantos corazones permanecen en la negrura del pecado, permanecen en una noche permanente lejos de la luz de Mi Sacratísimo Corazón.  
> Muchos corazones, muchas almas están sumergidas en el odio, en la sed de venganza, muchos corazones están lejos de la verdad, están ciegos,  
> están fríos ante la verdad de Mis palabras.  
> Deseo respuestas de mis hermanos, deseo verdaderos corazones, dóciles y entregados a la predicación del Evangelio, a la predicación de Mi  
> Palabra.  
> Hay almas erradas y corazones tercos que aún se resisten a ser guiados por Mi Sacratísimo Corazón.  
> Descubrid pues hoy Mi amor, descubrid Mi Divina Misericordia, creed en Mí, creed en Mi amor, dejad pues las divisiones, las rivalidades, dejas las persecuciones, dejad lo pasado y vivid hoy en la luz de Mi Sacratísimo Corazón, abandonad todo lo que os impida llegar a Mí, abandonad los pecados que llevan hoy a tantas almas al infierno, trabajad con amor por la predicación de Mi palabra, trabajad juntos por Mi Santa Iglesia y ofreced vuestros dolores, ofreced vues- tros días y vuestras horas con pleno amor por la salvación de tantas almas y tantos corazones que hoy no siguen el camino de la verdad, que hoy sólo están seducidos por el enemigo, por el adversario que tantas almas a precipitado al infierno.  
> Rezad, rezad con el corazón dispuesto, creed en Mis palabras, recibidlas en vuestro corazón porque Mis palabras son para el mundo entero, porque Mis palabras son para todos los hombres del mundo, de toda raza, de toda lengua, de toda religión, hay muchos corazones, hay muchos de mis hermanos que deben recibir Mi llamado de advertencia, de amor y de abundante Misericordia.  
> Creed en Mis Santas y Sacratísimas Palabras. Meditad Mi profundísimo Mensaje. Amén. Gloria a Dios Mi Padre.<footer>Leed: Lucas: C 16, V 12 y 13. Juan: C 2, V 12. Mateo: C 9, V 2 al 8. Juan: C 14, V 15 y 16.</footer>