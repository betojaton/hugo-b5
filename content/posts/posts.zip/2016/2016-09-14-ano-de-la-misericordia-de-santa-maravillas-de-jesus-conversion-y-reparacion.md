---
title: Año de la Misericordia De santa Maravillas de Jesús – Conversión y Reparación
author: admin

date: 2016-09-14T22:56:59+00:00
url: /ano-de-la-misericordia-de-santa-maravillas-de-jesus-conversion-y-reparacion/
tags: [Destacada]

---
“¡Pobre Jesús mío, qué ganas dan de quererte der veras por tantos como te quieren!”  
“¡Qué poco importa todo, menos el ofender a Dios!”  
“¡Quién pudiera ofrecer al Señor algo que pudiera consolarle!”  
“Quisiera yo poder, a costa de cuanto fuera necesario, transformar las ofensas que en el mundo se comneten, en gloria, amor y consuelo para el Corazón de mi dulcísimo Jesús”.