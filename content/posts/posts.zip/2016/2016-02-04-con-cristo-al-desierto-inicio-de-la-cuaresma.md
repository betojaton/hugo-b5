---
title: 'Con Cristo al desierto: Inicio de la Cuaresma'
author: admin

date: 2016-02-04T15:57:29+00:00
abstract: |
  **Miércoles 10 de Febrero de 2016**<br>
  En la Misa se realiza la ceremonia litúrgica de la imposición de las cenizas, en forma de cruz, sobre la frente de los fieles. este rito indica el comienzo de la Cuaresma - cuarenta días - en la cual los cristianos se dedican a la oración, la penitencia y actos de caridad y misericordia,(**la limosna como obra de caridad, la oración y el ayuno son las prácticas centrales de la Cuaresma, que nos ayudan a purificarnos del pecado, a volver a lo importante, elevar nuestra vida y amar al verdadero Amor**) como preparación para la Pasión...
url: /con-cristo-al-desierto-inicio-de-la-cuaresma/
tags: [Noticias]

---
**Miércoles 10 de Febrero de 2016**  
En la Misa se realiza la ceremonia litúrgica de la imposición de las cenizas, en forma de cruz, sobre la frente de los fieles. este rito indica el comienzo de la Cuaresma &#8211; cuarenta días &#8211; en la cual los cristianos se dedican a la oración, la penitencia y actos de caridad y misericordia,(**la limosna como obra de caridad, la oración y el ayuno son las prácticas centrales de la Cuaresma, que nos ayudan a purificarnos del pecado, a volver a lo importante, elevar nuestra vida y amar al verdadero Amor**) como preparación para la Pasión, Muerte y Resurrección de Cristo, acompañado del Señor que luego de su bautismo en el río Jordán, se fue a preparar para su misión (que culminaría con la Pasión, Muerte y Resurrección) durante cuarenta días en el desierto. La liturgia adopta el color morado como símbolo de austeridad; todos los Viernes de la Cuaresma son días de abstinencia. El Miércoles de Cenizas y el Viernes Santo son además días de ayuno.