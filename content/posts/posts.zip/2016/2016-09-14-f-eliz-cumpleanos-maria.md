---
title: ¡F eliz cumpleaños María!
author: admin

date: 2016-09-14T22:50:33+00:00
url: /f-eliz-cumpleanos-maria/
thumbnail: /images/fiesta-natividad-virgen-maria809.jpg
tags: [Destacada]

---
La Virgen María fue la Madre de Jesús y, con este hecho, se cumplieron las Escrituras y todo lo dicho por los profetas. Dios escogió a esta mujer para ser la Madre de su hijo. Con ella se aproximó la hora de la salvación. Por esta razón la Iglesia celebra esta fiesta con alabanzas y acciones de gracias.  
La fiesta de la Natividad de la Santísima Virgen María se comenzó a celebrar oficialmente con el Papa San Sergio (687-701 d.C.) al establecer que se celebraran en Roma cuatro fiestas en honor de Nuestra Señora: la Anunciación, la Asunción, la Natividad y la Purificación.  
Se desconoce el lugar donde nació la Virgen María. Algunos dicen que nació en Nazaret, pero otros opinan que nació en Jerusalén, en el barrio vecino a la piscina de Betesda. Ahí, ahora, hay una cripta en la iglesia de Santa Ana que se venera como el lugar en el que nació la Madre de Dios.