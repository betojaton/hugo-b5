---
title: 'PAPA FRANCISCO: “La Virgen María es sobre todo Madre de la Misericordia”'
author: admin

date: 2016-10-22T18:36:50+00:00
url: /papa-francisco-la-virgen-maria-es-sobre-todo-madre-de-la-misericordia/
thumbnail: /images/img-virgen-ninio-1.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-virgen-ninio.jpg" alt="img-virgen-ninio" class="alignright size-thumbnail wp-image-3817" />

> &#8220;Durante el mes de octubre miraremos a María de manera particular como la Madre de la Misericordia, especialmente con el Jubileo mariano que se realizará este mes.&#8221;

> “Servir significa cuidar a los frágiles de nuestras familias, de nuestra sociedad, de nuestro pueblo. Son los rostros sufrientes desprotegidos y angustiados a los que Jesús propone mirar e invitar concretamente a amar. Amor que se plasma en acciones y decisiones.”<footer>Papa Francisco.</footer>