---
title: 01 NOV – Feliz Día de todos los Santos
author: admin

date: 2016-10-22T18:44:18+00:00
url: /01-nov-feliz-dia-de-todos-los-santos/
thumbnail: /images/img-felizdiadetodoslossantos-01nov.jpg
tags: [Destacada]

---
### 1 de Noviembre

Los católicos estamos de fiesta porque el 1º de noviembre se celebra a todos los santos. Esa es la verdadera fiesta de estos días, celebrar a los monstruos y a las brujas no es de cristianos. Celebrar el día de muertos es una tradición de nuestra patria, y es bueno que como cristianos hagamos oración por nuestros difuntos.  
Todos, estamos llamados a ser santos, Dios nos quiere santos, y para eso nos dio el Don de la Fe, fue su regalo cuando nos bautizaron, y todos los que estamos bautizados tenemos que ser santos, pero también tenemos que querer serlo.

Ser santos es querer seguir a Jesús, actuar como él, hacer el bien como él, amar como él.  
SER SANTO ES SER AMIGO DE JESÚS.