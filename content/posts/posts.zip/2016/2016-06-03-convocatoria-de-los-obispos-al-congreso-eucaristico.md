---
title: Convocatoria de los Obispos al Congreso Eucarístico
author: admin

date: 2016-06-03T22:42:05+00:00
url: /convocatoria-de-los-obispos-al-congreso-eucaristico/
thumbnail: /images/img-congreso-eucaristico-nacional-1.jpg
tags: [Noticias]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-congreso-eucaristico-nacional.jpg" alt=" img-congreso-eucaristico-nacional" class="alignnone size-full wp-image-3582" />

**Queridos hermanos y hermanas de nuestra Patria:**  
Queremos invitarlos a celebrar juntos el 11° Congreso Eucarístico Nacional en la ciudad de **San Miguel de Tucumán**, cuna de nuestra independencia, durante los días **16 al 19 de junio de 2016**.  
Vamos a celebrar en la Eucaristía al Señor Resucitado, adorar su presencia y agradecer su acompañamiento desde los inicios de nuestra vida como pueblo. Por eso al lema del Congreso: “Jesucristo, Señor de la historia, te necesitamos” lo acompaña la frase: “Jesucristo, pan de vida y comunión para nuestro pueblo”.  
El Bicentenario de la Independencia nacional nos ofrece un marco histórico desafiante para que, asumiendo el legado de nuestros próceres, nos comprometamos a sembrar la cultura del encuentro que nos ayude a superar heridas y agobios, y a hacer de nuestra Patria una Nación fraterna cuya identidad sea la pasión por la verdad y el compromiso por el bien común.

La comunión con Jesucristo Resucitado, presente en la Eucaristía, nos permite mirar creativamente la historia y descubrir nuestra identidad y nuestra cultura, verdadero desafío para forjar el futuro, renovando nuestra fe, comprometiéndonos con la justicia y sirviendo solidariamente a la fraternidad.

Nos disponemos, como familia de Jesús, a celebrar el Año Santo de la Misericordia que ha de impulsarnos a buscar en la Eucaristía la fuente inagotable de su amor, a abrir nuestros corazones a la misericordia y a ser testigos de ella, especialmente frente a los pobres, a los enfermos y a los excluidos. Como enseña el Papa Francisco, “la Iglesia tiene la misión de anunciar la misericordia de Dios, corazón palpitante del Evangelio, que por su medio debe alcanzar la mente y el corazón de toda persona. La Esposa de Cristo hace suyo el comportamiento del Hijo de Dios que sale a encontrar a todos, sin excluir ninguno”. (Bula “Misericordiae Vultus”, 12).  
Confiamos el Congreso Eucarístico a la oración de todos ustedes. Que el camino a recorrer nos haga verdaderos discípulos misioneros de Jesús, centinelas de un tiempo nuevo, anunciadores de la civilización del amor.  
Con todos ustedes, nos ponemos en marcha en nombre del Señor. Que Nuestra Señora de Luján nos guíe y nos acompañe.  
Los Obispos Argentinos  
109° Asamblea Plenaria  
Pilar, 25 de abril de 2015

Cada 29 de junio, en la solemnidad de San Pedro y San Pablo, apóstoles, recordamos a estos grandes testigos de Jesucristo y, a la vez, hacemos una solemne confesión de fe en la Iglesia una, santa, católica y apostólica.  
El día 29 de junio, solemnidad de San Pedro y San Pablo, celebramos el Día del Papa y la colecta llamada desde los primeros siglos Óbolo de San Pedro.