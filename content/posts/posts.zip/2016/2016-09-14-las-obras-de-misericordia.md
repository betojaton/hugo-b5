---
title: LAS OBRAS DE MISERICORDIA
author: admin

date: 2016-09-14T23:06:46+00:00
url: /las-obras-de-misericordia/
tags: [Destacada]

---
<table class="table table­-striped" style="border-spacing: 1px;">
  <tr>
    <td class="text-right">
      <span class="text-success">CORPORALES</span>
    </td>
    
    <td >
      <span class="text-info">ESPIRITUALES</span>
    </td>
  </tr>
  
  <tr>
    <td class="success text-right">
      DAR DE COMER AL HAMBRIENTO
    </td>
    
    <td class="info">
      ENSEÑAR AL QUE NO SABE
    </td>
  </tr>
  
  <tr>
    <td class="success text-right">
      DAR DE BEBER AL SEDIENTO
    </td>
    
    <td class="info">
      DAR BUEN CONSEJO AL QUE LO NECESITA
    </td>
  </tr>
  
  <tr>
    <td class="success text-right">
      DAR POSADA AL PEREGRINO
    </td>
    
    <td class="info">
      CORREGIR AL QUE SE EQUIVOCA
    </td>
  </tr>
  
  <tr>
    <td class="success text-right">
      VESTIR AL DESNUDO
    </td>
    
    <td class="info">
      PERDONAR AL QUE NOS OFENDE
    </td>
  </tr>
  
  <tr>
    <td class="success text-right">
      VISITAR AL ENFERMO
    </td>
    
    <td class="info">
      CONSOLAR AL TRISTE
    </td>
  </tr>
  
  <tr>
    <td class="success text-right">
      VISITAR A LOS PRESOS
    </td>
    
    <td class="info">
      SUFRIR CON PACIENCIA LOS DEFECTOS DEL PRÓJIMO
    </td>
  </tr>
  
  <tr>
    <td class="success text-right">
      ENTERRAR A LOS DIFUNTOS
    </td>
    
    <td class="info">
      REZAR POR VIVOS Y DIFUNTOS
    </td>
  </tr>
  
  <tr>
    <td class="text-center">
      &#8220;UN POCO DE MISERICORDIA HACE AL MUNDO MENOS FRÍO Y MAS JUSTO&#8221; (PAPA FRANCISCO)
    </td>
  </tr>
</table>