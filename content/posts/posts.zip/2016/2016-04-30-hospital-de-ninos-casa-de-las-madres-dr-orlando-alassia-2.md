---
title: 'Hospital  de Niños, Casa de las Madres – Dr. Orlando Alassia'
author: admin

date: 2016-04-30T00:39:10+00:00
url: /hospital-de-ninos-casa-de-las-madres-dr-orlando-alassia-2/
thumbnail: /images/id-3517.jpg
tags: [Colaboraciones]

---
### Colaboraciones Anteriores: 29/04/2016, 06/12/2010

<img decoding="async" class="ngg_displayed_gallery mceItem" src="https://mariadelasantafe.org.ar/images/id-3517.jpg" data-mce-placeholder="1" />