---
title: Año de la Misericordia
author: admin

date: 2016-07-09T15:11:59+00:00
url: /ano-de-la-misericordia-2/
tags: [Destacada]

---
<img decoding="async" class="alignright size-full wp-image-3615" src="https://mariadelasantafe.org.ar/wp-content/uploads/2016/07/ninios-alzando-manos.jpg" alt="ninios-alzando-manos" />**Del Diario de Santa Faustína Kowalska  
** 

> “Hoy escuché estas palabras: ´En el Antiguo Testamento enviaba a los profetas con truenos a Mi pueblo. Hoy te envío a ti a toda la humanidad con Mi Misericordia. No quiero castigar a la humanidad doliente, sino que deseo sanarla, abrazarla a Mi Corazón misericordioso. Hago uso de los castigos cuando Me Obligan a ello; Mi mano se resiste a tomar la espada de la Justicia. Antes del día de la Justicia envío el día de la Misericordia´.” (N. 1588)  
> “Diles a las almas que no pongan obstáculos en sus propios corazones a Mi Misericordia que desea muchísimo obrar en ellos.  
> Mi Misericordia actúa en todos los corazones que le abren su puerta; tanto el pecador como el justo necesitan Mi Misericordia. La conversión y la perseverancia son las gracias de Mi Misericordia” (Palabras del Señor a la santa, n. 1577).