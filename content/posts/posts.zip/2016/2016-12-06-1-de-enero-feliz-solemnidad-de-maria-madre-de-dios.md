---
title: '1 de Enero: ¡Feliz Solemnidad de María, Madre de Dios!'
author: admin

date: 2016-12-06T17:24:36+00:00
url: /1-de-enero-feliz-solemnidad-de-maria-madre-de-dios/
thumbnail: /images/img-solemnidad-maria.jpg
tags: [Destacada]

---
> Un nuevo año comienza y la Iglesia, cada 1º de Enero, lo inicia celebrando la Solemnidad de “María, Madre de Dios” para pedir la protección de aquella que tuvo la dicha de concebir, dar a luz y criar al Salvador.  
> Es importante recordar que María no es sólo Madre de Dios, sino también nuestra porque así lo quiso Jesucristo en la cruz. Por ello, al comenzar el nuevo año, pidámosle a María que nos ayude a ser cada vez más como su Hijo.<footer>( San Juan Pablo II)</footer>