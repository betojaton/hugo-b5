---
title: 14 de Septiembre – La Fiesta del Triunfo de la Santa Cruz
author: admin

date: 2016-09-14T22:53:47+00:00
url: /14-de-septiembre-la-fiesta-del-triunfo-de-la-santa-cruz/
thumbnail: /images/fiesta-exaltacion-cruz.jpg
tags: [Destacada]

---
La esta del Triunfo de la Santa Cruz se hace en recuerdo de la recuperación de la Santa Cruz obtenida en el año 614 por el emperador Heraclio, quien la logró rescatar de los Persas que se la habían robado de Jerusalén.  
Nosotros recordamos con mucho cariño y veneración la Santa Cruz porque en ella murió nuestro Redentor Jesucristo, y con las cinco heridas que allí padeció pagó Cristo nuestras inmensas deudas con Dios y nos consiguió la salvación.