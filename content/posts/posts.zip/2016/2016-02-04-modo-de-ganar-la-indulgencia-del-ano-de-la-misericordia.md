---
title: Sobre el modo de ganar la Indulgencia del Año de la Misericordia
author: admin

date: 2016-02-04T15:51:42+00:00
url: /modo-de-ganar-la-indulgencia-del-ano-de-la-misericordia/
thumbnail: /images/misericordioso-como-padre.jpg
tags: [Noticias]

---
  1.<img decoding="async" class="alignright size-full wp-image-3155" src="https://mariadelasantafe.org.ar/images/misericordioso-como-padre-1.jpg" alt="misericordioso-como-padre" /> Para obtener la indulgencia se debe cumplir primeramente con las condiciones habituales: confesión sacramental, comunión eucarística, rezo de la profesión de fe y oración por las intenciones del Santo Padre. (Credo. Padre Nuestro. Ave María y Gloria)
  2. Nos dice el Santo Padre que los fieles “están llamados a realizar una breve peregrinación hacia la Puerta Santa, abierta en cada Catedral o en las iglesias establecidas por el Obispo diocesano y en las cuatro basílicas papales en Roma, como signo del deseo profundo de auténtica conversión”.

En SANTA FE-ARGENTINA los lugares designados para tal fin son:

  * Iglesia Catedral Metropolitana de Santa Fe de la Vera Cruz.
  * Basílica y Santuario de Ntra. Sra. de Guadalupe (Ciudad Sede).
  * Basílica Ntra. Sra. del Carmen (Ciudad Sede).
  * Basílica Natividad de la Santísima Virgen (Esperanza).

Es importante que este momento esté unido, ante todo, al Sacramento de la Reconciliación y a la celebración de la Santa Eucaristía con un reflexión sobre la misericordia”.  
Para nuestra Arquidiócesis se designan los siguientes lugares:

&#8211; Santuario de Ntra. Sra. de los Milagros  
(pp Jesuitas);  
&#8211; Santuario de Ntra. Sra. de los Dolores (San Martín Norte);  
&#8211; Santuario de San Cayetano (Ciudad Sede);  
&#8211; Parroquia y Santuario San Francisco Javier (San Javier);  
&#8211; Parroquia Ntra. Sra. de la Merced (San Justo);  
&#8211; Parroquia San Agustín y Santa Mónica (Carlos Pellegrini);  
&#8211; Parroquia Santa Margarita de Escocia (Gálvez) y la  
&#8211; Capilla Jesús de la Divina Misericordia (Bº Las Flores II, Ciudad Sede).