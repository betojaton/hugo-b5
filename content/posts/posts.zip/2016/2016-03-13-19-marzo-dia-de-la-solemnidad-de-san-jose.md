---
title: '19 marzo – Día de la  Solemnidad de San José'
author: admin

date: 2016-03-13T14:44:00+00:00
url: /19-marzo-dia-de-la-solemnidad-de-san-jose/
thumbnail: /images/img-sanjose-1.jpg
tags: [Notas]

---
## Oración de la Humildad a San José

<img decoding="async" loading="lazy" class="alignright wp-image-3419 size-medium" src="https://mariadelasantafe.org.ar/images/img-sanjose.jpg" alt="img-sanjose" width="314" height="420" /> 

> Eséñanos José  
> Cómo se es “no protagonista”  
> Cómo se avanza sin pisotear.  
> Cómo se colabora sin imponerse.  
> Cómo se ama sin reclamar.  
> Dinos; José  
> Cómo se vive siendo “número dos”.  
> Cómo se hacen cosas fenomenales  
> desde un segundo puesto.  
> Explícanos  
> Cómo se es grande sin exhibirse.  
> Cómo se lucha sin aplauso.  
> Cómo se avanza sin publicidad.  
> Cómo se persevera y se muere uno  
> sin esperanza de que le hagan un homenaje.  
> Amén.