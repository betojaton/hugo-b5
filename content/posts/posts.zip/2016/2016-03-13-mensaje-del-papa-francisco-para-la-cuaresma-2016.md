---
title: 'Mensaje del Papa  Francisco para la Cuaresma 2016'
author: admin

date: 2016-03-13T15:23:48+00:00
url: /mensaje-del-papa-francisco-para-la-cuaresma-2016/
thumbnail: /images/bn-cuaresma2016.jpg
tags: [Notas]

---
El mensaje del Papa Francisco para la Cuaresma 2016 lleva como título **«&#8217;Misericordia quiero y no sacrificio&#8217; (Mt 9,13). Las obras de misericordia en el camino jubilar»**

…La Cuaresma de este Año Jubilar, pues, es para todos un tiempo favorable para salir por fin de nuestra alienación existencial gracias a la escucha de la Palabra y a las obras de misericordia. Mediante las corporales tocamos la carne de Cristo en los hermanos y hermanas que necesitan ser nutridos, vestidos, alojados, visitados, mientras que las espirituales tocan más directamente nuestra condición de pecadores: aconsejar, enseñar, perdonar, amonestar, rezar. Por tanto, nunca hay que separar las obras corporales de las espirituales. Precisamente tocando en el mísero la carne de Jesús crucificado el pecador podrá recibir como don la conciencia de que él mismo es un pobre mendigo. A través de este camino también los «soberbios», los «poderosos» y los «ricos», de los que habla el Magnificat, tienen la posibilidad de darse cuenta de que son inmerecidamente amados por Cristo crucificado, muerto y resucitado por ellos. Sólo en este amor está la respuesta a la sed de felicidad y de amor infinitos que el hombre —engañándose— cree poder colmar con los ídolos del saber, del poder y del poseer. Sin embargo, siempre queda el peligro de que, a causa de un cerrarse cada vez más herméticamente a Cristo, que en el pobre sigue llamando a la puerta de su corazón, los soberbios, los ricos y los poderosos acaben por condenarse a sí mismos a caer en el eterno abismo de soledad que es el infierno. He aquí, pues, que resuenan de nuevo para ellos, al igual que para todos nosotros, las lacerantes palabras de Abrahán: «Tienen a Moisés y los Profetas; que los escuchen» (Lc 16,29). Esta escucha activa nos preparará del mejor modo posible para celebrar la victoria definitiva sobre el pecado y sobre la muerte del Esposo ya resucitado, que desea purificar a su Esposa prometida, a la espera de su venida.  
No perdamos este tiempo de Cuaresma favorable para la conversión. Lo pedimos por la intercesión materna de la Virgen María, que fue la primera que, frente a la grandeza de la misericordia divina que recibió gratuitamente, confesó su propia pequeñez (cf. Lc 1,48), reconociéndose como la humilde esclava del Señor (cf. Lc 1,38).

<p style="text-align: right;">
  **<em>Vaticano, 4 de octubre de 2015</em>**<br /> **<em> Fiesta de San Francisco de Assis</em>**<br /> **<em> FRANCISCUS</em>**
