---
title: 2016 Año Santo de la Misericordia
author: admin

date: 2016-11-04T14:14:49+00:00
url: /2016-ano-santo-de-la-misericordia/
thumbnail: /images/img-abrazo.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-abrazo-1.jpg" alt="img-abrazo" class="alignright size-thumbnail wp-image-3843" />  
2016 Año Santo de la Misericordia del 8 de diciembre de 2015, solemnidad de la Inmaculada Concepción al 20 de noviembre de 2016, domingo de Nuestro Señor Jesucristo Rey del universo.

**Palabras del Santo Padre:**

> “…Este Año Santo iniciará en la próxima solemnidad de la Inmaculada Concepción y concluirá el 20 de noviembre de 2016, domingo de Nuestro Señor Jesucristo Rey del universo y rostro vivo de la misericordia del Padre. Confío la organización de este Jubileo al Consejo Pontificio para la Promoción de la Nueva Evangelización, para que pueda animarlo como una nueva etapa del camino de la Iglesia en su misión de llevar a cada persona el Evangelio de la misericordia.  
> Estoy convencido que toda la Iglesia, que tiene tanta necesidad de recibir misericordia, porque somos pecadores, podrá encontrar en este Jubileo la alegría para redescubrir y hacer más fecunda la misericordia de Dios, con la cual todos estamos llamados a dar consolación a cada hombre y a cada mujer de nuestro tiempo. No olvidemos que Dios perdona todo, y Dios perdona siempre. No nos cansemos de pedir perdón. Confiemos este año desde ahora a la Madre de la Misericordia, para que dirija a nosotros su mirada y vele sobre nuestro camino: Nuestro camino penitencial, nuestro camino con el corazón abierto, durante un año a recibir la indulgencia de Dios, a recibir la misericordia de Dios….”