---
title: Mensaje, 8 de Enero 2001
author: admin

date: 2016-09-14T22:38:20+00:00
url: /mensaje-8-de-enero-2001/
tags: [Mensajes 2001]

---
**Me dice Jesús:**

> Hermanos míos: Mi Sacratísimo Corazón es ofendido a diario, es coronado por tantas espinas, la causa el pecado de Mis hermanos, la causa la arrogancia, la frialdad y la negación de muchos de Mis hermanos a Mi presencia, veo con dolor que muchos me rechazáis, que muchos no creéis en Mis palabras, siento muchas espinas, mucho dolor porque muchos hermanos prefieren la vida fácil, la vida sin sacrificios y sin aceptar la cruz.  
> Es tiempo de que abráis los ojos a Mi verdad y creáis en Mí verdaderamente, porque estoy a vuestro lado siempre, rezad constantemente, rezad por la paz, rezad para que las almas descubran que en Mi Sacratísimo Corazón, está la paz, está la verdad, está la luz.  
> Mi Sacratísimo Corazón es vuestro seguro camino para llegar a la vida eterna.  
> Sean Meditadas mis palabras.  
> Amén. Gloria a Dios Mi Padre.<footer>Leed:Lucas: C 13, V21.</footer> 

Predícalo al mundo entero.