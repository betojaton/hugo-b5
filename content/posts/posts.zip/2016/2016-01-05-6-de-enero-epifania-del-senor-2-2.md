---
title: 6 de enero – Epifanía del Señor
author: admin

date: 2016-01-05T14:09:56+00:00
url: /6-de-enero-epifania-del-senor-2-2/
thumbnail: /images/foto-epifania.jpg
tags: [Destacada]

---
Epifanía significa &#8220;manifestación&#8221;.  
Jesús se da a conocer. Aunque Jesús se dio a conocer en diferentes momentos a diferentes personas, la Iglesia celebra como epifanías tres eventos:  
Su Epifanía ante los Reyes Magos (Mt 2, 1-12)  
Su Epifanía a San Juan Bautista en el Jordán  
Su Epifanía a sus discípulos y comienzo de Su vida pública con el milagro en Caná.  
La Epifanía que más celebramos en la Navidad es la primera.  
Del pasaje bíblico sabemos que son magos, que vinieron de Oriente y que como regalo trajeron incienso, oro y mirra; de la tradición de los primeros siglos se nos dice que fueron tres reyes sabios: Melchor, Gaspar y Baltazar.