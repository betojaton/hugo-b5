---
title: 2 de Noviembre
author: admin

date: 2016-10-22T18:49:22+00:00
url: /2-de-noviembre/
tags: [Destacada]

---
La tradición de rezar por los muertos se remonta a los primeros tiempos del cristianismo, en donde ya se honraba su recuerdo y se ofrecían oraciones y sacrificios por ellos.  
Cuando una persona muere ya no es capaz de hacer nada para ganar el cielo; sin embargo, los vivos sí podemos ofrecer nuestras obras para que el difunto alcance la salvación.  
Con las buenas obras y la oración se puede ayudar a los seres queridos a conseguir el perdón y la purificación de sus pecados para poder participar de la gloria de Dios.  
A estas oraciones se les llama sufragios. El mejor sufragio es ofrecer la Santa Misa por los difuntos.