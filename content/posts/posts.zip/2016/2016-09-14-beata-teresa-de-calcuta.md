---
title: Beata Teresa de Calcuta
author: admin

date: 2016-09-14T22:58:50+00:00
url: /beata-teresa-de-calcuta/
tags: [Destacada]

---
> Los pobres son la esperanza del mundo porque nos proporcionan la ocasión de amar a Dios a través de ellos. Son el don de Dios a la humanidad, para que nos enseñen una manera diferente de amarlo, buscando siempre la manera de dignificarlos y rescatarlos