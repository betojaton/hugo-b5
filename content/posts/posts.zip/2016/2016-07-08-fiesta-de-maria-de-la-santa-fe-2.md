---
title: FIESTA DE MARÍA DE LA SANTA FE
author: admin

date: 2016-07-08T14:31:45+00:00
url: /fiesta-de-maria-de-la-santa-fe-2/
tags: [Noticias]

---
<img decoding="async" class="alignright size-full wp-image-3611" src="https://mariadelasantafe.org.ar/wp-content/uploads/2016/07/foto-msj-fiestamdsfe2016.jpg" alt="fiestamdsfe2016" />El 8 de julio la Madre se anuncia como MARÍA DE LA SANTA FE. En ese entonces hace saber que Santa Fe es una ciudad elegida, Santa y Bendita&#8230;

> &#8230; donde desea que se construya un Templo en honor y gloria a la Santísima Trinidad.

El lugar señalado por la Madre del Cielo es un campito, actualmente ubicado en la costanera santafesina (Avenida Almirante Brown y Regis Martínez – Santa Fe). Allí la Madre se manifiesta dentro de un triángulo de luz resplandeciendo en él, mostrándole un campo lleno de flores y en una de sus manifestaciones la Santísima Virgen le anuncia:

“Mi Campito es el lugar elegido para el Templo a la Santísima Trinidad, orad allí, id hacia el lugar elegido y veréis que Dios y vuestra Madre derraman abundantes bendiciones sobre todos lo que estéis allí, vais a ver todo lo que la Madre hace por cada uno de sus hijos, todo el Campito es lugar Santo y Bendito”&#8230;.

&#8230;Desde el 8 de Abril de 2006 al 8 de Junio de 2015, las manifestaciones de la Santísima Virgen y de Nuestro Señor Jesucristo fueron públicas, sumándose cada vez más creyentes..