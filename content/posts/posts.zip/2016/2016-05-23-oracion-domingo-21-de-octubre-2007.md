---
title: Oración, Domingo 21 de octubre, 2007
author: admin

date: 2016-05-23T15:34:20+00:00
url: /oracion-domingo-21-de-octubre-2007/
thumbnail: /images/corazon_jesus-224x300-1-1.png
tags: [Oraciones]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/corazon_jesus-3.png" alt="corazon_jesus" class="alignright size-medium wp-image-657" />

> Corazón de Jesús,  
> ven a reinar en nuestras familias,  
> Corazón de Jesús,  
> ven a reinar en nuestras comunidades.  
> Corazón de Jesús,  
> ven a reinar en nuestra patria.  
> Ven a traernos tu luz para disipar las tinieblas, para que reine tu paz, para que reine tu amor.  
> Corazón de Jesús, ven a instaurar en nosotros tu amor, que tu amor nos conduzca, que tu amor nos sane, que tu amor nos transforme.  
> Corazón de Jesús, en Ti confío.  
> Amén. Amén. Predícala hijo Mío al mundo entero.