---
title: Oración, 30 de noviembre, 2003
author: admin

date: 2016-05-23T16:10:52+00:00
url: /oracion-30-de-noviembre-2003/
tags: [Oraciones]

---
> Sagrado Corazón de Jesús instrúyeme, sagrado Corazón de Jesús guía mis pasos, mis acciones, mis palabras en este día, para que obre según tu voluntad.  
> Sagrado Corazón de Jesús que mis pies se aparten del mal, que mi lengua se aparte de las palabras oscuras, que mis manos trabajen hoy para la gloria de tu Nombre.  
> Sagrado Corazón de Jesús en ti confío.  
> Amén. Amén. Predica esta oración hijo mío al mundo entero.