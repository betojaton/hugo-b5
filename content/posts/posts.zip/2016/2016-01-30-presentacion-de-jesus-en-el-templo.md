---
title: '2 de Febrero  – Presentación de Jesús en el Templo.'
author: admin

date: 2016-01-30T14:54:09+00:00
abstract: '<img src="https://mariadelasantafe.org.ar/wp-content/uploads/2016/01/foto-msj-2feb-109x149.jpg" alt="foto-msj-2feb" class="alignright size-thumbnail wp-image-3313" />María y José presentan en el Templo al Niño Jesús como ofrenda, como anticipada cruz que Él llevaría, el Niño es fruto de alegría para muchos, Simeón profetiza a María un dolor, una espada atravesará su alma.'
url: /presentacion-de-jesus-en-el-templo/
thumbnail: /images/foto-msj-2feb-1.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/foto-msj-2feb-1.jpg" alt="foto-msj-2feb" class="alignright size-thumbnail wp-image-3313" />María y José presentan en el Templo al Niño Jesús como ofrenda, como anticipada cruz que Él llevaría, el Niño es fruto de alegría para muchos, Simeón profetiza a María un dolor, una espada atravesará su alma.