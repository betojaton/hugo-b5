---
title: Martirio de San Bautista
author: admin

date: 2016-08-01T21:47:08+00:00
url: /martirio-de-san-bautista/
thumbnail: /images/san-juan-bautista-martirio-1.jpg
tags: [Destacada]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/san-juan-bautista-martirio.jpg" alt=" san-juan-bautista-martirio" class="aligncenter size-full wp-image-3677" />  
Por ocasión de la fiesta celebrada en Maqueronte, la hija de Herodíades, Salomé, habiendo dado verdadero show de agilidad en la danza, entusiasmó a Herodes. Como premio pidió, por instigación de la madre, la cabeza de San Juan Bautista. Ultimo profeta y primer apóstol, dio la vida por su misión y por eso es venerado en la Iglesia como mártir.