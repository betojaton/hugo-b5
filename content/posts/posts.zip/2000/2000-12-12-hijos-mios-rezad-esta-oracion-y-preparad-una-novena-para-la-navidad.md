---
title: 'Hijos Míos, rezad esta oración y preparad una novena para la Navidad:'
author: admin

date: 2000-12-12T20:08:37+00:00
url: /2000/hijos-mios-rezad-esta-oracion-y-preparad-una-novena-para-la-navidad/
thumbnail: /images/natividad_de_jesus_maria.jpg
tags: [Oraciones]

---
![natividad_de_jesus_maria]
Dulce Salvador, Jesús mío que vienes a nosotros para traernos la paz, el amor y la gracia, que te preparemos el corazón para ser fieles a ti y que te recibamos como tú te lo mereces. Haz de nuestro corazón la cuna para que tú nazcas en ella. Amén.

**Rezad esta oración con el Santísimo Rosario. Amén. Amén.**