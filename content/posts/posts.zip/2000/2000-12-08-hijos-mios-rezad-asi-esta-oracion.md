---
title: 'Hijos Míos: Rezad así esta oración.'
author: admin

date: 2000-12-08T20:05:38+00:00
url: /2000/hijos-mios-rezad-asi-esta-oracion/
tags: [Oraciones]

---
Madre guíame, Madre llévame de tu mano para que no tropiece, llévame hacia la luz y la verdad que están en Jesús Tu Hijo Amadísimo.  
**Amén. Amén. Predícala.**