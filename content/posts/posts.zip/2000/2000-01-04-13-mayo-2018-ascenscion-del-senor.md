---
title: 13 de Mayo de 2018 – Ascensción del Señor
author: admin

date: 1970-01-01T00:00:00+00:00
draft: true
url: /2000/13-mayo-2018-ascenscion-del-senor
tags: [Notas]

---
Luego que el Señor Jesús se apareció a sus discípulos fue elevado al cielo. Este acontecimiento marca la transición entre la gloria de Cristo resucitado y la de Cristo exaltado a la derecha del Padre.

Marca también la posibilidad de que la humanidad entre al Reino de Dios como tantas veces lo anunció Jesús. De esta forma, la ascensión del Señor se integra en el Misterio de la Encarnación, que es su momento conclusivo.