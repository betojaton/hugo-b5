---
title: 20 de Mayo – Pentecostés
author: admin

draft: true
url: /2000/20-mayo-pentecostes
tags: [Notas]

---
“Al llegar el día de Pentecostés, estaban todos reunidos en un mismo lugar. De repente vino del cielo un ruido como el de una ráfaga de viento impetuoso, que llenó toda la casa en la que se encontraban. Se les aparecieron unas lenguas como de fuego que se repartieron y se posaron sobre cada uno de ellos; quedaron todos llenos del Espíritu Santo y se pusieron a hablar en otras lenguas, según el Espíritu les concedía expresarse. Había en Jerusalén hombres piadosos, que allí residían, venidos de todas las naciones que hay bajo el cielo”