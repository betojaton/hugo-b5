---
title: "San Francisco de Asís"
author: admin

date: 1970-01-01T00:00:00+00:00
draft: true
url: /2000/san-francisco-asis
tags: [Notas]

---
Memoria de san Francisco, el cual, después de una juventud despreocupada, se convirtió a la vida evangélica en Asís, localidad de Umbría, en Italia, y encontró a Cristo sobre todo en los pobres y necesitados, haciéndose pobre él mismo. Instituyó los Hermanos Menores y, viajando, predicó el amor de Dios a todos y llegó incluso a Tierra Santa. Con sus palabras y actitudes mostró siempre su deseo de seguir a Cristo, y escogió morir recostado sobre la nuda tierra.