---
title: 'Le dice la Santísima Virgen a Vicente:'
author: admin

date: 2012-05-26T23:30:29+00:00
url: /2012/le-dice-la-santisima-virgen-a-vicente-2-2/
thumbnail: /images/foto3-1.jpg
tags: [Oraciones]

---
<img decoding="async" loading="lazy" class="alignright size-full wp-image-1461" title="foto3" src="https://mariadelasantafe.org.ar/images/foto3.jpg" alt="Jesus dando el sacramento" width="226" height="355" />&#8220;Vicente hijo mío: Las almas caminan a tientas, en la oscuridad del pecado, muchas son las almas apartadas del verdadero camino, sumergidas en sus vicios y placeres que las conducen al abismo eterno.

Mis hijos deben despertar a esta realidad, Mis hijos deben sentir hoy con más fuerza Mi llamado de Madre a la conversión total y verdadera, las almas deben recibir a Jesús que se os ofrece como el alimento para la vida eterna, a través de Su Cuerpo y Su Sangre.

¿Cuanto hace que no hacéis una buena confesión? ¿Cuanto hace que no vais a recibir a Jesús Sacramentado que os espera?

¿Cuanto hace que os habéis olvidado del precepto de asistir a la Santa Misa de cada Domingo?  
Dios es Misericordioso y tanto os ha dado y aún así lo continuáis negando, rechazando y olvidándolo.

Apresurad entonces la marcha y volved a la Casa del Padre que os está esperando a las puertas de una definitiva conversión.

Meditad Mi Profundísimo Mensaje.

Amén. Gloria al Altísimo.

Leed: Lucas: C 13, V 25 al 27

Predícalo hijo mío al mundo entero.”