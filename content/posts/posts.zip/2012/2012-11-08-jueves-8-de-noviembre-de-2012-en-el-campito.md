---
title: Jueves 8 de noviembre2012en el “Campito”
date: 2012-11-08T20:40:12+00:00
url: /2012/jueves-8-noviembre-2012-en-el-campito/
thumbnail: /images/DSC09451-1.jpg
tags: 
  - Mensajes
  - Mensajes Presenci
---
**Dice la Santísima Virgen:**  
“Hijos míos, benditos y amados hijos míos, nuevamente os doy gracias porque respondéis a mi llamado, porque acudís cada uno de vosotros a los brazos de esta Madre. Mi Corazón Inmaculado os bendice a cada uno de vosotros y en forma especial.

Esta Madre se manifiesta con los hijos, con cada hijo en cada hogar, en cada familia, trayendo el mensaje del cielo, para la conversión de los corazones.

Mis hijos deben llegar a la conversión, Mis hijos, del mundo entero deben llegar todos a la conversión. Y Mi llamado es insistente, pido que Mis hijos se dediquen con más fuerza a la oración. Que los hijos acudan a la oración como puente, como puente para llegar a Jesús.

**<img decoding="async" loading="lazy" class="alignright size-full wp-image-1475" style="margin-left: 20px;" alt="virgen-maria" src="https://mariadelasantafe.org.ar/images/DSC09451.jpg" width="412" height="600" />**Hijos míos. Hijitos míos, no perdáis estos días tan valiosos, estas horas tan valiosas. El Señor os mira con misericordia y derrama en vosotros abundantes gracias que todos los hijos deben recibir. La humanidad debe comprender el camino, el camino en que está hoy, al borde del abismo, al borde del abismo eterno.

Y es como Madre que pido y suplico a todos Mis hijos la oración. Rezad mucho en vuestras familias, rezad mucho en la Santa Iglesia, rezad mucho, hijitos míos como lo desea Mi Corazón Inmaculado.

No temáis. No temáis porque la Madre está junto a vosotros y Mi Manto Celestial es la muralla que os cubre y os protege del enemigo, de Satanás que rodea siempre para haceros perder del camino, para tratar de desviaros del camino.

Aferraos vosotros a Mi Manto Celestial. Aferraos a Mi Rosario. No perdáis la fe ni la esperanza, y confiáis cada día más en la tags:
	- Mensajes Presencia del Señor, que os atiende, que os escucha, que permanece con vosotros.

Confiad, confiad, confiad. Porque aquí está la Madre, vuestra Madre, **María de la Santa Fe**.

Meditad. Meditad. Meditad Mis Palabras.”

**Dice Jesús:**  
“Hermanos míos, benditos y amados hermanos míos, abro las puertas de Mi Corazón a vosotros, y derramo Mi Preciosísima Sangre que os fortalece y os libera. Abro las puertas de Mi Corazón, donde brota todo Mi amor, hacia todos los hombres, este amor se derrama en la humanidad, cae a manos llenas sobre todos los corazones. Porque deseo que la humanidad encuentre el camino de la salvación. Que Mis hermanos encuentren el camino de la salvación.

Mi amor no tiene precio. Mi amor no tiene límites. Mi amor se derrama y pasa por las barreras del mundo, pasa por las puertas del mundo, Mi amor lo abarca todo y llega hasta el último rincón de la tierra. Sobre todos los corazones y en todas las almas. Mi amor cae en aquellos hermanos que están desesperados, en aquellos hermanos que están angustiados, Mi amor cae en vosotros en una forma especial. Dios invita cada día a emprender el camino, a retomar la marcha y a no mirar el pasado, si no este presente que os regala Mi Sacratísimo Corazón.

Sed buenos, sed misericordiosos, sed bondadosos y compasivos con vuestros hermanos. Transmitid la paz, sed mensajeros de Mi Paz y llevad Mi Paz a vuestras comunidades, llevad

Mi Paz y Mi Amor a vuestras comunidades. “Mi Paz, no tiene límites” Mi Paz os llega a vosotros en forma especial, para que se hagáis soldados fuertes y valerosos en Mi Santa Obra.

En éste momento paso sobre vosotros, y con Mis manos poderosas, toco vuestras cabezas para daros fuerzas, para daros el valor, para daros la paz. Afrontad el camino cada día. Dejad todas las luchas en el pasado y solamente trabajad y luchad para extender Mi Reino, Mi Reino de amor, de justicia, de paz y de eterna verdad.

Sed valerosos y no cobardes. Sed auténticos discípulos de Mi Sacratísimo Corazón. Os amo a todos. Os amo profundísimamente y os llevo a todos dentro de Mi Sacratísimo Corazón. Ya nadie dude de Mis Palabras, ya nadie rechace Mis Palabras.

Meditad. Meditad. Meditad Mis Palabras.

Os bendigo en el Nombre del Padre, y del Hijo y del Espíritu Santo Amén.”