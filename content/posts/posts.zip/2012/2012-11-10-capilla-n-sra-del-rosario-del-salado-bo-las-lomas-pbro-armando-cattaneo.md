---
title: Capilla N. Sra. del Rosario del Salado – Bº Las Lomas
author: admin

date: 2012-11-10T12:23:26+00:00
url: /2012/capilla-n-sra-del-rosario-del-salado-bo-las-lomas-pbro-armando-cattaneo/
tags: [Colaboraciones]

---
##### 09/06/2013, 10/11/2012

<!-- default-view.php -->

<div
	class="ngg-galleryoverview default-view "
	id="ngg-gallery-b335e8ece261ef104b07ac20ba860140-1">
  <!-- Thumbnails -->
  
  <div id="ngg-image-0" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/colaboracion_capilla-sra-rosario04.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/colaboracion_capilla-sra-rosario04.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/thumbs/thumbs_colaboracion_capilla-sra-rosario04.jpg"
               data-image-id="161"
               data-title="colaboracion_capilla-sra-rosario04"
               data-description=""
               data-image-slug="colaboracion_capilla-sra-rosario04"
               class="ngg-simplelightbox" rel="b335e8ece261ef104b07ac20ba860140"> <img
                    title="colaboracion_capilla-sra-rosario04"
                    alt="colaboracion_capilla-sra-rosario04"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/thumbs/thumbs_colaboracion_capilla-sra-rosario04.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-1" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/colaboracion_capilla-sra-rosario02.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/colaboracion_capilla-sra-rosario02.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/thumbs/thumbs_colaboracion_capilla-sra-rosario02.jpg"
               data-image-id="162"
               data-title="colaboracion_capilla-sra-rosario02"
               data-description=""
               data-image-slug="colaboracion_capilla-sra-rosario02"
               class="ngg-simplelightbox" rel="b335e8ece261ef104b07ac20ba860140"> <img
                    title="colaboracion_capilla-sra-rosario02"
                    alt="colaboracion_capilla-sra-rosario02"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/thumbs/thumbs_colaboracion_capilla-sra-rosario02.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-2" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/colaboracion_capilla-sra-rosario03.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/colaboracion_capilla-sra-rosario03.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/thumbs/thumbs_colaboracion_capilla-sra-rosario03.jpg"
               data-image-id="163"
               data-title="colaboracion_capilla-sra-rosario03"
               data-description=""
               data-image-slug="colaboracion_capilla-sra-rosario03"
               class="ngg-simplelightbox" rel="b335e8ece261ef104b07ac20ba860140"> <img
                    title="colaboracion_capilla-sra-rosario03"
                    alt="colaboracion_capilla-sra-rosario03"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/thumbs/thumbs_colaboracion_capilla-sra-rosario03.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-3" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/colaboracion_capilla-sra-rosario01.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/colaboracion_capilla-sra-rosario01.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/thumbs/thumbs_colaboracion_capilla-sra-rosario01.jpg"
               data-image-id="165"
               data-title="colaboracion_capilla-sra-rosario01"
               data-description=""
               data-image-slug="colaboracion_capilla-sra-rosario01"
               class="ngg-simplelightbox" rel="b335e8ece261ef104b07ac20ba860140"> <img
                    title="colaboracion_capilla-sra-rosario01"
                    alt="colaboracion_capilla-sra-rosario01"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/thumbs/thumbs_colaboracion_capilla-sra-rosario01.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-4" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/dscf2442.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/dscf2442.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/thumbs/thumbs_dscf2442.jpg"
               data-image-id="226"
               data-title="colaboracion_capilla-sra-rosario06"
               data-description=""
               data-image-slug="colaboracion_capilla-sra-rosario06"
               class="ngg-simplelightbox" rel="b335e8ece261ef104b07ac20ba860140"> <img
                    title="colaboracion_capilla-sra-rosario06"
                    alt="colaboracion_capilla-sra-rosario06"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/thumbs/thumbs_dscf2442.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-5" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/dscf2446.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/dscf2446.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/thumbs/thumbs_dscf2446.jpg"
               data-image-id="227"
               data-title="colaboracion_capilla-sra-rosario05"
               data-description=""
               data-image-slug="colaboracion_capilla-sra-rosario05"
               class="ngg-simplelightbox" rel="b335e8ece261ef104b07ac20ba860140"> <img
                    title="colaboracion_capilla-sra-rosario05"
                    alt="colaboracion_capilla-sra-rosario05"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/thumbs/thumbs_dscf2446.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-6" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/colaboracion_capilla-sra-rosario07.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/colaboracion_capilla-sra-rosario07.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/thumbs/thumbs_colaboracion_capilla-sra-rosario07.jpg"
               data-image-id="279"
               data-title="colaboracion_capilla-sra-rosario07"
               data-description=""
               data-image-slug="colaboracion_capilla-sra-rosario07"
               class="ngg-simplelightbox" rel="b335e8ece261ef104b07ac20ba860140"> <img
                    title="colaboracion_capilla-sra-rosario07"
                    alt="colaboracion_capilla-sra-rosario07"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/capilla-sra-rosario/thumbs/thumbs_colaboracion_capilla-sra-rosario07.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <br style="clear: both" /> <!-- Pagination -->
  
  <div class='ngg-clear'>
  </div>
</div>