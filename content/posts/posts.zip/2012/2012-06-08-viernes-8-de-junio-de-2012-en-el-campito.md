---
title: Viernes 8 de junio2012en “El Campito”
author: admin

date: 2012-06-08T22:38:18+00:00
url: /2012/viernes-8-de-junio-de-2012-en-el-campito/
thumbnail: /images/jesus_corazon008-1.jpg
tags: [Mensajes 2012]

---
<p align="JUSTIFY">
  **Dice la Santísima Virgen:**” Hijos míos; benditos y amados hijos míos aquí nuevamente está la Madre, aquí con cada uno de vosotros. Esta Madre que viene a acompañaros, en éste camino en la tierra. Esta Madre que os conduce a vosotros y os toma de la mano para que no equivoquéis el camino.



  Mi Corazón Inmaculado os bendice. Mi corazón de Madre está en vosotros para mostraros en forma especial y en éste día el camino que conduce a Jesús, a Cristo Jesús Mi Hijo Amadísimo.



  Todos los días debéis rezar por la paz en los corazones, las familias en el mundo entero El Santo Rosario es arma poderosa para vencer al enemigo, para vencer a Satanás. Rezad entonces hijitos Míos como lo pide Mi Inmaculado Corazón.


<p align="JUSTIFY">
  **Hoy aquí os bendigo,hoy aquí me manifiesto en esta Santa Fe, la Nueva Jerusalén. En ésta Argentina, tan dispersa, en ésta Argentina Santa y Bendita que está dominada por la oscuridad.** Rezad mucho para que todos Mis hijos vean la luz de Jesús, dejen entrar la luz de Jesús en sus corazones. Y ésta nación brille realmente como Dios Nuestro Señor lo desea.



  Debe resurgir la verdad en los corazones, deben los corazones buscar la verdad todos los días. La verdad os hace libres. La verdad desata todas las cadenas.



  Tened fe. Confiad y mirad Mis ojos de Madre, que os miran a vosotros. Como Madre veo vuestras angustias, dolores, vuestras penas y tristezas.



  Levantad el corazón, el ánimo, y confiad en Dios que os dará la respuesta a su debido tiempo.



  Meditad. Meditad. Meditad mis Palabras.”


<p align="JUSTIFY">
  **<img decoding="async" loading="lazy" class="alignright size-full wp-image-1484" title="jesus_corazon008" src="https://mariadelasantafe.org.ar/images/jesus_corazon008.jpg" alt="jesus_corazon008" width="238" height="320" />Dice Jesús:** “Hermanos míos, benditos y amados hermanos míos. Venid todos a Mí. Venid y llegad a Mi Sacratísimo Corazón. No os sintáis indignos. ¡Aquí estoy! Con vosotros estoy siempre, estoy en vuestros corazones.


<p align="JUSTIFY">
  Dejad siempre el lugar, en el interior de vuestro corazón, para Mi propio Corazón. Éste Corazón que os ama, éste Corazón que os bendice. Éste Corazón que derrama su bálsamo en vosotros, en vuestras familias, en vuestras comunidades. Mi Corazón es la paz, para las almas atormentadas. Mi Corazón es la serenidad para tantas almas angustiadas para tantas almas desesperadas.


<p align="JUSTIFY">
  Os muestro Mis Sacratísimas llagas, llagas abiertas, por amor a vosotros. Llagas que no dejan de sangrar por amor al mundo entero. Llagas que están abiertas para salvar a toda la humanidad, de la muerte eterna. Venid a Mí, que soy el Buen Pastor y vosotros sois Mis ovejas y estáis en Mi rebaño. Éste es Mi rebaño, vosotros estáis en él.



  ¡Venid, confiad! Llegad siempre a Mí, porque no quedaréis defraudados. No quedaréis jamás desamparados de Mi Mano, Mi Mano poderosa os bendice, os protege, os ama a todos.



  Hijitos Míos. Os amo a todos hermanos Míos. Confiad siempre, confiad en Mis Palabras, en Mi tags:
	- Mensajes Presencia. No dejéis jamás, que las dudas invadan vuestro corazón. Que el temor invada vuestro corazón.



  Sed auténticos mensajeros de Mis Palabras en el mundo entero. Sed testimonio de Mi tags:
	- Mensajes Presencia en el mundo entero. No guardéis Mis Palabras , que el mundo las conozca, que todos los hombres conozcan Mi tags:
	- Mensajes Presencia. Que la humanidad hoy se aparte del camino oscuro y vuelva a Mi camino. El camino de la verdad, de la justicia, de la vida. Mi Corazón es fuente de agua viva para todas las almas y ésta agua se vuelca sobre la humanidad para salvar a todos los hombres.


<p align="JUSTIFY">
  Vine, para salvar al mundo y no para condenarlo, vine para dar nuevas oportunidades a todas las almas, oportunidades de salvación. Que nadie tema acercarse a Mí. Todos deben llegar a Mí. Nadie debe sentirse excluido de éste llamado, llamo a los corazones, a las almas llamo, suplico, a todos los hombres. Llegad a mí y encontraréis la verdadera paz, encontraréis el consuelo, encontraréis la serenidad del alma. Soy el camino a la vida eterna , llegad a Mí, venid a Mí, cobijaos bajo el amparo de Mi Sacratísimo Corazón!



  Meditad. Meditad. Meditad Mis palabras.



  Os bendigo en el Nombre del Padre, y del Hijo y del Espíritu Santo. Amén.”
