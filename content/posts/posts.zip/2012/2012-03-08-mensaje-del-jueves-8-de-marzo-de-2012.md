---
title: Jueves 8 de Marzo, 2012
author: admin

date: 2012-03-08T10:48:01+00:00
url: /2012/mensaje-del-jueves-8-de-marzo-de-2012/
thumbnail: /images/FeRFV8DTw58a-1.jpg
tags: [Mensajes 2012]

---
**Dice la Santísima Virgen:**

<figure id="attachment_1366" aria-describedby="caption-attachment-1366" style="width: 290px" class="wp-caption alignright"><img decoding="async" loading="lazy" class="size-full wp-image-1366" title="mano" src="https://mariadelasantafe.org.ar/images/FeRFV8DTw58a.jpg" alt="mano" width="290" height="360" /><figcaption id="caption-attachment-1366" class="wp-caption-text">Mi corazón es luz y es paz para vosotros.</figcaption></figure>

****Hijos Míos; benditos y amados hijos míos. Aquí nuevamente está la Madre. Aquí nuevamente  
se manifiesta, María de la Santa Fe. Aquí muestro Mi Inmaculado Corazón, a cada uno de  
vosotros. Vosotros sois Mis mensajeros en el mundo entero. Vosotros, hijitos Míos, debéis ver  
Mi corazón de Madre cubierto de espinas, por los pecados del mundo, por las irreverencias del  
mundo, por la crueldad del mundo.

No dejéis de rezar. Rezad mucho, en familia, en comunidad, en todo lugar, rezad, el Santo  
Rosario. Pedid, hijitos Míos, que los corazones, de muchos de Mis hijos, se abran, hoy, a esta  
realidad, al mensaje de María. Se abran al mensaje que os trae, María de la Santa Fe. Muchos,  
son los hijos, los que caminan hoy en la oscuridad y encaminan sus vidas hacia el abismo.

Vivid cada día en la luz y no dejéis este camino, que estáis recibiendo por la Misericordia del  
Señor. La humanidad debe volver a la ley de Dios. Mis hijos deben mirar hacia la luz, y no hacia  
la oscuridad. El mundo está en la oscuridad y vosotros debéis llevar Mi luz de Madre, a todos  
los corazones. Porque la luz de Mi corazón, os conduce a la luz total, que es Cristo Jesús, Mi  
Hijo Amadísimo.

Hay muchas almas, muchos corazones, que aún, niegan Mi tags:
	- Mensajes Presencia. Que aún rechazan Mi  
tags:
	- Mensajes Presencia , que aún, cierran las puertas a Mis palabras maternales.

Estoy llamando, convocando, pidiendo a todos los corazones una respuesta, pidiendo a toda la  
humanidad que vuelva totalmente a la luz.

Aquí está la Madre. La Madre que os hace sentir el perfume de sus rosas. La Madre, que  
pone sus manos en cada uno de vosotros, para ayudaros a pasar las pruebas, los dolores, las  
angustias. A daros fuerza, para llevar vuestra cruz de cada día.

No temáis .Y vivid, verdaderamente en la luz. No temáis. Y aprovechad estos días en que la  
Madre se vuelve a manifestar sobre cada uno de vosotros.

He comenzado un nuevo camino y todos Mis hijos deben seguirme. Porque éste camino  
conduce a Jesús. En Jesús está, la verdadera libertad. En Cristo Jesús, Mi Hijo Amadísimo, está  
la auténtica libertad, para vuestros corazones, para vuestras almas.

Abrid vuestras manos, recibid el rosario que tengo en Mis manos, y llevadlo a vuestro corazón  
y allí vosotros recordaréis cada una de Mis palabras. Sentiréis, cada vez más cercana Mi  
tags:
	- Mensajes Presencia. Y seréis verdaderos mensajeros de todas Mis palabras hacia el mundo entero.

Todos los días, os pido la oración, todos los días, el Santo Rosario. Todos los días, ofreced, una  
penitencia, un sacrificio, por la conversión, de todos los pecadores.

Está brotando un nuevo tiempo, para esta tierra Santa y Bendita. Está brotando, un manantial  
de agua viva, para esta Nación Santa y Bendita.

¡Esperad! ¡Confiad! Esperad en el Señor, que en su momento justo os dará la respuesta. Aquí

está la Madre. Jamás lo dudéis.

Meditad. Meditad. Meditad Mis Palabras.

&nbsp;

**Dice Jesús:**

Hermanos Míos; benditos y amados hermanos Míos. Mi corazón os muestra, el camino de la  
luz. Mi corazón es luz y es paz para vosotros. Vengo a sanar las heridas. Vengo a daros nuevas  
fuerzas, para que no dejéis el camino y para que os toméis de Mis manos traspasadas por  
amor. Para que os toméis, de Mi Sacratísimo Corazón, y avancéis en la luz de la verdad.

¡Os amo a todos vosotros! Y estoy aquí presente, con todas las almas, con todos los corazones,  
del mundo entero. La humanidad, debe escuchar Mi voz. Mis hermanos, deben escuchar Mi  
voz. Los corazones, deben percibir Mi tags:
	- Mensajes Presencia real, entre cada uno de vosotros.

Estoy aquí, manifestando Mi amor infinito hacia vosotros. Estoy aquí, manifestando Mi Divina  
Misericordia, eterna Misericordia, que llega hacia vosotros a cada instante.

Venid siempre a Mí. Soy el camino, la verdad y la vida. Venid a Mí, y poned en Mi Sacratísimo  
Corazón, vuestras preocupaciones, vuestros temores, vuestras necesidades.

Os hablo de Mi amor infinito. Os hablo de Mi Misericordia infinita ,. Que el mundo hoy  
conozca, mi Misericordia, Mi amor, Mi verdad, Mi luz y Mi paz. Que el mundo ya no dude de  
Mis Palabras.

Que el mundo crea en Mí, que los hombres, vengan a Mí, cada día, a cada instante. Que  
vengan a beber, del agua de vida eterna que brota, de Mi Sacratísimo Corazón.

¡Gracias! Y no os sintáis indignos. Os amo a todos por igual, todos sois Mis ovejas y estáis en  
Mi rebaño y no separo a ninguno de Mi lado y os atraigo a todos con Mí amor,con Mi verdad y  
con Mi eterna paz.

Meditad. Meditad. Meditad Mis Palabras.

Os bendigo, en el Nombre del Padre, y del Hijo y del Espíritu Santo. Amén.