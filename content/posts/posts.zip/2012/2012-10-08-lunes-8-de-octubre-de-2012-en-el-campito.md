---
title: Lunes 8 de octubre, 2012 en el “Campito
date: 2012-10-08T13:46:27+00:00
url: /2012/lunes-8-octubre-2012-en-el-campito/
thumbnail: /images/jesus_hablando_muchacho-1.jpg
tags:
  - Mensaje
  - Mensajes Presencia
---
**Dice la Santísima Virgen:**  
“Hijos Míos, benditos y amados hijos Míos, la Madre viene hacia vosotros porque necesitáis de la Madre.  
La Madre está con sus hijos, porque los hijos claman a ésta Madre, suplican a ésta Madre. Debéis vosotros estar firmes en la fe y no vacilar en vuestra fe. Debéis creer en el Señor que está con los hijos y da la respuesta a los corazones en el momento oportuno, Mis palabras maternales son para vosotros, son para el mundo, son para todos los hijos que deben descubrir en ésta Madre, el camino que conduce a Jesús.

![](/images/jesus_hablando_muchacho.jpg)
**Hijos míos, rezad mucho, no dejéis de rezar. Rezad por la paz, fundamentalmente en los corazones y para que los hijos sean dóciles a la Gracia, para que los hijos permanezcan firmes en la fe. ¡No bajéis los brazos! Gracias por vuestra respuesta, gracias por vuestro SI, gracias por estar con ésta Madre. La Madre os bendice, la Madre está con los hijos, la Madre está aquí, **MARÍA DE LA SANTA FE**.

Meditad. Meditad. Meditad Mis palabras.”

**Dice Jesús:**  
“Hermanos Míos, benditos y amados hermanos míos, os doy la luz de Mi Sacratísimo Corazón, os muestro Mi camino, os conduzco por Mi camino.  
Quiero que cada uno tome su cruz y me siga. Quiero, que todos los corazones descubran la paz en Mí Sacratísimo Corazón, sed fieles al llamado. Abrid el corazón a Mis Palabras. No dejéis nunca que profetas falsos, que ídolos falsos ganen el interior de vuestro corazón.

¡Aquí estoy! Y quiero reinar con Mi Sacratísimo Corazón en vosotros, en vuestras familias, en vuestras comunidades, en todo lugar. Mi Corazón desea reinar, para que Mis hermanos encuentren la paz, descubran la paz. ¡Mi Paz! Que es la verdadera, la auténtica, la que salva a las almas.

Confiad en Mi, confiad y esperad y avanzad todos los días, un poco más, hacia Mi Sacratísimo Corazón. ¡No temáis! Aquí estoy derramando bendiciones en vosotros, en vuestras familias.  
¡No os angustiéis, y no os sintáis indignos! Porque Mi Amor se derrama a manos llenas en vosotros. Se derrama abundantemente en cada uno de vosotros y en forma especial. Abrid el corazón y Mis palabras entrarán a morar y a reinar en vosotros.

Os amo. Os amo. Os amo, porque sois Mis ovejas y estáis en Mi rebaño. Os amo. Que ya nadie dude de Mi presencia.

Meditad. Meditad. Meditad Mis palabras.

Os bendigo en el Nombre del Padre, y del Hijo y del Espíritu Santo. Amén.”