---
title: Domingo 8 de julio2012en el “Campito
date: 2012-07-08T23:42:56+00:00
url: /2012/domingo-8-de-julio-de-2012-en-el-campito/
thumbnail: /images/foto-virgennino-1.gif
tags: [Mensaje, Mensajes Presencia]
---
<img decoding="async" loading="lazy" class="alignright  wp-image-1503" title="foto-virgennino" src="https://mariadelasantafe.org.ar/images/foto-virgennino.gif" alt="virgen ninio" width="162" height="286" />

**Dice la Santísima Virgen:** “Hijos míos: benditos y amados hijos Míos nuevamente la Madre se manifiesta con vosotros.  
Nuevamente vengo desde el cielo a imploraros a vosotros la oración. Vengo como Madre a conducir vuestros corazones hacia Jesús, a conducir a todos Mis hijos del mundo hacia la luz que es Cristo Jesús Mi Hijo Amadísimo.

Muchas almas y muchos corazones se han apartado de este camino de luz y se han entregado al engaño, a la mentira, a la oscuridad, han abandonado la gracia y se han entregado al pecado. Es por Mis lágrimas, es por eso las innumerables espinas que hay en Mi Inmaculado Corazón.  
Vosotros seguid orando no bajéis los brazos, seguid el camino de la verdad, seguid en la luz, seguid en la justicia. Y recordad siempre que la Madre esta con vosotros, está a vuestro lado y que os viene a indicar permanentemente el camino que debéis seguir.  
Meditad. Meditad. Meditad Mis Palabras.”

**Dice Jesús:** “Hermanos míos benditos y amados hermanos míos. Os ofrezco Mis Manos para que avancéis hacia Mí, os ofrezco Mis Manos para que estéis siempre en Mi luz, para que estéis junto a Mí siempre. Os doy señales claras de Mi tags:
	- Mensajes Presencia. Mi amor hoy se vuelca en el mundo entero. Mi Divina Misericordia se vuelca en el mundo entero.  
Hablo a todos los corazones. Hablo a todos Mis hermanos .Quiero que todos Mis hermanos vivan en la luz. Quiero que la humanidad vuelva hacia Mí con urgencia .Estoy aquí como el Buen Pastor. Y vosotros sois Mis ovejas. Y Mi amor no tiene precio.

Mi amor lo vuelco a vuestros corazones porque os amo en forma especial a todos por igual. Derramo el bálsamo de Mis Sacratísimas Llagas en vosotros.  
<img decoding="async" loading="lazy" class="alignleft  wp-image-1500" title="foto-manos" src="https://mariadelasantafe.org.ar/images/foto-manos.jpg" alt="" width="206" height="210" /> 

Sentid Mi tags:
	- Mensajes Presencia, sentid Mi voz de amor, Mi voz de Misericordia, Mi voz de eterna paz. Vivid en la paz, trabajad por la paz, sed mensajeros de la paz. En este mundo de hoy, en este mundo enloquecido, en este mundo que solo conoce la guerra, el odio y la división.  
Rezad y no temáis, aquí estaré siempre, con cada uno de vosotros.

Os amo. Os amo. Os amo.

Meditad. Meditad. Meditad Mis Palabras.

Os bendigo en el Nombre del Padre y del Hijo y del Espíritu Santo. Amén.”