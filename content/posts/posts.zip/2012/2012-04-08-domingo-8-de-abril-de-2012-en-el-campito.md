---
title: Domingo 8 de abril2012en el “Campito”
author: admin

date: 2012-04-08T10:57:21+00:00
url: /2012/domingo-8-de-abril-de-2012-en-el-campito/
thumbnail: /images/Ave_Maria-1.jpg
tags: [Mensajes 2012]

---
<figure id="attachment_1364" aria-describedby="caption-attachment-1364" style="width: 366px" class="wp-caption alignright"><img decoding="async" loading="lazy" class="size-full wp-image-1364" title="Ave_Maria" src="https://mariadelasantafe.org.ar/images/Ave_Maria.jpg" alt="Ave_Maria" width="366" height="389" /><figcaption id="caption-attachment-1364" class="wp-caption-text">Mi amor de Madre se manifiesta con todos los hijos. Mi amor, mi amor misericordioso de Madre, se manifiesta en cada corazón.</figcaption></figure>

“Hijos míos; benditos y amados hijos míos. Os agradezco  
en forma especial, a cada uno de vosotros, por vuestra presencia junto a ésta Madre.  
Esta Madre, que hace descender una lluvia de bendiciones y de gracias sobre cada uno  
de vosotros, sobre vuestras familias, y sobre todos los hijos, que por alguna ocasión o  
motivo, no han podido estar aquí.

Mi amor de Madre se manifiesta con todos los hijos. Mi amor, mi amor misericordioso  
de Madre, se manifiesta en cada corazón. Gracias hijitos míos por abrir las puertas de  
vuestros corazones, por escuchar y atender a ésta Madre, por ser sencillos, simples y  
obedientes.

Tenéis que avanzar cada día, tenéis que superar las pruebas y cargar vuestras cruces. Y  
debéis acordaros que la Madre os acompaña, que la Madre os sostiene, que la Madre os  
conduce por el camino de la luz y de la verdad.

Hoy hay muchas almas ciegas y muchos corazones cerrados que no aceptan mis  
palabras maternales, hacia ellos también va mi amor, va mi presencia, va mi mirada  
maternal.

Vosotros debéis trabajar, poner vuestras manos para ser grande ésta Santa Obra, porque  
la Madre está aquí, en ésta Santa Fe la Nueva Jerusalén, en ésta Argentina, el Nuevo  
Israel.

La Madre está presente, a lo largo y a lo ancho de esta nación, llamando a todos  
los hijos a una profunda conversión, a una diaria conversión. Aceptad mis palabras  
profundamente en vuestro corazón, y vivid éstos días tan especiales en que la Madre  
aún permanece con cada uno de vosotros. Meditad. Meditad. Meditad Mis palabras.”

**Dijo Jesús:** 

“Hermanos Míos, benditos y amados hermanos Míos, sentid Mi presencia  
junto a vosotros, sentid el latir de Mi Sacratísimo Corazón, que late de amor por  
vosotros, que derrama todo su amor en vuestros corazones. Sentid Mi presencia y Mi  
amor misericordioso que os muestra el camino de la verdad. Luchad y trabajad, y abrid  
siempre las puertas para que Mis palabras entren en lo profundo de vuestro corazón.  
No os olvidéis de Mis promesas y de Mis palabras, que siempre se cumplen. Aquí  
estoy, invitando a todas las almas a una conversión definitiva, invitando a la humanidad  
a que se acerque a la luz, a Mi luz, a Mi verdad, a Mi amor.

Ya basta de ídolos falsos, ya basta de seguir luces engañosas, y que solamente  
conducen a la muerte eterna. Ya basta, seguid solamente Mi luz, Mi luz que os conduce  
a la vida eterna, seguid Mis pasos, porque tras Mis pasos camináis hacia la vida eterna.  
No dudéis de Mi amor, de Mis palabras, de Mi presencia. No dudéis jamás de éste amor  
misericordioso que siento por cada uno de vosotros.

Derramo en éste momento Mi Preciosísima Sangre sobre vosotros, para bendeciros,  
liberaros y daros la fuerza para seguir Mi camino. No dudéis jamás, jamás de Mi amor  
hacia cada uno de vosotros.

Meditad. Meditad. Meditad Mis palabras.

Os bendigo, en el Nombre del Padre, y del Hijo y del Espíritu Santo. Amén.”