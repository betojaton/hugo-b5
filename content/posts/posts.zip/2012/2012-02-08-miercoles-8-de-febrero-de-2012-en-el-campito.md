---
title: 'Miércoles 8 de febrero, 2012 en el “Campito”'
author: admin

date: 2012-02-08T00:50:41+00:00
url: /2012/miercoles-8-de-febrero-de-2012-en-el-campito/
thumbnail: /images/gentle_jesus_meek_and_mild-1.jpg
tags: [Mensajes 2012]

---
**Dijo la Santísima Virgen: **  
“Hijos Míos: benditos y amados hijos Míos, vengo como Madre a hablaros del amor y de la Misericordia del Señor. Vengo a mostraros el camino, y quiero como Madre, agradecer vuestra presencia.

****¡Gracias hijitos Míos! Por abrir vuestros corazones a Mis palabras maternales. Por estar dispuestos y estar entregados a ésta Madre. **Quiero, que hagáis florecer Mis rosales en vuestro corazón, cada día.** Que miréis a vuestro alrededor y os compadezcáis de los enfermos, de los desvalidos, de los pobres, de los niños sin hogar.

Quiero que miréis el mundo, y recéis mucho más para que la paz descienda en los corazones. Para que florezcan los jardines en el mundo entero. ¡Hijitos, dad mucho fruto! Dios, espera aún más de vosotros. Dios Nuestro Señor, está junto a vosotros. Y os muestra el camino.

¡Aquí tenéis a la Madre! Que os conduce a Cristo Jesús Mi Hijo Amadísimo. Venid con la Madre. Seguid los pasos, que esta Madre os indica .Avanzad y jamás miréis el pasado.

Avanzad todos los días tomados de Mi mano, junto a ésta Madre jamás os perderéis en el camino. Con la Madre, llegaréis a puerto seguro, que es Cristo Jesús Mi Hijo Amadísimo.

Meditad. Meditad. Meditad Mis palabras.

<figure id="attachment_1368" aria-describedby="caption-attachment-1368" style="width: 248px" class="wp-caption alignright"><img decoding="async" loading="lazy" class="size-medium wp-image-1368" title="jesus sentado" src="https://mariadelasantafe.org.ar/images/gentle_jesus_meek_and_mild-248x300.jpg" alt="jesus sentado" width="248" height="300" /><figcaption id="caption-attachment-1368" class="wp-caption-text">Vivid en el amor. Porque el amor, salvará al mundo.</figcaption></figure>

******Dijo Jesús:  
** “Hermanos Míos;  benditos y amados hermanos Míos, os ofrezco Mi Sacratísimo Corazón. Toco vuestras cabezas para daros la fortaleza. Os doy Mi Corazón, para que deis luz al mundo. Para que seáis Mis soldados. Para que veáis, en Mi Sacratísimo Corazón, la respuesta a todas vuestras necesidades.

¡Os amo a todos! Todos sois Mis ovejas. ¡Os amo a todos! Mi Corazón os bendice. Mi Corazón os fortalece. Mi Corazón está, permanentemente con vosotros.

¡No dudéis de Mi amor hacia vosotros! No dudéis, jamás, de Mi Misericordia, con vosotros y con el mundo entero. Doy, a cada instante, infinitas oportunidades, a todas las almas, a todos los corazones.

Doy, las mismas señales, a todas las almas, para que todos los hombres, se conviertan. Y lleguen a la vida eterna.

Llegad a Mí .Venid a Mí .Jamás dudéis de Mi amor hacia vosotros. Avanzad, todos los días. Avanzad. Y esperad y confiad, en Mi Divina Misericordia, para con vosotros, y para con el mundo entero.

Vivid en el amor. Porque el amor, salvará al mundo. Vivid en la paz, en la paz que os da  Mi Sacratísimo Corazón.

Meditad. Meditad. Meditad Mis palabras.

Os bendigo en el Nombre del Padre y del Hijo y del Espíritu Santo .Amén.”