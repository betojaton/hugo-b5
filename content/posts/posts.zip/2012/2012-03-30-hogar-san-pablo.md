---
title: Colaboración Hogar ”San Pablo”
author: admin

date: 2012-03-30T20:21:27+00:00
url: /2012/hogar-san-pablo/
tags: [Colaboraciones]

---
##### 13/07/2011 , 30/03/2012

<!-- default-view.php -->

<div
	class="ngg-galleryoverview default-view "
	id="ngg-gallery-1dfa7297d9d36d1ec055a94c68ca0e3f-1">
  <!-- Thumbnails -->
  
  <div id="ngg-image-0" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-san-pablo/dsc03122.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-san-pablo/dsc03122.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-san-pablo/thumbs/thumbs_dsc03122.jpg"
               data-image-id="95"
               data-title="dsc03122"
               data-description=""
               data-image-slug="dsc03122"
               class="ngg-simplelightbox" rel="1dfa7297d9d36d1ec055a94c68ca0e3f"> <img
                    title="dsc03122"
                    alt="dsc03122"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-san-pablo/thumbs/thumbs_dsc03122.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-1" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-san-pablo/dsc03123.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-san-pablo/dsc03123.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-san-pablo/thumbs/thumbs_dsc03123.jpg"
               data-image-id="96"
               data-title="dsc03123"
               data-description=""
               data-image-slug="dsc03123"
               class="ngg-simplelightbox" rel="1dfa7297d9d36d1ec055a94c68ca0e3f"> <img
                    title="dsc03123"
                    alt="dsc03123"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-san-pablo/thumbs/thumbs_dsc03123.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-2" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-san-pablo/dsc03124.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-san-pablo/dsc03124.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-san-pablo/thumbs/thumbs_dsc03124.jpg"
               data-image-id="97"
               data-title="dsc03124"
               data-description=""
               data-image-slug="dsc03124"
               class="ngg-simplelightbox" rel="1dfa7297d9d36d1ec055a94c68ca0e3f"> <img
                    title="dsc03124"
                    alt="dsc03124"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-san-pablo/thumbs/thumbs_dsc03124.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-3" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-san-pablo/dsc03125.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-san-pablo/dsc03125.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-san-pablo/thumbs/thumbs_dsc03125.jpg"
               data-image-id="98"
               data-title="dsc03125"
               data-description=""
               data-image-slug="dsc03125"
               class="ngg-simplelightbox" rel="1dfa7297d9d36d1ec055a94c68ca0e3f"> <img
                    title="dsc03125"
                    alt="dsc03125"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-san-pablo/thumbs/thumbs_dsc03125.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <br style="clear: both" /> <!-- Pagination -->
  
  <div class='ngg-clear'>
  </div>
</div>