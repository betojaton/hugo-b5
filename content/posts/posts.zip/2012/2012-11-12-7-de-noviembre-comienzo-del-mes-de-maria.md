---
title: 7 de noviembre comienzo del Mes de María
author: admin

date: 2012-11-12T13:54:40+00:00
url: /2012/7-de-noviembre-comienzo-del-mes-de-maria/
thumbnail: /images/virgen_sobre_mundo-1.jpg
tags: [Notas]
---
#### &#8220;Peregrinando en la Fe con María&#8221;

<img decoding="async" loading="lazy" src="https://mariadelasantafe.org.ar/images/virgen_sobre_mundo.jpg" alt="virgen_sobre_mundo" title="virgen_sobre_mundo" width="332" height="402" class="alignright size-full wp-image-1618" /> **María, Mediadora de todas las Gracias:**  
La fiesta de María Mediadora de todas las Gracias la instituyó el Papa Benedicto XV en 1921; en ella se nos invita a recurrir siempre con confianza a esta mediación  de la Madre del Redentor.

Maternidad espiritual de María: La Santísima Virgen, predestinada, junto con la Encarnación del Verbo, desde toda la eternidad, cual Madre de Dios, por designio de la Divina Providencia, fue en la tierra la esclarecida Madre del Divino Redentor, y en forma singular la generosa colaboradora entre todas las criaturas y la humilde esclava del Señor. Concibiendo a Cristo, engendrándolo, alimentándolo, presentándolo en el templo al Padre, padeciendo con su Hijo mientras El moría en la Cruz, cooperó en forma del todo singular, por la obediencia, la fe, la esperanza y la encendida caridad en la restauración de la vida sobrenatural de las almas. Por tal motivo es nuestra Madre en el orden de la gracia.

**María, Mediadora:**  
Y esta maternidad de María perdura sin cesar, desde el momento en que prestó fiel asentimiento en la Anunciación, y lo mantuvo sin vacilación al pie de la Cruz, hasta la consumación perfecta de todos los elegidos. Pues una vez recibida en los cielos, no dejó su oficio salvador, sino que continúa alcanzándonos por su múltiple intercesión los dones de la eterna salvación. Con su amor materno cuida de los hermanos de su Hijo, que peregrinan y se debaten entre peligros y angustias y luchan contra el pecado hasta que sean llevados a la patria feliz.  
**Por eso, la Santísima Virgen en la Iglesia es invocada con los títulos de Abogada, Auxiliadora, Socorro, Mediadora.**

<div class="oculta-home">
  <blockquote>
    <p style="text-align: center;">
      “María de la Santa Fe, Madre y custodia de nuestra Fe, ruega por nosotros”
    
    
    <p>
      <cite>Año de la Fe 2012-2013</cite>
    
  </blockquote>
  
  <p style="text-align: center;">
    **Credo:**
  
  
  <p style="text-align: center;">
    “Creo en Dios, Padre Todopoderoso, Creador del cielo y de la tierra. Creo en Jesucristo, su único Hijo, Nuestro Señor, que fue concebido por obra y gracia del Espíritu Santo, nació de Santa María Virgen, padeció bajo el poder de Poncio Pilato, fue crucificado, muerto y sepultado, descendió a los infiernos, al tercer día resucitó de entre los muertos, subió a los cielos y está sentado a la derecha de Dios, Padre Todopoderoso. Desde allí ha de venir a juzgar a los vivos y a los muertos. Creo en el Espíritu Santo, la Santa Iglesia Católica, la comunión de los santos, el perdón de los pecados, la resurrección de la carne y la vida eterna. Amén.”
  
</div>