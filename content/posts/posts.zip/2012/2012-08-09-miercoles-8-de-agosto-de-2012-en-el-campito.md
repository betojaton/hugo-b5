---
title: Miércoles 8 de agosto2012en el “Campito”
author: admin

date: 2012-08-09T00:19:18+00:00
url: /2012/miercoles-8-de-agosto-de-2012-en-el-campito/
thumbnail: /images/pintura_jesus_luz-1.jpg
tags: [Mensajes 2012]

---
**Dice la Santísima Virgen:** Hijos míos, benditos y amados hijos míos aquí está María con sus hijos y Mi Manto Celestial es la muralla que os protege a vosotros, pequeños hijitos míos.

Buscad refugio en Mi Manto Celestial. Buscad refugio en el Santo Rosario. La Madre se manifiesta con los hijos trayendo el mensaje del Señor, trayendo el mensaje del cielo e invitando a los hijos a la conversión.

<img decoding="async" loading="lazy" class="alignleft size-medium wp-image-1542" title="caliz_pan_uvas" src="https://mariadelasantafe.org.ar/images/caliz_pan_uvas-216x300.jpg" alt="" width="216" height="300" /> Mis hijos deben escuchar Mis palabras, Mis hijos deben estar atentos, son los días de la Madre con los hijos y la humanidad debe buscar el camino de la luz y de la verdad. Como Madre invito a todos los corazones a vivir en la verdad y a acercarse hacia Cristo Jesús Mi Hijo Amadísimo y a aceptar como alimento para la Vida Eterna a través de Su Cuerpo y de Su Sangre.

La Madre os bendice, ésta Madre os bendice en forma especial. Hago descender Mis gracias desde el cielo sobre cada uno de vosotros. Os escucho, os atiendo. No estáis desamparados. La Madre está a vuestro lado, siempre, a cada día, a cada instante, en cada momento.  
Meditad. Meditad. Meditad Mis palabras.

**<img decoding="async" loading="lazy" class="alignright size-medium wp-image-1543" title="pintura_jesus_luz" src="https://mariadelasantafe.org.ar/images/pintura_jesus_luz-199x300.jpg" alt="pintura_jesus_luz" width="199" height="300" />Dice Jesús:** Hermanos míos, benditos y amados hermanos míos. Mirad siempre la luz de Mi corazón, mirad la luz de Mi Divina Misericordia, y entregaos definitivamente a Mí.

Sacad del corazón la vanidad, el orgullo, los pensamientos incorrectos y dejad que Mi Corazón entre a reinar en vosotros. Dejad que Mi Sacratísimo Corazón os modele a cada instante.  
El mundo trata de apartaros de Mi lado. El mundo, con sus complacencias, trata de apartaros de mi lado. Manteneos firmes, junto a Mí, fieles junto a Mí. Aprovechad Mis palabras, meditadlas en vuestro corazón. Meditadlas cada día y así cada día iréis caminando en la verdad, en la luz, en la santidad.  
Sed, Mis mensajeros en el mundo entero, porque Mis palabras son para todos los hombres.

Os amo, infinitamente. Os amo.

Meditad. Meditad. Meditad Mis palabras.

Os bendigo, en el Nombre del Padre y del Hijo y del Espíritu Santo. Amén.