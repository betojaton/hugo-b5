---
title: Indulgencia Plenaria por el Año de la FE
author: admin

date: 2012-10-15T14:21:29+00:00
url: /2012/indulgencia-plenaria-por-el-ano-de-la-fe-2-2/
thumbnail: /images/logo_aniodelafe-1.jpg

---
[<img decoding="async" loading="lazy" class="wp-image-1577 alignleft" title="Ver Noticia Completa..." src="https://mariadelasantafe.org.ar/images/logo_aniodelafe.jpg" alt="logo_aniodelafe" width="189" height="230" />][1]Ciudad del Vaticano, 5 octubre  2012(VIS).- -Benedicto XVI concederá a los fieles la indulgencia plenaria con motivo del Año de la Fe que será válida desde su apertura (11 de octubre2012hasta su clausura, 24 de noviembre de 2013), según informa el decreto hecho público hoy firmado por el cardenal Manuel Monteiro de Castro y por el obispo Krzysztof Nykiel, respectivamente Penitenciario Mayor y Regente de la Penitenciaría Apostólica.

[>> Ver Noticia Completa][1]

 [1]: https://mariadelasantafe.org.ar/archives/1564 "Indulgencia Plenaria por el Año de la FE"