---
title: Martes 8 de mayo2012en “El Campito”
author: admin

date: 2012-05-08T23:09:13+00:00
url: /2012/martes-8-de-mayo-de-2012-en-el-campito/
thumbnail: /images/foto2-1.jpg
tags: [Mensajes 2012]

---
<figure id="attachment_1447" aria-describedby="caption-attachment-1447" style="width: 229px" class="wp-caption alignright"><img decoding="async" loading="lazy" class="size-full wp-image-1447 " title="foto1" src="https://mariadelasantafe.org.ar/images/foto1.jpg" alt="Rosario en mano" width="229" height="320" /><figcaption id="caption-attachment-1447" class="wp-caption-text">“…Aquí estoy con el Rosario en Mis manos y os pido que abráis vosotros vuestras manos y recibáis este Rosario. Que cada uno reciba éste Rosario y debéis llevarlo a vuestro corazón, allí hijitos míos está Mi amor de Madre, en vuestros corazones, allí está Mi presencia, allí están Mis palabras...”</figcaption></figure>

<p align="JUSTIFY">
  **Dice la Santísima Virgen:**”Hijos míos benditos y amados hijos míos, aquí me manifiesto nuevamente con vosotros. Vengo desde el cielo, trayendo sobre cada uno de vosotros las bendiciones y gracias que estáis necesitando.


<p align="JUSTIFY">
  Aquí me manifiesto y mi Manto Celestial os cubre a todos. Aquí estoy con el Rosario en Mis manos  y os pido que abráis vosotros vuestras manos  y recibáis este Rosario. Que cada uno reciba éste Rosario y debéis llevarlo a vuestro corazón, allí hijitos míos, está Mi amor de Madre, en vuestros corazones, allí está Mi presencia, allí están Mis palabras.


<p align="JUSTIFY">
  Debéis tomaros, siempre de las manos, y seguir avanzando, seguir el camino que Dios Nuestro Señor prepara para cada uno de vosotros.


<p align="JUSTIFY">
  No debéis bajar los brazos, y debéis sentir, Mi calor maternal, Mi presencia, Mi amor, Mis palabras, debéis sentir a ésta Madre cerca de vosotros, porque la Madre no se aparta nunca de vuestro lado, la Madre viene a socorreros, a daros fuerza, a daros, verdaderamente FUERZA para seguir el camino.


 Aquí están Mis palabras, Mi presencia real con vosotros. Aquí estoy  hijitos míos  y debéis sentir paz en vuestro corazón, que el mundo no ahogue esa paz, esa paz que ésta Madre pone en vuestro corazón.

<p align="JUSTIFY">
  Meditad. Meditad. Meditad Mis palabras.Debéis iluminar a todos vuestros hermanos, iluminar con vuestra fe, debéis avanzar en la fe, en la oración, en la penitencia y en los sacrificios. ¡No bajéis los brazos! porque aquí está  la Madre, junto a cada uno de sus hijos.


<p align="JUSTIFY">
  **<br /> Dice Jesús: **“Hermanos míos benditos y amados hermanos míos. ¡Mis pequeñas ovejas! ¡Mis ovejitas! ¡Mis hermanos! Aquí estoy y vengo para consolaros. Vengo, con Mi Divina Misericordia para sanaros. Vengo con Mi amor para cubrir vuestro corazón y sanaros. Sois, Mis pequeñas ovejas, sois, las ovejas de Mi rebaño, y estáis frente a Mi presencia.


<strong style="text-align: justify;"><img decoding="async" loading="lazy" class="alignleft size-medium wp-image-1456" title="foto2" src="https://mariadelasantafe.org.ar/images/foto2-168x300.jpg" alt="Jesus con ovejas" width="168" height="300" />**

<p align="JUSTIFY">
  Os traigo todas Mis palabras, Mis enseñanzas, Mi paz, os traigo éste amor que debe ser recibido y aceptado por los corazones. Aquí estoy, y Mi Sacratísimo Corazón, es vuestra paz, vuestro consuelo, vuestra serenidad.


<p align="JUSTIFY">
  Aferraos a Mí. No dudéis de Mi amor hacia vosotros. Sois Mis ovejas. ¡Mis pequeñas ovejas! Sois, Mis hermanos. Sois, Mis hijos. No dudéis jamás de este amor que derramo en cada uno de vosotros.


<p align="JUSTIFY">
  Sed siempre difusores de Mi palabra, de Mi amor, Mi verdad y Mi paz, y enseñad a las almas y a los corazones a vivir en la paz, en la verdad, en la luz. Aumentad vuestra fe, vuestra esperanza, y seguid Mis pasos, ¡seguid los pasos del Buen Pastor! que conduce a cada una de sus ovejas.


<p align="JUSTIFY">
  ¡Aquí está Mi amor para vosotros! Aquí está el bálsamo de Mis Sacratísimas Llagas para cada uno de vosotros, este bálsamo que es Mi Preciosísima Sangre y que derramo, sobre todos y en forma especial para sanaros, para daros todos los días nuevas fuerzas, para que jamás dudéis y no tengáis miedo del mundo y de los hombres.


<p align="JUSTIFY">
  Sed valerosos. Sed Mis soldados valerosos. Sed, sed  verdaderamente Mis ovejas. Sed ovejas buenas, dóciles, de corazón abierto, para todos los hombres.


<p align="JUSTIFY">
  Meditad. Meditad. Meditad Mis palabras.


<p align="JUSTIFY">
  Os bendigo, en el Nombre del Padre, y del Hijo, y del Espíritu Santo. Amén.
