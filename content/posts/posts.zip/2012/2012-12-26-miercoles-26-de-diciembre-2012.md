---
title: Miércoles 26 de diciembre, 2012
author: admin

date: 2012-12-26T13:23:33+00:00
url: /2012/miercoles-26-de-diciembre-2012/
thumbnail: /images/Dios-padre-es-el-unico.jpg
tags: [Notas]

---
**Por la mañana dice la Santísima Virgen:**  
![](/images/Dios-padre-es-el-unico.jpg)

> Vicente hijo mío . La humanidad se encamina hacia un sombrío destino , la humanidad camina a pasos agigantados, hacia un final de toda destrucción , los hombres , mis propios hijos siguen rechazando tantos medios para la conversión , para la definitiva conversión.  
> La rivalidad se ha apoderado en tantos grupos en la misma Santa Iglesia , rivalidad , desunión ,celos , envidias , difamaciones , mis hijos creen que Dios Nuestro Señor no mira estas cosas , oscuras que salen del corazón del hombre.  
> Hijitos míos, es necesario hoy , es urgente hoy que todos os volváis , con plena confianza a los brazos del Padre Eterno , que fijéis la mirada en El y os hagáis corderos mansos y no serpientes venenosas en que hoy estáis convertidos.  
> Volved la mirada y el corazón a Dios y así la humanidad tendrá un futuro de paz , de amor , de luz , solamente así reinará el amor en el mundo entero y en cada uno de los corazones.  
> Escuchad a María , a María de la Santa Fe , a María que está con sus hijos.  
> Esta tierra Santa y bendita , la Nueva Jerusalén ,esta tierra es el Nuevo Medjugorje.  
> Meditad Mi Profundísimo Mensaje.  
> Amén . Gloria a Cristo Jesús.  
> Leed: Mateo .C25 ,V19 al 23.  
> Predícalo a todos tus hermanos.