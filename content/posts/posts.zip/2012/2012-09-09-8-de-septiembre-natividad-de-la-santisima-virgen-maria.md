---
title: 8 de Septiembre, Natividad de la  Santísima Virgen María
author: admin

date: 2012-09-09T00:13:16+00:00
url: /2012/8-de-septiembre-natividad-de-la-santisima-virgen-maria/
thumbnail: /images/natividad_virgen-1.jpg
tags: [Notas]

---
<img decoding="async" loading="lazy" src="https://mariadelasantafe.org.ar/images/natividad_virgen.jpg" alt="natividad_virgen" title="natividad_virgen" width="232" height="320" class="alignright size-full wp-image-1539" />La Virgen María fue la Madre de Jesús y, con este hecho, se cumplieron las Escrituras y todo lo dicho por los profetas. Dios escogió a esta mujer para ser la Madre de su Hijo. Con ella se aproximó la hora de la salvación. Por esta razón la Iglesia celebra esta fiesta con alabanzas y acciones de gracias.  
El nacimiento de la Virgen María tuvo privilegios únicos. Ella vino al mundo sin pecado original. María, la elegida para ser Madre de Dios, era pura, santa, con todas las gracias más preciosas. Tenía la gracia santificante, desde su concepción. 

Después del pecado original de Adán y Eva, Dios había prometido enviar al mundo a otra mujer cuya descendencia aplastaría la cabeza de la serpiente. Al nacer la Virgen María comenzó a cumplirse la promesa.

La vida de la Virgen María nos enseña a alabar a Dios por las gracias que le otorgó y por las bendiciones que por Ella derramó sobre el mundo. Podemos encomendar nuestras necesidades a Ella. 

La fiesta de la Natividad de la Santísima Virgen María se comenzó a celebrar oficialmente con el Papa San Sergio (687-701 d.C.) al establecer que se celebraran en Roma cuatro fiestas en honor de Nuestra Señora: la Anunciación, la Asunción, la Natividad y la Purificación.

Se desconoce el lugar donde nació la Virgen María. Algunos dicen que nació en Nazaret, pero otros opinan que nació en Jerusalén. Ahí, ahora, hay una cripta en la iglesia de Santa Ana que se venera como el lugar en el que nació la Madre de Dios