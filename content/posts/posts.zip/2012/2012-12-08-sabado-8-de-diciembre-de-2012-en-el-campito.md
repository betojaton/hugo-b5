---
title: Sábado 8 de diciembre, 2012 en el “Campito”
date: 2012-12-08T12:17:47+00:00
url: /2012/sabado-8-diciembre-2012-en-el-campito/
thumbnail: /images/madre-hijo.jpg
tags:
  - Mensajes
  - Mensajes Presencia
---

  **Dice la Santísima Virgen:** “Hijos míos; benditos y amados hijos míos, derramo en vosotros abundantes bendiciones como cada día 8, derramo en vosotros las gracias que estáis necesitando.

  Como Madre me manifiesto nuevamente con Mis hijos, llamando a los corazones a vivir en la unidad, llamando a las almas a ser luz para el mundo.

![](/images/madre-hijo.jpg)
  
  Mi Corazón de Madre está tantas veces tan cubierto de espinas, las espinas que ponen los hijos rebeldes, los hijos que siguen el camino del pecado y de la oscuridad. Os invito a vosotros hijitos míos a ser luz para el mundo, a convocar a las almas, a convocar a los corazones, a ser vosotros testimonio auténtico de la presencia de ésta Madre con los hijos.


  Llevad Mi mensaje maternal a las almas, a los enfermos, a los hijos tan desesperados. Llevad Mi mensaje a todos los corazones que están necesitando hoy de ésta Madre, porque la Madre quiere estar con todos los hijos y que todos Mis hijos abran las puertas de sus corazones a Mi presencia.


  ¡Soy María de la Santa Fe! Y quiero que la fe de vuestros corazones no se apague, que crezca cada vez más y así muchísimas almas llegarán a Mi encuentro maternal, buscarán a esta Madre como remedio y consuelo porque esta Madre es el puente y el camino directo hacia Jesús, hacia Cristo Jesús Mi Hijo Amadísimo.


  No os olvidéis de Mis palabras, jamás, y meditadlas profundamente en vuestro corazón. Y cada día cuando estéis doloridos, angustiados, recordad Mis palabras, recordad que ésta Madre está a vuestro lado siempre, en todo momento, siempre estoy con vosotros. Nunca lo olvidéis.


  Meditad. Meditad. Meditad Mis palabras.”
