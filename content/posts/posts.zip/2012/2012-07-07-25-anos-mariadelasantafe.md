---
title: 25 años mariadelasantafe
author: admin

date: 2012-07-07T12:32:05+00:00
url: /2012/25-anos-mariadelasantafe/
thumbnail: /images/DSC09451-1.jpg
tags: [Notas]

---
A 25 años de la Manifestación de la Santísima Virgen como &#8220;María de la Santa Fe&#8221;.



<figure id="attachment_1475" aria-describedby="caption-attachment-1475" style="width: 144px" class="wp-caption alignleft"><img decoding="async" loading="lazy" class=" wp-image-1475 " title="virgen-maria" src="https://mariadelasantafe.org.ar/images/DSC09451-206x300.jpg" alt="virgen-maria" width="144" height="210" /><figcaption id="caption-attachment-1475" class="wp-caption-text">“…Hoy aquí os bendigo, hoy aquí me manifiesto en esta Santa Fe, la Nueva Jerusalén. En ésta Argentina, tan dispersa, en ésta Argentina Santa y Bendita que está dominada por la oscuridad…”</figcaption></figure>**08/07/1987 – 08/07/2012**

Las manifestaciones de la Santísima Virgen María y de Nuestro Señor Jesucristo en el “Campito”  
situado en la costanera santafesina, comienzan en el año 1987. La primera revelación fue el  
8 de abril de ese año y el 8 de julio la Madre se anuncia como MARIA DE LA SANTA FE. En ese  
entonces hace saber que Santa Fe es una ciudad elegida, Santa y Bendita.

Desde ese día nos invita a seguir el camino que conduce a Cristo Jesús su hijo amadísimo.  
María es el puente para llegar a Cristo Jesús, María va donde la llaman y la necesitan,  
siempre está presente, con su Manto maternal cubre a todos los hijos del mundo entero.

Ella nos sostiene, nos alza cuando caemos, somos sus hijos, estamos en su Inmaculado  
Corazón Respondamos a su llamado como nos pide, recurramos a ella que siempre nos  
ampara y nos cobija con su Manto Celestial.

08 de Junio de 2012