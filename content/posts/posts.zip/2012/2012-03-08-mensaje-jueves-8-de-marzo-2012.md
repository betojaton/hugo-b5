---
title: "Mensajes Presencia | Jueves 8 de Marzo, 2012"
date: 2012-03-08T15:29:00+00:00
url: /2012/mensaje-jueves-8-marzo-2012
tags: [Mensajes 2012, Mensajes Presencia]
---
![Foto familia rezando](/images/foto-rezo-familia.webp)

**Dice la Santísima Virgen:**  
Hijos Míos; benditos y amados hijos míos. Aquí nuevamente está la Madre. Aquí nuevamente se  
manifiesta, María de la Santa Fe. Aquí muestro Mi Inmaculado Corazón, a cada uno de vosotros.  
Vosotros sois Mis mensajeros en el mundo entero. Vosotros, hijitos Míos, debéis ver Mi corazón de  
Madre cubierto de espinas, por los pecados del mundo, por las irreverencias del mundo, por la  
crueldad del mundo.

No dejéis de rezar. Rezad mucho, en familia, en comunidad, en todo lugar, rezad, el Santo Rosario.  
Pedid, hijitos Míos, que los corazones, de muchos de Mis hijos, se abran, hoy, a esta realidad, al  
mensaje de María. Se abran al mensaje que os trae, María de la Santa Fe. Muchos, son los hijos, los  
que caminan hoy en la oscuridad y encaminan sus vidas hacia el abismo.  
Vivid cada día en la luz y no dejéis este camino, que estáis recibiendo por la Misericordia del Señor.  
La humanidad debe volver a la ley de Dios. Mis hijos deben mirar hacia la luz, y no hacia la  
oscuridad. El mundo está en la oscuridad y vosotros debéis llevar Mi luz de Madre, a todos los  
corazones. Porque la luz de Mi corazón, os conduce a la luz total, que es Cristo Jesús, Mi Hijo  
Amadísimo.

Hay muchas almas, muchos corazones, que aún, niegan Presencia. Que aún rechazan Mi Presencia , que aún, cierran las puertas a Mis palabras maternales.  
Estoy llamando, convocando, pidiendo a todos los corazones una respuesta, pidiendo a toda la  
humanidad que vuelva totalmente a la luz.

Aquí está la Madre. La Madre que os hace sentir el perfume de sus rosas. La Madre, que pone sus  
manos en cada uno de vosotros, para ayudaros a pasar las pruebas, los dolores, las angustias. A daros  
fuerza, para llevar vuestra cruz de cada día.

No temáis .Y vivid, verdaderamente en la luz. No temáis. Y aprovechad estos días en que la Madre  
se vuelve a manifestar sobre cada uno de vosotros.  
He comenzado un nuevo camino y todos Mis hijos deben seguirme. Porque éste camino conduce a  
Jesús. En Jesús está, la verdadera libertad. En Cristo Jesús, Mi Hijo Amadísimo, está la auténtica  
libertad, para vuestros corazones, para vuestras almas.

Abrid vuestras manos, recibid el rosario que tengo en Mis manos, y llevadlo a vuestro corazón y allí  
vosotros recordaréis cada una de Mis palabras. Sentiréis, cada vez más cercana Mi Presencia. Y  
seréis verdaderos mensajeros de todas Mis palabras hacia el mundo entero.  
Todos los días, os pido la oración, todos los días, el Santo Rosario. Todos los días, ofreced, una  
penitencia, un sacrificio, por la conversión, de todos los pecadores.

<mark style="background-color:#1cebfa" class="has-inline-color">Está brotando un nuevo tiempo, para esta tierra Santa y Bendita. Está brotando, un manantial de  
agua viva, para esta Nación Santa y Bendita.</mark>

<mark style="background-color:#1cebfa" class="has-inline-color">¡Esperad! ¡Confiad! Esperad en el Señor, que en su momento justo os dará la respuesta. Aquí está la  
Madre. Jamás lo dudéis.</mark>

Meditad. Meditad. Meditad Mis Palabras.