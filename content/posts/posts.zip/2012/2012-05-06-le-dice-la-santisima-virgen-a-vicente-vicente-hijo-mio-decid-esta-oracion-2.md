---
title: 'Le dice la Santísima Virgen a Vicente: “Vicente hijo mío; decid esta oración:'
author: admin

date: 2012-05-06T11:00:13+00:00
url: /2012/le-dice-la-santisima-virgen-a-vicente-vicente-hijo-mio-decid-esta-oracion-2/
tags: [Oraciones]

---
Señor dame sabiduría para entender tus caminos, para comprender el camino  
por donde tu amor me lleva, dame Señor la luz para iluminar a las almas que  
aún no te conocen. Amén.

Predícala hijo mío al mundo entero”