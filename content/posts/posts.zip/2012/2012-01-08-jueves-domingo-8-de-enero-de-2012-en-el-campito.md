---
title: Jueves domingo 8 de enero2012en el “Campito”
author: admin

date: 2012-01-08T01:24:09+00:00
url: /2012/jueves-domingo-8-de-enero-de-2012-en-el-campito/
thumbnail: /images/jesus2-e1337735192376.jpg
tags: [Mensajes 2012]

---
**Dice la Santísima Virgen:**  
“Benditos y amados hijos Míos, no debe entrar la tristeza en vuestro corazón. No debe entrar jamás, el desconsuelo, porque aquí está la Madre que viene a socorreros.

Aquí está la Madre que viene a recibir vuestras intenciones. Mi Corazón Inmaculado, está con vosotros, y Mi Manto Celestial os cubre a cada uno en forma especial.

Aquí está Mi Corazón de Madre con vosotros hijitos Míos, con todos los hijos del mundo entero a los cuales llamo siempre a la conversión.

Estoy aquí pequeños hijitos Míos. Os vengo a traer el mensaje del Señor. Todos debéis ver la luz que trae la Madre. La luz es Cristo Jesús, Mi Hijo Amadísimo.

Vosotros debéis vivir en la luz de la verdad, de la justicia, de la caridad. Debéis luchar junto a las pruebas, contra las tentaciones. Debéis perseverar frente a las pruebas y tener el corazón en lo alto.

Aquí está la Madre que os invita a vosotros a vivir en la unidad, que os invita a reflexionar cada día.

Abrid nuevamente vuestras manos y recibid el Rosario que os entrego a vosotros y llevadlo a vuestro corazón. Allí veréis cada una de Mis Palabras, recordaréis cada una de Mis Palabras para los tiempos cercanos.

<figure id="attachment_1370" aria-describedby="caption-attachment-1370" style="width: 300px" class="wp-caption alignright"><img decoding="async" loading="lazy" class="size-medium wp-image-1370" title="jesus mundo" src="https://mariadelasantafe.org.ar/images/jesus2.jpg" alt="jesus mundo" width="300" height="224" /><figcaption id="caption-attachment-1370" class="wp-caption-text">Que el mundo conozca Mi amor. Que el mundo conozca, hoy, Mi verdad y se aparte del camino oscuro y de pecado.</figcaption></figure>

Hijitos confiad en esta Madre. Confiad y no desesperéis. Confiad porque Mi Corazón está junto a vosotros.

<p align="JUSTIFY">
  Meditad. Meditad. Meditad Mis Palabras.”


<p align="JUSTIFY">
  **Dice Jesús:<br /> “**Hermanos Míos, benditos y amados hermanos Míos, Mi Corazón es paz y esta paz os la entrego a vosotros.


Mi Corazón es Palabra, Mi Corazón es luz. Os doy Mi Divina Misericordia y os muestro el camino de la verdad. Todos debéis seguir Mis pasos, debéis seguir Mi camino.

Mi Corazón es luz. Mi Corazón es el bálsamo para sanar vuestras heridas. No dudéis de Mi amor hacia vosotros. ¡Os amo! Porque sois Mis ovejas y estáis en Mi rebaño.

Que el mundo conozca Mi amor. Que el mundo conozca, hoy, Mi verdad y se aparte del camino oscuro y de pecado.

Creed en Mí y abrid siempre el corazón para recibir Mis Palabras, para recibir Mi consuelo, para recibir Mi bálsamo. Trabajad todos juntos, trabajad, os invito a que cada uno se acerqué a Mí, cada día, a cada instante, a cada momento.

¡Os amo a todos por igual! ¡Os amo!

Meditad. Meditad. Meditad Mis Palabras.

Os bendigo, en el Nombre del Padre y del Hijo y del Espíritu Santo. Amén.”