---
title: Vía Crucis María de la Santa Fe
author: admin

date: 2011-06-13T13:43:18+00:00
url: /2011/via-crucis-maria-de-la-santa-fe/
tags: [Via Crucis]

---
**¿Qué te he hecho, para que así me trates?**  
Ten compasión de Mí y abre tu corazón a Mis palabras, te amo: Jesús