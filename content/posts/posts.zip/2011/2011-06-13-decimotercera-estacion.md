---
title: 'Decimotercera Estación: “Jesús muerto es puesto en brazos de su Santísima Madre”'
author: admin

date: 2011-06-13T16:29:35+00:00
url: /2011/decimotercera-estacion/
thumbnail: /images/estacion06.jpg
tags: [Via Crucis]

---
<img decoding="async" loading="lazy" class="alignright size-full wp-image-348" title="estacion13" src="https://mariadelasantafe.org.ar/wp-content/uploads/2011/06/estacion013.jpg" alt="estacion13" width="282" height="368" />**G- Te adoramos, Señor y te bendecimos**  
R- Porque con tu Santa Cruz redimiste al mundo.

¿Qué palabras puedo decirte, Mi Señora y Madre mía, que puedo decirte, sólo decirte perdón por ser la causa de tu dolor, sólo decirte perdón porque por mí causa no hallas consuelo?

**_Hijo mío, hijito mío, piensa sólo en el amor de Jesús, piensa que estoy contigo, es la misión que Jesús me encomendó, es la tarea más hermosa y que más amo, sólo te pido, ya no peques más y así ya no me verás llorar._**

**Rezar un Padre Nuestro, un Ave María  y un Gloria.**

* * *

[<i class="fa fa-arrow-circle-left fa-fw"></i> Estaci&oacute;n Anterior][1]{.btn.btn-primary.pull-left} [Siguiente Estaci&oacute;n <i class="fa fa-arrow-circle-right fa-fw"></i>][2]{.btn.btn-primary.pull-right}

 [1]: /duodecima-estacion
 [2]: /decimocuarta-estacion