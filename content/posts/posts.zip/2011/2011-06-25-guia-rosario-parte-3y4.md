---
title: Parte 3 y 4
author: admin

date: 2011-06-25T22:45:43+00:00
url: /2011/guia-rosario-parte-3y4/
tags:
  - Guia del Rosario

---
### 3º Decimos: En el primer misterio contemplamos&#8230; (Nombrar el misterio que corresponde al día) a continuación rezamos: 

Rezamos:

  * **1 Padre Nuestro**
  * **10 Ave María**
  * **1 Gloria**

### 4º Finalizamos cada misterio diciendo, la siguiente jaculatoria: 

**&#8220;Padre Celestial, fuente de Misericordia y bondad,  guía a tus hijos y  aparta de nosotros todo mal&#8221;.** 

**Amén.**

**Madre mía bendice a mi familia.** 

**Amén.**