---
title: Oración por la Familia
author: admin

date: 2011-02-13T17:33:18+00:00
abstract: |
  <img src="https://mariadelasantafe.org.ar/wp-content/uploads/2016/12/img-sagrada-familia.jpg" alt="img-sagrada-familia" class="alignright size-full wp-image-3894" /><h3>Domingo 13 de febrero, 2011</h3>
  
  <blockquote>Sagrada Familia de Nazareth en este momento de prueba para el mundo, bendice a las familias del mundo entero, bendice a los padres, a los hijos, Sagrada Familia de Nazareth, que las familias sean luz para el mundo, que vivan en el amor, el respeto y la comprensión.
  Sagrada Familia de Nazareth, bendice copiosamente a las familias que pasan por momentos de dolor, incertidumbre y desesperanzas.
  Sagrada Familia de Nazareth, nosotros confiamos en ustedes.
  Amén. Gloria a la Sagrada Familia de Nazareth.</blockquote>
  
  “Predícalo a tus hermanos del mundo entero.”
url: /2011/oracion-por-la-familia/
thumbnail: /images/img-sagrada-familia.jpg
tags: [Mensajes 2011]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-sagrada-familia-1.jpg" alt="img-sagrada-familia" class="alignright size-full wp-image-3894" />

### Domingo 13 de febrero, 2011

> Sagrada Familia de Nazareth en este momento de prueba para el mundo, bendice a las familias del mundo entero, bendice a los padres, a los hijos, Sagrada Familia de Nazareth, que las familias sean luz para el mundo, que vivan en el amor, el respeto y la comprensión.  
> Sagrada Familia de Nazareth, bendice copiosamente a las familias que pasan por momentos de dolor, incertidumbre y desesperanzas.  
> Sagrada Familia de Nazareth, nosotros confiamos en ustedes.  
> Amén. Gloria a la Sagrada Familia de Nazareth.

“Predícalo a tus hermanos del mundo entero.”