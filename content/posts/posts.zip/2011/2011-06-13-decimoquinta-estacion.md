---
title: 'Decimoquinta Estación: “Jesús ha resucitado”'
author: admin

date: 2011-06-13T01:11:56+00:00
url: /2011/decimoquinta-estacion/
thumbnail: /images/estacion-015.png
tags: [Via Crucis]

---
img class=&#8221;alignright size-full wp-image-244&#8243; title=&#8221;estacion-015&#8243; src=&#8221;https://mariadelasantafe.org.ar/wp-content/uploads/2011/06/estacion-015.png&#8221; alt=&#8221;estacion-015&#8243; width=&#8221;284&#8243; height=&#8221;368&#8243; />**<G - Te adoramos, Señor y te bendecimos.**

R &#8211; Porque con tu Santa Cruz redimiste al mundo.

Oh Jesús mío, Resucitado y Glorioso, Salvador Misericordioso que cada día pueda cantar glorias eternas a tu Amor Eterno, a tu Amor Misericordioso, a tu Amor Glorioso.

Jesús resucitado, presente eternamente en cada Sagrario de la tierra, presente y vivo entre nosotros, que mi corazón sea un Sagrario viviente para tenerte siempre conmigo.

**Rezar un Padre Nuestro, un Ave María  y un Gloria.**

* * *

[<i class="fa fa-arrow-circle-left fa-fw"></i> Estaci&oacute;n Anterior][1]{.btn.btn-primary.pull-left} [Siguiente Estaci&oacute;n <i class="fa fa-arrow-circle-right fa-fw"></i>][2]{.btn.btn-primary.pull-right}

 [1]: /decimocuarta-estacion
 [2]: /oracion-final