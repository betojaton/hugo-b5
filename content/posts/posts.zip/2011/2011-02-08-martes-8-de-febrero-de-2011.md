---
title: Martes 8 de Febrero de 2011
author: admin

date: 2011-02-08T14:19:47+00:00
url: /2011/martes-8-de-febrero-de-2011/
tags: [Mensajes 2011]
---
**Dice la Santísima Virgen:** **“**Hijos Míos; benditos y amados hijos Míos. Vengo desde el cielo, trayendo gracias para vosotros. Vengo desde el cielo, a anunciaros el Mensaje del Señor. Quiero hijitos Míos, que escuchéis a ésta Madre; que viene hacia vosotros, para sosteneros en la lucha. Para daros fuerza a cada momento, para seguir el camino.

Hoy os entrego el Rosario de Mis Manos; y os pido, que abráis vuestras manos y recibáis este Rosario que debéis llevar a vuestro corazón. Y allí, en cada momento, de dolor y de dificultad; en cada momento muy triste, con éste Rosario podréis superar las pruebas.

¡Aquí está la Madre! ¡María de la Santa Fe! Que quiere la unidad de sus hijos. Que quiere que todos los corazones vivan en la luz. Que todos Mis hijos lleven la luz de Jesús a las almas que hoy están en la oscuridad.

¡No temáis, hijitos Míos! Y predicad al mundo entero, cada una de Mis Palabras. Vengo a cumplir la misión, que me ha dado el Padre: **Reunir a todo el rebaño. Convocar a todos los hijos. Llamar a todos los corazones; y presentarlos en Cristo Jesús Mi Hijo Amadísimo.**

¡No temáis! ¡Aquí está la Madre! Y ante las pruebas; recordad, todas Mis palabras; Mis enseñanzas; Mis advertencias.

Escuchad a ésta Madre, que os protege a vosotros con Su Manto Celestial. Que os cuida, en forma especial, a cada uno de vosotros.

¡Hijitos Míos! ¡Gracias! Por responder. ¡Hijitos Míos! ¡Gracias por estar aquí! con ésta Madre.

La Madre os bendice. La Madre os concede una gracia especial, a cada uno de vosotros.

Meditad. Meditad. Meditad Mis palabras.”

**Dice Jesús:** ****“Hermanos Míos; ****benditos y amados hermanos Míos. Nuevamente os doy Mi Paz. Nuevamente doy Mi Paz, a vosotros. Quiero que viváis Mi Paz. Quiero que seáis, mensajeros de Mi Paz; y de Mi Divina Misericordia. Os hablo hoy de Mi Amor, de Mi Eterno Amor hacia vosotros. No os sintáis indignos, os he traído hasta Mí, os he buscado, os he llamado por vuestros nombres. Estáis en torno a Mí. Y os hablo hoy de Mi Amor. ¡De Mi Eterno Amor! ¡De Mi Eterna Misericordia!

Quiero que seáis luz para el mundo. Quiero que seáis verdaderas hogueras de amor, para todas las almas. Ya no más rivalidad. Ya no más división, unidad en los corazones, paz en los corazones, verdad en los corazones. Así quiero a vosotros, que son Mis ovejas, y estáis en Mi rebaño.

Os amo. Os amo. Os amo. ¡Nunca lo dudéis! Sois Mis ovejas. Mis pequeñas ovejas a las cuales conduzco. Sois mis ovejas, y os hablo cada día de Mi amor, cada día de Mi paz, cada día de Mi eterna misericordia.

Que el mundo conozca mis Palabras. Que los hombres lleguen, hacia la fuente de Agua Viva que es Mi Sacratísimo Corazón, y admítanme, llegad a Mi, porque estáis agobiados, porque estáis cansados, porque ya, vuestras fuerzas, decaen.

¡No temáis! Estoy con vosotros. ¡No temáis! Os sostengo, os doy fuerzas. Os doy Mi Amor a cada instante.

Os amo. Os amo. Os amo.

Meditad. Meditad. Meditad Mis palabras.

Os bendigo, en el Nombre del Padre, y del Hijo, y del Espíritu Santo. Amén.”

&nbsp;