---
title: Jueves 8 de diciembre, 2011 en el Campito
date: 2011-12-08T22:22:51+00:00
url: /2011/mensajes-jueves-8-diciembre-2011-en-el-campito/
thumbnail: /images/maria-madre-de-dios-1.jpg
tags: [Mensajes 2011]
---
**Dice la Santísima Virgen:**

<figure id="attachment_1377" aria-describedby="caption-attachment-1377" style="width: 334px" class="wp-caption alignright"><img decoding="async" loading="lazy" class="size-full wp-image-1377" title="maria-madre-de-dios" src="https://mariadelasantafe.org.ar/images/maria-madre-de-dios.jpg" alt="maria-madre-de-dios" width="334" height="263" /><figcaption id="caption-attachment-1377" class="wp-caption-text">¡Olvidad el pasado! Y vivid en este presente. Recibid las palabras de esta Madre, en vuestro corazón; y que allí crezca para que dé frutos, para el mundo entero.</figcaption></figure>

Hijitos Míos; nuevamente agradezco vuestra presencia. Nuevamente os doy gracias; porque respondéis a esta Madre.

La Madre está aquí, está con vosotros, en todo momento, en todo lugar. Vengo a daros el consuelo, y a sanar vuestros corazones heridos. Vengo a llenaros con el amor, de Cristo Jesús Mi Hijo Amadísimo.

Quiero que caminéis en la verdad, os conduzco en la verdad, os llevo a la verdad total, que es Cristo Jesús Mi Hijo Amadísimo.

¡Olvidad el pasado! Y vivid en este presente. Recibid las palabras de esta Madre, en vuestro corazón; y que allí crezca para que dé frutos, para el mundo entero. Para que seáis cristianos verdaderos; para que deis ejemplo a todas las almas.

Os vengo a preparar. Os vengo a anunciar, una Nueva Aurora para el mundo entero; para todas las almas.

Quiero que todos los hijos encuentren por medio de esta Madre, a Cristo Jesús Mi Hijo Amadísimo. ¡Mi tarea está en el mundo entero! ¡En todos los rincones de la tierra! Con todas las almas y con todos los corazones. Porque quiero que todos Mis hijos, lleguen a la Vida Eterna. Que toda la humanidad se salve. Que todos los hijos, vean la luz del Señor.

Dios espera, con paciencia, y con misericordia a todas las almas, a todos los hijos; y da, infinitas oportunidades a todos los corazones. Oportunidades de conversión.

Todos Mis hijos, deben escuchar, mis palabras, y vivir este tiempo de gloria, de paz y de misericordia. ¡Rezad mucho! ¡Cread grupos de oración! ¡Multiplicad los Rosarios, por toda la faz de la tierra! Y pedid por la paz del mundo. Por la paz en las almas. Por la paz en los corazones.

¡Rezad mucho, por las familias! Por los enfermos. Por los que están solos y abandonados. ¡Rezad mucho! Os encomiendo esta tarea, ésta misión.

Abrid todos, vuestras manos, y recibid, el Rosario de Mis manos, y llevadlo a vuestro corazón. Allí, veréis, cada una de Mis Palabras. Allí sentiréis, cada una de Mis Palabras. Y así, iréis caminando, cada día, por el sendero de la verdad, de la luz, de la paz, de la misericordia.

¡No temáis; hijitos, no temáis! Y aprovechad, este tiempo, estos días, en que la Madre se manifiesta con todos los hijos en el mundo entero.

¡Venid a ésta Madre! Porque Mi Manto Celestial os cubre. Mi Manto Celestial os protege; contra las asechanzas del maligno. Recurrid a Mi Manto Celestial, en todo momento. Allí, los cobijo a vosotros, a vuestras familias, a vuestros amigos, a vuestros seres queridos.

Aquí estoy, en ésta nación Santa y Bendita. Aquí estoy y me manifiesto una vez más, para todos los corazones, del mundo entero.

Meditad. Meditad. Meditad Mis Palabras.

&nbsp;

**Dice Jesús:  
** Hermanos Míos; benditos y amados hermanos míos. Recibid Mi Preciosísima Sangre, recibid Mi paz, y Mi Divina Misericordia. Recibid Mi amor. Mi amor poderoso que sana. Mi amor poderoso que os fortalece.

Creed en cada una de Mis palabras. ¡Que el mundo no ahogue la fe, de vuestro corazón! Que el mundo no apague la luz de vuestro corazón. Llevad, Mis palabras al mundo. Mis Enseñanzas al mundo. Mi amor al mundo.

Os doy Mi amor a vosotros, entonces, vosotros, debéis dar amor, a vuestros hermanos. Debéis dar el corazón, a vuestros hermanos. ¡Nunca dividir! ¡Nunca separar, sino unir!

Os hablo, verdaderamente de este amor, para que este amor, os haga valerosos, sencillos, y humildes, y así, comprenderéis cada una de Mis Palabras.

¡No os sintáis indignos ante Mi tags:
	- Mensajes Presencia! Os busqué por vuestros nombres. ¡Os llamé por vuestros nombres! Os atraje hacia Mí, con Mi Divina Misericordia.

Sois Mis ovejas, y estáis en Mi Rebaño; y os vuelvo a dar una nueva oportunidad. ¡Venid a Mí! ¡Creed en Mí! Y refugiaos en Mi Sacratísimo Corazón, para pasar por todas las pruebas, para pasar por todas las tribulaciones.

¡No juzguéis a vuestros hermanos! ¡No dudéis de vuestros hermanos! Mirad a cada uno de vuestros hermanos, con infinita misericordia. Para que así, todos marchéis por el buen camino.

¡Os amo! ¡Os amo! ¡Os amo! Y os lo repetiré, eternamente. Porque Mi Amor es eterno, porque Mi Amor, no tiene barreras, ni límites. ¡Mi Amor, no separa! ¡Mi Amor, une y reúne a las almas, en torno a Mí!

Os vuelvo a dar Mi Preciosísima Sangre. Quiero, que seáis fuertes, y seáis testigos de Mi tags:
	- Mensajes Presencia con cada uno de vosotros, en el mundo entero.

¡Sed testigos! ¡Sed luz! ¡Sed faros para el mundo, y para las almas! ¡Llamad, convocad, pedid, reunid, a todas las almas! ¡A todos los corazones!

Os daré las fuerzas, os daré los medios, os daré las pruebas, de Mi tags:
	- Mensajes Presencia, para que así, trabajéis en el mundo, para que así, llevéis, Mis Palabras a todos los hombres, a todas las almas por igual. Sentíos amados, por Mi Sacratísimo Corazón. Sentíos, verdaderamente privilegiados, por mi Sacratísimo Corazón.

Haced caso, a cada uno de Mis pedidos. ¡No bajéis los brazos! Y luchad por la verdad, luchad por la vida, luchad por la justicia. ¡Luchad, luchad, luchad! Y creed, profundamente, porque, no quedaréis solos. No estáis desamparados; no estáis abandonados.

Mi mano poderosa os sostiene. Mi mano poderosa os da las fuerzas. Mi mano os da, nuevamente, otra oportunidad.

¡Tened fe! ¡Confiad en Mí! Y no dudéis de Mis Palabras. ¡No dudéis jamás de Mi tags:
	- Mensajes Presencia, con cada uno de vosotros!

Meditad. Meditad. Meditad Mis palabras.

Os bendigo, en el Nombre del Padre, y del Hijo, y del Espíritu Santo. Amén.