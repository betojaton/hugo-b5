---
title: MISTERIOS DOLOROSOS (Se rezan los martes y viernes)
author: admin

date: 2011-06-24T12:36:27+00:00
url: /2011/misterios-dolorosos-se-rezan-los-martes-y-viernes/
tags:
  - Guia del Rosario

---
#### 1º JESÚS ORA AL PADRE CELESTIAL EN EL HUERTO DE LOS OLIVOS: 

&#8220;Jesús sufre en su Corazón la angustia, la desesperación, pero su confianza y amor al Padre le hace afrontar con valor la cruz, acepta la voluntad del Padre&#8221;.

**Meditación:** Señor, que seamos fieles a Tí y jamás abandonemos el camino de la virtud y de la oración.

#### 2º LA FLAGELACIÓN DE NUESTRO SEÑOR JESUCRISTO: 

&#8220;Jesús es atado a la columna, es azotado con cinco mil azotes, es insultado, son desgarradas sus espaldas y un río de sangre se derrama por su Preciosísimo Cuerpo&#8221;.

**Meditación:** Señor, que no seamos tus verdugos, que no seamos nosotros nuevamente hoy, los que te azotemos con nuestros pecados.

#### 3º LA CORONACION DE ESPINAS DEL SALVADOR NUESTRO SEÑOR JESUCRISTO: 

&#8220;Jesús es coronado y no por reconocerlo así sus verdugos, sino con burlas e insultos, con una corona de 72 espinas que atravesaron su cabeza, su frente y desgarraron el corazón de la Madre&#8221;.

**Meditación:** Señor, cada espina de tu cabeza, es cada pecado que nosotros los hombres, ponemos en Ti.&nbsp; Que seamos corona, no de espinas, sino de flores.

#### 4º JESÚS LLEVA SU CRUZ HACIA EL MONTE CALVARIO: 

&#8220;Nuestro Señor Jesucristo acepta la cruz, el peso es grande, la cruz abre sus hombros, sus huesos saltan a la vista, la cruz es grande.&nbsp; La cruz es el amor de Él a la humanidad y a los pecadores&#8221;.

**Meditación:** Señor, que aliviemos tu cruz llevando nuestra cruz de cada día y aceptándola con amor por los demás.

#### 5º LA MUERTE DE CRISTO EN LA CRUZ: 

“Jesús es crucificado y allí muere, la Virgen María al pie de la cruz contempla desconsolada ese triste espectáculo, en soledad llora Ella resignándose a la voluntad de Dios&#8221;.

**Meditación:** Señor, que seamos capaces de resignarnos a tu voluntad en el dolor, en la desesperación, en la angustia, como lo hizo la Santísima Virgen María.