---
title: 'Segunda Estación: “Jesús cargado con la cruz”'
author: admin

date: 2011-06-13T16:40:53+00:00
url: /2011/segunda-estacion/
thumbnail: /images/estacion02-1.jpg
tags: [Via Crucis]

---
<div class="wp-block-image">
  <figure class="alignright"><img decoding="async" src="https://mariadelasantafe.org.ar/images/estacion02.jpg" alt="estacion02" class="wp-image-339" title="estacion02" /></figure>
</div>

**G- Te adoramos, Señor y te bendecimos**  
R- Porque con tu Santa Cruz redimiste al mundo.

Jesús, llevas sobre tu hombro la cruz, la cruz que cargas por amor, por ese eterno Amor que sientes por nosotros, esa cruz que yo fabriqué con cada uno de mis pecados.

**Rezar un Padre Nuestro, un Ave María&nbsp; y un Gloria.**

<hr class="wp-block-separator has-alpha-channel-opacity" />

<div class="wp-block-buttons is-content-justification-center is-layout-flex wp-container-15 wp-block-buttons-is-layout-flex">
  <div class="wp-block-button">
    <a class="wp-block-button__link has-vivid-cyan-blue-background-color has-background wp-element-button" href="/primera-estacion/"><- Estación Anterior</a>
  </div>
  
  <div class="wp-block-button">
    <a class="wp-block-button__link has-vivid-cyan-blue-background-color has-background wp-element-button" href="/tercera-estacion">Estación Siguiente -></a>
  </div>
</div>