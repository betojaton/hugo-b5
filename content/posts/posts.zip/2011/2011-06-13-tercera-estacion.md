---
title: 'Tercera Estación: “Jesús cae por primera vez”'
author: admin

date: 2011-06-13T16:39:44+00:00
url: /2011/tercera-estacion/
thumbnail: /images/estacion03-1.jpg
tags: [Via Crucis]

---
<div class="wp-block-image">
  <figure class="alignright"><a href="https://mariadelasantafe.org.ar/images/estacion03.jpg"><img decoding="async" src="https://mariadelasantafe.org.ar/images/estacion03.jpg" alt="estacion03" class="wp-image-336" title="estacion03" /></a></figure>
</div>

**G- Te adoramos, Señor y te bendecimos**  
R- Porque con tu Santa Cruz redimiste al mundo.

Jesús estoy golpeando tus espaldas, estoy burlándome de tu amor, estoy con los soldados descargando furia cruel sobre Ti, con cada pecado, con cada mala acción, con cada mal pensamiento, con cada crítica hacia mi prójimo, con cada infidelidad.

Perdón, Señor Jesús, perdón, ten compasión de mí.

**Rezar un Padre Nuestro, un Ave María&nbsp; y un Gloria.**

<hr class="wp-block-separator has-alpha-channel-opacity" />

<div class="wp-block-buttons is-content-justification-center is-layout-flex wp-container-14 wp-block-buttons-is-layout-flex">
  <div class="wp-block-button">
    <a class="wp-block-button__link has-vivid-cyan-blue-background-color has-background wp-element-button" href="/segunda-estacion"><- Estación Anterior</a>
  </div>
  
  <div class="wp-block-button">
    <a class="wp-block-button__link has-vivid-cyan-blue-background-color has-background wp-element-button" href="/cuarta-estacion">Estación Siguiente -></a>
  </div>
</div>