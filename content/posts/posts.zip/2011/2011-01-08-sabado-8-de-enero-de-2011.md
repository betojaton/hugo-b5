---
title: Sábado 8 de Enero, 2011
author: admin

date: 2011-01-08T14:18:25+00:00
url: /2011/sabado-8-de-enero-de-2011/
thumbnail: /images/jesus_ovejas-1.png
tags: [Mensajes 2011]
---
**Le dice la Santísima Virgen:** “Hijos Míos, benditos y amados hijos Míos, gracias nuevamente por responder al llamado de esta Madre, por escuchar a esta Madre, por estar atentos a Mis pedidos, gracias por estar aquí junto a la Madre. La Madre está con vosotros para mostraros el camino, para enseñaros el camino, para haceros ver a cada uno de vosotros la luz de Jesús. Son los tiempos de la Madre con todos los hijos, y vosotros debéis estar siempre atentos, debéis rezar todos los días para que la paz llegue al mundo, para que la paz llegue a los corazones, para que la paz reine en todas las familias.

Vengo como Madre a unir los corazones, a unir a las almas, a reunir el rebaño de Jesús, vengo como Madre a convocar a los hijos al trabajo, a todos Mis hijos. Pido la unidad en las almas, pido la unidad de los corazones, pido la unidad en todos los grupos, debéis ser luz y faro para el mundo, debéis ser testigos del Amor  Misericordioso de Jesús para con el mundo entero.

Comportaos verdaderamente como buenos cristianos y llevad la luz que Jesús os trae, llevad la luz a las almas que están desesperadas, a los corazones que están angustiados.

Trabajad pequeños hijitos Míos por la unidad, sed verdaderos faros de luz, sed verdaderas hogueras que iluminen al mundo entero. Es el tiempo de dar testimonio, es el tiempo de la verdad, no debéis quedaros callados, debéis dar la verdad al mundo, hacer conocer la verdad al mundo, que Mis hijos hoy se encuentren con Jesús a través de esta Madre, que Mis hijos se  encuentresn hoy con Jesús a través de Mi Inmaculado Corazón. Que todos los hijos respondan  a Mi Llamado urgentes a la conversión. Vosotros debéis seguir el camino, no me avandonéis, no avasndonéis Mi camino. Aqui esta la Madre que extiende sus brazos a vosotrospara sosteneros en la luchas del mundo.

**Meditad. Meditad. Meditad Mis palabras.”**

**<img decoding="async" loading="lazy" class="size-full wp-image-976 alignright" title="jesus_ovejas" src="https://mariadelasantafe.org.ar/images/jesus_ovejas.png" alt="jesus_ovejas" width="333" height="400" />**

**Dice Jesús a Vicente: “**Hermanos Míos, benditos y amados hermanos Míos hoy nuevamente os ofrezco Mi paz, y quiero que vosotros trabajéis por la paz, os ofrezco Mi paz para sanar vuestros corazones, para sanar vuestras heridas, os ofrezco Mi paz para que todos os acerquéis a Mi y recibáis gratuitamente Mi Divina Misericordia.

Os hablo de Mi amor, os hablo de Mi verdad, os hablo para que seáis libres, para que dejéis el pasado, para que atéis el pasado en el pasado y viváis en este presente que Mi Amor Misericordioso a todos os ofrece. Doy a cada instante a todas las almas, a todos Mis hermanos infinitas oportunidades. Doy a todos los corazones todos los medios posibles para que todos conozcan y lleguen a la vida eterna.

Buscad vosotros a los hermanos que están dispersos, a las ovejas que están dispersas, buscad vosotros pequeños hermanos Míos a los corazones enfermos, a las almas atrapadas en la oscuridad. Buscad, buscad, buscad y entregad vuestras vidas por la salvación de las almas.

Trabajad días a día, no os canséis del trabajo, trabajad día a día porque recibiréis vuestra recompensa.

Os hablo de paz, de unidad, quiero la unidad en las almas, quiero la sinceridad en las almas, quiero la obediencia en las almas. Estáis aquí junto a Mí, estáis dentro de Mi Sacratísimo Corazón, y Mi corazón os bendice, Mi corazón os sana, Mi corazón os libera, Mi corazón os da las fuerzas para seguir avanzando por el camino de Mi amor. Si encontráis espinas, si encontráis barreras, si encontráis  piedras en el camino acordaos de cada una de Mis palabras, acordaos todos de Mis palabras y entoncesasí podréis seguir la marcha.

Os amo. Os amo. Os amo a todos por igual. Sois Mis ovejas, sois Mi rebaño, creedlo así.

**Meditad. Meditad. Meditad Mis palabras.** 

**Os bendigo en el nombre del Padre y del Hijo y del Espíritu Santo. Amén.”**

&nbsp;