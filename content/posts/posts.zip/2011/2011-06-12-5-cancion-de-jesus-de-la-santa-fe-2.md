---
title: '5- Canción de Jesús de la Santa Fe'
author: admin

date: 2011-06-12T21:12:43+00:00
url: /2011/5-cancion-de-jesus-de-la-santa-fe-2/
tags: [Canciones]
---
Jesús, estás junto a mi,  
Jesús, junto a las aguas,  
veo tu presencia,  
tómame de las manos  
para seguir caminando,  
sobre la arena, sobre las piedras,  
sobre la tierra firme.

Jesús estás allí y a veces no te veo,  
a veces mis ojos están  
cerrados y no te veo, porque miro el mundo  
y no me fijo en tu corazón.

Allí, en la arena junto a las aguas de la Setúbal,  
allí, estás, allí, presente,  
me esperas, para recorrer el mundo,  
para navegar todas las aguas del mundo y llevar tu mensaje,  
llevar tus palabras a mis hermanos.

Las aguas mansas de tu corazón llegan hasta mí,  
llegan y calman la sed ardiente de mi corazón.