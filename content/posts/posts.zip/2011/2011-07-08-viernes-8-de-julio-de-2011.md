---
title: Viernes 8 de julio, 2011
date: 2011-07-08T23:38:03+00:00
url: /2011/viernes-8-julio-2011/
tags: [Mensaje, Mensajes Presencia]
---
Dice la Santísima Virgen:

**Hijos Míos;** benditos y amados hijos míos. En este día especial, os concedo una gracia, a cada uno de vosotros. Una gracia especial; porque aquí se manifiesta María de la Santa Fe. Porque aquí está la Madre escuchándoos y atendiéndoos.

Veo, hijitos Míos, vuestros corazones, doloridos, angustiados, preocupados. Confiad en esta Madre, que os agradece a cada uno de vosotros, vuestra presencia.

Os bendigo a vosotros, en forma especial y bendigo a esos hijos, que no han podido llegar. Mi corazón de Madre, se vuelca hacia todos los hijos del mundo, llamando a cada corazón a la unidad. Llamando a todos los hombres a vivir en la paz y en la verdad.

Mi corazón de Madre, atrae a los hijos y los conduce a Jesús. Vosotros, debéis seguir a esta Madre a llegar a Jesús, para encontraros con Jesús.

En Jesús está la luz. En Jesús está la Paz. Vosotros debéis confiar, profundamente y dejar que el corazón de esta Madre os conduzca día a día, minuto a minuto.

¡Hijitos Míos! Tomaos de Mi Mano. ¡Hijitos Míos! Escuchad, cada una de Mis Palabras y confiad plenamente en la respuesta del Señor a su debido tiempo. ¡Estos son Mis días! Con cada uno de vosotros. Aquí me manifiesto, con los hijos; aquí transmito mis palabras de Madre, para todos los hijos del mundo.

Quiero la unidad, la paz, la verdad. Quiero en los hijos unidad. Quiero que todos llevéis al mundo Mis Mensajes, Mis Enseñanzas, Mis Advertencias.

Buscad siempre las palabras de esta Madre; y acercaos por medio de Mi Inmaculado Corazón, hacia el Corazón Sacratísimo de Cristo Jesús, Mi Hijo Amadísimo.

Id Hijitos Míos, a la Santa Misa, confesad vuestros pecados con el sacerdote. Id hijitos Míos, a recibir el Cuerpo y la Sangre de Cristo Jesús Mi Hijo Amadísimo, que a todos os espera, que a todos os convoca.

Hijitos Míos, rezad en familia, en comunidad. ¡.¡Rezad el Santo Rosario! ¡Siempre! Por la paz, para que reine la paz para que reine la verdad, en los corazones. Para que reine la verdad, en todas las naciones.

Rezad mucho, en estos tiempos difíciles, para que ya, no se dicten más leyes contra la vida.

¡Rezad! ¡Rezad! Y así ayudaréis a esta Madre, en éste camino, en esta tierra Santa y Bendita. Sed Mis Mensajeros. Hoy os lo pido, hoy, a cada uno de vosotros. Os lo pido, en forma especial.

Meditad. Meditad. Meditad Mis Palabras.

&nbsp;

Dice Jesús:

**Hermanos Míos;** benditos y amados hermanos Míos. Venid a Mí si estáis agobiados. Venid a Mí si ya no podéis avanzar, si ya vuestras fuerzas decaen.

¡Venid a Mí! Porque os consolaré y os daré fuerzas para seguir el camino. ¡Confiad! Confiad plenamente en mis palabras; y sentid la tags:
	- Mensajes Presencia Real entre vosotros. Sentid que Mis Manos os tocan, os sanan, os liberan, os purifican.

Sentid Mi tags:
	- Mensajes Presencia en este momento con vosotros, concediéndoos gracias tras gracias; bendición tras bendición que provienen de este Mi Sacratísimo Corazón hacia todos vosotros. Recurrid a Mí en todo momento. Recurrid a Mí, y sentid, que Mis manos os movilizan, que Mis manos os mueven verdaderamente a llegar y a encontraros conmigo.

No dudéis de Mi tags:
	- Mensajes Presencia y de Mi Amor hacia cada uno de vosotros. ¡No dudéis!  Porque todos estáis en Mi rebaño. Porque todos sois Mis ovejas. Porque os amo en forma especial, a vosotros, predilectos de Mi Sacratísimo Corazón. Predilectos verdaderamente, de Mi Amor.

¡Convocad a las almas! A los corazones. Convocad a todos al trabajo. Convocad, verdaderamente, con amor, con verdad, con sencillez y humildad, y creed definitivamente en Mi tags:
	- Mensajes Presencia con cada uno de vosotros.

Hoy os sano, os libero, os purifico. Os hago hombres nuevos, os hago almas dispuestas al trabajo. Corazones dispuestos, al trabajo. Avanzad conmigo en esta barca. Avanzad conmigo en las praderas de Mi Sacratísimo Corazón. Donde está la paz, la verdad, la eterna luz.

Que el mundo no os seduzca. Que las luces falsas y pasajeras, no os seduzcan; y no os quiten de Mi lado. ¡Quedaos junto a Mí! Quedaos verdaderamente dentro de Mi Sacratísimo Corazón.

Trabajad cada día, para ser un poco mejores. Trabajad para que los hermanos, apartados de la luz y de la verdad, vuelvan a Mi rebaño. ¡Os amo a todos! Os envío a misionar. ¡Os amo a todos! Verdaderamente. ¡Os amo!

Meditad. Meditad. Meditad Mis Palabras.

Os bendigo, en el Nombre del Padre, y del Hijo, y del Espíritu Santo. Amén.