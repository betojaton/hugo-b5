---
title: Jueves 8 de septiembre de 2011
author: admin

date: 2011-09-08T01:22:29+00:00
url: /2011/jueves-8-de-septiembre-de-2011/
thumbnail: /images/sagradocorazon-89-1.gif
tags: [Mensajes 2011]
---
<img decoding="async" loading="lazy" src="https://mariadelasantafe.org.ar/images/sagradocorazon-89.gif" alt="" title="sagradocorazon-89" width="287" height="340" class="alignleft size-full wp-image-1063" />**Dice la Santísima Virgen:** Hijos Míos; benditos y amados hijos Míos. Nuevamente gracias a cada uno de vosotros, por vuestra presencia. Nuevamente me manifiesto con vosotros.

Hijitos Míos, que os llevo a todos dentro de Mi Inmaculado Corazón. Como Madre os defiendo, os protejo, os cuido de los planes del adversario. Os libro de tantos peligros que tenéis en el mundo. Vengo con el rosario en Mis Manos; para darlo a cada uno de ustedes. Para que todos comprendáis el significado de la oración. Para que no perdáis el tiempo en vanidades del mundo; sino que dediquéis más horas al Señor. Que entreguéis el corazón al Señor, que os está esperando. Que necesita de vuestra respuesta, de vuestro SI generoso.

El mundo os seduce. El mundo quiere arrastraros hacia el abismo. Y vosotros debéis estar alertas; con los ojos bien abiertos; y con el corazón abierto de par en par, al mensaje del Señor; a Su tags:
	- Mensajes Presencia; a Su invitación a la conversión diaria.  
Aquí está la Madre; siempre con vosotros en todo lugar. Y os entrego el perfume de Mis Rosas, que es una Gracia; una Gracia especial, para cada uno de vosotros; para vuestras familias; para vuestros seres queridos, para todos.

La Madre viene desde el Cielo, a traer el Mensaje del Señor para el mundo entero. Para que todas las almas se conviertan. Para que todos los corazones vean hoy la luz de Cristo Jesús Mi Hijo Amadísimo.

¡Ayudadme vosotros, hijitos Míos! A buscar a las almas, a buscar a los corazones que están en la oscuridad; que están oprimidos, angustiados, doloridos.  
Tenéis una misión. Una tarea importante, que os encomiendo en este día tan especial. Venid pues hacia ésta Madre, porque esta Madre va hacia vosotros, a vuestro encuentro. Y cuando caéis, cuando dobláis la rodilla, ésta Madre viene a ayudaros, a daros fuerza para seguir nuevamente el camino.

Hijitos, hijitos Míos amadísimos Escuchad atentamente Mis Palabras. Que el mundo las conozca. Y que todos los corazones lleguen a una definitiva conversión. Rezad mucho, mucho por la Santa Iglesia. Rezad mucho, mucho por vuestros gobernantes. Rezad para que todos los corazones, se dejen conducir, por la luz y la presencia del Espíritu Santo.  
Meditad. Meditad. Meditad Mis Palabras.

**Dice Jesús:** Hermanos Míos; benditos y amados hermanos Míos. No os sintáis indignos. Vengo hacia vosotros, para daros la paz de Mi Sacratísimo Corazón. Para daros Mi Divina Misericordia. Para daros todo Mi Amor.  
Deseo que vuestros corazones, sean hogueras ardientes. Hogueras de amor para vuestros hermanos. ¡Ya no más división y odios, entre los hombres! Quiero la unidad en las almas, y la paz de los corazones.

Vengo a daros la paz, a cada uno de vosotros. A serenar vuestro espíritu. A liberaros, en este momento de las ataduras del mundo.  
Creed en Mis Palabras, en Mi tags:
	- Mensajes Presencia. Sentid, en este momento, que Mis Manos Poderosas de Amor, os dan la paz, os dan el consuelo, os dan la total serenidad.

Venid a Mí. Sois Mis ovejas. Venid a Mí y recibid Mis Palabras y así vosotros, con estas Mis Palabras iréis al mundo a llevar, éste Mi Mensaje, para todos los corazones, para todos Mis hermanos.  
Son tiempos de prueba. Tiempos dolorosos. Tiempos de angustia. Debéis confiar en Mí. Estoy en la barca, y no os dejaré huérfanos. No quedaréis solos. 

Estoy con vosotros. Aquí y en vuestros corazones.

Creed en Mis Palabras. Y dejad que os conduzca día a día con Mi Amor. Con Mi Paz. Con Mi Verdad. Vivid en la verdad. Porque la verdad, os hace, eternamente libres.

Llegad a Mí. Recibid Mi Cuerpo y Mi Sangre en la Eucaristía. Llegad a Mí. Llegad. Llegad, y no dudéis de mis Palabras. Llegad a Mí. Y sentid, que os abrazo con la luz de Mi Sacratísimo Corazón. Sentid vosotros.

Estoy aquí. Me manifiesto entre vosotros. Trayéndoos Mi Amor; trayéndoos Mi Paz. Trayéndos Mi Verdad .Os amo. Os amo. Os amo. Sois Mis ovejas. Os amo profundamente. Os amo a todos por igual.

Meditad. Meditad. Meditad Mis Palabras.

Os bendigo en el Nombre del Padre, y del Hijo, y del Espíritu Santo. Amén.