---
title: Jueves 13 de octubre, 2011
author: admin

date: 2011-10-13T15:04:18+00:00
url: /2011/jueves-13-de-octubre-2011/
tags: [Mensajes 2011]

---
**Le dice la Santísima Virgen a Vicente:**

> “Vicente hijo mío: Decid esta oración:  
> Sagrada Familia de Nazareth en este momento de prueba para el mundo, bendice a las familias del mundo entero, bendice a los padres, a los hijos, Sagrada Familia de Nazareth, que las familias sean luz para el mundo, que vivan en el amor, el respeto y la comprensión.  
> SagradaFamilia de Nazareth, bendice copiosamente a las familias que pasan por momentos de dolor, incertidumbre y desesperanzas.  
> Sagrada Familia de Nazareth, nosotros confiamos en  
> ustedes. Amén.  
> Gloria a la Sagrada Familia de Nazareth.