---
title: Mensajes de Jesús y María a Vicente
author: admin

date: 2011-11-02T21:37:07+00:00
url: /2011/mensajes-de-jesus-y-maria-a-vicente/
tags: [Oraciones]

---
#### 09-10-11

Más tarde en casa estas palabras de Jesús,  
se me presenta el niño Jesús en su cuna y  
el mismo Jesús me dice“Quiero conquistar  
el mundo, al mundo entero”.

#### 01-11-11

Siento la voz de María que me dice  
No deben secarse las rosas que he puesto  
en esta tierra bendita.

&nbsp;

#### 01-11-11

**La Madre me dice:**  
Quiero que los hijos se reúnan en Mi lugar  
Santo y Bendito, implorando la Misericordia  
del Señor.