---
title: 'Cuarta Estación: “Jesús encuentra a su Santísima Madre”'
author: admin

date: 2011-06-13T16:38:42+00:00
url: /2011/cuarta-estacion/
thumbnail: /images/estacion04-1.jpg
tags: [Via Crucis]

---
<div class="wp-block-image">
  <figure class="alignright"><img decoding="async" src="https://mariadelasantafe.org.ar/images/estacion04.jpg" alt="estacion04" class="wp-image-341" title="estacion04" /></figure>
</div>

**G- Te adoramos, Señor y te bendecimos**  
R- Porque con tu Santa Cruz redimiste al mundo.

Oh Señora y Madre mía, que escena coloco a tus pies, que dolor más grande pongo en tu Corazón, cuantas lágrimas derramas por mi, soy la causa, el motivo de tu profundísimo dolor.

Madre mía, socórreme porque sin Ti nada puedo.

 **Rezar un Padre Nuestro, un Ave María&nbsp; y un Gloria.**

<hr class="wp-block-separator has-alpha-channel-opacity" />

<div class="wp-block-buttons is-content-justification-center is-layout-flex wp-container-13 wp-block-buttons-is-layout-flex">
  <div class="wp-block-button">
    <a class="wp-block-button__link has-vivid-cyan-blue-background-color has-background wp-element-button" href="/tercera-estacion"><- Estación Anterior</a>
  </div>
  
  <div class="wp-block-button">
    <a class="wp-block-button__link has-vivid-cyan-blue-background-color has-background wp-element-button" href="/quinta-estacion">Estación Siguiente -></a>
  </div>
</div>