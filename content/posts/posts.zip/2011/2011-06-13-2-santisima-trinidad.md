---
title: '2- Santísima Trinidad'
author: admin

date: 2011-06-13T12:53:14+00:00
url: /2011/2-santisima-trinidad/
tags: [Canciones]
---
<p class="estribillo">
  Gloria al Padre Cielo y Tierra<br /> Gloria al Hijo Celestial<br /> Gloria al Espíritu Santo<br /> Santísima Trinidad.


Que se doblen las rodillas en la tierra  
y en el Cielo tan solo al oír Tu Nombre  
Santísima Trinidad  
Que canten loas los hombres y cielo y  
tierra proclamen a Ti Gloria Santa Madre  
y a tu Hijo terrenal.

Que se rompan las tinieblas cuando  
tu luz se derrame que hasta los ciegos  
te llamen cuando te puedan mirar y que  
te puedan cantar los débiles de razón dale  
fuerza al corazón para que puedan amar.

Da posada al peregrino y al débil dale la  
fe que beba quien tenga sed que entiendan  
los que no alcanzan a comprender tus bonanzas  
Santísima Trinidad y has que duerman  
en paz los que en el Cielo descansan.

&nbsp;