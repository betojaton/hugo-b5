---
title: Viernes 8 de Mayo de 2011
author: admin

date: 2011-05-08T22:13:32+00:00
url: /2011/viernes-8-de-mayo-de-2011/
tags: [Mensajes 2011]
---
**Dice la Santísima Virgen:** “Hijos míos, benditos y amados hijos míos. Hoy nuevamente os digo: gracias, por responder a cada uno de Mis llamados.

<p dir="ltr">
  Os digo ¡Gracias! Y os doy Mi bendición de Madre para daros fuerza, para que sigáis el camino, para que Mis palabras os ayuden a pasar las pruebas.


<p dir="ltr">
  Os doy, Mi Corazón de Madre, porque quiero que vosotros que sois Mis hijos, estéis siempre en Mi tags:
	- Mensajes Presencia. Os invito a cada uno de vosotros a llevar la luz de Jesús a todas las almas que están en la oscuridad. Os invito a ser mensajeros en el mundo entero, del mensaje de Dios Nuestro Señor; que pide a sus hijos conversión. Que pide a sus hijos, un cambio de vida. Que pide a toda la humanidad que vuelva a su ley.


Vosotros estáis con la Madre. Estáis aquí presentes y la Madre os lo agradece. Os doy nuevamente Mi bendición y os entrego Mis Rosas para vosotros, que son una Gracia especial, que os concedo hoy y en éste momento. Tomad ésta Rosa. Tomad todas las Rosas que la Madre os entrega. Y así veréis, el cambio también de vuestro corazón. No dejéis jamás la oración. No abandonéis el camino. Manteneos firmes en la fe y afrontad las tormentas del mundo con valor, con perseverancia.

<p dir="ltr">
  Acordaos siempre de Mis palabras, en todo momento y aún también en los más difíciles. Acordaos de éstas, Mis palabras.


<p dir="ltr">
  Hijitos, os ilumino. Hijitos, os conduzco. Y quiero que vosotros conduzcáis a todas las almas del mundo. Llevad siempre, el Mensaje de Dios a todos los corazones. Dad siempre testimonio ante el mundo, con un corazón humilde, con un corazón sencillo, con un corazón obediente.


<p dir="ltr">
  Dios os está mirando. Dios está con vosotros. Aquí está el Señor!


<p dir="ltr">
  Meditad. Meditad. Meditad Mis Palabras.”


<p dir="ltr">
  **Dice Jesús: **“Hermanos míos, benditos y amados hermanos míos. La luz de Mi Sacratísimo Corazón, llega a vosotros.


<p dir="ltr">
  Vengo hacia vosotros, os busco. Quiero llegar hacia vosotros. Quiero que hagáis primar, en vuestro corazón a Mi Amor eterno, a Mi Amor que no tiene precio.


<p dir="ltr">
  A éste Amor, que os ofrezco a vosotros para transformaros y modelaros. Para daros nuevas oportunidades, para daros a vosotros Mi Amor. Este Amor que no tiene fin. Este Amor eterno, que llega a vosotros para conduciros, que llega a vosotros, para invitaros cada día, a seguir avanzando, en el bien y en la verdad.


<p dir="ltr">
  Venid a Mí! No dudéis jamás de Mi Amor. No dudéis nunca de Mi Misericordia hacia vosotros. Os amo profundísimamente. Os amo a todos por igual y no separo a ninguna de las ovejas; porque todas estáis en Mi redil. Estáis en Mi rebaño y Soy el Buen Pastor que os viene a conduciros.


<p dir="ltr">
  Trabajad día a día. Trabajad, para que vuestro corazón sea luz. Para que vuestro corazón, sea misericordia. Para que vuestro corazón, sea verdad.


<p dir="ltr">
  Os amo infinitamente. Os amo a todos por igual y tengo predilección por éste pueblo Santo y Bendito; por ésta Nación Santa y Bendita. Por esta Nación, que debe resurgir a la luz,  y apartarse de los falsos ídolos, que corroen, que corroen el corazón y envilecen a las almas.


<p dir="ltr">
  Todos: venid a Mí. Todos: llegad a Mí. Porque no separo, a ninguno de Mi lado.


<p dir="ltr">
  Meditad. Meditad. Meditad Mis Palabras.


<p dir="ltr">
  Os bendigo, en el Nombre del  Padre y del Hijo y del Espíritu Santo. Amén.”


&nbsp;