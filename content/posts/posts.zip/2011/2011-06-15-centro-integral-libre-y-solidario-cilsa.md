---
title: Centro Integral Libre y Solidario – CILSA
author: admin

date: 2011-06-15T21:33:18+00:00
url: /2011/centro-integral-libre-y-solidario-cilsa/
tags: [Colaboraciones]

---
##### 14/04/2010

<!-- default-view.php -->

<div
	class="ngg-galleryoverview default-view "
	id="ngg-gallery-d3b55693aaf098d72c1632527eed710a-1">
  <!-- Thumbnails -->
  
  <div id="ngg-image-0" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cilsa/mariadelasantefecilsa.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cilsa/mariadelasantefecilsa.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cilsa/thumbs/thumbs_mariadelasantefecilsa.jpg"
               data-image-id="34"
               data-title="mariadelasantefecilsa"
               data-description=""
               data-image-slug="mariadelasantefecilsa"
               class="ngg-simplelightbox" rel="d3b55693aaf098d72c1632527eed710a"> <img
                    title="mariadelasantefecilsa"
                    alt="mariadelasantefecilsa"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cilsa/thumbs/thumbs_mariadelasantefecilsa.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <br style="clear: both" /> <!-- Pagination -->
  
  <div class='ngg-clear'>
  </div>
</div>