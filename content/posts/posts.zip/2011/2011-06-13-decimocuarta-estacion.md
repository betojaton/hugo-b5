---
title: 'Decimocuarta Estación: “Jesús es puesto en el sepulcro”'
author: admin

date: 2011-06-13T16:27:14+00:00
url: /2011/decimocuarta-estacion/
thumbnail: /images/estacion06.jpg
tags: [Via Crucis]

---
<img decoding="async" loading="lazy" class="alignright size-full wp-image-348" title="estacion14" src="https://mariadelasantafe.org.ar/wp-content/uploads/2011/06/estacion014.jpg" alt="estacion14" width="282" height="368" />**G- Te adoramos, Señor y te bendecimos**  
R- Porque con tu Santa Cruz redimiste al mundo.

Oh Jesús, bendito sepulcro que tu Cuerpo recibió, que tu Cuerpo cobijó ¿y yo no puedo dar cabida en mi corazón a tu Cuerpo y por qué?, porque está cubierto y lleno de placeres, de vanidades, de riquezas falsas, de dioses falsos, de difamaciones.

Oh bendito y amado Jesús, ven a morar en mí, ven a habitar en mí, que reciba con amor tu Cuerpo y tu Sangre en cada Eucaristía y que no pierda jamás esta gracia.

**Rezar un Padre Nuestro, un Ave María  y un Gloria.**

* * *

[<i class="fa fa-arrow-circle-left fa-fw"></i> Estaci&oacute;n Anterior][1]{.btn.btn-primary.pull-left} [Siguiente Estaci&oacute;n <i class="fa fa-arrow-circle-right fa-fw"></i>][2]{.btn.btn-primary.pull-right}

 [1]: /decimotercera-estacion
 [2]: /decimoquinta-estacion