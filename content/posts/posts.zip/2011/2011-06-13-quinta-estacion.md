---
title: 'Quinta Estación: “Jesús ayudado por el Cirineo”'
author: admin

date: 2011-06-13T16:37:30+00:00
url: /2011/quinta-estacion/
thumbnail: /images/estacion05-1.jpg
tags: [Via Crucis]

---
<div class="wp-block-image">
  <figure class="alignright"><img decoding="async" src="https://mariadelasantafe.org.ar/images/estacion05.jpg" alt="estacion05" class="wp-image-344" title="estacion05" /></figure>
</div>

**G- Te adoramos, Señor y te bendecimos**  
R- Porque con tu Santa Cruz redimiste al mundo.

Jesús tendré el valor de alguna vez llevar tu cruz, tendré el valor de defender tu causa, tendré el valor de jugarme verdaderamente por una causa justa, tendré el valor de dar mi auténtico testimonio de cristiano, ¡tendré el valor de dar mi vida por Ti!

**Rezar un Padre Nuestro, un Ave María&nbsp; y un Gloria.**

<hr class="wp-block-separator has-alpha-channel-opacity" />

[<i class="fa fa-arrow-circle-left fa-fw"></i> Estación Anterior][1]{.btn.btn-primary.pull-left} [Siguiente Estación <i class="fa fa-arrow-circle-right fa-fw"></i>][2]{.btn.btn-primary.pull-right}

 [1]: /cuarta-estacion
 [2]: /sexta-estacion