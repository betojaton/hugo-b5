---
title: 'Le dice la Santísima Virgen a Vicente: “Vicente hijo mío: decid esta oración:'
author: admin

date: 2011-02-13T00:27:23+00:00
url: /2011/le-dice-la-santisima-virgen-a-vicente-vicente-hijo-mio-decid-esta-oracion/
thumbnail: /images/sagradafamilia-3.png
tags: [Oraciones]

---
<div class="wp-block-image">
  <figure class="alignright"><img decoding="async" src="https://mariadelasantafe.org.ar/images/sagradafamilia-2-275x300.png" alt="" class="wp-image-909" title="sagradafamilia" /></figure>
</div>

Sagrada Familia de Nazareth en este momento de prueba para el mundo, bendice a las familias del mundo entero, bendice a los padres, a los hijos, Sagrada Familia de Nazareth, que las familias sean luz para el mundo, que vivan en el amor, el respeto y la comprensión.

Sagrada Familia de Nazareth, bendice copiosamente a las familias que pasan por momentos de dolor, incertidumbre y desesperanzas.

Sagrada Familia de Nazareth, nosotros confiamos en ustedes.

**Amén. Gloria a la Sagrada Familia de Nazareth.**

**Predícalo a tus hermanos del mundo entero.”**