---
title: Sábado 8 de octubre de 2011
author: admin

date: 2011-10-08T22:43:16+00:00
url: /2011/sabado-8-de-octubre-de-2011/
tags: [Mensajes 2011]
---
**Dice la Santísima. Virgen:  
** Hijos Míos: benditos y amados hijos Míos. Hoy nuevamente os digo gracias. Y hago descender, una lluvia de rosas, sobre cada uno de vosotros.

Vengo a escucharos. Vengo hijitos Míos a acompañaros. Vengo a consolar vuestros corazones. Mi corazón de Madre está con vosotros y os acompaño, a todos y en forma especial.

Sentid la presencia de María entre vosotros. Sentid, el perfume de Mis Rosas, que es una Gracia, que os concedo a vosotros.

Venid a los brazos, de esta Madre en estos tiempos tan difíciles para el mundo. Rezad mucho vosotros y enseñad a todas las almas, a rezar.

Rezad el Santo Rosario para que llegue la paz al mundo. La paz a todas las naciones. La paz a todos los corazones.

María se manifiesta, con todos los hijos del mundo. Invito a la conversión, a la unidad, a la paz. Invito a los corazones a volver hacia el Señor; a que todos Mis hijos vuelvan a la Ley del Señor.

Apartad del corazón las tinieblas del pecado; las tinieblas de las dudas y de todo rencor. Sembrad en el corazón, la paz. Sembrad en vuestro corazón el amor.

Dad fruto, vosotros hijitos Míos. Dad fruto, donde debáis estar. Dad fruto, para todas las almas; y dad ejemplo al mundo de que estáis con la Madre.

Aquí me manifiesto, en esta Santa Fe, la Nueva Jerusalén. Aquí me manifiesto en esta tierra, santa y bendita. En esta Argentina, en este país, que sufre tanto. Que padece tanto. Y que en un tiempo no muy lejano, verá la luz de la paz, la unidad y la concordia.

Creed en Mis Palabras de Madre y sentid Mi llamado a vuestros corazones. Sed mensajeros hijitos Míos, ante el mundo de cada una de Mis Palabras. No temáis a las pruebas. Confiad en María, que está con los hijos; que llama a los hijos, que convoca a todos los hijos.

No hay muralla, ni barrera que pueda detener mi avance hacia Mis hijos. No hay barrera que pueda detener Mi Amor hacia Mis hijos.Allí donde hay un hijo necesitado, allí va esta Madre. Allí va Mi Corazón Inmaculado. Sentid hijitos Míos Mi tags:
	- Mensajes Presencia entre vosotros y meditad estas palabras, y estad con los enfermos, con los que sufren, con los que lloran. Estad presentes, todos vosotros, con las almas más necesitadas, con los corazones, más necesitados, con los hijos que están tan abandonados.

Escuchad, meditad y poned en práctica cada una de Mis Palabras son para vosotros, son para el mundo entero.

Meditad. Meditad. Meditad Mis Palabras.

&nbsp;

**Dice Jesús:  
** Hermanos Míos; benditos y amados hermanos Míos. Os muestro, Mis Sacratísimas Llagas. Derramo el bálsamo de Mis Sacratísimas Llagas, sobre vosotros. Mi Preciosísima Sangre, que os libera, que os fortalece que os da la paz.

Os invito a vivir en la verdad. Que seáis sencillos, humildes y obedientes. Que miréis Mi Corazón Sacratísimo, traspasado, por amor a vosotros.

¡No dudéis jamás de Mi Amor hacia vosotros! Estoy aquí, os escucho. Estoy con vosotros, siempre, iluminándoos, guiándoos, llevándoos a vosotros por el camino de la verdad, de la unidad, y de la paz.

Sentid vosotros, Que Mi Corazón Sacratísimo, está con vosotros, está permanentemente, y os guía.

Os doy Mi Amor, en este momento y siempre. Derramo Mi Divina Misericordia sobre vosotros, sobre el mundo entero, porque quiero que toda la humanidad vuelva hacia Mí. Que todas las almas vuelvan, vuelvan hacia Mí.

¡No dudéis de Mis Palabras! De Mi Amor. ¡No os sintáis indignos! Sentid verdaderamente, Mi Paz, que llega a vosotros, Mi Paz que llega a vuestros corazones.

¡Venid a Mí! Si estáis agobiados. ¡Venid a Mí! Si estáis cansados. ¡Venid a Mí! Porque os espero con los brazos abiertos, para daros el consuelo y la paz.

¡Os amo, os amo, os amo a todos por igual! Sois Mis ovejas, y estáis en Mi rebaño. Sois Mis ovejas y yo soy el Buen Pastor, que os conduzco, que os guío, que os preservo del maligno.

¡Creed en Mí! ¡Creed en Mis Palabras! ¡Creed en Mi tags:
	- Mensajes Presencia!

Meditad. Meditad. Meditad Mis Palabras.

Os bendigo, en el Nombre del Padre, y del Hijo, y del Espíritu Santo. Amén.