---
title: 'Novena Estación: “Jesús cae por tercera vez”'
author: admin

date: 2011-06-13T16:34:07+00:00
url: /2011/novena-estacion/
thumbnail: /images/estacion06.jpg
tags: [Via Crucis]

---
<div class="wp-block-image">
  <figure class="alignright size-full"><img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2011/06/estacion06-1.jpg" alt="" class="wp-image-3554" title="estacion09" /></figure>
</div>

**G- Te adoramos, Señor y te bendecimos**  
R- Porque con tu Santa Cruz redimiste al mundo.

Oh Mi Jesús, oh Mi Señor, oh Mi Salvador, Mi redentor, no Jesús, no puedo seguir haciendo lo que quiero, no puedo seguir descargando duros golpes sobre Ti, no puedo seguir aumentando tu cruelísimo dolor, oh Jesús que mi corazón sea lugar donde Tú puedas venir a buscar el fruto verdadero y auténtico que Tú esperas.

**Rezar un Padre Nuestro, un Ave María&nbsp; y un Gloria.**

<hr class="wp-block-separator has-alpha-channel-opacity" />

[<i class="fa fa-arrow-circle-left fa-fw"></i> Estación Anterior][1]{.btn.btn-primary.pull-left} [Siguiente Estación <i class="fa fa-arrow-circle-right fa-fw"></i>][2]{.btn.btn-primary.pull-right}

 [1]: /octava-estacion
 [2]: /decima-estacion