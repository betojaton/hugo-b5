---
title: Mensaje, 1 de Noviembre 2011
author: admin

date: 2011-11-01T19:57:28+00:00
url: /2011/mensaje-1-noviembre-2011/

tags: [Mensajes 2011]

---
**Le dice la Santísima Virgen a Vicente:**

> “Vicente hijo mío, rezad esta oración:  
> Madre mía, en medio de éstas pruebas y dificultades te necesito, ven a darme fuerzas, a socorrerme, a levantar mi espíritu.  
> Necesito, OH Madre mía, tu presencia, para que pue- da seguir dando testimonio, ante el mundo, del amor Misericordioso y Eterno, de Dios, Nuestro Señor.

Amén.