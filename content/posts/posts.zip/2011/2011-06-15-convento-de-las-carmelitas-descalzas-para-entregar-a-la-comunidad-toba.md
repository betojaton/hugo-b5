---
title: Convento de las Carmelitas Descalzas – Para entregar a la comunidad Toba.
author: admin

date: 2011-06-15T21:31:46+00:00
url: /2011/convento-de-las-carmelitas-descalzas-para-entregar-a-la-comunidad-toba/
tags: [Colaboraciones]

---
##### 13/02/2010

<!-- default-view.php -->

<div
	class="ngg-galleryoverview default-view "
	id="ngg-gallery-d4ab02f7367fb44cec4c5544e81a1f34-1">
  <!-- Thumbnails -->
  
  <div id="ngg-image-0" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/convento-de-las-carmelitas-descalzas/mariadelasantefetoba.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/convento-de-las-carmelitas-descalzas/mariadelasantefetoba.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/convento-de-las-carmelitas-descalzas/thumbs/thumbs_mariadelasantefetoba.jpg"
               data-image-id="31"
               data-title="mariadelasantefetoba"
               data-description=""
               data-image-slug="mariadelasantefetoba"
               class="ngg-simplelightbox" rel="d4ab02f7367fb44cec4c5544e81a1f34"> <img
                    title="mariadelasantefetoba"
                    alt="mariadelasantefetoba"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/convento-de-las-carmelitas-descalzas/thumbs/thumbs_mariadelasantefetoba.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-1" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/convento-de-las-carmelitas-descalzas/carmelitas_descalzas.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/convento-de-las-carmelitas-descalzas/carmelitas_descalzas.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/convento-de-las-carmelitas-descalzas/thumbs/thumbs_carmelitas_descalzas.jpg"
               data-image-id="63"
               data-title="carmelitas_descalzas"
               data-description=""
               data-image-slug="carmelitas_descalzas"
               class="ngg-simplelightbox" rel="d4ab02f7367fb44cec4c5544e81a1f34"> <img
                    title="carmelitas_descalzas"
                    alt="carmelitas_descalzas"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/convento-de-las-carmelitas-descalzas/thumbs/thumbs_carmelitas_descalzas.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <br style="clear: both" /> <!-- Pagination -->
  
  <div class='ngg-clear'>
  </div>
</div>