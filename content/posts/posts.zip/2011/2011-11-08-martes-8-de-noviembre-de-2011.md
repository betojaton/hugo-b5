---
title: Martes 8 de noviembre de 2011
author: admin

date: 2011-11-08T22:11:55+00:00
url: /2011/martes-8-de-noviembre-de-2011/
thumbnail: /images/jesus02eg6-1.gif
tags: [Mensajes 2011]
---
**Dice la Santísima Virgen:**  
“Hijos Míos; benditos y amados hijos Míos, nuevamente esta Madre se manifiesta con vosotros, nuevamente me hago presente, para escucharos, para atenderos. Estoy aquí presente, y veo vuestros corazones, veo, el interior de cada uno de vosotros. Aquí se manifiesta la Madre; aquí está María con los hijos. Mi corazón de Madre os bendice en forma especial. Os bendice a vosotros, y bendice a vuestras familias.

La Madre llama al mundo entero a la conversión, la Madre pide a todos los hijos la conversión, todos Mis hijos deben orar, todos Mis hijos deben rezar para que venga la paz sobre el mundo, para que venga la paz sobre todas las naciones, para que venga la paz al interior de cada corazón.

¡Son tiempos muy dolorosos! ¡Son tiempos, de mucha oscuridad! y vosotros, no debéis perder la fe, no debéis perder las esperanzas, no debéis dejar que la angustia y el temor se adueñen de vuestro corazón, jamás dejéis que la oscuridad os invada.

Recibid vosotros siempre la luz de Jesús, la luz de Cristo Jesús, Mi Hijo Amadísimo, que os señala un camino, seguid esta luz, la luz de la verdad, de la justicia y la caridad.  
¡Hijos! ¡Hijitos Míos! ¡Confiad en esta Madre! Y aprovechad éste tiempo tan oportuno, estos días tan oportunos. No dejéis, jamás, que las dudas, que los temores y los cuestionamientos, os hagan perder el rumbo.

¡Rezad mucho! ¡Rezad! Tened fe, y rezad porque aquí está la Madre. La Madre os escucha. ¡A todos, os escucha!  
Meditad. Meditad. Meditad Mis Palabras.”

<figure id="attachment_1380" aria-describedby="caption-attachment-1380" style="width: 269px" class="wp-caption alignright"><img decoding="async" loading="lazy" class="size-medium wp-image-1380" title="jesus rezando" src="https://mariadelasantafe.org.ar/images/jesus02eg6.gif" alt="jesus rezando" width="269" height="300" /><figcaption id="caption-attachment-1380" class="wp-caption-text">Venid todos a Mí, llegad a Mí, y mirad la luz de Mi Sacratísimo Corazón, mirad ésta luz, y mirad Mi Sagrado Rostro, ¡mirad Mis ojos! y confiad en Mi tags:
	- Mensajes Presencia, no dudéis jamás de Mi amor hacia vosotros.</figcaption></figure>

**Dice Jesús:  
** “Hermanos Míos; benditos y amados hermanos Míos. Venid todos a Mí, llegad a Mí, y mirad la luz de Mi Sacratísimo Corazón, mirad ésta luz, y mirad Mi Sagrado Rostro, ¡mirad Mis ojos! y confiad en Mi tags:
	- Mensajes Presencia, no dudéis jamás de Mi amor hacia vosotros.

¡Confiad! y venid a Mí en todo momento porque os traigo la paz, el amor y la verdad. ¡Venid a Mí! Sed fieles a Mí, acercaos a Mí, porque os doy el camino de la luz, porque os doy el camino de la paz.

¡Trabajad por Mi Reino! Esforzaos todos los días, por ser mejores, ayudad a los hermanos desamparados, a las almas oprimidas, a los corazones angustiados, estad con los enfermos, con los que sufren en el cuerpo y en el alma.

¡Llegad a Mí! porque os espero. Doy Mi Divina Misericordia a todas las almas, doy Mi Divina Misericordia a todos los corazones, al mundo entero, para que todos los hombres se salven.

¡Nadie cuestione, Mis Palabras! ¡Nadie dude jamás de Mis Palabras! Nadie, rechace Mi amor, por buscar los amores del mundo.  
Recibid Mi Amor Misericordioso, este amor que os lo entrego hoy a vosotros, este amor que sana, que enriquece, este amor que os hace libres, que desata las cadenas, que os oprimen al mundo.

¡Mi amor, es eterno! Mi Misericordia es eterna, es para todo el mundo, es para todas las almas. Confiad, plenamente en Mí. ¡Confiad! y venid a buscar el agua de vida eterna, que brota de Mi Sacratísimo Corazón.

Derramo, en éste momento, sobre vosotros, Mi Preciosísima Sangre, que os libera, que os fortalece, que os enriquece. Derramo Mi Preciosísima Sangre, para haceros dóciles a Mí, dóciles a Mis Palabras, dóciles, a Mi Amor.  
No dudéis jamás, y llegad, llegad totalmente a Mí, en todo momento, porque sois Mis ovejas, y estáis todos en Mi rebaño. ¡Os amo! ¡Os amo! ¡Os amo!  
Meditad. Meditad. Meditad Mis Palabras.  
Os bendigo, en el Nombre del Padre, y del Hijo, y del Espíritu Santo. Amén.”