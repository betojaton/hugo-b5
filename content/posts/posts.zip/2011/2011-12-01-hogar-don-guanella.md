---
title: Hogar “Don Guanella”
author: admin

date: 2011-12-01T20:01:37+00:00
url: /2011/hogar-don-guanella/
tags: [Colaboraciones]

---
##### 23/11/2011

<!-- default-view.php -->

<div
	class="ngg-galleryoverview default-view "
	id="ngg-gallery-59d91aeae001613d3ab68a19543420b3-1">
  <!-- Thumbnails -->
  
  <div id="ngg-image-0" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-don-guanella/hogar_don_guanella_01.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-don-guanella/hogar_don_guanella_01.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-don-guanella/thumbs/thumbs_hogar_don_guanella_01.jpg"
               data-image-id="68"
               data-title="hogar_don_guanella_01"
               data-description=""
               data-image-slug="hogar_don_guanella_01"
               class="ngg-simplelightbox" rel="59d91aeae001613d3ab68a19543420b3"> <img
                    title="hogar_don_guanella_01"
                    alt="hogar_don_guanella_01"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-don-guanella/thumbs/thumbs_hogar_don_guanella_01.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-1" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-don-guanella/hogar_don_guanella_02.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-don-guanella/hogar_don_guanella_02.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-don-guanella/thumbs/thumbs_hogar_don_guanella_02.jpg"
               data-image-id="69"
               data-title="hogar_don_guanella_02"
               data-description=""
               data-image-slug="hogar_don_guanella_02"
               class="ngg-simplelightbox" rel="59d91aeae001613d3ab68a19543420b3"> <img
                    title="hogar_don_guanella_02"
                    alt="hogar_don_guanella_02"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-don-guanella/thumbs/thumbs_hogar_don_guanella_02.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-2" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-don-guanella/hogar_don_guanella_03.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-don-guanella/hogar_don_guanella_03.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-don-guanella/thumbs/thumbs_hogar_don_guanella_03.jpg"
               data-image-id="70"
               data-title="hogar_don_guanella_03"
               data-description=""
               data-image-slug="hogar_don_guanella_03"
               class="ngg-simplelightbox" rel="59d91aeae001613d3ab68a19543420b3"> <img
                    title="hogar_don_guanella_03"
                    alt="hogar_don_guanella_03"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-don-guanella/thumbs/thumbs_hogar_don_guanella_03.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <br style="clear: both" /> <!-- Pagination -->
  
  <div class='ngg-clear'>
  </div>
</div>