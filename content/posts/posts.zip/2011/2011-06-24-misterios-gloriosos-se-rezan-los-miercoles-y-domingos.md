---
title: MISTERIOS GLORIOSOS (Se rezan los miércoles y domingos)
author: admin

date: 2011-06-24T08:42:51+00:00
url: /2011/misterios-gloriosos-se-rezan-los-miercoles-y-domingos/
tags:
  - Guia del Rosario

---
#### 1º LA TRIUNFANTE RESURRECCIÓN DE NUESTRO SEÑOR&nbsp; JESUCRISTO: 

&#8220;María recibe gozosa la presencia de su Hijo resucitado, entre el coro de ángeles y el cantar de serafines&#8221;.

**Meditación:** Señor, que seamos como María, que aceptemos tu voluntad y resucitemos contigo para siempre de todo pecado.

#### 2º JESÚS TRIUNFADOR ASCIENDE A LOS CIELOS: 

&#8220;María, los apóstoles y un gran número de creyentes se dirigen al Monte de los Olivos, allí Jesús los bendice y se despide ascendiendo a&nbsp; los Cielos&#8221;.

**Meditación:** Señor, que seamos como María, que llevemos nuestro corazón al Cielo en cada necesidad para encontrarte siempre.

#### 3º LA VENIDA DEL ESPÍRITU SANTO SOBRE LA VIRGEN Y SOBRE LOS APÓSTOLES: 

“María se encuentra reunida con los apóstoles y demás creyentes en Jesús, un viento, estremecedor y llamas de fuego que descienden sobre sus cabezas, el Espíritu Santo prometido por Jesús ha llegado&#8221;.

**Meditación:** Señor, que aceptemos abiertamente los dones del Espíritu Santo, que nuestro corazón sea sensible y que vivamos en comunidad cristiana como en la primera comunidad.

#### 4º LA ASUNCIÓN DE LA SANTÍSIMA VIRGEN MARÍA EN CUERPO Y ALMA A LOS CIELOS: 

“María finaliza su obra terrenal, María es alzada en Cuerpo y Alma a los cielos, duerme el sueño más hermoso y despierta en el Reino de los cielos, su sepultura es un rosal que cubre todo.”

**Meditación:** Señor, que seamos como la Virgen María, fieles hasta el final, fieles y sumisos hasta nuestra muerte y que podamos gozar con la&nbsp; Virgen María de tu Reino Celestial.

#### 5º MARÍA ES CORONADA COMO REINA UNIVERSAL DE TODO LO CREADO: 

&#8220;La Virgen María, recibe la corona de los Santos en los Cielos, recibe la corona con el anuncio del Ángel, recibe la corona en el nacimiento de Jesús, recibe la corona en la resurrección de Jesús.

**Meditación:** Señor, que seamos cada día mejores, que demos nuestro corazón a la Virgen, como la corona que Ella merece, que nuestra voz nunca se acalle para alabarle y honrarle como Madre nuestra que es.