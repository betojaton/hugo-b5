---
title: 'Duodécima Estación: “Jesús muere en la cruz”'
author: admin

date: 2011-06-13T16:31:00+00:00
url: /2011/duodecima-estacion/
thumbnail: /images/estacion06.jpg
tags: [Via Crucis]

---
<img decoding="async" loading="lazy" class="alignright size-full wp-image-348" title="estacion12" src="https://mariadelasantafe.org.ar/wp-content/uploads/2011/06/estacion012.jpg" alt="estacion12" width="282" height="368" />**G- Te adoramos, Señor y te bendecimos**  
R- Porque con tu Santa Cruz redimiste al mundo.

Jesús, hiciste todo por mí, te entregaste por mí, allí en la cruz diste el amor más profundísimo, el amor que sigues dando y ofreciendo. Oh Jesús, Mi Señor, Mi Salvador, quiero con mi entrega, mi docilidad, mi obediencia asemejarme a Ti, asemejarme un poco y ser valeroso en mis decisiones.

**Rezar un Padre Nuestro, un Ave María  y un Gloria.**

* * *

[<i class="fa fa-arrow-circle-left fa-fw"></i> Estaci&oacute;n Anterior][1]{.btn.btn-primary.pull-left} [Siguiente Estaci&oacute;n <i class="fa fa-arrow-circle-right fa-fw"></i>][2]{.btn.btn-primary.pull-right}

 [1]: /undecima-estacion
 [2]: /decimotercera-estacion