---
title: Martes 8 de Marzo de 2011 en el “Campito”
author: admin

date: 2011-03-08T14:22:29+00:00
url: /2011/martes-8-de-marzo-de-2011-en-el-campito/
tags: [Mensajes 2011]
---
**Dice la Santísima Virgen:** “Hijos Míos, benditos y amados hijos Míos, acudid a ésta Madre en toda necesidad, recurrid a ésta Madre, que abre sus brazos para socorreros, para sosteneros, para daros fuerza.

Aquí está la Madre presente, que os viene a hablar, a cada uno de vosotros y al mundo entero. Pido a todos los hijos, a todos los corazones, que vengáis todos hacia esta Madre, porque la Madre ilumina con su corazón, a todos los hijos.

Estos son Mis días, aquí estoy con vosotros hijitos Míos, aprovechad estos momentos, este tiempo. Recibid en vuestro corazón Mis palabras. Recibid cada uno de Mis mensajes.

Llamo siempre a la conversión, a la unidad, a la paz, llamo a todos los hijos a vivir en la luz y en la verdad.

Mis Palabras no pueden quedar archivadas, Mis palabras de Madre son para todos los hijos del mundo entero, la humanidad por completo, debe volver al Señor.

Los hijos deben volver al Señor, escuchad, todos vosotros a ésta Madre, y tomad siempre en vuestras manos el Rosario, y así con la oración, con la verdadera oración, llegará la paz al mundo.

¡Rezad por la paz! ¡Rezad por la unidad de las familias! ¡Rezad por los jóvenes! ¡Rezad! ¡Rezad! ¡Rezad todos los días el Santo Rosario!

Formad, hijitos Míos, grupos de oración, formad, hijitos Míos grupos marianos que prediquen Mis Palabras de Madre, que estén junto a ésta Madre, acompañando a ésta  Madre en su dolor. Derramo muchas lágrimas ¡Abundantes lágrimas! por los hijos que están sumergidos en la oscuridad, por las almas que continuamente están en guerras, por las almas, que desprecian la ley del Señor.

Escuchad, hijitos Míos, atended hijitos Míos, abrid vuestras manos, y recibid en éste momento Mi Inmaculado Corazón, y llevadlo a vuestro corazón, y allí, a cada instante, y a cada momento, recordaréis todas Mis palabras. Dejad que la Madre os conduzca. ¡Aquí está la Madre con los hijos! ¡Aquí está María! reuniendo el rebaño de Cristo Jesús Mi Hijo Amadísimo.

Meditad. Meditad. Meditad Mis Palabras.”

**Dice Jesús:** “Hermanos Míos, benditos y amados hermanos Míos, Mi Divina Misericordia está con vosotros, Mi Divina Misericordia llega a vosotros. ¡Os amo profundamente! ¡Os amo eternamente! Y vuelco, en éste momento, Mi Preciosísima sangre, para liberaros, para  Fortaleceros, para daros fuerza. Vuelco en vosotros Mi Preciosísima Sangre para limpiaros, para haceros, luz para el mundo.

Debéis ser luz en el mundo, debéis llevar Mi Luz al mundo y a todas las almas. Debéis transmitir, a todos los corazones Mis palabras de amor  de paz y de verdad.

La humanidad debe acercarse a Mí, los hombres deben llegar a Mí, deben terminar las guerras y divisiones, los odios y los rencores.

Todos debéis llegar a Mí porque Mi Sacratísimo Corazón os ama a todos por igual, porque Mi Sacratísimo Corazón os bendice a todos por igual.

Creed en Mí. Creed en Mi tags:
	- Mensajes Presencia. Creed en cada una de mis Palabras. Que nadie cuestione ya. Que la humanidad, ya no cuestione. Estoy aquí presente, os escucho, os atiendo, estoy con vosotros, sois Mis ovejas, y estáis en Mi rebaño, sois mis ovejas, y estáis junto a Mí.

Os amo. Os amo. Os amo. Avanzad, por el camino de la luz. Avanzad, por el camino de la paz y de la verdad.

Os amo. ¡Os amo infinitamente a todos! Os amo.

**Meditad. Meditad. Meditad Mis Palabras.**

**Os bendigo, en el Nombre del padre, y del Hijo, y del espíritu santo. Amén.**

&nbsp;