---
title: Copa de Leche “Esperanza Solidaria” de Barrio “Las Lomas”.
author: admin

date: 2011-06-15T21:30:53+00:00
url: /2011/hospital-de-ninos-casa-de-las-madres-dr-orlando-alassia/
tags: [Colaboraciones]

---
##### 06/01/2010

<!-- default-view.php -->

<div
	class="ngg-galleryoverview default-view "
	id="ngg-gallery-11f9a3427d43d3cb83f8214d442b8fc4-1">
  <!-- Thumbnails -->
  
  <div id="ngg-image-0" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/copa-de-leche/mariadelasantafe-laslomas.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/copa-de-leche/mariadelasantafe-laslomas.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/copa-de-leche/thumbs/thumbs_mariadelasantafe-laslomas.jpg"
               data-image-id="30"
               data-title="las lomas"
               data-description=""
               data-image-slug="las-lomas"
               class="ngg-simplelightbox" rel="11f9a3427d43d3cb83f8214d442b8fc4"> <img
                    title="las lomas"
                    alt="las lomas"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/copa-de-leche/thumbs/thumbs_mariadelasantafe-laslomas.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <br style="clear: both" /> <!-- Pagination -->
  
  <div class='ngg-clear'>
  </div>
</div>