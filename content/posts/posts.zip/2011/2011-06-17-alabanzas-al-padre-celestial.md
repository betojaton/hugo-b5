---
title: ALABANZAS AL PADRE CELESTIAL
author: admin

date: 2011-06-17T22:47:11+00:00
url: /2011/alabanzas-al-padre-celestial/
tags:
  - Guia del Rosario

---
<blockquote class="wp-block-quote">
  <p>
    Padre de amor<br />Dios de la sabiduría<br />Padre de la caridad<br />Espíritu de bendición<br />Gloría de los desvalidos<br />Ráfaga de la Misericordia
  
  
  <cite>**Danos sabiduría y tú Misericordia**</cite>
</blockquote>

### CONSAGRACION 

Madre nuestra, Madre de la Santa Fe, bajo tu Manto estamos y en tu Corazón nos refugiamos.  
Míranos, no permitas que nada malo nos suceda, Dios ha hecho maravillas en Tí,  
queremos que Tú a través de tu Sagrado Corazón de Madre hagas maravillas en nosotros.

Amén.

### ORACION 

Madre eres luz, eres nuestra esperanza.  
Eres el camino, eres la estrella del alba.  
Te pido que borres todo orgullo,  
toda insinuación a la soberbia.  
Te ruego más que por mí, por mis hermanos,  
en especial por aquellos que desprecian tu Santísimo Nombre y tú Virginal Maternidad.  
Madre nuestra de la Santa Fe, bendícenos y acércanos a Jesús.

Amén