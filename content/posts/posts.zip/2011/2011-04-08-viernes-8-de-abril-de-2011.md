---
title: Viernes 8 de Abril de 2011
author: admin

date: 2011-04-08T14:23:55+00:00
url: /2011/viernes-8-de-abril-de-2011/
tags: [Mensajes 2011]
---
**Dice la Santísima Virgen:** “Hijos míos, benditos y amados hijos míos. Hago descender, de Mis Manos, una lluvia de bendición sobre vosotros.

Os entrego en éste momento, las rosas que llevo en Mis Manos, para cada uno de vosotros; para concederos la gracia que estáis necesitando.

Aquí está la Madre, con los hijos. Aquí está la Madre junto a los hijos, reuniendo  al rebaño, convocando al rebaño a la oración. Aquí María se manifiesta con los hijos, para llamar a toda la humanidad a la conversión. Para llamar a todos los corazones a vivir en la paz. Entrego, hijitos míos, a cada uno de vosotros Mi Inmaculado Corazón, donde hallaréis refugio.

Venid a ésta Madre! Y tomaos de Mi Manto Celestial, porque a todos os protejo; a todos os cuido. Estoy con vosotros siempre, os acompaño a todo lugar; veo vuestros corazones. Veo la alegría y el dolor. Veo la angustia y el sufrimiento. Veo, hijitos míos, vuestro corazón dolorido; vuestro corazón angustiado. Y ésta madre os dice: No temáis! Y permaneced fuertes. Permaneced, en el puesto de batalla. No temáis!

Recordad, que siempre la Madre permanece a vuestro lado. Vosotros debéis confiar. Debéis confiar profundamente en Mis palabras  y acudir en todo momento hacia Mis brazos maternales. Porque ésta madre, os conduce a todos vosotros hacia el Corazón de Jesús.

Escuchad, todas Mis palabras! Y vivid éste tiempo de GRACIA; en que la Madre habla a todos los hijos del mundo.

Mis hijos, no deben teme!  Mis hijos deben elevar el  corazón hacia el Señor. Mis hijos, deben estar alertas, porque son muchos, los lobos vestidos de corderos, que andan por todo el mundo, buscando a las almas incautas, a las almas débiles. Vosotros debéis formar, un gran grupo. Debéis formar, una cadena invencible, junto a Mi Rosario, para que así, así hijitos míos, derribéis todas las murallas, derribéis todos los planes de Satanás.

Permaneced en vela. Rezad en Comunidad. Rezad en familia, todos los días el Santo Rosario. Pedid siempre por la paz. Por la paz del mundo. Por la paz en las familias.

¡Pedid! No os canséis de pedir. Porque el Señor escucha a todos sus hijos. El Señor escucha a todos los corazones. Jamás dejéis de rezar! Jamás abandonéis el camino. Y seguid los pasos de Jesús, porque Jesús os conduce a todos, a la Vida Eterna.

Son días especiales y Mis hijos hoy, deben reconocerlo. Son días oportunos. Y Mis hijos, deben reconocerlo!

Que ya nadie dude de Mi tags:
	- Mensajes Presencia. Que ya nadie cuestione Mis palabras. Hablo a todos los hijos, nadie queda excluido!

**Meditad. Meditad. Meditad Mis palabras.”**

**Dice Jesús:** “Hermanos Míos, benditos y amados hermanos Míos. Estáis en Mi rebaño, porque sois Mis ovejas. Estáis junto a Mí y os doy nuevas oportunidades.

Vuelco en vosotros Mi Preciosísima Sangre, para liberaros en este momento. Para fortaleceros en éste momento.

Vuelco mi Preciosísima Sangre, para daros la paz, para daros la fortaleza. Para que así creáis en Mi tags:
	- Mensajes Presencia. Para que así sintáis Mis palabras, en lo profundo de vuestro corazón.

Allí en vuestro corazón, quiero reinar. Allí quiero estar, con Mi Sacratísimo Corazón enseñándoos a cada instante el camino. Mostrándoos el camino.Dejad que os conduzca! Dejad que os modele! No temáis  y acercaos cada uno de vosotros a Mí, porque espero pacientemente a toda la humanidad. Porque espero a todos los hombres. Porque espero. Espero. Espero con paciencia, a todas las almas!

Mis palabras son profundísimas. Mis Palabras son amor. Mis Palabras son verdad, para el mundo entero. Buscad el refugio. Buscad el refugio en Mi Sacratísimo Corazón. Mirad Mis Sacratísimas Llagas que sangran hoy, por esta humanidad, rebelde y oscurecida. Por esta humanidad, a la cual vuelvo a dar nuevas oportunidades. Creed en Mí, verdaderamente, creed en Mí! Y dejad, que día a día os vaya transformando, os vaya modelando a cada uno de vosotros.

Os amo. Os amo. Os amo profundísimamente. Os amo y os perdono, a todos vosotros; porque estáis dentro de Mi Sacratísimo Corazón.

Nadie dude. Nadie tema acercarse a Mí. Os espero a todos. Os espero. Con Mis brazos abiertos. ¡Os espero!

**Meditad. Meditad. Meditad Mis palabras.**

**Os bendigo en el Nombre del padre  y del Hijo y del Espíritu Santo. Amén.”**

&nbsp;