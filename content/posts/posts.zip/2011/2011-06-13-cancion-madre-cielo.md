---
title: Madre del Cielo
author: admin

date: 2011-06-13T12:51:21+00:00
url: /2011/cancion-madre-cielo/
tags: [Canciones]
---
Estribillo:  
_Madre del cielo, hoy te encontré  
María Madre de la Santa Fe._

Cuando anduve por el mundo  
sin pensar Yo te olvide  
y hoy me muestras el camino  
Donde a Jesús encontré  
.Gracias mi Madre querida  
María de Santa Fe,  
soy tu hijo arrepentido,  
que vuelve a buscar tu fe.

Estribillo

Desde esa luz tan potente  
en que derrama tu amor  
hoy me muestras el camino  
para acercarme al Señor,  
Gloria por el gran momento  
que contigo me encontré.  
Gloria a ti Madre del Cielo  
María de Santa Fe!.

Estribillo

Madre has venido a Santa Fe,  
Éste es tú nuevo hogar.  
Hoy tu mano nos conducirá,  
hacia la Patria Celestial.

Estribillo

Has venido a esta tierra  
A traernos hoy la paz.  
Hoy María te cantamos  
Llenos de felicidad. 

Estribillo

Bienvenida a nuestra tierra  
OH María de la paz.  
Bienvenida Madre nuestra.  
Madre mia ven hacia mi 

Estribillo

Caminamos en esta tierra  
Con tú Manto Celestial.  
OH María Madre mía.  
Te queremos hoy cantar

Estribillo