---
title: 'Octava Estación: “Jesús consuela a las piadosas mujeres”'
author: admin

date: 2011-06-13T16:34:53+00:00
url: /2011/octava-estacion/
thumbnail: /images/estacion06.jpg
tags: [Via Crucis]

---
<div class="wp-block-image">
  <figure class="alignright size-full"><img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2011/06/estacion08-1.jpg" alt="" class="wp-image-3555" title="estacion08" /></figure>
</div>

**G- Te adoramos, Señor y te bendecimos**  
R- Porque con tu Santa Cruz redimiste al mundo.

Cuanto amor entregas Mi buen Jesús a las piadosas mujeres, cuanto amor entregas a todos por igual, ¿por qué no imito tu generosidad?, ¿por qué no me brindo hacia mi hermano con amor?, ¿por qué rechazo y reniego siempre de tu Misericordia para con todos los hombres?

Hazme sentir Jesús en mi corazón tu profundísimo amor, tu misericordioso amor.

**Rezar un Padre Nuestro, un Ave María&nbsp; y un Gloria.**

<hr class="wp-block-separator has-alpha-channel-opacity" />

[<i class="fa fa-arrow-circle-left fa-fw"></i> Estación Anterior][1]{.btn.btn-primary.pull-left} [Siguiente Estación <i class="fa fa-arrow-circle-right fa-fw"></i>][2]{.btn.btn-primary.pull-right}

 [1]: /septima-estacion
 [2]: /novena-estacion