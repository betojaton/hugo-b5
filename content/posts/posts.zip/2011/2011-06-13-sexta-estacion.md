---
title: 'Sexta Estación: “La Verónica enjuga el rostro de Jesús”'
author: admin

date: 2011-06-13T13:36:39+00:00
url: /2011/sexta-estacion/
thumbnail: /images/estacion06.jpg
tags: [Via Crucis]

---
**<img decoding="async" loading="lazy" class="alignright size-full wp-image-348" title="estacion06" src="https://mariadelasantafe.org.ar/images/estacion06-1.jpg" alt="estacion06" width="282" height="368" />G- Te adoramos, Señor y te bendecimos**  
R- Porque con tu Santa Cruz redimiste al mundo.

Jesús, que sea valiente soldado y no cobarde, para pasar como lo hizo la Verónica entre la crueldad y las amenazas de los soldados, a secar y limpiar tu rostro, limpiando y defendiendo todos los valores y no tener miedo de dar testimonio de la verdad.

**Rezar un Padre Nuestro, un Ave María  y un Gloria.**

* * *

[<i class="fa fa-arrow-circle-left fa-fw"></i> Estaci&oacute;n Anterior][1]{.btn.btn-primary.pull-left} [Siguiente Estaci&oacute;n <i class="fa fa-arrow-circle-right fa-fw"></i>][2]{.btn.btn-primary.pull-right}

 [1]: /quinta-estacion
 [2]: /septima-estacion