---
title: MISTERIOS GOZOSOS (Se rezan los lunes y sábados)
author: admin

date: 2011-06-24T22:35:11+00:00
url: /2011/misterios-gozosos-se-rezan-los-lunes-y-sabados/
tags:
  - Guia del Rosario

---
#### 1º EL ANGEL GABRIEL ANUNCIA A MARÍA QUE SERÁ LA MADRE DEL SALVADOR: 

&#8220;María recibe en su Corazón la noticia de la redención de los hombres, es portadora del Hijo de Dios, es Madre del mundo&#8221;.

**Meditación:** Señor que seamos también nosotros, medios portadores de tu Buena Noticia.

#### 2º LA VISITA DE LA VIRGEN MARÍA A SU QUERIDA PRIMA ISABEL: 

&#8220;María parte aprisa entre las penurias del desierto, el frío, el calor, los&nbsp; peligros de la noche, a visitar y anunciar a su prima lo que sucede en ella.&nbsp; Ayuda a su prima en las difíciles horas que le están por venir&#8221;.

**Meditación:** Señor, que sepamos darnos al prójimo como lo hizo María con todo, sin esperar nada a cambio.

#### 3º EL NACIMIENTO DE JESÚS EN LA GRUTA DE BELÉN: 

“María y José parten a Belén para empadronarse, María debe ser el medio para los hombres, llega el tiempo y nace el Salvador en una gruta oculta en las montañas, en medio de la humildad y de la oscuridad de la noche&#8221;.

**Meditación:** Señor, que seamos cada uno cuna para que Tú nazcas diariamente en ella.

#### **4º EL NIÑO JESÚS ES PRESENTADO EN EL TEMPLO:** 

“María y José presentan en el Templo al Niño Jesús como ofrenda, como anticipada cruz que Él llevaría, el Niño es fruto de alegría para muchos, Simeón profetiza a María un dolor, una espada atravesará su alma.&#8221;

**Meditación:** Señor, que no seamos nosotros la espada que atraviese el Corazón de María.

#### **5º EL NIÑO JESÚS PERDIDO EN JERUSALÉN Y ES HALLADO EN EL TEMPLO:** 

“Los padres de Jesús, María y José angustiados, doloridos, buscan a Jesús durante tres días enteros, al final es hallado en el Templo con los doctores de la ley&#8221;.

**Meditación:** Señor, que seamos capaces de encontrarte prontamente si hubiésemos perdido la gracia.