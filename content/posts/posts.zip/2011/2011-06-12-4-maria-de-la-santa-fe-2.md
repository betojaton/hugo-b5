---
title: 4 – María de la Santa Fe
author: admin

date: 2011-06-12T21:13:41+00:00
url: /2011/4-maria-de-la-santa-fe-2/
thumbnail: /images/img_canciones-1.jpg
tags: [Canciones]
---
<img decoding="async" loading="lazy" class="alignright size-full wp-image-604" title="img_canciones" src="https://mariadelasantafe.org.ar/images/img_canciones.jpg" alt="img_canciones" width="406" height="304" />

<div class="alignleft"  style="width: 49%">
  <p class="estribillo " style="background-position: 96% center;">
    María, María de Mi Santa Fe<br /> cuanto te queremos y te agradecemos<br /> por ser Nuestra Madre y hacer tanto bien.
  
  
  <p>
    Has venido a Santa Fe a visitar a tus hijos<br /> y a través de tanto amor se acerquen a<br /> Jesucristo, Madre mía estoy aquí, gracias<br /> por tu comprensión y por darnos el mensaje<br /> de acercarnos al Señor.
  
  
  <p>
    Eres estrella de luz para alumbrar a tus<br /> hijos y guiarnos al Salvador Nuestro<br /> Señor Jesucristo, Madre escuchaste el<br /> ruego de guiar nuestro camino para<br /> encontrar al final la luz de amor de tu sino.
  
  
  <p>
    ¡Oh! Virgen mía te oímos con humilde<br /> devoción por eso es que te rogamos pide<br /> nuestra redención, Madre ruégale a Jesús<br /> porque Él es el Salvador quien nos perdona<br /> y nos lleva a la Casa del Señor.
  
</div>