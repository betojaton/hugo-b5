---
title: 'Undécima Estación: “Jesús es clavado en la cruz”'
author: admin

date: 2011-06-13T16:32:00+00:00
url: /2011/undecima-estacion/
thumbnail: /images/estacion06.jpg
tags: [Via Crucis]

---
<img decoding="async" loading="lazy" class="alignright size-full wp-image-348" title="estacion11" src="https://mariadelasantafe.org.ar/wp-content/uploads/2011/06/estacion011.jpg" alt="estacion11" width="282" height="368" />**G- Te adoramos, Señor y te bendecimos**  
R- Porque con tu Santa Cruz redimiste al mundo.

Llegó el momento, el cumplimiento de todo lo predicho por los profetas, Jesús es puesto sobre la cruz y son clavadas sus manos y sus pies, son traspasados profundamente y cae hasta la última gota de su Preciosísima Sangre, los clavos salen de mi corazón y de mis pensamientos. Mi Buen Jesús, dame la oportunidad de remediar y sacar con mis buenas obras los clavos que yo mismo puse allí.

**Rezar un Padre Nuestro, un Ave María  y un Gloria.**

* * *

[<i class="fa fa-arrow-circle-left fa-fw"></i> Estaci&oacute;n Anterior][1]{.btn.btn-primary.pull-left} [Siguiente Estaci&oacute;n <i class="fa fa-arrow-circle-right fa-fw"></i>][2]{.btn.btn-primary.pull-right}

 [1]: /decima-estacion
 [2]: /duodecima-estacion