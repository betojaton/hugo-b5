---
title: 'Oración final:'
author: admin

date: 2011-06-13T00:56:57+00:00
url: /2011/oracion-final/
thumbnail: /images/foto-final-1.png
tags: [Via Crucis]

---
<div class="clear">
</div>

<img decoding="async" loading="lazy" class="alignright size-full wp-image-239" title="foto-final" src="https://mariadelasantafe.org.ar/images/foto-final.png" alt="foto-final" width="295" height="310" /> Padre Eterno, Dios Nuestro, que la meditación y la constante súplica de nuestros corazones llegue hasta Ti, no tengas en cuenta nuestras faltas, perdona nuestros pecados y concédenos la gracia de servirte fielmente y de reparar todos nuestros pecados.

Por Jesucristo, Tu Hijo, que contigo vive y reina, en la unidad del Espíritu Santo, por los siglos de los siglos.

Amén

&nbsp;