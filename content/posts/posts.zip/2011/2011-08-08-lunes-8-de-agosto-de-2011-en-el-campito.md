---
title: Lunes 8 de agosto de 2011 en el “Campito”
author: admin

date: 2011-08-08T18:11:04+00:00
url: /2011/lunes-8-de-agosto-de-2011-en-el-campito/
tags: [Mensajes 2011]
---
**Dice la Virgen: “**Hijos Míos: benditos y amados hijos Míos. Traigo hoy, Mi bendición Maternal. Derramo en vosotros una lluvia de rosas, que son Gracias, que os concedo a cada uno de vosotros.

Hoy María se manifiesta con todos sus hijos del mundo entero, llevando a todos los corazones el mensaje del Señor. El mensaje que invita a la conversión. Hoy María se manifiesta con cada uno de vosotros en esta Tierra Santa y Bendita. En esta Nación María se manifiesta con el amor del Señor, para cada uno de sus hijos. Y el Señor espera de todos los corazones, la respuesta.

Son estos días, los días especiales. Que ninguno de los hijos debe pasar por alto. Son días de gracia y que todos los hijos deben aprovechar, deben recibir en sus corazones.

Estos días de tanta Gracia, de tanta Misericordia. Porque el Señor se manifiesta con los hijos y envía Su Misericordia a todas las almas.

Son los días de la Madre con los hijos. Y llamo, a las almas del mundo, a la oración y a la conversión. No perdáis el tiempo. Estos días, son los días más oportunos.

Venid a la Madre! Acudid a la Madre! Dejad, que con Mi Manto Celestial os cubra, os proteja y os defienda del adversario, que está causando división en las familias, división entre hermanos, división entre los corazones. Poned entonces, hijitos Míos en vuestros corazones una muralla para que el adversario, no entre, para que el adversario no entre a vuestros pensamientos.

Estos son los días, en que la Madre se manifiesta de una forma especial, con todos los hijos y con vosotros que estáis aquí, en torno a Mi Inmaculado Corazón.

Abrid, vosotros hijitos Míos, vuestras manos y recibid, esta rosa que os concedo, que es una Gracia y llevadla a vuestro corazón. Y esperad en el momento oportuno, que Dios Nuestro Señor responderá y a su debido tiempo.

Escuchad a ésta Madre. Seguid a ésta Madre. Porque la Madre os lleva a todos hacia la luz de la verdad que es Cristo Jesús, Mi Hijo Amadísimo.

Meditad. Meditad. Meditad Mis Palabras.”

** **

**Dice Jesús:** “Hermanos Míos; benditos y amados hermanos Míos. Os doy, nuevamente hoy Mi Paz. Os entrego Mi Paz. Os doy Mi Divina Misericordia, Mi Divina Misericordia que sana, que fortalece, que os hace hombres nuevos. Dejad vosotros que Mi Paz more en vuestros corazones. Que Mi Paz os haga dóciles a cada una de Mis Palabras.

Os amo a todos por igual, y todos estáis en Mi rebaño. Os amo infinitamente! Os amo eternamente! Y vuelco mi Preciosísima Sangre sobre vosotros,  sobre esta nación, sobre el mundo entero, sobre todos los corazones.

Venid a Mí. Y os sentiréis aliviados. Venid a Mí sin temor! No temáis acercaros a Mí. Porque os espero a todos con Mi Amor poderoso. Con Mi Amor que borra todas las tinieblas. Con Mi Amor que borra toda tristeza, con Mi Amor que borra todo dolor de vuestro corazón.

Confiad en Mí, en cada una de Mis Palabras. Confiad en Mi tags:
	- Mensajes Presencia entre vosotros. Sentid Mi tags:
	- Mensajes Presencia real entre vosotros.

Camino entre vosotros. Estoy a vuestro lado. Estoy en vuestro corazón. Percibid Mi tags:
	- Mensajes Presencia real en éste momento, en todo momento junto a cada uno de vosotros.

Venid a Mí!. Llegad a Mí! Acudid a Mí Y sentiréis que vuestro yugo se aliviana; que vuestro yugo se hace más liviano con Mi tags:
	- Mensajes Presencia, con Mi ayuda, con Mis Palabras. Venid todos entonces hacia la fuente de Gracia que es, Mi Sagrado Corazón. Este Corazón que ama a todos por igual. Este Corazón que derrama Su Preciosísima Sangre para fortaleceros, para enseñaros a caminar, para mostraros el verdadero camino.

Vivid en la verdad. Vivid, todos en la verdad. Vivid en la Paz. Vivid, verdaderamente, confiando en cada una de Mis Palabras y en Mi tags:
	- Mensajes Presencia.

No temáis. No temáis. Estoy con vosotros. Estoy siempre. Estoy eternamente.

Meditad. Meditad. Meditad Mis palabras.

Os bendigo en el Nombre del Padre, y del Hijo y del Espíritu Santo. Amén. “