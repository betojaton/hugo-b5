---
title: MISTERIOS LUMINOSOS (Se rezan los jueves)
author: admin

date: 2011-06-19T22:44:51+00:00
url: /2011/misterios-luminosos-se-rezan-los-jueves/
tags:
  - Guia del Rosario

---
#### 1º EL BAUTISMO DE JESÚS EN EL RÍO JORDÁN: 

&#8220;Jesús recibe el bautismo de Juan, en el río Jordán, los Cielos se abren y desciende el Espíritu Santo en forma de Paloma&#8221;

**Meditación:** Señor, que abramos el corazón para ser los testigos de tu luz en el mundo entero.

#### 2º LA AUTOREVELACIÓN DE JESÚS EN LAS BODAS DE CANÁ: 

&#8220;Jesús y María Santísima son los invitados a una boda, falta el vino y María intercede ante su Hijo&#8221;.

**Meditación:** Señor, que tengamos el corazón dispuesto para escucharte y para esperar pacientemente tus respuestas.

#### 3º EL ANUNCIO DEL REINO DE DIOS INVITANDO A LA CONVERSIÓN: 

&#8220;Jesús anuncia el Reino de Dios a todos los hombres señala ,el camino para todos los corazones&#8221;.

Meditación: Señor, que seamos también nosotros evangelizadores y testigos de tu Reino en el mundo entero.

#### 4º LA TRANFIGURACIÓN DE JESÚS EN EL MONTE TABOR: 

&#8220;Jesús se revela en la transfiguración frente a sus apóstoles, mostrando toda su Gloria&#8221;.

**Meditación:** Señor, que la luz de tu Corazón nos ilumine y que cada corazón sea un Monte Tabor donde Tú resplandezcas siempre.

#### 5º JESÚS INSTITUYE LA EUCARISTÍA: 

“Jesús celebra su última cena y deja a sus apóstoles la misión, confiere el sacerdocio y la tarea de celebrar siempre la Eucaristía.”

**Meditación:** Señor, que nuestra vida sea estar contigo, estar en cada Eucaristía y recibirte siempre en tu Cuerpo y en tu Sangre como alimento para la vida eterna.