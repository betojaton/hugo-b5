---
title: 'Primera Estación: “Jesús es condenado a muerte”'
author: admin

date: 2011-06-13T16:42:12+00:00
url: /2011/primera-estacion/
thumbnail: /images/primera-estacion-1.png
tags: [Via Crucis]

---
<div class="wp-block-image">
  <figure class="alignright"><img decoding="async" src="https://mariadelasantafe.org.ar/images/primera-estacion.png" alt="primera-estacion" class="wp-image-313" /></figure>
</div>

**G- Te adoramos, Señor y te bendecimos**  
R- Porque con tu Santa Cruz redimiste al mundo.

Jesús, mis cobardías, mis rebeldías, mis infidelidades son la causa de tu condena, mi pecado es la causa, de que tú por amor te entregas por nosotros.

**Rezar un Padre Nuestro, un Ave María&nbsp; y un Gloria.**

<hr class="wp-block-separator has-alpha-channel-opacity" />

<div class="wp-block-buttons is-content-justification-center is-layout-flex wp-container-16 wp-block-buttons-is-layout-flex">
  <div class="wp-block-button">
    <a class="wp-block-button__link has-vivid-cyan-blue-background-color has-background wp-element-button" href="/segunda-estacion">Siguiente Estación -></a>
  </div>
</div>