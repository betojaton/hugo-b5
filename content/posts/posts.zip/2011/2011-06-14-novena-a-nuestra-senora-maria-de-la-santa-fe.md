---
title: NOVENA A NUESTRA SEÑORA MARÍA DE LA SANTA FE
author: admin

date: 2011-06-14T22:58:39+00:00
url: /2011/novena-a-nuestra-senora-maria-de-la-santa-fe/
tags:
  - Guia del Rosario

---
<p class="has-text-align-center">
  Comenzar la novena el último día del mes terminando el día 8,<br />es decir rezar durante nueve días seguidos el Santísimo Rosario<br />por todas las intenciones que la Santísima Virgen dio durante todos estos años.


<div class="wp-block-buttons is-content-justification-center is-layout-flex wp-container-17 wp-block-buttons-is-layout-flex">
  <div class="wp-block-button">
    <a class="wp-block-button__link has-vivid-cyan-blue-background-color has-background wp-element-button" href="https://mariadelasantafe.org.ar/manifestaciones/novena/">Ver Novena</a>
  </div>
</div>