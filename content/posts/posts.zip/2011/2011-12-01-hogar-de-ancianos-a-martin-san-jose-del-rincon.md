---
title: Hogar de Ancianos “A. Martín” (San José del Rincón)
author: admin

date: 2011-12-01T19:58:44+00:00
url: /2011/hogar-de-ancianos-a-martin-san-jose-del-rincon/
tags: [Colaboraciones]

---
##### 04/10/2011

<!-- default-view.php -->

<div
	class="ngg-galleryoverview default-view "
	id="ngg-gallery-a79f237797ccaacba15efded49972806-1">
  <!-- Thumbnails -->
  
  <div id="ngg-image-0" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-ancianos/hogar_ancianos_01.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-ancianos/hogar_ancianos_01.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-ancianos/thumbs/thumbs_hogar_ancianos_01.jpg"
               data-image-id="65"
               data-title="hogar_ancianos_01"
               data-description=""
               data-image-slug="hogar_ancianos_01"
               class="ngg-simplelightbox" rel="a79f237797ccaacba15efded49972806"> <img
                    title="hogar_ancianos_01"
                    alt="hogar_ancianos_01"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-ancianos/thumbs/thumbs_hogar_ancianos_01.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-1" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-ancianos/hogar_ancianos_02.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-ancianos/hogar_ancianos_02.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-ancianos/thumbs/thumbs_hogar_ancianos_02.jpg"
               data-image-id="66"
               data-title="hogar_ancianos_02"
               data-description=""
               data-image-slug="hogar_ancianos_02"
               class="ngg-simplelightbox" rel="a79f237797ccaacba15efded49972806"> <img
                    title="hogar_ancianos_02"
                    alt="hogar_ancianos_02"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-ancianos/thumbs/thumbs_hogar_ancianos_02.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-2" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-ancianos/hogar_ancianos_03.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-ancianos/hogar_ancianos_03.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-ancianos/thumbs/thumbs_hogar_ancianos_03.jpg"
               data-image-id="67"
               data-title="hogar_ancianos_03"
               data-description=""
               data-image-slug="hogar_ancianos_03"
               class="ngg-simplelightbox" rel="a79f237797ccaacba15efded49972806"> <img
                    title="hogar_ancianos_03"
                    alt="hogar_ancianos_03"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/hogar-ancianos/thumbs/thumbs_hogar_ancianos_03.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <br style="clear: both" /> <!-- Pagination -->
  
  <div class='ngg-clear'>
  </div>
</div>