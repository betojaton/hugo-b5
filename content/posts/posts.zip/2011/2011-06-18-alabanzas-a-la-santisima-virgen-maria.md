---
title: ALABANZAS A LA SANTISIMA VIRGEN MARIA
author: admin

date: 2011-06-18T22:45:59+00:00
url: /2011/alabanzas-a-la-santisima-virgen-maria/
tags:
  - Guia del Rosario

---
<div class="wp-block-columns is-layout-flex wp-container-23 wp-block-columns-is-layout-flex">
  <div class="wp-block-column is-layout-flow wp-block-column-is-layout-flow" style="flex-basis:100%">
    <div class="wp-block-columns is-layout-flex wp-container-21 wp-block-columns-is-layout-flex">
      <div class="wp-block-column is-layout-flow wp-block-column-is-layout-flow">
        <p>
          Señor, ten piedad de nosotros<br />Señor, ten piedad de nosotros<br />Cristo, ten piedad de nosotros<br />Cristo, ten piedad de nosotros<br />Señor, ten piedad de nosotros<br />Señor, ten piedad de nosotros<br />Cristo, óyenos<br />Cristo, óyenos<br />Cristo, escúchanos<br />Cristo, escúchanos<br />Dios, Padre Celestial<br />Ten piedad de nosotros<br />Dios Hijo, Redentor del mundo<br />Ten piedad de nosotros<br />Dios.  Espíritu Santo<br />Ten piedad de nosotros<br />Santa Trinidad, un solo Dios<br />Ten piedad de nosotros<br />Santa María, ruega por nosotros<br />Santa Madre de Dios<br />Santa Virgen de las Vírgenes<br />Madre de Cristo<br />Madre de la Iglesia<br />Madre de la Divina Gracia<br />Madre Purísima<br />Madre Castísima
        
      </div>
      
      <div class="wp-block-column is-layout-flow wp-block-column-is-layout-flow">
        <p>
          Madre y Virgen<br />Madre sin mancha<br />Madre Inmaculada<br />Madre amable<br />Madre admirable<br />Madre del buen consejo<br />Madre del Creador<br />Madre del Salvador<br />Virgen prudentísima<br />Virgen venerada<br />Virgen laudable<br />Virgen poderosa<br />Virgen clemente<br />Virgen fiel<br />Espejo de Justicia<br />Sede de sabiduría<br />Causa de nuestra alegría<br />Vaso espiritual<br />Vaso honorable<br />Vaso insigne de devoción<br />Rosa Mística<br />Torre de David<br />Torre de marfil<br />Casa de oro<br />Arca de la Alianza<br />Puerta del Cielo
        
      </div>
      
      <div class="wp-block-column is-layout-flow wp-block-column-is-layout-flow">
        <p>
          Estrella de la mañana<br />Salud de los enfermos<br />Refugio de los pecadores<br />Consuelo de los afligidos<br />Auxilio de los cristianos<br />Luz de Nazaret<br />Rosa pura<br />Pétalos de amor<br />Corazón de los desvalidos<br />Rayo de amor<br />Joya del corazón<br />Reina Inmaculada<br />Reina de los Ángeles<br />Reina de los patriarcas<br />Reina de los profetas<br />Reina de los apóstoles<br />Reina de los mártires<br />Reina de  los confesores<br />Reina de las Vírgenes<br />Reina de todos los Santos<br />Reina concebida sin pecado original<br />Reina llevada al Cielo<br />Reina del Sacratísimo Rosario<br />Reina de la Sagrada Familia<br />Reina de la paz
        
      </div>
    </div>
  </div>
</div>

**Cordero de Dios, que quitas el pecado del mundo**

&#8211; _Perdónanos, Señor_

**Cordero de Dios, que quitas el pecado del mundo**

&#8211; _Escúchanos, Señor_

**Cordero de Dios, que quitas el pecado del mundo**

&#8211; _Ten piedad de nosotros_

**OREMOS:** Dios nuestro, Padre Todopoderoso, por intercesión de Nuestra Madre Inmaculada, la Santísima Virgen te pedimos la salud del alma y del cuerpo, para que gocemos del Reino Celestial, por intermedio de Nuestro Señor Jesucristo.&nbsp; Amén