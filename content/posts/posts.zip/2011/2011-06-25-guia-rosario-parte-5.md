---
title: Parte 5
author: admin

date: 2011-06-25T22:33:00+00:00
url: /2011/guia-rosario-parte-5/
tags:
  - Guia del Rosario

---
### 5º Continuamos rezando de la misma forma el 2º, 3º, 4º, y 5º misterio. 

**Al finalizar el 5º misterio, rezamos la Salve, un Padre Nuestro, el  Ángelus y un Gloria.**

**El Ángelus:**

**G &#8211; El Ángel del Señor anunció a María**

R &#8211; Y concibió por obra y gracia del Espíritu Santo. Dios te salve María&#8230;

**G &#8211; He aquí la esclava del Señor.**

R &#8211; Hágase en Mí según tu palabra. Dios te salve María&#8230;

**G &#8211; Y el Verbo se hizo carne.**

R &#8211; Y habitó entre nosotros. Dios te salve María…

**G &#8211; Ruega por nosotros Santa Madre de Dios.**

R &#8211; Para que seamos dignos de alcanzar las promesas de Nuestro Señor Jesucristo.

**Oremos:  
** Te suplicamos Señor, derrames tu gracia en nuestras almas, para que habiendo conocido por la voz del Ángel la Encarnación de tu Hijo, por los méritos de su Pasión y de su cruz, lleguemos a la gloria de la resurrección.

**Por Jesucristo Nuestro Señor. Así sea.**