---
title: Neonatología – Dr. José María Cullen
author: admin

date: 2011-06-15T21:38:17+00:00
url: /2011/neonatologia-dr-jose-maria-cullen/
tags: [Colaboraciones]

---
##### 22/12/2009, 15/10/2010

<!-- default-view.php -->

<div
	class="ngg-galleryoverview default-view "
	id="ngg-gallery-ac22388f1d994f827902735d862bf5d0-1">
  <!-- Thumbnails -->
  
  <div id="ngg-image-0" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cullen/dsc06312.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cullen/dsc06312.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cullen/thumbs/thumbs_dsc06312.jpg"
               data-image-id="1"
               data-title="Maria de la Santa Fe 06"
               data-description=""
               data-image-slug="maria-de-la-santa-fe-06"
               class="ngg-simplelightbox" rel="ac22388f1d994f827902735d862bf5d0"> <img
                    title="Maria de la Santa Fe 06"
                    alt="Maria de la Santa Fe 06"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cullen/thumbs/thumbs_dsc06312.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-1" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cullen/dsc06317.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cullen/dsc06317.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cullen/thumbs/thumbs_dsc06317.jpg"
               data-image-id="2"
               data-title="Maria de la Santa Fe 05"
               data-description=""
               data-image-slug="maria-de-la-santa-fe-05"
               class="ngg-simplelightbox" rel="ac22388f1d994f827902735d862bf5d0"> <img
                    title="Maria de la Santa Fe 05"
                    alt="Maria de la Santa Fe 05"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cullen/thumbs/thumbs_dsc06317.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-2" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cullen/dsc06318.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cullen/dsc06318.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cullen/thumbs/thumbs_dsc06318.jpg"
               data-image-id="3"
               data-title="Maria de la Santa Fe 04"
               data-description=""
               data-image-slug="maria-de-la-santa-fe-04"
               class="ngg-simplelightbox" rel="ac22388f1d994f827902735d862bf5d0"> <img
                    title="Maria de la Santa Fe 04"
                    alt="Maria de la Santa Fe 04"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cullen/thumbs/thumbs_dsc06318.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-3" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cullen/dsc06327.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cullen/dsc06327.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cullen/thumbs/thumbs_dsc06327.jpg"
               data-image-id="4"
               data-title="Maria de la Santa Fe 03"
               data-description=""
               data-image-slug="maria-de-la-santa-fe-03"
               class="ngg-simplelightbox" rel="ac22388f1d994f827902735d862bf5d0"> <img
                    title="Maria de la Santa Fe 03"
                    alt="Maria de la Santa Fe 03"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cullen/thumbs/thumbs_dsc06327.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-4" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cullen/dsc06334.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cullen/dsc06334.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cullen/thumbs/thumbs_dsc06334.jpg"
               data-image-id="5"
               data-title="Maria de la Santa Fe 02"
               data-description=""
               data-image-slug="maria-de-la-santa-fe-02"
               class="ngg-simplelightbox" rel="ac22388f1d994f827902735d862bf5d0"> <img
                    title="Maria de la Santa Fe 02"
                    alt="Maria de la Santa Fe 02"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cullen/thumbs/thumbs_dsc06334.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-5" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cullen/mariadelasantefe3.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cullen/mariadelasantefe3.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cullen/thumbs/thumbs_mariadelasantefe3.jpg"
               data-image-id="8"
               data-title="Maria de la Santa Fe 01"
               data-description=""
               data-image-slug="maria-de-la-santa-fe-01"
               class="ngg-simplelightbox" rel="ac22388f1d994f827902735d862bf5d0"> <img
                    title="Maria de la Santa Fe 01"
                    alt="Maria de la Santa Fe 01"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cullen/thumbs/thumbs_mariadelasantefe3.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <br style="clear: both" /> <!-- Pagination -->
  
  <div class='ngg-clear'>
  </div>
</div>