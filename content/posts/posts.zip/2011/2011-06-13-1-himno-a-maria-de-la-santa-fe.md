---
title: '1- Himno a María de la Santa Fe'
author: admin

date: 2011-06-13T12:54:52+00:00
url: /2011/1-himno-a-maria-de-la-santa-fe/
thumbnail: /images/img_canciones-1.jpg
tags: [Canciones]
---
<p class="estribillo">
  Ora, ora Madre Nuestra<br /> Reina Inmaculada, María<br /> de la Santa Fe.


Llegamos a tu Casa, agotados  
del trayecto, trayendo en  
nuestro pecho, rosas perfumadas.

Madre de Cristo, Madre Inmaculada,  
Madre de los pobres, Madre de  
la esperanza, Madre de nosotros  
tus hijos del alma.  
Eres la Reina del mundo, eres  
la Reina de lo Creado, eres  
la Reina de las estrellas, eres  
la flor más delicada.

Traemos a tus pies, Madre  
Inmaculada, peticiones, ruegos,  
agradecimientos, traemos, todo  
para Ti Madre Inmaculada.

Rosa Mística, pétalo de belleza  
María de la Santa Fe, tu  
ciudad, tu pueblo, este  
país todo entero te aclama  
Madre, Madre Inmaculada.