---
title: ORACIÓN A MARÍA DE LA SANTA FE
author: admin

date: 2011-06-16T22:56:33+00:00
url: /2011/oracion-a-maria-de-la-santa-fe/
tags:
  - Guia del Rosario

---
María Madre Mía de la Santa Fe.  
Tú eres la esperanza de ésta tu Santa Fe,  
cobijados por tu Manto de celeste angelical,  
nos demuestras cada día que nos quieres mucho más.

Con el coro de los ángeles,  
la presencia de Tu Hijo y la Paloma de la paz,  
bendijiste ésta tierra de grandeza y humildad.

Oh gracias Madre querida por encontrarnos acá.  
implorando tu gracia y tu Manto Celestial.  
Reina Inmaculada guíanos a encontrar  
el camino de la paz y el amor.

Oh gracias Madre querida por encontrarnos acá.  
Amén