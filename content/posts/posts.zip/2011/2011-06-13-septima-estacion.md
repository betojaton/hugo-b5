---
title: 'Séptima Estación: “Jesús cae por segunda vez”'
author: admin

date: 2011-06-13T16:35:52+00:00
url: /2011/septima-estacion/
tags: [Via Crucis]

---
**G- Te adoramos, Señor y te bendecimos**  
R- Porque con tu Santa Cruz redimiste al mundo.

Jesús, nuevamente caes a causa de mí, caes por sostenerme a mí y evitas que me condene eternamente, caes para que yo viva eternamente, para que mi corazón no sea seducido por los placeres del mundo, por las vanidades del mundo, caes para que mi corazón se desapegue de lo terrenal y vislumbre lo celestial.

**Rezar un Padre Nuestro, un Ave María&nbsp; y un Gloria.**

<hr class="wp-block-separator has-alpha-channel-opacity" />

[<i class="fa fa-arrow-circle-left fa-fw"></i> Estación Anterior][1]{.btn.btn-primary.pull-left} [Siguiente Estación <i class="fa fa-arrow-circle-right fa-fw"></i>][2]{.btn.btn-primary.pull-right}

 [1]: /sexta-estacion
 [2]: /octava-estacion