---
title: 'Décima Estación: “Jesús despojado de sus vestiduras”'
author: admin

date: 2011-06-13T16:33:10+00:00
url: /2011/decima-estacion/
thumbnail: /images/estacion06.jpg
tags: [Via Crucis]

---
<div class="wp-block-image">
  <figure class="alignright size-full"><img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2011/06/estacion010-1.jpg" alt="" class="wp-image-3544" title="estacion10" /></figure>
</div>

**G- Te adoramos, Señor y te bendecimos**

R- Porque con tu Santa Cruz redimiste al mundo.

Jesús mío, si ya tu Cuerpo era una llaga entera, ya despedazado, ya completamente agotado de fuerzas, ¿cómo puede ser entonces que te despojen con crueldad de tus vestiduras, dejándote ver tu Cuerpo Santísimo ante la muchedumbre?

**_¿Y entonces acaso tú, con tus malos pensamientos, con tus críticas, con tus bajos deseos, con tus mentiras y faltas de caridad no me estás despojando de mis vestiduras con mayor crueldad?_**

Oh Jesús mío, no permitas que ya más te ofenda, que ya más sea el tirano cruel que te cause tanto dolor.

**_No temas, te amo, te amo eternamente y quiero para tu alma el gozo de la vida eterna, ven a Mí, entrégate a Mí, pon tu corazón junto a Mi pecho y siente el latir de Mi Corazón que tanto te ama y que tanto ama al mundo, estoy contigo, estoy siempre, no temas a nada y has siempre Mi voluntad._**

**Rezar un Padre Nuestro, un Ave María&nbsp; y un Gloria.**

<hr class="wp-block-separator has-alpha-channel-opacity" />

[<i class="fa fa-arrow-circle-left fa-fw"></i> Estación Anterior][1]{.btn.btn-primary.pull-left} [Siguiente Estación <i class="fa fa-arrow-circle-right fa-fw"></i>][2]{.btn.btn-primary.pull-right}

 [1]: /novena-estacion
 [2]: /undecima-estacion