---
title: Parte 1 y 2
author: admin

date: 2011-06-26T20:59:39+00:00
url: /2011/guia-rosario-parte-1y2/
thumbnail: /images/rosario-1.png
tags:
  - Guia del Rosario

---
### 1º Nos hacemos la señal de la cruz: 

&#8220;Por la señal de la Santa Cruz, de&nbsp; nuestros enemigos, líbranos Señor, Dios Nuestro.&nbsp; En el Nombre del Padre y del Hijo y del Espíritu Santo. Amén&#8221;.

### 2º Nos ponemos en presencia de Dios y para que la oración &nbsp;llegue al Cielo pedimos humildemente perdón por nuestras faltas y decimos: 

**&#8220;Señor mío y Dios mío, reconozco que soy pecador, he pecado contra Ti y&nbsp;contra mi prójimo; Me arrepiento del mal que he hecho, porque me hice indigno&nbsp;de tu amor y merecedor de tu castigo. Confío en Tu Misericordia porque&nbsp;Tu Hijo Jesús murió por mí en la cruz; te pido que me perdones e imploro tu gracia para cumplir mi propósito de no ofenderte más&#8221;.**

**Amén.**

Ven, Espíritu Santo, llena los corazones de tus fieles y enciende en ellos el fuego de tu amor.

G &#8211; **Envía, Señor tu Espíritu y todo será creado.**

R &#8211; Y renovaras la faz de la tierra.

Oh Dios que aleccionaste los corazones de tus fieles con la ciencia del Espíritu Santo, haz que guiados por ese mismo&nbsp;Espíritu, saboreemos la dulzura del bien y gocemos siempre de sus divinos consuelos. Por Cristo Nuestro Señor. Así sea.

G &#8211; **Señor abre mis labios.**

R &#8211; Y mi boca anunciará tus alabanzas.

G &#8211;&nbsp;**Oh Dios, ven en mi ayuda.**

R &#8211; Señor apresúrate a socorrerme.

G &#8211;&nbsp;**Gloria al Padre y al Hijo y al Espíritu Santo.**

R &#8211; Como era en un principio, ahora y siempre, por los siglos de los siglos.

Amén.

Rezar el Santo Rosario diariamente con la siguiente intención:

**&#8220;Que Dios envíe al mundo su Misericordia sobre todos sus hijos,&nbsp;que el Señor bendiga a sus hijos en todo lugar y que sus hijos&nbsp;lleguen a Él por el camino del amor&#8221;.**