---
title: Sábado 8 de Mayo de 2010
author: admin

date: 2010-05-08T13:55:00+00:00
url: /2010/sabado-8-de-mayo-de-2010/
tags: [Mensajes 2010]

---
**Dice la Santísima Virgen:** Hijos Míos, benditos y amados hijos Míos.Gracias nuevamente por responder. Gracias por vuestro &#8220;si&#8221; No temáis acercaos a la Madre. ¡No temáis! Y llegad a la Madre. Porque la Madre os conduce a Jesús. Porque os llevo hacia Jesús. Porque quiero que todos conozcáis a Jesús. Que busquéis y viváis en la luz que seáis mensajeros de la luz a vuestros hermanos. Ved, hijitos Míos. ¡Cuánta oscuridad reina en todas partes! Hoy veis hijitos Míos, cuántos son los corazones, que están atrapados en la oscuridad.

¡Debéis vosotros llevar la luz! Debéis tener encendidas vuestras lámparas, y no dejar nunca que apague. ¡Rezar vosotros! Hijitos Míos y acompañad a ésta Madre, que os viene anunciando los mensajes del Señor. Debéis escuchar atentamente y apartar el temor y las dudas. ¡Debéis confiar en Mis Palabras! y dejar, que Mi Corazón de Madre os conduzca. Debéis dejar, que las ROSAS DE MI MANTO, caigan en vuestros corazones. Los hagan fuertes, valerosos, y jamás temerosos. Hijitos Míos, aprovechad éstos días, éste tiempo, estos días gloriosos, en que ésta Madre, se manifiesta junto a vosotros, para enseñaros el camino. Para mostraros el camino.

Una y otra vez, os pediré la ORACIÓN, juntos, la ORACIÓN. Os pediré, nuevamente, que recéis el Santo Rosario, para alejar, tantas calamidades. Para alejar tantos males. Volcaos, pues, hijitos Míos, a Mi Inmaculado Corazón. Volcaos hijitos Míos, a Mi Manto Celestial y difundid todas mis palabras, que no queden guardadas, porque llamo hoy a la humanidad a la converción, llamo a todos los hijos a la converción. ¡Debe la humanidad por completo, volver al Señor! Deben todos los hijos, escuchar la Voz del Señor. Deben los corazones, encontrar la verdad  y la luz; y apartar todas las tinieblas; las tienieblas del terror, las tinieblas del pecado.

Que Mis Palabras de Madre, os ayuden a vosotros. Que Mis Palabras os den fuerza, para seguir el camino; para avanzar por éste camino que tantas veces, se os hace tan pesado. Pero, recordad, ¡Que estoy con vosotros! ¡Recordad que estoy a vuestro lado y que os acompaño, y os conduzco siempre! Recordad siempre Mis Palabras, Meditadlas profundamente; y que jamás el temor, se adueñe de vuestro corazón. Esforzaos cada día, por ser mejores. Esforzaos minuto a minuto, para ser testigos, verdaderos testigos en el mundo entero. Dad pues el ejemplo, enseñad al que no sabe; predicad y difundid. Y avanzad, como lo desea Cristo Jesús, Mi Hijo Amadísimo.

**Meditad. Meditad. Meditad Mis Palabras.**

**Dice Jesús:** Hermanos Míos; benditos y amados hermanos Míos. Os muestro la luz de Mi Corazón. Os muestro y os doy Mi Paz. Os señalo, el verdadero camino, Mi Sacratísimo Corazón. Venid a Mí todos. Acudid a Mi Corazón Sacratísimo, y sacad de corazón: la maleza. Sacad del corazón: la cizaña. Y dejad que crezca el buen trigo. ¡Os amo a todos! Y os hablo a todos por igual. Porque quiero de vosotros, verdaderamente, un pueblo orante. Escuchad Mis Palabras. Escuchad verdaderamente Mis Palabras. Y ponedlas en práctica. Os hablo de Mi Amor. Os hablo de Mi Paz. Os hablo de Mi Divina Misericordia. Y vuelco Mi Divina Misericordia en vosotros. No busquéis pues interrogantes. No busquéis cuestionamiento. Buscad siempre Mis Palabras. Buscad Mi Corazón. Buscad Mi Cuerpo y Mi Sangre. Y acercaos a Mí. Porque os salvaré. Acercaos a Mí, porque os fortaleceré. Mis Palabras son bálsamo. Mis Palabras son consuelo. Mis Palabras son fuerza para vuestros corazones alicaídos. ¡Creed en Mí! ¡Creed en Mi tags:
	- Mensajes Presencia!¡Creed en Mi Amor Poderoso hacia vosotros y hacia el mundo entero! Sois testigos de Mis Palabras. Y éstas Palabras deben llegar a todos los rincones de la tierra. La humanidad debe comprender. Debe entender. Debe aceptar Mi tags:
	- Mensajes Presencia. Mi tags:
	- Mensajes Presencia real con vosotros. ¡Creed! Y dejad que os transforme día a día. ¡Creed! Y no temáis. Porque todas las tormentas pasarán. Toda la oscuridad desaparecerá; y brillará, la luz de la verdad. La luz de la paz. La luz verdadera que reinará en todos los corazones. Creed hoy verdaderamente. Creed.

Os amo. Os amo. Os amo. ¡Jamás dudéis de Mi Amor hacia vosotros!

**Meditad. Meditad. Meditad Mis Palabras.**

**Os bendigo, en el Nombre del Padre, y del Hijo y del Espíritu Santo. Amén.**

&nbsp;