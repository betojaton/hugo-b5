---
title: Viernes 8 de Enero, 2010
author: admin

date: 2010-01-08T13:15:01+00:00
url: /2010/viernes-8-de-enero-de-2010/
tags: [Mensajes 2010]

---
**Dice la Santísima Virgen:** Hijos míos, benditos y amados hijos míos, os traigo Mí Inmaculado Corazón para cada uno de vosotros, os traigo Mí amor de Madre para sosteneros en la lucha, para daros fuerza para seguir avanzando por este camino. Abrid hijitos míos vuestras manos y recibid el Rosario que tengo en Mis manos y llevadlo a vuestro corazón y allí en vuestro corazón debéis meditar con el Rosario en cada una de Mis palabras. Debéis recordar Mis palabras, debéis sentir profundamente Mis palabras de Madre que son dirigidas a cada uno de vosotros y al mundo entero.

Hijitos míos transitad en la luz, transitad en la verdad, transitad en la justicia y en la caridad todos juntos. Avanzad y jamás miréis el pasado, avanzad y dejad que esta Madre os conduzca cada día, a cada momento, a cada instante. Mis palabras no deben quedar archivadas, siempre os lo digo, no deben quedar archivadas. Quiero que Mis hijos respondan a Mi llamado de conversión, quiero que la humanidad responda hoy a Mí llamado de conversión, en este tiempo, en estos días tan difíciles para el mundo entero, en estos días tan oscuros para el mundo entero.

Vosotros debéis llevar la luz de Jesús a todos los rincones de la tierra, llevar la luz de Jesús, llevar el mensaje de Jesús. El mensaje es el AMOR, el mensaje es la CARIDAD, el mensaje es la JUSTICIA.

Hijitos, hijitos míos amadísimos, tened presentes Mis palabras a cada instante, a cada momento y en todo lugar y recordad que la Madre está con vosotros siempre, siempre, siempre.

**Meditad. Meditad. Meditad Mis palabras.**

**Dice Jesús:** Hermanos míos, benditos y amados hermanos míos, mirad Mí corazón traspasado, mirad Mi corazón herido por amor a vosotros, mirad Mis ojos que os miran a cada uno de vosotros, mirad éste corazón que os ama profundísimamente a cada uno por igual. Mí corazón no separa, Mí corazón os une a todos, os doy la luz, la luz de Mi Divina Misericordia para iluminaros el camino, para mostraros la verdad, para enseñaros a caminar verdaderamente como buenos hijos y como buenos hermanos.

Trabajad verdaderamente, trabajad y apartad del corazón los pensamientos oscuros, los pensamientos que no vienen, que no vienen del bien, sino del mal. Creed en Mis palabras, en Mí presencia y fijad constantemente la mirada en Mí Sacratísimo Corazón, allí encontrareis paz, consuelo y el bálsamo para sanar cada una de vuestras heridas.

Os amo a todos ovejitas mías, os amo a todos y todos estáis en Mi rebaño, os amo creedlo así verdaderamente.

Os amo. Os amo. Os amo.

**Meditad. Meditad. Meditad Mis palabras.**

**Os bendigo en el Nombre del Padre y del Hijo y del Espíritu Santo.**

**Amén.**

&nbsp;