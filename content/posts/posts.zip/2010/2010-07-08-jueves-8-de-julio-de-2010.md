---
title: Jueves 8 de Julio de 2010.
author: admin

date: 2010-07-08T14:03:38+00:00
url: /2010/jueves-8-de-julio-de-2010/
tags: [Mensajes 2010]

---
**Dice la Santísima Virgen:** “Hijos Míos; benditos y amados hijos Míos, acercaos a la Madre, llegad a ésta Madre, venid a los brazos de ésta Madre; porque no quedaréis desamparados. Os escucho, os atiendo, estoy con vosotros a cada instante y en cada momento. Hijitos Míos, hijitos amadísimos, rezad todos vosotros, rezad todos los días el Rosario, por la paz del mundo. Os invito al trabajo, os invito hijitos Míos, a que cada día deis el corazón a Jesús, que ofrezcáis el corazón a Jesús, para que Jesús os modele a vosotros. Gracias por vuestra respuesta, gracias por vuestro SI.

Mis Mensajes, Mis Palabras, son para vosotros, son para el mundo entero, no debéis guardarlas, no debéis archivarlas. Aquí está la Madre, en ésta tierra Santa y Bendita, en LA SANTA FE,  LA NUEVA JERUSALEM, llamando a todos los hijos del mundo a la conversión. Solamente, con el cambio profundo de corazón llegará la paz al mundo. Los hijos, deben vivir hoy en la luz y apartarse de todas las tinieblas. Deben vivir en la Gracia, deben vivir en la claridad. Mis hijos deben atender a cada una de Mis Palabras, Mis Palabras Profundas, Mis Palabras de Amor, Mis Enseñanzas.

No temáis hijitos Míos, confiad en ésta Madre, creed en Mi tags:
	- Mensajes Presencia Celestial con vosotros, cumplid con Mis Palabras y aprovechad éste tiempo en que está la Madre junto a vosotros, aprovechad estos días de GRACIA y de GLORIA; para ésta tierra Santa y Bendita.

Hijitos Míos, os doy Mis Palabras de Amor, Hijitos Míos, os doy Mis Enseñanzas, poned en práctica Mis Palabras, y difundid a los hijos del mundo entero Mi tags:
	- Mensajes Presencia.

Convoco, pido, reclamo Mis derechos sobre ésta Nación Santa y Bendita.

Que los hijos, pues, no dejen pasar de lado este tiempo especial, estos días, tan especiales en que los hijos profundísimamente, se encuentren con Jesús, se entreguen a Jesús, crean en Jesús.

Hijitos Míos, meditad Mis Palabras, Hijitos Míos creed en Mis Palabras y con vuestra oración, secad las lágrimas de Mis Ojos.

**Meditad. Meditad. Meditad Mis Palabras.**

**Dice Jesús:** Hermanos Míos, benditos y amados hermanos Míos, hoy os entrego Mi Sacratísimo Corazón, en vuestras manos pongo Mi Sacratísimo Corazón, en vuestro corazón pongo Mi Sacratísimo Corazón. Sentid Mi verdadera tags:
	- Mensajes Presencia, Mi real tags:
	- Mensajes Presencia entre vosotros. Sentid verdaderamente el fuego abrasador de Mi Amor que viene a vosotros para liberaros, para desataros de las cadenas, del temor, de las dudas.

Os doy, en éste instante, en éste momento, el fuego abrasador de Mi Amor, el fuego que libera, que purifica, el fuego que os hace eternamente libres.

Mi Amor es para vosotros, Mis Palabras son enseñanza para vosotros, sentid, pues, realmente Mis palabras dentro de cada uno de vosotros. Sentid que Mi Sacratísimo Corazón está en vosotros, mostrándoos a cada uno el camino. El camino es la verdad, el camino es la justicia; el camino es la unidad, el camino es el amor al prójimo.

Hermanos Míos tened fe y confianza en Mis Palabras, Hermanos Míos creed en cada una de Mis Palabras, tened confianza.

Confiad, confiad, confiad, y jamás dudéis de Mi Amor hacia cada uno de vosotros.

Recibid Mi Divina Misericordia, recibid la luz de Mi Corazón, recibid la paz de Mi Corazón.

**Meditad. Meditad. Meditad Mis Palabras.**

**Os bendigo, en el Nombre del Padre y del Hijo y del Espíritu Santo. Amén.**

&nbsp;