---
title: Viernes 8 de Octubre de 2010.
author: admin

date: 2010-10-08T14:11:57+00:00
url: /2010/viernes-8-de-octubre-de-2010/
tags: [Mensajes 2010]

---
**Dice la Santísima Virgen:** “Hijos Míos: benditos y amados hijos Míos. Gracias por responder a Mi llamado. Gracias por estar junto a ésta Madre.

Os invito, a que abráis vuestras manos, y recibid, el Rosario que ésta madre os entrega. Tened en vuestras manos este Rosario, y luego llevadlo a vuestro corazón, para que así, todos vosotros, meditéis en cada una de Mis palabras.

Estoy con vosotros pequeños hijos míos, Os estoy acompañando en éste tiempo de la historia, en este tiempo de la humanidad.

Vengo a anunciaros las palabras del Señor, y a mostraros, a todos vosotros, y al mundo entero, el verdadero camino que es Cristo Jesús Mi Hijo Amadísimo. Muchas almas desconocen, verdaderamente, ésta verdad, muchos corazones, desconocen ésta realidad.

Aquí está María PRESENTE. Aquí está la Madre, convocando y reuniendo al rebaño de Jesús, para presentarlo al Señor.

En ésta Nación Santa, María ha puesto Sus pies, en ésta Bendita Argentina, La Madre, ha puesto su hogar, y los hijos deben salir hacia el mundo a llevar el Mensaje del Señor. No os quedéis dormidos, no perdáis las horas tan valiosas.

Dios os mira con bondad y Misericordia y espera respuesta de todos los hijos, espera respuesta, de sus hijos predilectos.

Hijitos Míos, trabajad, trabajad mucho, trabajad en la unidad, colaborad en el Reino del Señor.

Ofreced cada día: penitencias, sacrificios por la salvación de todas las almas, y rezad, constantemente, rezad el Santo Rosario, rezad en la unidad, todos vosotros, y enseñad a todos los corazones a orar. Éste es el tiempo oportuno en que vosotros debéis dar testimonio, en que vosotros debéis dar el ejemplo en el mundo entero.

Sed verdaderamente luz para el mundo, sed faros para el mundo, iluminad a todas las almas, a todos los corazones, y vivid cada día en la verdad, porque la verdad os hace libres, porque la verdad desata las cadenas. Vivid en la verdad, y enseñad a todas las almas a vivir en la verdad.

Comunicad Mis palabras a vuestros hermanos, llevad, Mis palabras a todos vuestros hermanos. Este es el tiempo de María, aprovechad este tiempo, estos días, estas horas tan valiosas. Aprovechad.

**Meditad. Meditad. Meditad Mis palabras.”**

**Dice Jesús:** “Hermanos Míos; benditos y amados hermanos Míos. Mi Sacratísimo Corazón, es paz para vosotros. Vuelco en vosotros el amor de Mi Sacratísimo Corazón, os muestro Mi Sacratísimo Corazón a cada instante. Os doy la paz de éste Corazón, para que vosotros viváis en paz, para que llevéis la paz, para que llevéis la verdad.

Os hablo de amor, os hablo de paz, os hablo de verdad. El mundo hoy vive en la oscuridad, la humanidad vive alejada de la verdad, y quiero salvar a todos los hombres. Quiero que toda la humanidad, regrese, a Mi Divina Misericordia.

Vosotros estáis en Mi rebaño, vosotros sois Mis ovejas, y estáis dentro de Mi Sacratísimo Corazón.

Os hablo hoy de amor, os hablo, nuevamente, de verdad, os hablo, nuevamente, de paz. La paz debe reinar en las almas, la paz debe reinar en los hogares, en las familias, en las comunidades. En todo lugar debe reinar la paz.  Os amo a vosotros en forma especial, os amo, os amo, os amo. Creed en Mi amor y venid a Mí si estáis agobiados, si estáis doloridos, si estáis angustiados. Venid a Mí, y no busquéis los caminos fáciles, no busquéis los caminos equivocados y que llevan a la perdición. Venid a Mí, y encontraréis la eterna paz, venid a Mí y sentiréis Mi presencia que os transforma, que os modela, que os enriquece. Venid a Mí y disfrutad de Mis palabras, disfrutad de Mi presencia, gozaos con Mis palabras y reverdeced, cada día, floreced cada día, perfumad el mundo desde vuestro corazón, perfumad al mundo con vuestros actos, con vuestra oración, con vuestra entrega.

No os canséis de practicar el bien, no os canséis de dar la mano al prójimo, no os canséis de predicar, al mundo entero, Mis palabras, de amor y de verdad.

Estoy, con vosotros siempre, os atiendo, os escucho, os socorro a cada instante, porque Mi Divina Misericordia se posa en vosotros, se derrama en vosotros. Mi Divina Misericordia os envuelve en la luz y en la paz para que veáis, cada día el camino con mejor claridad.

Creed en Mis palabras y acercaos a Mí. Creed en Mi amor y acercaos a Mí. Creed en Mi paz y acercaos a Mí. Que nadie dude de Mi amor, que nadie dude de Mi presencia, que nadie cuestione Mis palabras.

**Os amo. Os amo. Os amo.**

**Trabajad. Trabajad. Trabajad. Os amo.**

**Meditad. Meditad. Meditad Mis palabras.**

**Os bendigo, en el Nombre del Padre, y del Hijo, y del Espíritu santo. Amén.”**

&nbsp;