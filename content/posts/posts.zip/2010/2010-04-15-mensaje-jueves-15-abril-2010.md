---
title: Mensaje, Jueves 15 de Abril, 2010
author: admin

date: 2010-04-15T21:38:55+00:00
url: /2010/mensaje-jueves-15-abril-2010/
tags: [Mensajes 2010]

---
**Me dice la Santísima Virgen:**

> Hijos Míos; benditos y amados hijos míos. Nuevamente gracias, por vuestro “SI”; y ésta Madre quiere deciros, a cada uno de vosotros, y en forma especial, que no están lejanos los días en que ésta Madre, ya no estará más presente con vosotros.
> 
> ¡Hijitos Míos, quiero que aprovechéis este tiempo! Quiero que escuchéis Mis Palabras. Quiero que meditéis Mis Mensajes; y profundicéis en ellos.
> 
> ¡Éstos son los días! de la madre con sus hijos. Estos son Mis días; con cada uno de vosotros. Y quiero que permanezcáis fieles, que cumpláis con Mis pedidos.
> 
> Continuad rezando, todos juntos, como lo hacéis hasta ahora. Continuad por siempre; aunque ésta Madre no esté junto a vosotros, físicamente.
> 
> Continuad rezando, todos juntos para pedir al Señor: MISERICORDIA POR EL MUNDO ENTERO. Para pedir al Señor, por todo el mundo. Para que cada uno de vosotros, ruegue a Dios Padre Todopoderoso, por la humanidad, por las almas extraviadas. Por los corazones sumergidos en la oscuridad.
> 
> ¡Tenéis una tarea! No abandonéis la marcha. ¡Tenéis una tarea! Avanzad todos juntos. ¡Tenéis una tarea! Profundizad en Mis Palabras. Difundid Mis palabras. Sed mensajeros de Mis Palabras. Os doy ¡tantas señales de Mi tags:
	- Mensajes Presencia! Tantas claras señales de Mi real presencia maternal con vosotros. Escuchad a la Madre. Meditad las palabras de ésta Madre. No la paséis por alto. Os lo digo a vosotros, y lo digo también a todos Mis Hijos Predilectos, los sacerdotes; de aquí, y del mundo entero. A todos hablo por igual. A todos invito. A todos convoco. A todos llamo hoy a una definitiva conversión.

Creed en la Madre. Creed en Mis Palabras. Creed profundamente en Mis Mensajes. Meditad. Meditad. Meditad Mis Palabras.