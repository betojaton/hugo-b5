---
title: Oración al Sagrado Corazón de Jesús.
author: admin

date: 2010-07-19T00:31:03+00:00
url: /2010/oracion-al-sagrado-corazon-de-jesus-2/
tags: [Oraciones]

---
<img decoding="async" loading="lazy" class="alignright size-full wp-image-787" title="sagrado-corazon-de-jesus" src="https://mariadelasantafe.org.ar/wp-content/uploads/2010/07/sagrado-corazon-de-jesus.png" alt="sagrado-corazon-de-jesus" width="200" height="251" />**”Vicente hermano mío: Decid esta oración todos los días**

Sagrado Corazón de Jesús, en ti  
pongo mis preocupaciones, te  
dejo en tus manos mis angustias, temores y problemas.

Sagrado Corazón de Jesús, confío en ti  
y te pido que me des luz, que me des  
fortaleza para enfrentar todas las situaciones.

Sagrado Corazón de Jesús, en ti confío, espero en ti  
y sé que a su debido tiempo tendré la respuesta  
que tu quieras darme.

Sagrado Corazón de Jesús, confió en ti, espero en ti,  
creo en ti.

**Amen. Amén.**

**Predica esta oración a todos tus hermanos y diles que todos confíen en Mí y esperen con plena confianza Mi respuesta.”**