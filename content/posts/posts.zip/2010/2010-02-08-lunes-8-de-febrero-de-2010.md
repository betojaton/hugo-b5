---
title: Lunes 8 de Febrero de 2010
author: admin

date: 2010-02-08T13:46:03+00:00
url: /2010/lunes-8-de-febrero-de-2010/
tags: [Mensajes 2010]

---
**Dice la Santísima Virgen:** Hijos míos, benditos y amados hijos míos, gracias nuevamente porque estáis con la Madre. Gracias por vuestra respuesta. Gracias por vuestro sí, habéis llegado a los pies de la Madre, estáis junto a la Madre y la Madre está con vosotros, señalando a vuestros corazones el camino.

Hijitos míos, hijitos amadísimos, escuchad cada una de Mis palabras, atended a cada uno de Mis pedidos. Dejad todo aquello, todo aquello que hace daño en vuestro corazón y vivid  en el Amor, en la Paz, en la Verdad, en la Unidad. Abandonad todo tipo de tinieblas y vivid en la luz de Cristo Jesús, Mí Hijo Amadísimo. Mis palabras de Madre, son para todos los hijos del mundo, es para señalar el camino a esta humanidad tan rebelde, tan equivocada, tan apartada del camino verdadero, del camino del Señor. Hijos míos, hijitos míos amadísimos atended profundamente a Mis palabras y meditadlas en vuestro corazón y difundidlas al mundo entero como lo pide esta Madre **“MARIA DE LA SANTA FE”**

**Meditad. Meditad. Meditad Mis palabras.**

**Dice Jesús:** Hermanos míos, benditos y amados hermanos míos, os muestro nuevamente Mi Sacratísimo Corazón, debe ser el refugio para vosotros, Mí Sacratísimo Corazón, éste corazón que mana su Preciosísima  Sangre sobre cada uno de vosotros. Vivid todos juntos en la unidad, vivid y caminad, juntos todos, en la unidad, trabajad profundamente, profundamente para que sean difundidas Mis Palabras al mundo entero, os invito a cada uno de vosotros que estáis en Mi Rebaño, a caminar junto a Mí, a seguir Mis pasos, a seguir Mi camino. No temáis, no temáis, porque estoy con vosotros en la barca.

No temáis, escuchad Mis palabras de amor, Mis palabras de verdad, Mis palabras de profundísima paz, debéis ser mensajeros de la Paz, mensajeros de Mi amor , mensajeros de Mi verdad, dejad todo aquello, todo aquello que os impide llegar plenamente a Mí.

Os amo a todos por igual, sois Mis ovejas.Os amo, os amo profundísimamente.

No dudéis jamás de Mi presencia con vosotros. No dudéis  jamás de Mis palabras hacia vosotros, sed fieles a Mi amor, sed fieles a Mis palabras, sed fieles al llamado que hoy os hago. Este llamado que os invita a vuestros corazones a una sincera y definitiva conversión, enseñad a todas las almas, a todos los corazones a vivir en la luz y la verdad, sólo así llegará la paz sobre el mundo, sólo así llegara la auténtica y definitiva paz sobre el mundo.

Os amo pequeñas ovejitas mías, os amo a todos por igual.

Recibid Mi luz, Mi Divina Misericordia. Recibid el Bálsamo de Mis Sacratísimas Llagas sobre a cada uno de vosotros. Confiad en Mí. Confiad profundamente en Mis palabras. Creed en Mí. Creed profundamente en Mí.

**Meditad. Meditad. Meditad Mis palabras.**

**Os bendigo en el Nombre del Padre y del Hijo y del Espíritu Santo. Amén. .**

 ****

&nbsp;