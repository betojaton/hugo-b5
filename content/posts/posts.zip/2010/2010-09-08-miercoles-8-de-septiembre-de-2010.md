---
title: Miércoles 8 de Septiembre de 2010
author: admin

date: 2010-09-08T14:08:48+00:00
url: /2010/miercoles-8-de-septiembre-de-2010/
tags: [Mensajes 2010]

---
**Dice la Santísima Virgen:** Hijos Míos Benditos y amados hijos Míos. Gracias por responder a Mi llamado. Benditos seáis vosotros que estáis en éste momento junto a la Madre. Derramo en vosotros, pequeños hijitos Míos todas las Gracias que estáis necesitando.

Estoy con vosotros, mostrándoos Mi Inmaculado Corazón de Madre, porque Mi Corazón es puente, para que todos lleguéis a Cristo Jesús Mi Hijo Amadísimo.

Estoy con vosotros hijitos Míos, y llevo en Mi Corazón Inmaculado, vuestro corazones, corazones angustiados, doloridos, tristes.

Mi Corazón de Madre, está con vosotros, Mi Corazón de Madre os atiende, os escucha. Mi Corazón de Madre hace descender en vosotros las bendiciones del cielo.

Hijitos Míos, hijitos amadísimos, aprovechad éste tiempo, estos días en que la Madre está junto a vosotros.

Aquí he puesto Mis Pies, en ésta la Santa Fe. Aquí he puesto Mi Hogar definitivo, en ésta la Santa Fe, en esta Argentina, Santa y Bendita, que debe volver a los brazos del Señor, que debe volver a ley del Señor, que debe volver  a la luz y salir de la oscuridad.

Vosotros tenéis una tarea importante: Rezad Todos Vosotros. Rezad, así lo desea Dios Nuestro Señor.

Éste es el tiempo, el tiempo de que seáis soldados valerosos, fuertes, no temerosos, Sino: fuertes, para defender, para luchar, para dar testimonio ante el mundo entero.

Meditad, cada una de Mis Palabras. Y recordad, que María está con vosotros, que María, permanece a vuestro lado, que María os bendice permanentemente.

**Meditad. Meditad. Meditad Mis Palabras.”**

**Dice Jesús:** “Hermanos Míos, benditos y amados hermanos Míos, abrid vuestro corazón para recibir Mí Sacratísimo Corazón, abrid vuestro corazón para que entre Mi Amor a reinar en vosotros, para que entre Mi Paz y Mi Verdad a iluminar vuestras almas.

Abrid el corazón a Mis Palabras y avanzad cada día en la verdad, avanzad junto a Mí, porque os llevo de Mí Mano.

Porque estoy con vosotros, bendiciendo, derramando gracias, derramando abundantes gracias, en cada uno de vosotros.

Os amo a todos por igual, os amo a todos. Y vosotros debéis amaros unos a otros, como hermanos que sois, debéis comprenderos unos a otros, debéis dar testimonio en el mundo entero de cada una de Mis palabras.

Os bendigo abundantemente, porque quiero que estéis permanentemente a Mi Lado.

Os hablo de Mi Amor, os hablo de Mi Paz, os hablo siempre de Mi Verdad, porque la verdad os hace libres, porque la verdad desata y rompe las cadenas del adversario.

Estoy aquí, estoy con vosotros, estoy en el mundo entero, estoy llamando e invitando a la conversión a todas las almas.

Doy la paz al mundo entero, que el mundo hoy reciba mi Paz, que el mundo encuentre Mí paz,  que el mundo viva en paz, en la verdadera paz.

Os hablo de Mi Amor  y de Mi Divina Misericordia, os hablo de Mi Paz Eterna. Encontrad Mi Paz, recibid Mi Paz, aceptad Mi Paz.

**Meditad. Meditad. Meditad Mis Palabras.**

**Os bendigo en el Nombre del Padre, y del Hijo, y del Espíritu santo. Amén.”**

**  
** 

&nbsp;

&nbsp;