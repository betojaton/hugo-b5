---
title: Lunes 8 de Marzo de 2010
author: admin

date: 2010-03-08T13:49:24+00:00
url: /2010/lunes-8-de-marzo-de-2010/
thumbnail: /images/santisima_trinidad-1.png
tags: [Mensajes 2010]

---
**<img decoding="async" loading="lazy" class="size-full wp-image-779 alignright" title="santisima_trinidad" src="https://mariadelasantafe.org.ar/images/santisima_trinidad.png" alt="santisima_trinidad" width="336" height="429" />Dice la Santísima Virgen:** Hijos míos; benditos y amados hijos míos. Acudid en todo momento a ésta Madre. Acudid a Mi Corazón Inmaculado, y dejad que ésta Madre os transforme. Dejad que Mi Corazón de Madre, seque las lágrimas y el dolor de vuestro corazón. Quiero que todos vengáis a Mí; porque aquí tenéis a la Madre, que abre Su Manto Celestial para cobijaros a cada uno de vosotros.

Mis palabras, no pueden quedar archivadas. Mis enseñanzas, Mis advertencias, deben ser conocidas por el mundo entero.

Os agradezco a vosotros, pequeños hijitos Míos, que respondéis a mi llamado; que estáis escuchando Mis Palabras. Dadlas al mundo entero, a todos Mis Hijos.

Renovad, cada día la esperanza, y la fe. Y pedid, pedid con insistencia. Porque el Señor, bendice a Su Pueblo. Porque el Señor, bendice a Sus Hijos. Porque Dios Nuestro Señor, da a cada momento, infinitas pruebas de Su tags:
	- Mensajes Presencia. Da infinitas oportunidades, a todos los hijos del mundo.

Que los hijos pues, sepan aprovechar éste tiempo de Gracia. Éste tiempo tan especial. Que los hijos sepan aprovechar, éste momento tan especial, que la Madre os regala. No perdáis pues los días, las horas, los minutos, en vanidades y  trivialidades.

Esforzaos cada día, levantaos cada día, del pecado; y acercaos al Corazón Sacratísimo de Jesús. Que os bendice, que os ama, que os da la paz.

Mis palabras, son enseñanza, y quiero que todos vosotros, seáis auténticos mensajeros de Mi tags:
	- Mensajes Presencia en  ésta, **_EN LA SANTA FE, LA NUEVA JERUSALEM._** El nuevo faro, para el mundo entero. El nuevo faro, que iluminará a todas las almas del mundo.

¡Predicad! Predicad al mundo entero Mi tags:
	- Mensajes Presencia. Comunicad, al mundo entero Mi tags:
	- Mensajes Presencia.

**Escuchad con atención, Mis pedidos de Madre: que no queden archivadas Mis Palabras.** 

**Dadlas a conocer.**

**Meditad. Meditad. Meditad Mis Palabras.**

**Dice Jesús:** Hermanos Míos: Benditos y amados hermanos míos. Os doy Mi Sacratísimo Corazón. Os doy, Mi Divina Misericordia. Os señalo, el camino de Mi Amor. Que es el camino de la verdad. Os señalo Mi Camino. Quiero que estéis junto a Mí; y que cada uno de vosotros, cargue su cruz.

¡Yo estoy con vosotros! ¡No estáis solos! ¡No estáis desamparados! ¡No estáis a la deriva! Mi Corazón Sacratísimo está con vosotros. En todo momento.

Permanentemente, éste Corazón, que da la paz al mundo; que da la enseñanza, al mundo; que da la oportunidad, al mundo.

¡Rezad! Y ofreced, verdaderamente sacrificios, por las almas más alejadas de Mi Amor. Por las almas, más sumergidas en el pecado. Por las almas más encadenadas a sus vicios y a las tinieblas.

Sois vosotros Mis ovejas; y quiero que Mis Hijos ¡Mis Hijos ¡¡predilectos ¡ Mis Hijos predilectos! En ésta tierra, construyan y levanten El Templo en Honor a la Santísima Trinidad.

¡Creed en Mí! Porque os amo. Creed en Mi tags:
	- Mensajes Presencia real junto a vosotros.

Soy el Buen Pastor. Soy el Pastor de todas las ovejas. Escuchad Mis Palabras. Atended a Mis Palabras. Meditad, cada una de Mis Palabras.

**Meditad. Meditad. Meditad Mis palabras.** 

&nbsp;

**Os bendigo, en el Nombre del Padre, y del Hijo, y del Espíritu Santo. Amén.**

&nbsp;