---
title: Miércoles 8 de Diciembre de 2010
author: admin

date: 2010-12-08T14:16:25+00:00
url: /2010/miercoles-8-de-diciembre-de-2010/
tags: [Mensajes 2010]

---
**Le dice la Santísima Virgen:** “Hijos míos, benditos y amados hijos míos, vengo a consolar como Madre vuestro corazón dolorido,    a secar vuestras lágrimas, vengo  a daros como Madre la fuerza para que sigáis el camino, hijitos míos aquí tenéis a la Madre, acudid a la Madre en todo momento, no os desesperéis, confiad en el Señor, confiad en su Providencia. Hijitos míos, rezad, y así vuestro corazón verá la luz, rezad y así cada uno de vosotros veréis el camino. Aquí está la Madre junto a cada uno de vosotros, os tomo de la mano para que avancéis por éste camino, os tomo de la mano para que no perdáis el rumbo. Sentid vosotros el perfume de Mis rosas, sentid hijitos míos Mí presencia maternal con vosotros, en vuestros hogares, en vuestras familias. Avanzad cada  día en la verdad, avanzad cada día en la justicia, trabajad cada día, todos los días con amor, con entrega y con mucha generosidad ese es el pedido de esta Madre.

Vengo a convocaros a todos vosotros, para que deis testimonio en el mundo entero, vengo a convocaros a todos vosotros para que meditéis Mis palabras y las deis al mundo entero, sentid vosotros Mí presencia maternal.

Hijitos míos, no temáis aquí está la Madre que os cobija a todos bajo su manto celestial, meditad Mis palabras, Mis profundas palabras, meditadlas en lo profundo de vuestro corazón.

**Meditad. Meditad. Meditad. Mis palabras.”**

**Le dice Jesús:** “Hermanos míos, benditos y amados hermanos míos os entrego nuevamente Mí paz, os ilumino con la luz de Mí Sacratísimo Corazón, os doy la paz  profunda para vuestros corazones, sentid Mí presencia en vosotros, sentid Mi real  presencia en vuestros corazones, os toco con Mis manos sacratísimas en forma especial en este día para devolveros la paz, para haceros sentir Mí paz. Mis palabras son paz, Mis palabras sanan, Mis palabras os conducen, vosotros estáis en Mi camino, vosotros estáis en Mí rebaño, porque  son Mis ovejas escucháis Mi voz, escuchad pues atentamente, meditad profundamente cada una de Mis Palabras, os hablo de Mí amor, os hablo de Mí paz, os hablo de mí infinita Misericordia. Que nadie dude pues de Mis palabras, que nadie tema pues todos debéis llegar a Mí, todos debéis acudir a Mí, estoy dándoos signos  y señales de Mí presencia, que el mudo escuche Mí voz, que la humanidad por entero escuche Mí voz, que los corazones que hoy están sumergidos en el odio, en la rivalidad, en la oscuridad escuchen también Mi voz. Que nadie se aparte de Mí lado, porque a todos os recibo, porque a todos os abrazo, a todos os amo por igual, doy Mí infinita misericordia a todas las almas en el mundo entero, que el hombre hoy no deje pasar éste momento tan especial, que los corazones no dejen pasar de lado éste momento tan, tan especial para el mundo entero.

Os amo. Os amo, os amo sois Mis ovejas, os amo venid a Mí, llegad a Mí. Creed en Mí, os amo.

**Meditad. Meditad. Meditad Mis palabras.**

**Os bendigo en el Nombre del Padre y del Hijo y del Espíritu Santo. Amén.”**

&nbsp;