---
title: Domingo 8 de Agosto de 2010
author: admin

date: 2010-08-08T14:06:05+00:00
url: /2010/domingo-8-de-agosto-de-2010/
tags: [Mensajes 2010]

---
**Dice la Santísima Virgen:** Hijos Míos; benditos y amados hijos Míos. Hago descender en éste día, sobre vosotros ¡Miles de bendiciones! Derramo en vosotros, todas las GRACIAS que estáis necesitando. Desde el cielo traigo estas GRACIAS para vosotros; para vuestros corazones; para vuestras familias; para vuestras comunidades. Vengo como Madre, a llamar a todos los hijos. ¡A buscar a Mis hijos!  A reunir a mis hijos. En un solo rebaño. El rebaño, que pertenece a Cristo Jesús, Mi Hijo Amadísimo. ¡Quiero la oración de todos los corazones! ¡Quiero la unidad, en los corazones! ¡Quiero la paz de los corazones! ¡Buscad, cada día la paz! ¡Vivid cada día en paz! ¡Sembrad la paz!; allí donde hay división, donde hay error, donde hay rivalidad. ¡Llevad la paz, a los corazones afligidos! ¡A las almas angustiadas! ¡Socorred vosotros, hijitos Míos! A todos los enfermos! ¡A las almas que están doloridas! ¡A las almas que están sufriendo!  ¡Socorred vosotros, pequeños hijitos Míos! ¡A todas esas almas! Y llevadle, el mensaje de ésta Madre. ¡El mensaje de amor! ¡El mensaje de paz ¡El mensaje de luz!

Vosotros pequeños hijitos Míos, debéis vivir en la luz. En la luz que os transmite Cristo Jesús Mi Hijo Amadísimo. Debéis ¡vivir en la luz! ¡En la luz de la GRACIA!¡Irradiad la luz de vuestro corazón!¡A éste mundo ciego!¡A éste mundo, que está en la oscuridad!¡A éste mundo sumergido en el pecado!

¡Hijitos! ¡Hijitos Míos! Os encomiendo ésta tarea. ¡Aquí está la Madre del cielo! ¡Aquí está la Madre de Jesús! Junto a vosotros, en todo momento; en todo lugar. Vengo a conduciros, a vosotros, por éste camino; a enseñaros a caminar. Para que así, el mundo se convierta. Para que así  las almas, conozcan la salvación.

Rezad! Todos los días, el Santo Rosario. ¡Rezad! ¡No os canséis, de rezar! Porque Dios Nuestro Señor, ¡Escucha a todos los hijos! ¡Socorre a todos los hijos! ¡Ningún hijo, queda desamparado, de la Mano Misericordiosa del Señor!

¡Atended a ésta Madre, en estos tiempos! ¡Llevad Mis Mensajes! ¡Llevad Mis Palabras Maternales a todos los hijos! ¡A todos los rincones de la tierra!

**Meditad. Meditad. Meditad Mis Palabras.**

**Dice  Jesús:** Hermanos Míos; benditos y amados hermanos Míos. Derramo en vostoros Mi Amor.¡Derramo el fuego abrazador de Mi Amor! ¡Mi Amor purifica! ¡Mi Amor sana! ¡Mi Amor libera! ¡Mi Amor desata tantas cadenas! ¡Todas las cadenas! ¡Mi Amor, os purifica completamente! ¡Buscad Mi Amor! ¡Dejad que Mi Amor os transforme! ¡Abandonad, todo el pasado! ¡Todo lo oscuro! Y vivid en éste tiempo, que estáis recibiendo con la abundante Misericordia de Mi Sacratísimo Corazón. ¡Os amo a todos por igual! ¡Os reúno a todos, en Mi Sacratísimo Corazón! ¡Os abrazo, infinitamente, con éste Corazón, que nunca cesa de amar! ¡Que jamás cesa de amaros! ¡Os amo a todos por igual! ¡Os abrazo a todos por igual! ¡Y MI Preciosísima Sangre se derrama en vosotros! ¡Porque Mi Sangre, os libera! ¡Porque, Mi Sangre, os fortalece! ¡Porque, Mi Sangre, os muestra el camino! ¡Todos debéis, seguir el camino de la luz! ¡Todos debéis llevar el Mensaje de la Luz, a todas las almas! Sois ¡Mis pequeñas ovejas! ¡Sois Mis ovejas! ¡Sois verdaderamente, las ovejas, que estáis en Mi corral! ¡Os hablo de amor! ¡Os hablo de caridad! ¡Os hablo de verdad! ¡Os hablo de paz!

Que el mundo conozca hoy, Mi Paz. Que el mundo conozca hoy, Mi Verdad. ¡Que la humanidad encuentre Mi Luz a tiempo! ¡Que todas las almas, encuentren hoy, Mi Luz a tiempo!  ¡Os envío a vosotros! ¡A todos vosotros! ¡Os envío, a todas las almas! ¡Llevad, a las almas, éste Mensaje de amor! ¡Llevad, a los corazones, éste Mensaje de esperanza! ¡De esperanza para toda la humanidad!

¡Creed en Mis Palabras! ¡En Mi tags:
	- Mensajes Presencia Real con vosotros! ¡Estoy con vosotros siempre! ¡Eternamente, presente entre vosotros! ¡Creed en Mis Palabras! ¡Y llevadlas, a todos los hombres, del mundo entero!

**Meditad. Meditad. Meditad Mis Palabras.**

**Os bendigo, en el Nombre del Padre, y del Hijo, y del Espíritu Santo. Amén.**

&nbsp;