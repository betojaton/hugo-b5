---
title: Jueves 8 de Abril de 2010
author: admin

date: 2010-04-08T13:52:27+00:00
url: /2010/jueves-8-de-abril-de-2010/
tags: [Mensajes 2010]

---
**Dice la Santísima Virgen:** Hijos míos; benditos y amados hijos míos; escuchad a ésta Madre. Prestad atención a Mis palabras. Meditad Mis palabras profundamente.

Os hablo del Amor del Señor. Os hablo de la Misericordia del Señor; para con el mundo entero. Os vengo a hablar de la verdad, de la luz y de la paz. De la paz, de la luz y de la verdad, que están en Cristo Jesús Mi Hijo Amadísimo.

Avanzad con la Madre, todos vosotros, en la unidad, en la paz, en la verdad. Avanzad con la Madre, y no detengáis la marcha. Sacad del corazón los malos pensamientos. Sacad del corazón, todo aquello, que os impide el caminar.

Escuchad Mis palabras, profundamente. Creed en Mis palabras, y que todos Mis hijos, conozcan verdaderamente, que tienen aquí, a ésta Madre, que viene a hablaros, que viene a enseñaros, que viene a mostraros, cada día el camino.

Rezad, pequeños hijitos míos. Rezad por el mundo entero; por la conversión de los pecadores. Rezad profundamente y uníos al Corazón de ésta Madre. Uníos por el Rosario, a Mi Inmaculado Corazón. Creed en Mis palabras, en cada una de ellas. Son para vosotros, son para el mundo entero.

**Meditad. Meditad. Meditad Mis Palabras.**

 ****

**Dice Jesús:** Hermanos Míos; benditos y amados hermanos míos. Derramo en vosotros, Mi Divina Misericordia. Derramo en vosotros, Mi paz. Derramo en vosotros, Mi amor.

Vengo a liberaros, de las cadenas. Vengo a liberaros, a cada uno de vosotros, de tantas ataduras. Vengo a  despertar vuestro corazón dormido. Vuestro espíritu dormido. Para que seáis testigos de Mi tags:
	- Mensajes Presencia; mensajeros de Mi tags:
	- Mensajes Presencia, en el mundo entero.

Vengo a hablaros de Mi amor; a mostraros Mi Sacratísimo Corazón, herido y traspasado por amor a vosotros.

¡No os sintáis indignos! Y que Mis palabras obren en vuestro corazón. Que Mis palabras modelen vuestro corazón. Que Mis palabras os muestren, a cada uno de vosotros el camino.

Os amo a todos por igual. ¡Os amo a todos! No separo a Mis hermanos. No separo a Mis ovejas; uno a todas las ovejas. Convoco a todas las ovejas. Llamo a todos los hombres, a vivir en la verdad; a vivir en la Gracia; a vivir en la luz.

Os muestro la luz de Mi Sacratísimo Corazón. Mirad Mi Sacratísimo Corazón. Mirad Mis Ojos. Mirad Mis Sacratísimas Llagas.

Os amo. Os amo. Os amo.

**Meditad. Meditad. Meditad Mis Palabras.**

**Os bendigo, en el Nombre del Padre, y del Hijo, y del Espíritu Santo. Amén**

&nbsp;