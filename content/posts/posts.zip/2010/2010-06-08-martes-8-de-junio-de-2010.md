---
title: Martes 8 de Junio de 2010.
author: admin

date: 2010-06-08T13:56:43+00:00
url: /2010/martes-8-de-junio-de-2010/
thumbnail: /images/corazon-de-jhs-1.png
tags: [Mensajes 2010]

---
**Dice la Santísima Virgen:** Hijos Míos; benditos y amados hijos Míos. Vengo como Madre nuevamente; a enseñaros a todos el camino. Vengo a traeros la luz de Jesús para vuestros corazones. Muchos de los cuales están hoy en la oscuridad. Vengo a traer la luz de Jesús, para que todos caminéis en la verdad. Para que todos escuchéis Mis palabras, atentamente, y las pongáis en práctica. Vengo a llamar nuevamente a la oración. Que todos Mis hijos, se vuelquen a la oración pidiendo por la paz del mundo. Por la paz de todas las naciones. Fundamentalmente por la paz de los corazones. Si no hay paz en los corazones no habrá nunca paz en el mundo. No habrá nunca, paz, que reine definitivamente. Por eso pido hoy como Madre: LA CONVERSIÓN .INSISTO EN LA CONVERSIÓN. Y quiero que todos vosotros, enseñéis, a vuestros hermanos, a buscar el camino correcto. Ya basta de odio. Ya basta de rencor. Es tiempo de amor. Tiempo de verdad.

Veis hijitos Míos, que el mundo, cada vez más, se hunde; a causa del pecado; a causa del odio. Y vosotros debéis luchar; con todas las armas justas. Debéis luchar. Para que reine siempre la verdad. Para que reinen las leyes de verdad en todas las naciones. Sois testigos, de la tags:
	- Mensajes Presencia Celestial de María con vosotros. Aquí está María llamando a los hijos, del mundo entero, llamando a los corazones. Vosotros sois testigos y debéis transmitir Mis Palabras a todo el mundo. Vengo hablando a todos los hijos. Hablo a todos los hijos. Mi Corazón de Madre, no pone nunca barreras. Las barreras, las ponen Mis propios hijos.

Os pido, hijitos Míos, os pido a cada uno de vosotros, seguid rezando, continuad con la oración. Acercaos con frecuencia, a la Santa Misa y a los Sacramentos. Acercaos a recibir el Cuerpo y la Sangre de Cristo Jesús Mi Hijo Amadísimo. Acercaos y no temáis. Porque la Madre os sostiene. Porque la Madre os cubre con Su Manto Celestial.

Venid a ésta Madre, y llegaréis al Hijo. Acudid a la Madre y encontraréis al Hijo. Escuchad Mis palabras de Madre y comprenderéis profundamente las palabras del Hijo.

**Que Mis Palabras sean meditadas por todos vosotros.** 

**Ponedlas en práctica. No la archivéis en el corazón. Ponedlas en práctica.**

**Meditad. Meditad. Meditad Mis Palabras.**

**<img decoding="async" loading="lazy" class="size-full wp-image-973 alignright" title="corazon-de-jhs" src="https://mariadelasantafe.org.ar/images/corazon-de-jhs.png" alt="corazon-de-jhs" width="255" height="255" />Dice Jesús:** Hermanos Míos; benditos y amados hermanos Míos. Os muestro Mi Sacratísimo Corazón. Os doy Mi Sacratísimo Corazón. Os doy Mi Paz a vosotros.

La luz de Mi Divina Misericordia, se derrama en vosotros para señalaros el camino de la paz, de la conversión. La Luz dMi Divina Misericordia transforma los corazones, mueve los corazones. Emblandece los corazones tan cerrados a Mis palabras.

La Luz de Mi Divina Misericordia viene a traer consuelo, a las almas angustiadas; a los corazones doloridos. La Luz de Mi Divina Misericordia, trae bálsamo para todas las almas. Para las almas más heridas; para las almas más desesperadas.

Mis Palabras. Son Amor. Mis Palabras. Son verdad. Mis Palabras. Son enseñanza para cada uno de vosotros. Son enseñanzas para todas las naciones, iluminan a todos los corazones y muestran a las almas el camino a seguir. Seguid el camino de la verdad, el camino del amor, el camino de la paz. Seguid el camino que os propone, Mi Sagrado Corazón. Mi Sacratísimo Corazón. Seguid el camino auténtico, y no desviéis la mirada, hacia el mundo y hacia las pasiones terrenales. Seguid el camino de Mi Amor, de Mi Verdad, de Mi Paz. Mirad Mi Corazón. Mirad Mi Sagrado Rostro. Mirad Mis Ojos. Que os miran a vosotros y os invitan hoy nuevamente a la conversión. Creed en Mi tags:
	- Mensajes Presencia. Estoy con vosotros siempre, en cada momento, a cada instante. Os escucho, os atiendo y vuelco en vosotros, a manos llenas todo Mi Amor. Mi Amor no tiene límites. Mi Amor, Mi Amor es eterno. Mi Amor pasa por todas las barreras. Mi Amor derrite el hielo de los corazones. Mi Amor derriba las murallas. MI Amor ilumina, ilumina al mundo entero, ilumina a todos los corazones.

Dejaos, pues, iluminar por Mi Amor.  Dejaos conducir por Mi Amor .Dejaos transformar por Mi Amor. Dejad que os libere, que os sane, que os purifique, que os transforme verdaderamente hoy, en hombres nuevos.

Meditad Mis Palabras, profundamente. Meditadlas y creed; creed definitivamente en Mi tags:
	- Mensajes Presencia.

**Meditad. Meditad. Meditad Mis palabras.**

**Os bendigo en el Nombre del Padre, y del Hijo, y del Espíritu Santo. Amén.**

&nbsp;