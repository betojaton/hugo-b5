---
title: Mensaje, Lunes 3 de mayo 2010
author: admin

date: 2010-05-04T00:03:21+00:00
url: /2010/mensaje-lunes-3-mayo-2010/
thumbnail: /images/jesus-corazon-luminoso-1.jpg
tags: [Mensajes 2010]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/wp-content/uploads/2003/09/virgen_corazon.png" alt="virgen_corazon" class="alignright size-full wp-image-777" />

> Hijos Míos; benditos y amados hijos Míos. Vengo a traeros a vosotros la paz. Vengo a traeros el consuelo. Vengo a sanar las heridas de vuestro corazón. Y, a daros fuerza, para que todos avancéis. Vengo como Madre, a escuchar vuestras intenciones. Vengo a consolar a los tristes. Vengo a dar; una nueva oportunidad, a todos Mis hijos.  
> Mis hijos deben escuchar a ésta Madre. La humanidad debe escuchar a ésta Madre. Y, por medio de Mi Corazón Inmaculado; LLEGAR A Cristo Jesús, Mi Hijo Amadísimo.  
> Estoy cumpliendo LA MISIÓN EN EL MUNDO ENTERO. Estoy llevando a cabo, ésta tarea, en el mundo entero.
> 
> Pido a Mis hijos: la conversión.
> 
> Pido a toda la humanidad: la conversión.
> 
> Pido a Mis hijos Predilectos, los sacerdotes; un poco más de humildad. Un poco más de entrega, un poco más de obediencia.
> 
> Y vosotros, pequeños hijitos Míos, debéis estar atentos a Mis Palabras. Debéis escuchar Mis Palabras. Y hacerlas germinar en vuestro corazón. ¡No seáis plantas estériles!¡No seáis tierra estéril! Sed verdaderamente, tierra fértil. Plantas que den fruto para los hermanos.  
> Recordad éstas palabras: ”Por los frutos os reconocerán”. Si ponéis, verdaderamente vuestro corazón en éstas palabras, iréis día a día madurando, y creciendo. Como lo desea DIOS NUESTRO SEÑOR”POR LOS FRUTOS, OS RECONOCERÁN.”, AQUÍ, Y EN EL MUNDO ENTERO.  
> Entonces ¿Qué esperáis? Trabajad y valorad Mis Palabras para estos tiempos; para vosotros, para el mundo entero.  
> Escuchad a la Madre.
> 
> Seguid el camino de la Madre. Seguid Mis Pasos. 

Meditad. Meditad. Meditad Mis Palabras.

<img decoding="async" src="https://mariadelasantafe.org.ar/images/jesus-corazon-luminoso.jpg" alt="jesus-corazon-luminoso" class="alignright size-medium wp-image-4125" /> 

> Hermanos Míos; benditos y amados hermanos Míos. ¡Que ya nadie cuestione Mis Palabras!¡Que ya nadie en el mundo, niegue Mis Palabras!  
> Porque llamo hoy a todos Mis hermanos, a la verdad. Llamo a todos Mis hermanos, a la verdad. Llamo a toda la humanidad ¡a vivir en la verdad! ¡a vivir en la paz!¡a vivir en la luz!
> 
> Hablo, para que todos los corazones, vean a tiempo; la luz de Mi Divina Misericordia.  
> Hablo, para que todas las almas, conozcan profundamente, el Amor de Mi Sacratísimo Corazón.  
> ¡No hay barreras! ¡No hay piedras! ¡No hay, verdaderamente murallas! Que el hombre quiera poner, y que los hermanos, si lo desean de corazón, no las puedan atravesar.  
> Porque abro Mi Corazón, de par en par. A todas las almas; doy Mi Amor a manos llenas, a todas las almas. Doy Mi Luz Misericordiosa, a todos los corazones. Para sacaros de la ceguera. Para sacaros del letargo. Para sacaros de la ignorancia.  
> Os amo a todos. Os amo.¡ Y jamás lo dudéis! Jamás verdaderamente, lo dudéis. Os amo a todos. Creedlo profundamente así.  
> Meditad. Meditad. Meditad Mis Palabras.<footer>Leed : Salmo 24.</footer> 

Os bendigo, en el Nombre del Padre, y del Hijo, y del Espíritu Santo. Amén.