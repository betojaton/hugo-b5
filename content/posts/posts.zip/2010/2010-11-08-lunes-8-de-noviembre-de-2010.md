---
title: Lunes 8 de Noviembre de 2010.
author: admin

date: 2010-11-08T14:14:51+00:00
url: /2010/lunes-8-de-noviembre-de-2010/
tags: [Mensajes 2010]

---
**Dice la Santísima Virgen:** “Hijos Míos: benditos y amados hijos Míos. Vengo como Madre a consolaros. Vengo desde el cielo, a traeros el Mensaje del Señor. Derramo en vosotros y en éste día, abundantes bendiciones.

Quiero que lleguéis a ésta Madre, quiero que cada día 8 estéis con la Madre.

Aquí se hace presente María, para estar con los hijos. Os invito hijitos míos a vivir en la paz. Os invito hijitos míos a que sigáis el camino de Jesús, a que avancéis por el camino de la luz, a que avancéis por el camino de la verdad.

Aquí se manifiesta esta Madre. Vengo  desde el cielo, hijitos míos para pedir, a todos los corazones la oración, que todos los hijos se unan en oración, por la paz del mundo, por la paz de los corazones.

Que Mis hijos ya no cuestionen Mis palabras, que Mis hijos, no cierren las puertas a Mi tags:
	- Mensajes Presencia.

Mis lágrimas caen abundantemente y tengo innumerables espinas en Mi Corazón, cuando los hijos rechazan la Mano Misericordiosa del Señor, cuando los hijos se apartan del verdadero camino y se encierran en la oscuridad del pecado.

Hijitos míos, estad junto a la Madre, hijitos míos, caminad con la Madre, no os sintáis solos,  porque aquí está María, porque la Madre está con vosotros siempre.

Os hablo de conversión todos los días, porque quiero que la humanidad, encuentre la salvación y llegue a la Vida Eterna.

Hijitos míos, recibid Mis palabras en vuestro corazón, recibid Mis enseñanzas, recibid Mis mensajes y que el mundo entero los conozca, que todos los hijos conozcan que tienen aquí a ésta Madre. Permaneced en la luz, difundid la luz, irradiad la luz a todos los corazones, y en especial, a las almas que están en la oscuridad, del pecado.

**Vivid en la Gracia, hijitos míos, vivid cada día en la Gracia.** 

**Aquí está la Madre, aquí está María con cada uno de vosotros.**

**Meditad. Meditad. Meditad Mis palabras.”**

**Dice Jesús:** “Hermanos Míos: benditos y amados hermanos Míos, os entrego nuevamente Mi Sacratísimo Corazón, os doy la fuerza para vuestros corazones.

Toco en éste momento, con Mis manos, vuestros corazones, derramo en vosotros, ahora, Mi Divina Misericordia, Mi paz, Mi luz.

Vosotros debéis seguir Mi camino, debéis avanzar junto a Mí y sentir que Mi Corazón Sacratísimo, os libera, os purifica, os fortalece. Os hablo hoy de Mi amor, os hablo de Mi paz y de Mi verdad. Os hablo, para que enseñéis a las almas, a vivir en la verdad.

El mundo, debe conocer Mi paz, los hombres deben conocer Mi paz, la humanidad debe ver Mi luz, debe reconocer  Mi luz de amor, Mi luz que salva, Mi luz que libera.

Hablo a todos los corazones, a todos Mis hermanos, a toda la humanidad, hablo a todas las naciones, que la humanidad vuelva hacia Mí, que los hombres vuelvan hacia Mí. Esforzaos, cada día, por vivir en la GRACIA. Trabajad, cada día, para vivir, en la GRACIA.

No temáis, estoy con vosotros en la barca, y vosotros sois Mis ovejas. Estoy con vosotros, aún en medio de las más fuertes tormentas, estoy con vosotros en la barca, no temáis y permaneced juntos, permaneced, verdaderamente en la luz, permaneced en la verdad. Derramo Mi paz, en éste momento, derramo el bálsamo de Mis Sacratísimas Llagas, en éste momento, sobre cada uno de vosotros.

No os sintáis indignos, he recibido cada una de vuestras palabras, he recibido en Mi Corazón, cada  una de vuestras peticiones.

No temáis, permaneced junto a Mí, porque estoy con vosotros, siempre. Permaneced firmes junto a Mí, porque a vuestro lado está, Mi Sacratísimo Corazón.

**Meditad. Meditad. Meditad Mis palabras.**

**Os bendigo en el Nombre del Padre, y del Hijo y del Espíritu santo. Amén.”**

&nbsp;