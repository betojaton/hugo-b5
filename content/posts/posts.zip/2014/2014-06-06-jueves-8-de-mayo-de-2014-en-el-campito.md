---
title: Jueves 8 de Mayo, 2014 en el “Campito”
date: 2014-06-06T11:09:32+00:00
url: /2014/jueves-8-mayo-2014-en-el-campito/
thumbnail: /images/biblia-rosario-byn-1.jpg
audio:
  - /wp-content/themes/mdstafe2013/audio/2014/08-05-2014.mp3
fecha-audio:
  - 08-05-2014
tags: [Mensaje, Mensajes Presencia]

---
![Titulo Imagen](/images/biblia-rosario-byn.jpg)
**Dice la Santísima Virgen:** “Hijos Míos benditos y amados hijos Míos, gracias por encontraros nuevamente con esta Madre, por estar aquí a los pies de esta Madre que viene a escuchar vuestras peticiones y vuestras intenciones.

Esta Madre que se manifiesta con cada uno de sus hijos, conduciendo a todos los hijos hacia Jesús, esa es Mi tarea maternal, llevar a los hijos hacia Jesús hacia la luz y la verdad que está en Cristo Jesús Mi Hijo Amadísimo.

Hijitos, aquí está María. María de La Santa Fe está junto a vosotros, en vuestras familias, está presente en vuestros hogares.  
Esta madre está con los hijos que lloran, con los hijos que sufren, con los hijos que están abandonados.

Mi amor maternal llega a todos los corazones y a todas las almas. Mi protección maternal está sobre todos los hijos. Escuchad a esta Madre, seguid, seguid a esta Madre porque la Madre es el puente directo hacia Cristo Jesús Mi Hijo Amadísimo.

Abrid vuestras manos, recibid el Rosario que tengo en Mis manos y ponedlo en vuestro corazón y allí hijitos Míos, recordad cada una de Mis palabras, todas Mis palabras y en todo momento sentid la presencia maternal de María con cada uno de sus hijos.

Meditad. Meditad. Meditad Mis palabras.”

**Dice Jesús:**  
“Hermanos Míos, benditos y amados hermanos Míos, escuchad Mis palabras, sentid Mis palabras en vuestro corazón y sentid Mi paz en lo profundo de vuestra alma. Sentid Mi presencia real en vuestros corazones. Mi presencia que llega para sanar y fortalecer vuestras almas.

Estáis junto a Mi y vuelco en vosotros todo Mi amor y sobre toda la humanidad vuelco a manos llenas Mi amor y Mi Divina Misericordia.

Y aún así hay muchas almas y muchos corazones que no se acercan hacia este camino, que no difunden la luz de Mi Sacratísimo Corazón.

Pongo Mis manos sobre vuestras cabezas, pongo Mis manos para daros fuerzas y para sanaros y para que sintáis siempre Mi paz y Mi amor en vuestras almas.

Gozad de Mi presencia, sentid Mi presencia, sentid el calor profundísimo que irradia Mi Sacratísimo Corazón hacia vuestras almas, para despertaros del adormecimiento, de la inercia y para que caminéis siempre en la luz y en la verdad, para que caminéis en la Gracia.

No bajéis los brazos, jamás bajéis los brazos, seguid siempre rezando, no bajéis los brazos y acudid siempre hacia Mí. No abandonéis el rebaño, permaneced junto a Mí.

Sed fieles al llamado y sentid a cada momento Mi presencia entre vosotros.

Os Amo a todos, Os Amo, Os Amo, Os Amo.

Meditad. Meditad. Meditad Mis palabras.

Os Bendigo en el Nombre del Padre y del Hijo y del Espíritu Santo. Amén.”

> Junio conmemoramos el mes del Sagrado Corazón de Jesús.