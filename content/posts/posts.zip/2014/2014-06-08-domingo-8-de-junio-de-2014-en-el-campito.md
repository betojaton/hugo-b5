---
title: Domingo 8 de Junio, 2014 en el “Campito”
date: 2014-06-08T18:51:01+00:00
url: /2014/domingo-8-junio-2014-en-el-campito/
thumbnail: /images/maria-rosas-1.png
audio:
  - /wp-content/themes/mdstafe2013/audio/2014/08-06-2014.mp3
fecha-audio:
  - 08-06-2014
tags: [Mensaje, Mensajes Presencia]
---
<![Titulo Imagen](/images/maria-rosas.png)

**Dice la Santísima Virgen:** “Hijos Míos benditos y amados hijos Míos, gracias por estar nuevamente junto a esta Madre. Esta Madre hoy os bendice a todos vosotros de una forma especial. Esta Madre hace descender en vosotros una lluvia de rosas sobre vuestros corazones.  
Hijitos Míos, abrid vuestras manos nuevamente recibid Mi Rosario y llevadlo a vuestro corazón. Hijos Míos, hijitos escuchad el mensaje de María, el mensaje que esta Madre trae para toda la humanidad el mensaje de conversión.

Los hijos deben vivir en la luz, Jesús es la luz, Cristo Jesús Mi Hijo Amadísimo es el único camino, es la verdad y la vida.  
Hijitos Míos, enseñad a las almas, rezad hijitos Míos todos los días, para que haya paz en todas las Naciones y en todos los corazones. No os olvidéis jamás de los sacramentos, acercaos a la confesión, acercaos a recibir a Jesús que se hace presente en cada Eucaristía.

No os olvidéis hijitos Míos que esta Madre siempre está a vuestro lado. Que os viene a conducir, que os viene a llevar de la mano hacia el Señor. Cada una de Mis palabras debe ser meditada profundamente en vuestro corazón todos los días de vuestras vidas, cada palabra debe estar en vuestro corazón, y vosotros debéis dar al mundo, enseñar al mundo y comunicar al mundo, la presencia de **María de la Santa Fe** con todos Sus hijos.

Aquí es la Nueva Jerusalén, Argentina el Nuevo Israel. Esta Nación que brillará en la luz. Que verá la luz, a su debido tiempo.  
Vosotros rezad, todos los días rezad, y meditad profundamente cada una de Mis palabras.

Meditad. Meditad. Meditad Mis palabras.”

**Dice Jesús:** “Hermanos Mío, benditos y amados hermanos Míos pongo Mi mano en vuestro corazón, para sanaros, para fortaleceros, pongo Mi mano sobre vuestras cabezas para daros fuerza para seguir Mi camino. Pongo Mi mano nuevamente en vuestro corazón para que sintáis todos vosotros Mi amor en lo más profundo de vuestro corazón.  
Sois Mis ovejas, y os pido que sigáis Mi camino, que sigáis Mis pasos, que no os apartéis jamás de Mi lado. Os amo profundamente, y vuelco sobre vosotros, Mi Divina, Mi Eterna Misericordia.  
Vivid en la luz .Vivid en la verdad, sed mensajeros de la luz y de la verdad. No os quedéis en el camino. Avanzad siempre hacia adelante. Avanzad y veréis HIJOS MÍOS Y HERMANOS MÍOS, veréis la luz de Mi Sacratísimo Corazón.

Os amo a todos. Os amo profundísimamente. No os sintáis indignos. Os amo eternamente. Venid a Mí si estáis agobiados. Venid a Mí si estáis cansados y no dudéis jamás de Mi presencia y de Mi amor hacia cada uno de vosotros.

Mirad siempre Mis ojos. Mirad Mi rostro y encontraréis la Paz para vuestras vidas. No os sintáis indignos. Estoy aquí con vosotros, porque os amo, porque amo a toda la humanidad por igual, a todas las almas, a todos los corazones.

Sentid Mi presencia a vuestro lado. Sentid Mi presencia con vosotros. Os amo. Os amo. Os amo.

Meditad. Meditad. Meditad Mis Palabras.

Os bendigo en el Nombre del Padre. Y del Hijo y del Espíritu Santo. Amén.”