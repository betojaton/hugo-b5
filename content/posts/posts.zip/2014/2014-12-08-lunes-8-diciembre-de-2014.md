---
title: Lunes, 8 Diciembre de 2014

date: 2014-12-08T12:13:30+00:00
url: /2014/lunes-8-diciembre-de-2014/
thumbnail: /images/espiritu-santo-1.jpg
tags: [Mensaje tags:
	- Mensajes Presencia]

---
**Dice la Santísima Virgen:**  
“Hijos Míos, benditos y amados hijos Míos, llegad a Mi regazo maternal, llegad a Mis brazos maternales, porque esta Madre viene a cobijaros a vosotros, porque esta Madre se manifiesta con sus hijos, porque esta Madre esta presente consolando los corazones afligidos, sosteniendo a las almas abatidas, llenando de paz a los corazones perturbados La Madre esta aquí y habla a todos los hijos por igual. La Madre viene a reunir a los hijos en un solo rebaño, esa es Mi tarea, es Mi misión y pido de Mis hijos, de todos Mis hijos una autentica colaboración, un trabajo arduo todos los días. Hijitos trabajad cada día, hay tantas almas que están caminando errantes en el mundo, hay tantos corazones que están divagando en el mundo y necesitan hoy de vuestras palabras, de vuestro ejemplo, de vuestra entrega total hacia ellos. El Señor os fortalece en esta tarea, el Señor os da la fuerza para que sigáis su camino, para que jamás os apartéis de la luz, para que viváis siempre en la luz y cuando las tinieblas sacudan vuestro corazón, vuestra mente, vuestro espíritu recordad que esta la Madre, defendiéndoos, protegiéndoos, dándoos a todos la fuerza, la fuerza necesaria para que os volváis a levantar, no bajéis los brazos, no bajéis, no desesperéis, confiad hijitos míos confiad en la presencia del Señor junto a cada uno de vosotros.  
Meditad. Meditad. Meditad. Mis palabras.”

<img decoding="async" loading="lazy" src="https://mariadelasantafe.org.ar/images/espiritu-santo-1.jpg" alt="espiritu-santo" width="300" height="199" class="alignright size-medium wp-image-740" /> **Dice Jesús:**  
Hermanos Míos, benditos y amados hermanos Míos os ofrezco, Mi corazón, os ofrezco toda Mi paz, estáis abatidos, cansados, agobiados os ofrezco Mi paz, os entrego Mi paz para sanar vuestras heridas, estoy guiándoos, conducíos, estoy dándoos Mi paz, Mi verdadera paz, Mi eterna paz, no debéis apartaros de mi lado , debéis permanecer junto a Mi, debéis estar junto al pastor que viene a cuidar a sus ovejas, que viene a conducir a cada oveja hacia verdes praderas. Venid a Mi, no dejéis Mi camino. Vivid cada día con la Luz de Mi corazón. Sentid verdaderamente en vosotros Mi presencia, Mi amor, Mis palabras. Sentid en lo profundo de vuestro corazón, éste amor que os ofrezco gratuitamente a todos. Os amo profundamente, profundísimamente.  
Os amo y no debéis sentiros indignos. Confiad más en Mí. Confiad y no bajéis los brazos frente a las pruebas y dificultades. Estoy siempre no lo dudéis, estoy siempre entre vosotros, estoy aquí siempre eternamente con cada uno de Mis hermanos, con cada uno de Mis Hijos.  
Meditad. Meditad. Meditad Mis palabras.

Os bendigo en el nombre del Padre y del Hijo y del Espíritu Santo. Amén.”