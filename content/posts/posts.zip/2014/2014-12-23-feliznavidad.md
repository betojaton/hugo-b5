---
title: Feliz Navidad!

date: 2014-12-23T20:38:02+00:00
url: /2014/feliznavidad/
thumbnail: /images/navidad2014-web-1.gif
tags: [Notas]

---
<img decoding="async" loading="lazy" class="aligncenter size-full wp-image-2697" src="https://mariadelasantafe.org.ar/images/navidad2014-web.gif" alt="navidad2014-web" width="716" height="227" />