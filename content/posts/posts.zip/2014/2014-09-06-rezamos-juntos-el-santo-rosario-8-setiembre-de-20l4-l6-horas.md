---
title: Rezamos juntos el Santo Rosario, 8 setiembre, 20l4 – l6 horas.

date: 2014-09-06T21:26:23+00:00
url: /2014/rezamos-juntos-el-santo-rosario-8-setiembre-de-20l4-l6-horas/
thumbnail: /images/post-rezar-08092014-1.jpg

---
[<img decoding="async" loading="lazy" class="alignnone size-medium wp-image-2576" src="https://mariadelasantafe.org.ar/images/post-rezar-08092014.jpg" alt="&quot;ELEVEMOS NUESTRO CORAZON A DIOS&quot; - Rezamos juntos el Santo Rosario el día 8 setiembre 20l4, a las l6 horas. Lugar: Avda. Alte Brown y Regis Martinez -Santa Fe" width="368" height="368" />][1]

 [1]: https://mariadelasantafe.org.ar/images/post-rezar-08092014.jpg