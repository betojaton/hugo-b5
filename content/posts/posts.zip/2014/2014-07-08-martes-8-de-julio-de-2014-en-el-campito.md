---
title: Martes, 8 de Julio de 2014 en el “Campito
date: 2014-07-08T12:02:34+00:0
url: /2014/martes-8-de-julio-de-2014-en-el-campito/
thumbnail: /images/jesus-reunido-con-ninios-1.jpg
audio:
  - /wp-content/themes/mdstafe2013/audio/2014/08-07-2014.mp3
fecha-audio:
  - 08-07-2014
tags:
  - Mensaje 2014
  - Mensajes Presencia

---
![jesus-reunido-con-ninios](https://mariadelasantafe.org.ar/images/jesus-reunido-con-ninios.jpg)
**Dice la Santísima Virgen María:**
“Hijos Míos; benditos y amados hijos Míos, aquí nuevamente está la Madre con vosotros, soy María de la Santa Fe, la Madre que viene hacia los hijos, a conducir a cada hijo hacia Jesús. Soy la Madre, que está con todos los hijos del mundo, la reina de la Santa Fe, de la fe de Mis hijos, “María de la Santa Fe”.  
Estoy pidiendo a los corazones la conversión, estoy pidiendo a cada hijo la conversión y la oración.  
Mis hijos del mundo deben llegar a Jesús, la humanidad debe encontrarse con Jesús, Mis hijos no deben apartarse de la oración y de los Sacramentos. Mis hijos del mundo deben escuchar con atención el Mensaje que os trae la Madre del Cielo.

No bajéis los brazos, aun en medio de las más grandes dificultades, no bajéis los brazos, y recordad que esta Madre permanece siempre a vuestro lado.  
Hijitos Míos, abrid el corazón al Mensaje del Señor, y haced floreced el Jardín que el Señor ha puesto en vuestros corazones.  
Vivid en la luz, en la verdad, sed mensajeros de la luz y de la verdad, y apartad las tinieblas que tantas veces rodean vuestro corazón. Tened fe, confiad y rezad todos los días el Santísimo Rosario. No os olvidéis de las promesas que esta Madre os trae a cada uno de vosotros.

Meditad. Meditad. Meditad Mis palabras.”

**Dice Jesús:**  
“Hermanos Míos, benditos y amados hermanos Míos, estoy con vosotros, estoy aquí, estoy siempre. Mi Corazón está sobre vosotros, Mi Corazón Sacratísimo os bendice en forma especial, y os da la paz para vuestras almas. Acudid a Mí, llegad a Mí, refugiaos en Mi corazón, para hallar la paz, para encontrar la paz, para que viváis en paz. Creed en Mis palabras, y dejad que conduzca vuestras vidas, vuestros corazones y os haga cada día más dóciles a Mi amor.

Derramo Mi amor, Mi Divina Misericordia, sobre vosotros y el mundo entero, sobre toda la humanidad, que debe escuchar Mi voz y acercarse a la luz de la verdad. Os amo. Os amo. Os amo y quiero que el mundo escuche con atención, cada una de Mis palabras.

No os apartéis de Mi lado, permaneced junto a Mí, creed en Mi presencia y dejad que os transforme a diario.

Abrid vuestras manos, recibid Mi Sacratísimo Corazón, llevadlo a vuestro corazón y sentid cada día Mi presencia en vosotros.

Sed fieles al llamado que habéis recibido. No tapéis la luz del sol con vuestra mano, mirad la luz del sol de Mi Sacratísimo Corazón y encontraréis respuesta, encontraréis la paz, encontraréis el consuelo.

Venid a Mí, llegad a Mí, creed en Mí. Os amo. Os amo. Os amo a todos por igual.

Meditad. Meditad. Meditad Mis palabras.

Os bendigo en el Nombre del Padre y del Hijo y del Espíritu Santo. Amén.”