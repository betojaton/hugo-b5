---
title: La Visitación de la Virgen María

date: 2014-05-09T00:15:26+00:00
abstract: '<img src="https://mariadelasantafe.org.ar/wp-content/uploads/2014/05/virgen-isabel.jpg" alt="virgen-isabel" width="200" height="272" class="alignright size-full wp-image-2477" />Luego que María Santísima oyó del ángel Gabriel que su prima Isabel también esperaba un hijo, sintiéndose iluminada por el Espíritu Santo, comprendió que debería ir a visitar a aquella familia y ayudarles y llevarles las gracias y bendiciones del Hijo de Dios que se había encarnado en Ella. Fue María la que se adelantó a saludar a Isabel puesto que es la Virgen María la que siempre se adelanta a dar demostraciones de cariño a quienes ama...'
url: /2014/visitacion-la-virgen-maria/
thumbnail: /images/virgen-isabel-1.jpg
tags: [Notas]

---
<img decoding="async" loading="lazy" src="https://mariadelasantafe.org.ar/images/virgen-isabel.jpg" alt="virgen-isabel" width="200" height="272" class="alignright size-full wp-image-2477" />Luego que María Santísima oyó del ángel Gabriel que su prima Isabel también esperaba un hijo, sintiéndose iluminada por el Espíritu Santo, comprendió que debería ir a visitar a aquella familia y ayudarles y llevarles las gracias y bendiciones del Hijo de Dios que se había encarnado en Ella. Fue María la que se adelantó a saludar a Isabel puesto que es la Virgen María la que siempre se adelanta a dar demostraciones de cariño a quienes ama.

Por medio de la visita de María llevó Jesús a aquel hogar muchos favores y gracias: el Espíritu Santo a Isabel, la alegría a Juan, el don de Profecía, etc., los cuales constituyen los primeros favores que nosotros conocemos que haya hecho en la tierra el Hijo de Dios encarnado. San Bernardo señala aquí que desde entonces María quedó constituida como un &#8220;Canal inmenso&#8221; por medio del cual la bondad de Dios envía hacia nosotros las cantidades más admirables de gracias, favores y bendiciones.