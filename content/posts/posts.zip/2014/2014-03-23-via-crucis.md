---
title: Video Vía Crucis de “María de la Santa Fe”
date: 2014-03-23T17:24:05+00:00
url: /2014/via-crucis/
tags:
  - Notas
---
#### Primera Parte del Vía Crucis
[![Primera Parte del Vía Crucis]
(https://img.youtube.com/vi/ZZt71oNP1SM/mqdefault.jpg)]
(https://www.youtube.com/watch?v=ZZt71oNP1SM)


#### Segunda Parte del Vía Crucis
[![Segunda Parte del Vía Crucis]
(https://img.youtube.com/vi/yYVyJte9zfs/mqdefault.jpg)]
(https://www.youtube.com/watch?v=yYVyJte9zfs)


#### Tercer y Ultima Parte del Vía Crucis
[![Tercer y Ultima Parte del Vía Crucis]
(https://img.youtube.com/vi/ACc644TNpa4/mqdefault.jpg)]
(https://www.youtube.com/watch?v=ACc644TNpa4)