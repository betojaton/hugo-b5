---
title: Viernes 15 de Agosto – La Asunción de la Virgen María

date: 2014-08-16T00:32:17+00:00
url: /2014/viernes-15-de-agosto-asuncion-virgen-maria/
thumbnail: /images/virgen-asuncion-1.jpg

---
[<img decoding="async" loading="lazy" class="size-medium wp-image-2559 aligncenter" src="https://mariadelasantafe.org.ar/images/virgen-asuncion.jpg" alt="virgen-asuncion" width="311" height="420" />][1]

En este día de la Asunción festejamos lo que María hace con nosotros todos los días: llevarnos a Dios. Este es su cuidado materno, el motivo de su intercesión constante, el interés de su <span class="text_exposed_show">bondad.<br /> Hoy vemos como Ella, nuestra hermana por ser humana, nuestra madre por encomienda divina, se va a donde pertenecemos todos los cristianos. Como una madre que se aleja de su niño unos pasos para decirnos: “ven, camina hacia mí, y llegarás a El”.</span>

_Reflexión del Evangelio de:_  
_Pbro.Lic. Mauro Carlorosi, C.O._

 [1]: https://mariadelasantafe.org.ar/images/virgen-asuncion.jpg