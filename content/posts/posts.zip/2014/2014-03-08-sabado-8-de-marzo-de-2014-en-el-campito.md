---
title: Sábado 8 de marzo, 2014 en el “Campito”
date: 2014-03-08T11:03:41+00:00
url: /2014/sabado-8-de-marzo-de-2014-en-el-campito/
thumbnail: /images/jesus-entrando.jpg
audio:
  - /wp-content/themes/mdstafe2013/audio/2014/08-03-2014.mp3
tags: 
  - Mensajes 2014
  - Mensajes Presencia
---
![Titulo Imagen](/images/jesus-entrando.jpg)

**Dice la Santísima Virgen:**  
“Hijos Míos, benditos y amados hijos Míos, gracias por estar con la Madre. Hago descender sobre vosotros una lluvia de rosas, hago descender sobre vosotros gracia sobre gracia.

Os doy hijitos Míos Mi Rosario, pongo en vuestras manos Mi Rosario, para que vosotros, todos los días, recéis por la paz del mundo, por las familias, por los corazones que hoy están cegados por el odio.

Hijos Míos, hijitos Míos, aquí está la Madre llamando a sus hijos a la conversión, llamando a todos los corazones a la conversión. Mi corazón de Madre está con los hijos, con los hijos que sufren, con los hijos necesitados, con los hijos enfermos. La Madre está con todos los hijos, nadie queda desamparado.

Mi Manto Celestial os cubre, os protege y os resguarda de las insidias del malvado, rezad entonces como lo pide Mi Inmaculado Corazón. Rezad y trabajad, el mundo necesita de vuestras palabras, de vuestro ejemplo, de vuestro testimonio, el mundo necesita de vuestra entrega. El Señor os quiere obreros, os quiere trabajadores firmes y soldados decididos.

No bajéis los brazos jamás y seguid luchando todos los días de vuestra vida. Recordad que la Madre está siempre junto a cada uno de vosotros.

Meditad. Meditad. Meditad Mis palabras.”

**Dice Jesús:**  
“Hermanos Míos, benditos y amados hermanos Míos, os doy Mi paz, sentid Mi paz en vuestros corazones, sentid Mi presencia en vuestros corazones.  
Aquí estoy. Estoy junto a vosotros, os vengo a acompañar y a guiar, vengo a conduciros, no debéis temer porque Mi Corazón Sacratísimo es la luz y la verdad, es la paz y el consuelo.

No temáis.

No bajéis los brazos y sentid que Mis palabras hoy os transforman, os hacen hombres nuevos.  
Os amo a todos por igual y todos estáis junto a Mí porque sois Mis ovejas.  
Que el mundo ya no dude de Mis palabras, que el mundo, que toda la humanidad, se acerque a la fuente de GRACIA DE MI DIVINA MISERICORDIA.  
Estoy aquí, no lo dudéis. Os amo profundísimamente. Seguid Mi camino, Mis pasos, cada uno tome su cruz y me siga. No os olvidéis de Mis palabras y de Mis promesas.

Os amo profundísimamente y pongo en éste momento Mis manos sobre vuestras cabezas, Mis manos para sanaros. Mis manos para fortaleceros. Mis manos para que sintáis Mi profunda paz en vuestro corazón.

Sed fieles al llamado. No bajéis jamás los brazos. Sed fieles. Os amo. Os amo. Os amo.

No os sintáis indignos. Os amo

Meditad. Meditad. Meditad Mis palabras.

Os bendigo en el nombre del Padre, y del Hijo y del Espíritu Santo. Amén.”