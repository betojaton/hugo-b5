---
title: La Inmaculada Concepción de María

date: 2014-12-08T13:29:16+00:00
url: /2014/la-inmaculada-concepcion-de-maria/
thumbnail: /images/inmaculada-conepcion-maria-e1418070909103-1.jpg
tags: [Notas]

---
<img decoding="async" loading="lazy" class="alignright  wp-image-2648" src="https://mariadelasantafe.org.ar/images/inmaculada-conepcion-maria-e1418070909103.jpg" alt="inmaculada-conepcion-maria" width="192" height="299" />La Inmaculada Concepción de María es el dogma de fe que declara que por una gracia especial de Dios, ella fue preservada de todo pecado desde su concepción.

El dogma fue proclamado por el Papa Pío IX el 8 de diciembre de 1854, en su bula Ineffabilis Deus: &#8220;&#8230;declaramos, proclamamos y definimos que la doctrina que sostiene que la beatísima Virgen María fue preservada inmune de toda mancha de la culpa original en el primer instante de su concepción por singular gracia y privilegio de Dios omnipotente, en atención a los méritos de Cristo Jesús Salvador del género humano, está revelada por Dios y debe ser por tanto firme y constantemente creída por todos los fieles&#8230;&#8221; (Pío IX, Bula Ineffabilis Deus, 8 de diciembre de 1854)