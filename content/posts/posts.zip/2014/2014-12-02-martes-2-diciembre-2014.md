---
title: Martes 2 diciembre de 2014

date: 2014-12-02T15:11:41+00:00
url: /2014/martes-2-diciembre-2014/
thumbnail: /images/Sermon5-270x270-2.jpg
tags: [Mensajes]

---
<img decoding="async" loading="lazy" src="https://mariadelasantafe.org.ar/images/Sermon5-270x270-1.jpg" alt="cruz-madera-cielo-luz" width="270" height="270" class="alignright size-full wp-image-2674" />**Le dice la Santísima Virgen a Vicente:**

“Vicente hijo mío: María es la Madre que señala el camino a sus hijos, María es el puente a lo que los hijos deben acudir para llegar a Jesús, la Madre es el puente, la unión entre los hijos y Cristo Jesús, Mi Hijo Amadísimo.  
Lluvia de bendiciones caen en este suelo bendito, perforado y herido por tanto dolor y tantas divisiones inútiles, la Madre cumple su misión, ningún hijo debe interponerse en mi camino de llegar a todas las almas.  
Meditad Mi Mensaje.  
Amén. Gloria al Altísimo.  
Leed: Jonás: C 2 V 6 al 9  
Predícalo a todos tus hermanos.”

**Le dice la Santísima Virgen a Vicente:**

“Vicente hijo mío: Grandes cosas esperan a esta Nación, grandes bendiciones llegan para esta Nación que debe salir de la arrogancia, la prepotencia y los enfrentamientos, grandes luces iluminan el Cielo de este pueblo reservado para Dios, aquí hay una gran esperanza para el mundo entero, no queden cerradas vuestras bocas, no queden estériles vuestros corazones, es el tiempo de trabajar en la tierra.  
Meditad este Mensaje  
Amén. Gloria al Corazón de Jesús  
Leed: 1era San Pedro: C 1 V 3 y 4  
Predícalo”