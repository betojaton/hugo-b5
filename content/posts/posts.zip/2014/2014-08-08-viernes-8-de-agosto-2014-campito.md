---
title: Viernes 8 de Agosto, 2014 en el “Campito”
date: 2014-08-08T11:11:45+00:00
url: /2014/viernes-8-agosto-2014-campito/
thumbnail: /images/corazon-sagrado01-e1410107393820-1.jpg
tags:
- Mensajes 2014
- Mensajes Presencia

---
[![jesus-corazon-sagrado](/images/corazon-sagrado01-e1410107393820.jpg)]

#### Dice Jesús:

“Hermanos Míos, benditos y amados hermanos Míos, Mis manos están sobre vosotros, sentid Mi Presencia y sentid que Mi Corazón Sacratísimo os toca en forma especial. Sentid Mi voz que os llama, que os invita a la conversión. Sentid la voz del buen pastor, del buen pastor que está junto a sus ovejas, del buen pastor que viene a cuidar a sus ovejas, y las ovejas, todas las ovejas deben escuchar la voz del buen pastor.  
Escuchad, escuchad, escuchad, y sentid en lo profundo de vuestro corazón, el amor inconmensurable de Mi Sacratísimo Corazón.  
La humanidad debe volver a Mí, todos los hombres deben volver a mí y encontrar la paz en mi Sacratísimo Corazón. Dejad que os transforme a través de Mi Divina Misericordia, dejad que el amor de Mi Sacratísimo Corazón os vaya modelando, os vaya guiando, os vaya señalando el camino.  
Sentid, sentid Mi amor profundísimo por cada uno de vosotros, olvidad el pasado, olvidaos del pasado y vivid en éste presente. Olvidaos del pasado y vivid este tiempo de amor, de misericordia y de paz que os entrego a cada uno de vosotros, que entrego a toda la humanidad.  
Todos Mis hermanos, todos por igual deben escuchar, deben sentir Mi voz, deben acercarse a Mí, porque no separo, porque no divido, porque no desuno, porque Mi corazón une a las almas. Es el hombre con sus leyes el que separa, el que divide el que dispersa a las ovejas, por eso os hablo a todos vosotros, para que transforméis vuestras vidas, para que os hagáis hombres nuevos, para que la luz que os entrego en forma especial en vuestro corazón la deis al mundo y a los hombres, a vuestros hermanos.  
Buscad a las almas, buscad a los que sufren, buscad a los que están tristes, a los que están desesperados, buscad, id hacia el mundo, porque las almas, todas las almas os necesitan.  
Dad vuestros talentos para el mundo, entregad al mundo vuestro amor, convertíos en servidores, sed verdaderos prójimos entre vosotros. Vivid con amor, dad el saludo al hermano, dad el corazón al hermano, dad vuestras vidas al servicio de todos los hombres, de toda la humanidad. Trabajad por amor, por el amor y con la paz que os da Mi Sacratísimo Corazón. Que ya nadie dude de Mi Presencia, que ya nadie rechace Mi Presencia, que toda la humanidad se acerque a Mí y encontrará la definitiva paz, la auténtica paz, la verdadera paz.  
Os amo. Os amo. Os amo y pongo Mis manos nuevamente sobre vuestras cabezas, sentid, sentid que Mis manos os sanan, que Mis manos os están liberando, os están fortaleciendo. No dudéis de Mi amor hacia cada uno de vosotros, no lo dudáis jamás.  
Meditad. Meditad. Meditad Mis palabras.  
Os bendigo, en el Nombre del Padre y del Hijo y del Espíritu Santo. Amén.”

#### 21-08-14

**Le dice la Santísima Virgen a Vicente:**

“Vicente hijo mío: Los corazones deben estar atentos para escuchar la voz de Dios, Nuestro Señor, atentos y dispuestos a seguir al Señor en su camino, mis hijos hoy todos deben despertar y dejarse conducir por la Mano del Señor que dá a todos una nueva oportunidad, a cada instante el Señor brinda a sus hijos una nueva oportunidad, no lo olvidéis,  
Meditad Mi Profundísimo Mensaje.  
Amén. Gloria a Cristo Jesús

<address>
  Leed: Hechos C 12, V 7 al 10<br /> Predícalo a todos tus hermanos.”
</address>

<address>
   
</address>

<address>
  Hechos C 12, V 7 al 10<br /> 7 “Y he aquí que se presentó un ángel del Señor, y una luz resplandeció en la cárcel; y tocando a Pedro en el costado, le despertó, diciendo: Levántate pronto. Y las cadenas se le cayeron de las manos.<br /> 8 Le dijo el ángel: Cíñete, y átate las sandalias. Y lo hizo así. Y le dijo: Envuélvete en tu manto, y sígueme.<br /> 9 Y saliendo, le seguía; pero no sabía que era verdad lo que hacía el ángel, sino que pensaba que veía una visión.<br /> 10 Habiendo pasado la primera y la segunda guardia, llegaron a la puerta de hierro que daba a la ciudad, la cual se les abrió por sí misma; y salidos, pasaron una calle, y luego el ángel se apartó de él.”
</address>

#### 30-08-14

**Le dice la Santísima Virgen a Vicente:**

“Hijo mío, los corazones están tan alejados de Dios, Nuestro Señor, tan sumergidos están los corazones en el materialismos la ambición, cegados por el poder y las riquezas y se olvidan de lo esencial y fundamental, la salvación eterna de sus almas.  
Como Madre vengo hacia mis hijos para llamar a todos los corazones a vivir en la luz de la gracia y apartarse definitivamente de las sombras del abismo que trata de engullir a todas las almas, mis hijos no pueden ni deben abandonar la oración para hacer frente a los embates del enemigo que por todos los medios lucha para quitarme a las almas de mi lado, de mi regazo maternal.  
Rezad el Rosario os lo pido, rezad hijos míos el Rosario para que hagáis una muralla que el adversario no pueda atravesar.  
Meditad Mi Profundísimo Mensaje  
Amén. Gloria a Cristo Jesús

<address>
  Leed: 2da Tesalonicenses: C 2, V 4 al 7<br /> Hazlo conocer a tus hermanos.”
</address>