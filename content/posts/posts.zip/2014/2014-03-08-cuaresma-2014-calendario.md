---
title: Cuaresma 2014 – Calendario
date: 2014-03-08T20:21:34+00:00
url: /2014/cuaresma-2014-calendario/
thumbnail: /images/200414-dgopascua-1.jpg
tags:
  - Notas

---

![050314-miercolesceniza](/images/050314-miercolesceniza.jpg) 
05/03/2014 – Miércoles de Ceniza 2014: El Miércoles de Ceniza es para los católicos día de ayuno y abstinencia, se realiza la imposición de la ceniza a los fieles que asisten a Misa. Da inicio a la “Cuaresma”.
![090314-primerdgo](/images/090314-primerdgo.jpg) 
09/03/2014 – Primer Domingo de Cuaresma 2014: El 9 de Marzo de 2014 es “Primer Domingo de Cuaresma.
![100314-primerlunes](/images/100314-primerlunes.jpg) 
10/03/2014 – Primer Lunes de Cuaresma 2014: El 10 de Marzo de 2014 es el “Primer Lunes de Cuaresma”.
![250314-anunciacionarcangel](/images/250314-anunciacionarcangel.jpg) 
25/03/2014 – Anunciación del Arcángel Gabriel a la Santísima Virgen María: La fiesta de la Anunciación de la Virgen María se celebra nueve meses antes de la Natividad de Cristo. Es la celebración del anuncio del nacimiento de Cristo hecho a la Virgen María.
![060414-dgopasion](/images/060414-dgopasion.jpg) 
06/04/2014 – Domingo de Pasión 2014: El 6 de Abril de 2014 es “Domingo de Pasión”.
![110414-viernesdolores](/images/110414-viernesdolores.jpg) 
11/04/2014 – Viernes de Dolores 2014: El “Viernes de Dolores” es el viernes anterior al Domingo de Ramos, comprendido dentro de la última semana de la Cuaresma.
![120414-sabadopasion](/images/120414-sabadopasion.jpg) 
12/04/2014 – Sábado de Pasión 2014: La víspera del “Domingo de Ramos”, día en que se inicia la Semana Santa, recibe el nombre de “Sábado de Pasión”, un día que no debe ser confundido con el “Sábado Santo”.
![130414-dgoramos](/images/130414-dgoramos.jpg) 13/04/2014 – Domingo de Ramos 2014: Es el primer día de la Semana Santa, se conmemoran la Pasión, Muerte y Resurrección de Jesús. Las ceremonias litúrgicas comienzan con la bendición de las palmas y ramas de olivo que llevan los fieles. De este modo se rememora el pasaje evangélico de la Entrada de Jesús en Jerusalén.
![170414-juevessto](/images/170414-juevessto.jpg) 
17/04/2014 – Jueves Santo 2014: El Jueves Santo, se celebra el jueves anterior al Domingo de Resurrección, en el transcurso de la Semana Santa cristiana. En este día se recuerda la última cena de Jesús, y la Iglesia Católica conmemora la institución de la Eucaristía.
![190414-sabadosto](/images/190414-sabadosto.jpg) 1
9/04/2014 – Sábado Santo 2014: El sábado Santo (ó Sábado de Gloria) es el día de espera litúrgica por excelencia, de espera silenciosa junto al sepulcro, que se manifiesta con la ausencia de celebraciones o símbolos visibles en las iglesias.
![200414-dgopascua](/images/200414-dgopascua.jpg) 
20/04/2014 – Domingo de Pascua 2014: El Domingo de Resurrección (ó Domingo de Pascua) es la fiesta más importante para todos los cristianos, que conmemoran la Resurrección de Jesús.