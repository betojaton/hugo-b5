---
title: Martes 8 de abril, 2014 en el “Campito”
date: 2014-04-08T23:31:30+00:00
url: /2014/martes-8-abril-2014-en-el-campito/
thumbnail: /images/jesus-dabeber-leproso-1.jpg
audio:
  - /wp-content/themes/mdstafe2013/audio/2014/08-04-2014.mp3
tags: [Mensaje 2014, Mensajes Presencia]
---

![Imagen Virgen con Niños](/images/virgen-con-ninios.jpg)

**Dice la Santísima Virgen:**  
“Hijos Míos; benditos y amados hijos Míos, aquí nuevamente está la Madre junto a vosotros, la Madre que os viene a acompañar y a guiar, la Madre que os guía y acompaña cada día de vuestra vida; la Madre que conduce a vuestros corazones hacia Jesús.

La Madre está con los hijos con todos los hijos del mundo, la Madre pide a los hijos la conversión y la unidad.

Mis hijos del mundo deben escuchar hoy el Mensaje de María y volver por medio de Mi Inmaculado Corazón hacia Cristo Jesús Mi Hijo Amadísimo.

No tengáis miedo hijitos Míos y rezad mucho en estos tiempos tan difíciles para el mundo, rezad mucho y sed mensajeros y difusores de Mis palabras maternales.

Estoy hijitos Míos, con cada uno de vosotros, en vuestros hogares, con vuestras familias, estoy siempre presente escuchando a todos los hijos, atenta a las necesidades de cada uno de Mis hijos.

Escuchad a María que se manifiesta en esta tierra Santa y Bendita, en esta Santa Fe, La Nueva Jerusalén. No bajéis los brazos y seguid trabajando por Mi Santa Obra.

Meditad. Meditad. Meditad Mis palabras.”

![jesus-dabeber-leproso](/images/jesus-dabeber-leproso.jpg)
**Dice Jesús:**  
“Hermanos Míos: benditos y amados hermanos Míos, vuelco en vosotros Mi Divina Misericordia, vuelco en vosotros todo Mi amor en vosotros y en vuestros corazones, para sanar las heridas, vuelco Mi amor para que vosotros viváis en el amor y en la paz.

Para que deis la mano a los hermanos que están más alejados, para que deis vuestro corazón a los hermanos que están sufriendo.

Os amo a todos por igual porque todos estáis en Mi rebaño, porque todos sois Mis ovejas y Mi corazón no separa a ninguno.

Os hablo de Mi amor, de Mi paz y de Mi verdad, porque el hombre debe hoy vivir en el amor en la paz y en la verdad. Los corazones deben alejarse de la mentira y de los ídolos falsos y vivir  
bajo la luz de Mi Sacratísimo Corazón.

La humanidad debe percibir la luz de Mi Sacratísimo Corazón y destruir definitivamente los ídolos falsos que han ganado tanto terreno.

Os Amo. Os Amo. Os Amo. Creed en Mis palabras, en Mi presencia y en Mi Divina Misericordia.

Os invito a ser mensajeros de Mi amor, mensajeros de todas Mis palabras, mensajeros de toda Mi paz.

Trabajad, no os canséis, trabajad y no dudéis jamás de Mi presencia junto a cada uno de vosotros.

Recibid en vuestro corazón Mi paz, recibid en vuestro corazón Mi amor, recibid en vuestro corazón Mi verdad. No temáis. No temáis. No temáis, sois Mis ovejas.

Os Amo a todos, Os Amo infinitamente a todos.

Meditad. Meditad. Meditad Mis palabras.

Os Bendigo en el Nombre del Padre y del Hijo y del Espíritu Santo. Amén.”