---
title: Mensaje, Lunes 10 de Octubre, 2014
date: 2014-10-10T11:22:32+00:00
url: /2014/mensaje-lunes-10-octubre-2014/
thumbnail: /images/img-corpus-christi.jpg
---
![foto-campito-paloma](/images/foto-campito-paloma.jpg) 

**Dice la Santísima Virgen:** > Hijos Míos; benditos y amados hijos Míos; nuevamente María está con Sus hijos; nuevamente María viene hacia los hijos; nuevamente María trae las palabras del cielo para sus hijos, para todos los hijos del mundo entero. 

Mis hijos deben escuchar, Mis hijos deben aprender a caminar; Mis hijos, todos Mis hijos, deben tener en sus corazones, el amor y la verdad.¡Aquí está la Madre, con los hijos! ¡Aquí está la Madre con todos los corazones! Ayudando, consolando, socorriendo. ¡Hay tantos hijos en el mundo que no conocen esta verdad! Que no conocen esta rea-lidad.Vosotros hijitos Míos sois bendecidos y privilegiados; ¡Sois tan afortunados! Porque tenéis este regalo que viene del cielo. 

Aprovechad entonces, estos días, estos momentos, estas horas tan valiosas; y rezad mucho, rezad, ¡porque hay tantas almas, y hay tantos corazones que están completamente alejados de la verdad; que están seducidos por el enemigo, y siguen los pasos del maligno! ¡Rezad entonces! Rezad mucho; y pedid siempre para voso-tros la luz del Espíritu Santo, para cada una de vuestras decisiones. 

> No dejéis de lado ninguno de Mis palabras. 

Meditad. Meditad. Meditad Mis Palabras.

![img-jesus-hablando](https://mariadelasantafe.org.ar/images/img-jesus-hablando.jpg) 
**Dice Jesús:** > Hermanos Míos; benditos y amados hermanos Míos; estáis junto a Mí, estáis como Mis Discípulos, en torno a Mí; estáis escuchando Mis palabras, os veo a vosotros, veo vuestro corazones, veo vuestras intenciones.

Estoy dándoos a todos, siempre y a cada instante, una nueva oportunidad. > ¡Jamás dejéis que el dolor, que el rencor, se anide en vuestro corazón!¡Jamás! Sentid, entonces, a cada instante, Mis palabras, Mi Presencia, Mi amor. Sentid verdaderamente que Mis manos os tocan y os sanan, os liberan y os fortalecen. ¡NodudéisjamásdeMiamorhaciavosotros!¡Os amo infinitamente, y os llamé en forma especial y por vuestros nombres; y os traje hacia Mi lado. Os atraje con la luz de Mi Sacratísimo Corazón.

Hay muchas piedras que han sido corridas, hay muchas piedras que han sido destruidas, el camino está libre; avanzad por este camino avanzad y no dudéis jamás de éste amor Misericordioso, que os doy a cada uno de vosotros.¡Cuando estéis cansados, venid a Mí! ¡Cuando estéis doloridos, venid a Mí! Cuando vuestras fuerzas se acaben, venid a Mí. Las pruebas, las cruces, los dolores, son purificación y para que todos deis fruto, para todo0s deis el mismo fruto para las almas. 

El fruto que deis, debe ser para el mundo, para vuestros hermanos, para la salvación de todas las almas. ¡Dad fruto en abundancia! ¡No cerréis vuestras bocas!¡No sintáis vergüenza de Mí! ¡No os avergoncéis de Mis Palabras! ¡Hablad, predicad, anunciad al mundo Mi Presencia! Con vuestra palabra, con vuestro testimonio, porque todos dijisteis ¡SI! Todos pusisteis la mano en éste arado, y debéis trabajar la tierra, que se os ha dado a cada uno de vosotros; la tierra que debe producir y en abundancia, el fruto para el mundo entero. 

Os amo. Os amo. Os amo. 

¡Creed en Mí, sentid Mi Presencia! ¡En este momento! ¡YA! MIRAD MI ROSTRO, AQUÍ ESTOY, MIRAD, MIRAD MIS OJOS, MIRAD, AQUÍ ESTOY. 

Os amo. Os amo. Os amo a todos profundamente. 
Os amo.Meditad. Meditad. 

> Meditad Mis Palabras.

*Leed :Salmo 60.*

Os bendigo en el Nombre del Padre, y del Hijo y Espíritu Santo. Amén.