---
title: Bautismo de Jesús
date: 2014-01-08T20:42:03+00:00
url: /2014/bautismo-de-jesus/
thumbnail: /images/jesus-bautizando-1.jpg
tags:
  - Notas

---
### Domingo 12 de Enero de 2014

![Titulo Imagen](/images/jesus-bautizando.jpg)
La “Festividad del Bautismo del Señor” se celebra el domingo siguiente a la “Epifanía”, con la que se culmina el ciclo de Navidad. Este día se conmemora el Bautismo de Jesús en el río Jordán, por parte de Juan Bautista.

Jesús, que vino de Galilea al río Jordán donde estaba Juan, para ser bautizado por él. Pero Juan trataba de impedírselo diciendo: “Soy yo el que necesita ser bautizado por ti, ¿y tú vienes a mí?” Jesús le respondió: “Déjame ahora, pues conviene que así cumplamos toda justicia.” Bautizado Jesús, salió del agua; y en esto se abrieron los cielos y vio al Espíritu de Dios que bajaba en forma de paloma y venía sobre él. Y una voz que salía de los cielos decía: “Este es mi Hijo amado, en quien me complazco”.