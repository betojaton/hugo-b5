---
title: Mes de María

date: 2014-11-09T23:57:55+00:00
url: /2014/mes-de-maria/
addthis_exclude:
  - 'true'
tags: [Notas]

---
#### 7 de noviembre al 8 de diciembre &#8211; Mes de María

Del 7 de noviembre (fiesta de María Mediadora de todas las Gracias) al 8 de diciembre (fiesta de la Inmaculada Concepción), la Iglesia celebra el mes de María invitándonos a conocer, honrar y amar más a nuestra Madre, la Santísima Virgen.  
Este mes se lo dedicamos a la más delicada de todas las criaturas: la Santísima Virgen >María, nuestra dulce Madre del Cielo, alma delicada que ofreció su vida al cuidado y servicio de Jesucristo, nuestro Redentor.

**¿Qué se acostumbra hacer este mes?**

  * Rezar en familia todos los días
  * Honrarla con cánticos
  * Rezar el Santo Rosario en familia

**Reflexionar en los principales misterios de la vida de María**

Reflexionar implica hacer un esfuerzo con la mente, la imaginación y, también, con el corazón, para profundizar en las virtudes que la Virgen vivió a lo largo de su vida. Podemos meditar en cómo María se comportó, por ejemplo, durante:

  * la Anunciación.
  * la Visita a su prima Santa Isabel.
  * el Nacimiento del Niño Jesús.
  * la Presentación del Niño Jesús en el templo.
  * el Niño Jesús perdido y hallado en el templo.
  * las Bodas de Caná.
  * María al pie de la Cruz.