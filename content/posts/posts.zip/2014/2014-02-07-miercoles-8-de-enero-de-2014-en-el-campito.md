---
title: Miércoles 8 de enero, 2014 en el “Campito”
date: 2014-02-07T20:55:17+00:00
url: /2014/miercoles-8-enero-2014-en-el-campito/
thumbnail: /images/manos-rezando.jpg
audio:
  - /wp-content/themes/mdstafe2013/audio/2014/08-01-2014.mp3
tags:
  - Mensaje
  - Mensajes Presencia
---
![Imagen Madre Teresa](/images/madre-teresa-ninio.jpg)

**Dice la Santísima Virgen:**  
“Hijos míos, benditos y amados hijos míos. ¡No estéis tristes! ¡No estéis angustiados! Porque aquí tenéis a la Madre que se manifiesta con todos los hijos.

Sacad del corazón la tristeza y el dolor y vivid cada día de vuestra vida, dando gracias al Señor dando gracias a su amor y a su Misericordia.  
No estéis hijitos míos tristes, levantad vuestro espíritu y trabajad como lo desea Dios Nuestro Señor por la extensión de Su Reino, trabajad en el mundo, socorred a las almas y a los necesitados.

No guardéis estos tesoros que la Madre os da, dadlos al mundo, a las almas, id hacia los corazones y a las almas que están desesperadas y que necesitan hoy de una palabra de consuelo, de aliento, de fortaleza.

Hijos míos, id hacia el mundo y anunciad que María se manifiesta con todos los hijos. Anunciad que la Madre está presente con los hijos, socorriendo a las almas y a los corazones, socorriendo a todos los hijos por igual.

Porque esta Madre viene a unir a los hijos y no viene a separar, viene a unir a todos los corazones, a todas las almas en un solo rebaño.

La Madre viene a unir a las almas y vosotros hijitos míos debéis trabajar, mucho, para que todas las almas vivan en la unidad.

> Os invito como siempre a rezar, a rezar mucho, todos los días el Santo Rosario y así haréis una muralla y una coraza contra el adversario, haréis una muralla que el adversario no podrá jamás traspasar.


> ¡Aquí está la Madre! esta Madre pasa sobre vosotros, sobre vuestras cabezas, tocando vuestros corazones, tocándoos a cada uno de vosotros en forma especial y dando Mi Bendición Maternal, para que superéis todas las pruebas y los escollos, para que avancéis y nunca os quedéis detenidos en el camino.


> Aprovechad hijitos míos, que la Madre está presente con vosotros, aprovechad estos días especiales. Aprovechadlos.



  Meditad. Meditad. Meditad Mis palabras.”

![Imagen Madre Teresa](/images/manos-rezando.jpg")

**Dice Jesús:**  
“Hermanos míos; benditos y amados hermanos míos, hoy nuevamente os entrego Mi profundísima paz y quiero sanaros y liberaros de tantas ataduras, dejad vosotros que Mi mano os sane y os libere, os purifique y os de la auténtica paz, que el mundo no os da.

Os doy a manos llenas, Mi amor y Mi Misericordia, Mi amor profundísimo que sana, que fortalece, que os da nuevas esperanzas.

Nunca debéis bajar los brazos, aunque sintáis el cansancio y el agobio. Nunca bajéis los brazos y permaneced a Mi lado, porque sois Mis ovejas. No os apartéis jamás de

Mi rebaño y permaneced junto a Mi, porque en Mí hallaréis la paz profunda y auténtica, la paz que os da Mi Sacratísimo Corazón.

El mundo no os da la paz, el mundo tan enloquecido, no os da la paz, solamente Mi Sacratísimo Corazón os da la paz eterna, la paz profunda, la paz que debe reinar siempre en vuestras almas. ¡Recordad Mis palabras, meditad Mis palabras! y acercaos hacia Mí, porque a todos os recibo, porque abro Mi Corazón Sacratísimo para todas las almas, recordad que el hombre es el que separa y divide, que Mi Corazón Sacratísimo os une, os atrae, os reúne a todos en un mismo rebaño.

Confiad en Mí .En Mis palabras, en Mi presencia, sentid Mi presencia junto a vosotros. Sentid Mi presencia en vosotros.

¡Aquí estoy! estoy siempre a vuestro lado, estoy con todas las almas del mundo entero, jamás quedaréis defraudados, si estáis junto a Mí. ¡Jamás!  
Os amo. Os amo. Os amo. No os sintáis indignos. Os amo a todos por igual. A todos.

Meditad. Meditad. Meditad Mis palabras.

Os bendigo en el Nombre del Padre y del Hijo y del Espíritu Santo. Amén.”