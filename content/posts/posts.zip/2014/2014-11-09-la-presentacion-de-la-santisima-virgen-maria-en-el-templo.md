---
title: La Presentación de la Santísima Virgen María en el Templo

date: 2014-11-09T23:46:11+00:00
url: /2014/la-presentacion-de-la-santisima-virgen-maria-en-el-templo/
tags: [Notas]

---
#### 21 de noviembre &#8211; La Presentación de la Santísima Virgen María en el Templo

Honramos la Presentación en el Templo de aquella Niña de bendición.

La Virgen María fue llevada a la edad de tres años por sus padres San Joaquín y Santa Ana. Allí, junto a otras doncellas y piadosas mujeres, fue instruida cuidadosamente respecto la fe de sus padres y sobre los deberes para con Dios.