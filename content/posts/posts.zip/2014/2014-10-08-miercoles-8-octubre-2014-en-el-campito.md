---
title: Miércoles 8 de octubre, 2014 en el “Campito”
date: 2014-10-08T19:00:18+00:00
url: /2014/miercoles-8-octubre-2014-en-el-campito/
thumbnail: /images/jesus-camino-palo.jpg
tags:
- Mensajes 2014
- Mensajes Presencia

---
![jesus-camino-palo](/images/jesus-camino-palo.jpg)
**Dice la Santísima Virgen:**  
“Hijos Míos, benditos y amados hijos Míos, aún hay muchos hijos, aún hay muchos hijos que no creen en Mi presencia, hay muchos hijos que tienen cerradas las puertas de su corazón a la presencia de ésta Madre.

Esta Madre viene para conducir a cada uno de sus hijos y llevarlos a Jesús, conducirlos a Jesús, esa es Mi tarea, que todos lleguéis a Jesús, que todos os encontréis con Jesús, que todos estéis cara a cara con Jesús, con Cristo Jesús Mi Hijo Amadísimo.  
Esta Madre viene a enseñar y vosotros hijitos Míos debéis predicar al mundo Mi presencia, anunciar al mundo Mi presencia.  
Os envío hijitos míos como misioneros, en éste mundo de hoy, a que busquéis a las almas, a los corazones, a los hijos que están en la oscuridad.  
Hijos, no permitáis que las tinieblas invadan vuestro corazón, no permitáis. Dejad siempre que brille la luz de Jesús en vuestro corazón y así viviréis completamente en paz.  
Meditad. Meditad. Meditad Mis palabras.”

![2personas-cruz-al-hombro](/images/2personas-cruz-al-hombro.jpg){title="title", class=.myClass, width=40, height=50 }

**Dice Jesús:**  
“Dice Jesús: hermanos Míos, benditos y amados hermanos Míos, sentid Mi amor dentro de vosotros, sentid el fuego de Mi amor en vuestros corazones. Os amo profundísimamente y todos debéis mirar siempre Mi Sacratísimo Corazón, para encontrar la paz.  
Os amo a todos por igual, y no divido, no separo. Atraigo a Mis hermanos hacia la fuente inagotable de amor que es Mi Sacratísimo Corazón.  
Marchad en la verdad, marchad en la luz y seguid Mis pasos. Cada uno tome su cruz y siga Mi camino, cada uno asuma su cruz y siga Mi camino. Os invito a ser mensajeros del amor y de la paz, os invito a todos siempre a que meditéis Mis palabras, a que no abandonéis Mi camino, a que sigáis marchando junto a Mí, porque soy el Buen Pastor y vosotros Mis ovejas.  
Y os hablo, una y otra vez de Mi amor, infinitamente de Mi amor, que no se extingue, Mi amor lo vuelco en vosotros en el mundo entero y aún así hay tantas almas que rechazan este amor profundísimo de Mi Sacratísimo Corazón.  
Rezad todos los días. Vivid en la verdad, todos los días, y resplandeced con la luz de Mi Sacratísimo Corazón.  
Os amo. Os amo. Os amo.  
Meditad. Meditad. Meditad Mis palabras.  
Os bendigo en el Nombre del Padre y del Hijo y del Espíritu Santo. Amén.”