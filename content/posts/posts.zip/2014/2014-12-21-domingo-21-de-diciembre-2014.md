---
title: Domingo, 21 de diciembre 2014

date: 2014-12-21T14:21:33+00:00
url: /2014/domingo-21-de-diciembre-2014/
thumbnail: /images/corazon_jesus-224x300-1.png
tags: [Mensajes]

---
#### Mensajes de Jesús y María de la Santa Fe

**Por la noche le dice la Santísima Virgen a Vicente:  
** “Vicente hijo mío: los hijos deben perseverar en la oración para ganar las batallas que libra el enemigo, los hijos deben orar permanentemente para hacer frente a las insidias del enemigo, María como Madre os propone, esta Madre os propone a todos, rezad el Santo Rosario todos los días, formad grupos de oración, rezad el Santo Rosario en comunidad y no dejéis de asistir a la oración con vuestros hermanos, así ayudaréis a esta Madre en esta batalla contra el adversario, escuchad a María, a esta Madre que se hace presente en esta Santa Fe.  
Meditad Mi Profundísimo Mensaje. Amén. Gloria al Sagrado Corazón de Jesús  
Leed: hebreos; C 3; 10 al 12. Hazlo conocer a tus hermanos.”

<img decoding="async" loading="lazy" src="https://mariadelasantafe.org.ar/images/corazon_jesus-3.png" alt="corazon_jesus" width="224" height="300" class="alignright size-medium wp-image-657" /> **Le dice Jesús:  
** “Vicente hermano mío: Invito a mis hermanos a acercarse al Sacramento de la Reconciliación, invito a mis hermanos a llegar ante el sacerdote, a todos mis hermanos llamo a través del sacerdote, para que cada uno limpie su corazón y su alma de los pecados, no os olvidéis jamás que estoy en el sacerdote escuchándoos, que estoy presente vivo eternamente en cada Hostia Consagrada y aún mis hermanos piden signos mayores para ver y creer.  
Venid a Mí, os doy el agua viva que brota de Mi Corazón traspasado por amor, por amor a cada uno de vosotros.  
¿Por qué aún muchos dudáis de Mi presencia, de mi amor y de mis mensajes a la humanidad?  
Meditad Mi Profundísimo Mensaje. Amén. Gloria a Dios Mi Padre.  
Leed: 1er Libro Macabeos: C 5, V 4 al 6. Lucas: C 7; 2 al 8. Predícalo a todos tus hermanos.”

**Le dice Jesús:  
** “Vicente hermano mío: Recitad esta oración de la noche

> Padre vengo a pedirte en este momento por mis hermanos, vengo a pedirte en este momento, en este encuentro de oración por todos aquellos que necesitan hoy de ti, Padre mío, ayúdalos, sana a los enfermos, levanta el corazón de los abatidos, levanta el espíritu de aquellos corazones atormentados y que sufren tanto espiritualmente y físicamente.  
> Padre bueno y Misericordioso te pido por todos, por todas las personas que sufren, que están solas y que muy pocos se acuerdan de ellas.  
> Bendíceme Padre Eterno con tu gracia.  
> Amén.

Predícala hijo mío a tus hermanos.”