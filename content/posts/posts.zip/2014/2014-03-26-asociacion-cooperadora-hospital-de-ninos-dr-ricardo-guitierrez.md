---
title: Asociación Cooperadora Hospital de Niños – Dr. Ricardo Guitierrez

date: 2014-03-26T23:10:56+00:00
url: /2014/asociacion-cooperadora-hospital-de-ninos-dr-ricardo-guitierrez/
addthis_exclude:
  - 'true'
tags: [Colaboraciones]

---
#### <i class="fa fa-calendar fa-fw"></i> Colaboraciones Anteriores:  26/03/2014, 20/03/2013 {.text-center}

<!-- default-view.php -->

<div
	class="ngg-galleryoverview default-view "
	id="ngg-gallery-aaf3281f61f7d19470e6aa0f7b54049d-1">
  <!-- Thumbnails -->
  
  <div id="ngg-image-0" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/colaboracion-coop-hospital-ninios-200313-01.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/colaboracion-coop-hospital-ninios-200313-01.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/thumbs/thumbs_colaboracion-coop-hospital-ninios-200313-01.jpg"
               data-image-id="206"
               data-title="colaboracion-coop-hospital-ninios-200313-01"
               data-description=""
               data-image-slug="colaboracion-coop-hospital-ninios-200313-01"
               class="ngg-simplelightbox" rel="aaf3281f61f7d19470e6aa0f7b54049d"> <img
                    title="colaboracion-coop-hospital-ninios-200313-01"
                    alt="colaboracion-coop-hospital-ninios-200313-01"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/thumbs/thumbs_colaboracion-coop-hospital-ninios-200313-01.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-1" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/colaboracion-coop-hospital-ninios-200313-02.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/colaboracion-coop-hospital-ninios-200313-02.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/thumbs/thumbs_colaboracion-coop-hospital-ninios-200313-02.jpg"
               data-image-id="207"
               data-title="colaboracion-coop-hospital-ninios-200313-02"
               data-description=""
               data-image-slug="colaboracion-coop-hospital-ninios-200313-02"
               class="ngg-simplelightbox" rel="aaf3281f61f7d19470e6aa0f7b54049d"> <img
                    title="colaboracion-coop-hospital-ninios-200313-02"
                    alt="colaboracion-coop-hospital-ninios-200313-02"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/thumbs/thumbs_colaboracion-coop-hospital-ninios-200313-02.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-2" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/colaboracion-coop-hospital-ninios-200313-03.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/colaboracion-coop-hospital-ninios-200313-03.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/thumbs/thumbs_colaboracion-coop-hospital-ninios-200313-03.jpg"
               data-image-id="208"
               data-title="colaboracion-coop-hospital-ninios-200313-03"
               data-description=""
               data-image-slug="colaboracion-coop-hospital-ninios-200313-03"
               class="ngg-simplelightbox" rel="aaf3281f61f7d19470e6aa0f7b54049d"> <img
                    title="colaboracion-coop-hospital-ninios-200313-03"
                    alt="colaboracion-coop-hospital-ninios-200313-03"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/thumbs/thumbs_colaboracion-coop-hospital-ninios-200313-03.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-3" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/colaboracion-coop-hospital-ninios-200313-04.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/colaboracion-coop-hospital-ninios-200313-04.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/thumbs/thumbs_colaboracion-coop-hospital-ninios-200313-04.jpg"
               data-image-id="209"
               data-title="colaboracion-coop-hospital-ninios-200313-04"
               data-description=""
               data-image-slug="colaboracion-coop-hospital-ninios-200313-04"
               class="ngg-simplelightbox" rel="aaf3281f61f7d19470e6aa0f7b54049d"> <img
                    title="colaboracion-coop-hospital-ninios-200313-04"
                    alt="colaboracion-coop-hospital-ninios-200313-04"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/thumbs/thumbs_colaboracion-coop-hospital-ninios-200313-04.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-4" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/CAM00700.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/CAM00700.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/thumbs/thumbs_CAM00700.jpg"
               data-image-id="298"
               data-title="CAM00700"
               data-description=""
               data-image-slug="cam00700"
               class="ngg-simplelightbox" rel="aaf3281f61f7d19470e6aa0f7b54049d"> <img
                    title="CAM00700"
                    alt="CAM00700"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/thumbs/thumbs_CAM00700.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-5" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/CAM00704.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/CAM00704.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/thumbs/thumbs_CAM00704.jpg"
               data-image-id="301"
               data-title="CAM00704"
               data-description=""
               data-image-slug="cam00704"
               class="ngg-simplelightbox" rel="aaf3281f61f7d19470e6aa0f7b54049d"> <img
                    title="CAM00704"
                    alt="CAM00704"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/thumbs/thumbs_CAM00704.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-6" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/CAM00701.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/CAM00701.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/thumbs/thumbs_CAM00701.jpg"
               data-image-id="299"
               data-title="CAM00701"
               data-description=""
               data-image-slug="cam00701"
               class="ngg-simplelightbox" rel="aaf3281f61f7d19470e6aa0f7b54049d"> <img
                    title="CAM00701"
                    alt="CAM00701"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/thumbs/thumbs_CAM00701.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-7" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/CAM00702.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/CAM00702.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/thumbs/thumbs_CAM00702.jpg"
               data-image-id="300"
               data-title="CAM00702"
               data-description=""
               data-image-slug="cam00702"
               class="ngg-simplelightbox" rel="aaf3281f61f7d19470e6aa0f7b54049d"> <img
                    title="CAM00702"
                    alt="CAM00702"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/thumbs/thumbs_CAM00702.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-8" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/CAM00703.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/CAM00703.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/thumbs/thumbs_CAM00703.jpg"
               data-image-id="302"
               data-title="CAM00703"
               data-description=""
               data-image-slug="cam00703"
               class="ngg-simplelightbox" rel="aaf3281f61f7d19470e6aa0f7b54049d"> <img
                    title="CAM00703"
                    alt="CAM00703"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/thumbs/thumbs_CAM00703.jpg"
                    width="100"
                    height="75"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-9" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/colaboracion-hospital-allassia-20160428-01.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/colaboracion-hospital-allassia-20160428-01.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/thumbs/thumbs_colaboracion-hospital-allassia-20160428-01.jpg"
               data-image-id="351"
               data-title="colaboracion-hospital-allassia-20160428-01"
               data-description=""
               data-image-slug="colaboracion-hospital-allassia-20160428-01"
               class="ngg-simplelightbox" rel="aaf3281f61f7d19470e6aa0f7b54049d"> <img
                    title="colaboracion-hospital-allassia-20160428-01"
                    alt="colaboracion-hospital-allassia-20160428-01"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/thumbs/thumbs_colaboracion-hospital-allassia-20160428-01.jpg"
                    width="200"
                    height="150"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-10" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/colaboracion-hospital-allassia-20160428-02.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/colaboracion-hospital-allassia-20160428-02.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/thumbs/thumbs_colaboracion-hospital-allassia-20160428-02.jpg"
               data-image-id="352"
               data-title="colaboracion-hospital-allassia-20160428-02"
               data-description=""
               data-image-slug="colaboracion-hospital-allassia-20160428-02"
               class="ngg-simplelightbox" rel="aaf3281f61f7d19470e6aa0f7b54049d"> <img
                    title="colaboracion-hospital-allassia-20160428-02"
                    alt="colaboracion-hospital-allassia-20160428-02"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/thumbs/thumbs_colaboracion-hospital-allassia-20160428-02.jpg"
                    width="200"
                    height="150"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <div id="ngg-image-11" class="ngg-gallery-thumbnail-box " >
    <div class="ngg-gallery-thumbnail">
      <a href="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/colaboracion-hospital-allassia-20160428-03.jpg"
               title=""
               data-src="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/colaboracion-hospital-allassia-20160428-03.jpg"
               data-thumbnail="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/thumbs/thumbs_colaboracion-hospital-allassia-20160428-03.jpg"
               data-image-id="353"
               data-title="colaboracion-hospital-allassia-20160428-03"
               data-description=""
               data-image-slug="colaboracion-hospital-allassia-20160428-03"
               class="ngg-simplelightbox" rel="aaf3281f61f7d19470e6aa0f7b54049d"> <img
                    title="colaboracion-hospital-allassia-20160428-03"
                    alt="colaboracion-hospital-allassia-20160428-03"
                    src="https://mariadelasantafe.org.ar/wp-content/gallery/cooperadora-hospital-ninios/thumbs/thumbs_colaboracion-hospital-allassia-20160428-03.jpg"
                    width="200"
                    height="150"
                    style="max-width:100%;"
 /> </a>
    </div>
  </div>
  
  <br style="clear: both" /> <!-- Pagination -->
  
  <div class='ngg-clear'>
  </div>
</div>