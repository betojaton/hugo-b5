---
title: Solemnidad de todos los Santos

date: 2014-11-09T23:19:08+00:00
url: /2014/solemnidad-de-todos-los-santos/
tags: [Notas]

---
### 1º de Noviembre &#8211; Solemnidad de todos los Santos

Este día se celebran a todos los millones de personas que han llegado al cielo, aunque sean desconocidos para nosotros.  
Santo es aquel que ha llegado al cielo, algunos han sido canonizados, o sea declarados oficialmente santos por el Sumo Pontífice, y son por esto propuestos por la Iglesia como ejemplos de vida cristiana.

Comunión de los santos: La comunión de los santos, significa que ellos participan activamente en la vida de la Iglesia, por el testimonio de sus vidas, por la transmisión de sus escritos y por su oración. Contemplan a Dios, lo alaban y no dejan de cuidar de aquellos que han quedado en la tierra. La intercesión de los santos significa que ellos, al estar íntimamente unidos con Cristo, pueden interceder por nosotros ante el Padre. Esto ayuda mucho a nuestra debilidad humana.  
Su intercesión es su más alto servicio al plan de Dios. Podemos y debemos rogarles que intercedan por nosotros y por el mundo entero.

Aunque todos los días deberíamos pedir la ayuda de los santos, es muy fácil que el ajetreo de la vida nos haga olvidarlos y perdamos la oportunidad de recibir todas las gracias que ellos pueden alcanzarnos. Por esto, la Iglesia ha querido que un día del año lo dediquemos especialmente a rezar a los santos para pedir su intercesión.