---
title: 'Me dice la Santísima Virgen una oración:'
author: admin

date: 2001-02-13T20:19:55+00:00
url: /2001/me-dice-la-santisima-virgen-una-oracion/
thumbnail: /images/SAGRADAFAMILIA-1.png
tags: [Oraciones]

---
<img decoding="async" loading="lazy" class="alignright size-medium wp-image-653" title="SAGRADA FAMILIA" src="https://mariadelasantafe.org.ar/images/SAGRADAFAMILIA-241x300.png" alt="SAGRADA FAMILIA" width="241" height="300" />Sagrada Familia de Nazaret une a las familias. Sagrada Familia de Nazaret guía a los padres, guía a los hijos. Sagrada Familia de Nazaret danos la paz, danos la verdad, danos tu luz. Amén. Amén.

Predícala al mundo entero.