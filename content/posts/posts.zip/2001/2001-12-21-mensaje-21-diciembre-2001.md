---
title: Mensaje, 21 Diciembre, 2001
author: admin

date: 2001-12-21T21:37:20+00:00
url: /2001/mensaje-21-diciembre-2001/
thumbnail: /images/img-msj-21122001-1.jpg
tags: [Mensajes 2001]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-msj-21122001.jpg" alt="img-msj-21122001" class="alignright size-thumbnail wp-image-3877" />**Me dice la Santísima Virgen:**

> Hijo mío: Mis mensajes deben alertar al mundo y a mis hijos, mis mensajes, mis palabras de Madre son difundidas al mundo y a todos mis hijos, deseo como Madre tener respuestas de los corazones, deseo que abráis todos el corazón al llamado urgente que os hace el Altísimo, Dios Nuestro Señor, no busquéis caminos equivocados, caminos tortuosos, no busquéis el placer y los caminos del pecado, buscad la luz de Dios, buscad la luz que Cristo Jesús, Mi Hijo Amadísimo os revela a todos vosotros, sentid a la Madre angustiada, dolorida, entristecida por la rebeldía de muchos hijos, por la rebeldía del mundo hacia la palabra de Dios, hacia la vida consagrada, hacia los Sacramentos, cuantos de mis hijos han olvidado la confesión, cuantos de mis hijos han olvidado mis palabras y mis enseñanzas de Madre, cuantos de mis hijos aborrecen las cosas sagradas y cambian sus horas y sus días por el placer, por el engaño y la seducción del maligno, del enemigo.  
> Debéis despertar de esta noche en que vivís, debéis despertar del pecado y vivir en la gracia, en la luz y en la verdad, rezad el Santo Rosario para alcanzar la paz, rezad el Santo Rosario para vencer el enemigo que ataca con fuerza, que ataca despiadadamente a todos mis hijos del mundo, que ataca a la Santa Iglesia de Mi Hijo Amadísimo, Cristo Jesús.  
> Es un tiempo de confusión, es un tiempo de desolación, de tristeza, de dolor, acudid pues hacia esta Madre, acudid a la Santa Iglesia, acudid acia sus pastores y ministros y rezad por todos ellos porque el ataque de Satanás es severo y doloroso, dejad que esta Madre reine en vuestros corazones, en vuestros hogares, en vuestras familias, en vuestras comunidades, en vuestros conventos, en vuestras ciudades y pueblos, dejad a la Madre remar porque la Madre es la Capitana de un gran ejército que el enemigo jamás podrá destruir.  
> Vengo hacia vosotros como Madre por que Dios Nuestro Señor así lo ha dispuesto, vengo hacia vosotros por Mi eterno amor de Madre hacia cada uno de vosotros.  
> Meditad Mi profundísimo Mensaje.  
> Amén. Gloria a Dios Nuestro Señor.<footer>Leed: Génesis: C 10, V 6 y 7. &#8211; Éxodo: C 14, V 9. &#8211; Isaías: C 10, V 12. &#8211; Jeremías: C 7, V 9. &#8211; Lucas: C 15, V 10 al 12. &#8211; Mateo: C 4, V 17. &#8211; Apocalipsis: C 14, V 2 al 6.</footer> 

Predícalo hijo mío a las naciones del mundo entero