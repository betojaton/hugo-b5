---
title: Mensaje, 18 Diciembre 2001
author: admin

date: 2001-12-18T16:50:20+00:00
url: /2001/mensaje-18-diciembre-2001/
thumbnail: /images/paloma-193x300-1.png
tags: [Mensajes 2001]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/rosario-msj-jul2002.jpg" alt="rosario-msj-jul2002" class="alignright size-medium wp-image-3593" />**Me dice la Santísima Virgen:**

> Hijos míos: Rezad el Santo Rosario todos los días, rezad en este tiempo de adviento en que estáis preparándoos para celebrar una nueva Navidad para que todos mis hijos, para que el mundo entero encuentre la luz y la verdad que están en Cristo Jesús, Mi Hijo Amadísimo, único Salvador, único Redentor, rezad todos los días el Santo Rosario, arma poderosa, arma que destruye todos los planes y todas las obras del adversario, rezad el Santo Rosario en familia, rezad en los Templos, rezad en las ermitas, rezad por la conversión de todos los pecadores, como Madre llego a vosotros, como Madre deseo que todos mis hijos descubran el valor importante de la oración.  
> Meditad Mi profundísimo Mensaje.  
> Amén. Gloria a Cristo Jesús.<footer>Leed: Lucas: C 9, V 7 al 14.</footer> 

Predícalo hijo mío al mundo entero.

<img decoding="async" src="https://mariadelasantafe.org.ar/images/paloma-1-193x300.png" alt="paloma" class="alignright size-medium wp-image-655" /> **Me dice Jesús:**

> Hermano mío: Mi Sacratísimo Corazón da al mundo, da a todos mis hermanos tantas oportunidades, deseo que el mundo busque Mi Amor y Mi paz, que el mundo, la humanidad por completo viva en la verdad y se aparte de la mentira y del engaño donde reina Satanás con sus secuaces.  
> El mundo está oscurecido, está atrapado en las redes del adversario, perversión, droga, guerra, sexo, todos los males que el enemigo siembra, que el enemigo siembra al paso de mis hermanos.  
> Buscad pues la luz y la fortaleza, buscad las armas poderosas, acercaos a Mi Santa Iglesia, confesad, comulgad y vivid en gracia, rezad y estaréis fortalecidos para la dura y cruel batalla que hoy sacude al mundo entero, no os apartéis de Mí, no os apartéis de Mi camino pues en Mi camino está la verdad y la vida eterna, en Mi Sacratísimo Corazón está la paz y la verdad eterna.  
> Meditad Mi profundísimo Mensaje.  
> Amén. Gloria a Dios Mi Padre.<footer>Leed: Isaías: C 10, V 8. &#8211; Lucas: C 13, V 17.</footer> 

Predícalo hermano mío al mundo entero.