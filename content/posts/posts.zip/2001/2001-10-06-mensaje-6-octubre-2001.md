---
title: Mensaje, 6 Octubre 2001
author: admin

date: 2001-10-06T20:07:43+00:00
url: /2001/mensaje-6-octubre-2001/
tags: [Mensajes 2001]

---
> Hijos míos: Decid estas alabanzas al Sagrado Corazón de Jesús:  
> Sagrado Corazón de Jesús, paz y amor, se nuestro refugio.  
> Sagrado Corazón de Jesús, luz del mundo, guíanos.  
> Sagrado Corazón de Jesús, paz para los hombres, consuélanos con tu amor.  
> Amén. Gloria al Sagrado Corazón de Jesús.

Predica esta oración al mundo entero