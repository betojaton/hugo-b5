---
title: 'Hijos míos, rezad así esta oración:'
author: admin

date: 2001-04-25T20:23:31+00:00
url: /2001/hijos-mios-rezad-asi-esta-oracion-2/
thumbnail: /images/paloma_animado2-1.gif
tags: [Oraciones]

---
<div class="wp-block-image">
  <figure class="alignright"><img decoding="async" src="https://mariadelasantafe.org.ar/images/paloma_animado2.gif" alt="paloma_animada" class="wp-image-784" title="paloma_animada" /></figure>
</div>

Oh Espíritu Santo, guíanos.

Oh Espíritu Santo, socórrenos.

Oh Espíritu Santo, mueve nuestro corazón y hazlo llegar cada día al encuentro con Dios.

Amén. Amén. Predícala.