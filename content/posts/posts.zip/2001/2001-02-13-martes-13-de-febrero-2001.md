---
title: Martes 13 de febrero, 2001
author: admin

date: 2001-02-13T15:10:42+00:00
url: /2001/martes-13-de-febrero-2001/
thumbnail: /images/foto-mesnaje-octubre2-1.png
tags: [Mensajes 2001]

---
<img decoding="async" class="alignright size-medium wp-image-3060 img-circle" src="https://mariadelasantafe.org.ar/images/foto-mesnaje-octubre2.png" alt="foto-mensaje-octubre2" />  
**Me dice la Santísima Virgen una oración:**

> “Sagrada Familia de Nazaret une a las familias. Sagrada Familia de Nazaret guía a los padres, guía a los hijos.  
> Sagrada Familia de Nazaret danos la paz, danos la verdad, danos tu luz.  
> Amén. Amén.  
> Predícala al mundo entero.”