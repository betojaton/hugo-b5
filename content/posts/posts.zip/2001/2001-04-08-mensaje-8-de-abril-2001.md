---
title: Mensaje 8 de Abril, 2001
author: admin

date: 2001-04-08T14:40:51+00:00
url: /2001/mensaje-8-de-abril-2001/
tags: [Mensajes 2001]

---
**Me dice Jesús:**

> Hermanos míos: Buscad la conversión de vuestros corazones, buscad la conversión de vuestras vidas, vivid en la luz, vivida en la gracia y apartaos de las sombras, apartaos de la oscuridad que solo pertenece al adversario, que solo pertenece a Satanás.  
> Vivid en la luz, en la gracia que os da Mi Sacratísimo Corazón, vivid en la gracia, en la verdad en la única verdad, que os da Mi Sacratísimo Corazón.  
> Meditad Mi profundísimo Mensaje.  
> Amén. Gloria a Dios Mi Padre.  
> Leed; Mateo: C 12, V 24 y 25.<footer>Predicalo al mundo entero. <footer>