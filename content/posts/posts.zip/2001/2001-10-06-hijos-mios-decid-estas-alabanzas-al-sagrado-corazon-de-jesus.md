---
title: 'Hijos Míos, decid estas alabanzas al Sagrado Corazón de Jesús:'
author: admin

date: 2001-10-06T20:24:11+00:00
url: /2001/hijos-mios-decid-estas-alabanzas-al-sagrado-corazon-de-jesus/
tags: [Oraciones]

---
Sagrado corazón de Jesús, paz y amor, se nuestro refugio.

Sagrado Corazón de Jesús, luz del mundo, guíanos.

Sagrado Corazón de Jesús, paz para los hombres, consuélanos con tu amor. Amén. Gloria al Sagrado Corazón de Jesús.

Predíca esta oración al mundo entero.