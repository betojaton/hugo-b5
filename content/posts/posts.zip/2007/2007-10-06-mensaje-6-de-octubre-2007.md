---
title: Mensaje, 6 de Octubre, 2007
author: admin

date: 2007-10-06T18:11:06+00:00
url: /2007/mensaje-6-de-octubre-2007/
thumbnail: /images/img-caminandoconjesus-1.jpg
tags: [Mensajes 2007]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-caminandoconjesus.jpg" alt="img-caminandoconjesus" class="alignright size-medium wp-image-3809" />**Me dice la Santísima Virgen:**

> Hijo mío: deben renacer los corazones, deben surgir las almas a este nuevo sol que el Señor da a sus hijos, los hijos hoy deben volver con plena confianza la mirada hacia el Señor y definitivamente abandonar todo pecado, desterrar la oscuridad y vivir en la luz, porque en la luz, está la vida, la verdad y la auténtica paz.  
> Meditad Mi Profundo Mensaje.  
> Amén. Gloria a Cristo Jesús.<footer>Leed: 1ra. De Timoteo C. 3 V. 6 al 8</footer> 

Predícalo hijo mío a todos tus hermanos.

<img decoding="async" src="https://mariadelasantafe.org.ar/images/foto-cura-manossobrecabeza.jpg" alt="foto-cura-manossobrecabeza" class="alignright size-medium wp-image-3808" /> 

> Vicente hijo mío: digo a todos tus hermanos, acrecentad la oración por la Santa Iglesia azotada hoy por los vendavales del maligno, azotadas por las persecuciones de los corazones indolentes que rechazan toda enseñanza, que rechazan la corrección y la verdad que la Santa Iglesia imparte.  
> Rezad por los sacerdotes, por aquellos sacerdotes titubeantes en su vocación y arremetidos interiormente de placeres profanos y perversos a los ojos de Dios, Nuestro Señor, rezad por los obispos que llevan tras de sí una pesada cruz, por la fortaleza y perseverancia, rezad por el Sumo Pontífice, rezad por la estabilidad espiritual y síquica de los pastores, de todos mis hijos predilectos, rezad la Madre os lo pide, María de la Santa Fe, María del Rosario.  
> María, Madre de todos los hombres.  
> Meditad este Mensaje.  
> Amén. Bendito y Alabado Sea el Nombre del Señor.<footer>Leed: Ezequiel C. 41 V. 2 al 17 &#8211; Lucas C. 5 V. 21 al 26 &#8211; Marcos C. 14 V. 25</footer> 

Predícalo a todos tus hermanos.