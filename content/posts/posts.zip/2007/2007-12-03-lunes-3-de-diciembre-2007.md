---
title: Mensaje Lunes 3 de diciembre, 2007
author: admin

date: 2007-12-03T21:16:26+00:00
url: /2007/lunes-3-de-diciembre-2007/
tags: [Mensajes 2007]

---
### Le dice la Santísima Virgen a Vicente:

> Hijos míos: Benditos y amados hijos míos; avanzad cada día y nunca retrocedáis. Avanzad aunque encontréis espinas y piedras en el camino; vosotros debéis seguir caminando. Avanzad cada día porque ésta Madre está con vosotros; porque ésta Madre va conduciéndoos, va guiándoos. A nada debéis temer; porque vosotros sabéis que estáis en la verdad; que estáis en un camino de verdad y de justicia. Vosotros debéis ser cada uno en especial, mis más fuertes soldados; debéis preparar vuestro corazón y la armadura que es la oración para que salgáis victoriosos, en las batallas y en las pruebas.  
> Hijitos, no os olvidéis de mis palabras, de mis promesas, de mis enseñanzas. Meditadlas en vuestro corazón y vivid cada día como lo desea Dios Nuestro Señor. Vivid en la oración, en la penitencia, en la entrega verdadera de vuestro corazón a ésta Obra de Amor y de redención.  
> Que mis palabras florezcan en vuestros corazones, día a día.

> Dios haga a cada uno de vosotros dóciles, dóciles verdaderamente al señor. Escuchad mis palabras; deseo que no sean predicadas como en un cementerio; sino que germinen en cada corazón, en cada uno de mis hijos. Éste es el tiempo de la oración; es el tiempo de la penitencia. Que el mundo no os arrastre a las trivialidades, los pasatiempos del mundo. No ahoguen la luz de vuestro corazón; meditad hijitos míos en éstas mis palabras de Madre; y sentid mi presencia junto a vosotros. Son los días en que debéis estar, cada uno de vosotros, más fuertes que nunca.  
> Sed testigos, sed verdaderamente testigos de la verdad, en el mundo entero.  
> Meditad. Meditad. Meditad mis palabras.