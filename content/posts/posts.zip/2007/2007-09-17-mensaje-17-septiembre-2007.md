---
title: Mensaje, 17 de Septiembre 2007
author: admin

date: 2007-09-17T12:57:07+00:00
url: /2007/mensaje-17-septiembre-2007/
thumbnail: /images/foto-jesus-abre-aguas-1.jpg
tags: [Mensajes 2007]

---
__ Hora: 17 y 16._  
**Me dice la Santísima Virgen:**

<img decoding="async" src="https://mariadelasantafe.org.ar/images/foto-jesus-abre-aguas-1.jpg" alt="foto-jesus-abre-aguas" class="alignright size-medium wp-image-4314" /> 

> Hijos míos: Benditos y amados hijos míos: os traigo la luz del sol, la luz que es Cristo Jesús Mi Hijo Amadísimo; os traigo hijitos míos, el consuelo de Madre, para vuestros corazones doloridos y agobiados. No estéis tristes, porque vuestros seres queridos ya partieron, están junto a Mí en el Reino Celestial; y aquí, hijitos míos tenéis a la Madre que está a vuestro lado, para sosteneros, para secar vuestras lágrimas, para consolar vuestros corazones. Hijitos, hijitos míos, pido en especial, pido al mundo entero la conversión, pido a la humanidad, a todos mis hijos una respuesta total y definitiva hacia el Señor; y vosotros, como soldados de esta Santa Obra, debéis dar el testimonio, para el mundo entero. No temáis las flechas, las piedras, a las espinas, a las pruebas, no temáis, porque son medios para ir purificando vuestro espíritu, vuestro corazón. Avanzad todos juntos; avanzad unidos, avanzad hijitos míos, porque así lo desea Dios Nuestro Señor; que reine pues en vuestro corazón el gozo y la paz; que reine en vuestro corazón la armonía, la serenidad, la tranquilidad para que, ante las tormentas, las pruebas, nunca sucumbáis; tenéis pues aquí, a la Madre, aferraos hijitos al Santo Rosario, rezad por el mundo, rezad por las familias, rezad por los gobernantes; rezad por la Santa Iglesia, por la unidad de sus miembros, por la comprensión entre sus miembros. Aquí está María, aquí está esta Madre que ha abierto todos los caminos para que vosotros avancéis por ellos. 

Meditad. Meditad, Meditad mis palabras.  
__ Hora: 17 y 20._

**Me dice Jesús:**

> Hermanos míos: Benditos y amados hermanos míos, recibid la Luz de Mi Sacratísimo Corazón; la Luz que borra todas las tinieblas, la Luz que dispersa todas las tinieblas; recibid en profundidad todo Mi Amor, que lo doy al mundo, que lo doy a mis hermanos, y que por muy pocos es recibido. Sed mensajeros de Mi Amor, sed testigos de Mi Amor, al mundo entero. Quiero que toda la humanidad, descubra la luz que hay en Mi Sacratísimo Corazón; quiero que la humanidad y los hombres, vean en Mi Sacratísimo Corazón el camino a la vida eterna. Las guerras, las divisiones, las desuniones provienen del adversario; vosotros hermanos míos, vivid cada día unidos a Mi Sacratísimo Corazón, aferrados a Mi Sacratísimo Corazón; confiad plenamente en Mí; confiad en Mis palabras y no dudéis de mi amor, hacia vosotros, y bendigo a todos mis hermanos, que no han podido llegar, vivid estos días, estas horas, estos minutos; vividlo plenamente en la paz, en el amor, en la caridad. Sed fieles, verdaderamente fieles a lo que habéis recibido; no temáis y creed profundamente en Mí. Recibid Mi Cuerpo. Recibid Mi Sangre.  
> Meditad. Meditad, Meditad Mis palabras.<footer>Leed :Lucas C7, V 2 al 7.</footer> 

Os bendigo en el nombre del Padre y del Hijo y del Espíritu Santo.  
__ Hora: 17 y 24._