---
title: Mensaje, 29 de Noviembre 2007
author: admin

date: 2007-11-29T12:25:35+00:00
abstract: |
  <em>_ Hora: 17 y 15.</em>
  **Me dice la Santísima Virgen:**
  <img src="https://mariadelasantafe.org.ar/wp-content/uploads/2007/11/manos-rezando-rosario-368x320.png" alt="" class="alignright size-medium wp-image-4315" /><blockquote>Hijos míos: Benditos y amados hijos míos; gracias nuevamente por responder a mi llamado, gracias por abrir vuestro corazón para que ésta Madre entre a reinar, en cada uno de vosotros. Hijitos, hijitos míos; os acompaño, os guío, os muestro el camino, a cada uno de vosotros, para que todos encontréis y viváis en la luz, que es Cristo Jesús, Mi Hijo Amadísimo.
  Quiero que todos mis hijos en el mundo, se acerquen a los brazos de ésta Madre; porque esta Madre es el camino, es el puente hacia Jesús. Estoy cumpliendo una gran misión, una gran tarea, junto a todos los hijos, y, también, derramo muchas lágrimas, con los hijos que siguen caminos extraviados...</blockquote>
url: /2007/mensaje-29-noviembre-2007/
thumbnail: /images/manos-rezando-rosario-1.png
tags: [Mensajes 2007]

---
__ Hora: 17 y 15._  
**Me dice la Santísima Virgen:**  
<img decoding="async" src="https://mariadelasantafe.org.ar/images/manos-rezando-rosario.png" alt="" class="alignright size-medium wp-image-4315" /> 

> Hijos míos: Benditos y amados hijos míos; gracias nuevamente por responder a mi llamado, gracias por abrir vuestro corazón para que ésta Madre entre a reinar, en cada uno de vosotros. Hijitos, hijitos míos; os acompaño, os guío, os muestro el camino, a cada uno de vosotros, para que todos encontréis y viváis en la luz, que es Cristo Jesús, Mi Hijo Amadísimo.  
> Quiero que todos mis hijos en el mundo, se acerquen a los brazos de ésta Madre; porque esta Madre es el camino, es el puente hacia Jesús. Estoy cumpliendo una gran misión, una gran tarea, junto a todos los hijos, y, también, derramo muchas lágrimas, con los hijos que siguen caminos extraviados.  
> Hijitos, no perdáis nunca la fe; no perdáis la confianza; y tened el corazón libre de oscuridad. Y dejad que solo la luz de Jesús, reine en vosotros. No temáis a las adversidades, y sed valientes para luchar, y para perseverar.  
> Hijitos, cuántos son los corazones, cuántas son las almas que desconocen hoy, la existencia de ésta Madre. Cuántas! Miles! miles! Entonces os encomiendo la gran tarea de la oración, para salvar a tantas almas de los caminos equivocados.  
> Preparad el corazón; preparad vuestro espíritu; levantad vuestras cabezas hacia el cielo. Nunca dejéis que el desánimo, que el desgano, gane en vuestro corazón.  
> Meditad cada una de mis palabras profundamente en vuestro corazón. Meditadlas así os lo pido, a cada uno de vosotros.

Meditad. Meditad. Meditad mis palabras.

__ Hora: 17 y 18._  
**Me dice Jesús:**

> Hermanos míos: Benditos y amados hermanos míos; disfrutad de Mi Paz; vivid en Mi Paz; llevad Mi Paz. No dejéis que el temor, se apodere de vosotros; dejad solamente que Mi Luz y Mi Amor, os transformen, os modelen, os enriquezcan. Doy al mundo, y a todos los hombres, infinitas oportunidades. Miles de caminos, para que todos lleguen a Mi Sacratísimo Corazón. Entrego Mis Palabras a todos los hombres. Palabras inmensas en amor; palabras llenas de amor; palabras impregnadas del Amor de Mi Sacratísimo Corazón. De éste Corazón, que sangra por todos los hombres; de éste Corazón Sacratísimo que emana sangre de amor, por toda la humanidad. Quiero que todos los hombres encuentren la luz, encuentren el camino a la vida eterna.  
><img decoding="async" src="https://mariadelasantafe.org.ar/images/img-jesus-corona.jpg" alt="img-jesus-corona" class="alignright size-full wp-image-4313" /> Vosotros sois testigos y mensajeros de mis palabras. No miréis nunca hacia el pasado y vivid éste presente, que os ofrece Mi Sacratísimo Corazón.  
> Buscad en todo momento Mi Paz, buscad en todo momento Mi Amor.  
> Que en vuestros rostros y en vuestras miradas, brille el amor de Mi Sacratísimo Corazón. El mundo, los hombres, buscan el camino fácil, amplio, y que lleve a la perdición. Vosotros entonces sed mensajeros de la verdad y testigos para que todas las almas, todos los corazones, busquen el camino correcto; el que conduce a la vida eterna, Mi Sacratísimo Corazón.  
> Sean meditadas Mis Palabras, profundamente, profundamente.  
> Os amo. Os amo. Os amo. Nunca dudéis de Mi Amor, hacia cada uno de vosotros.<footer>Leed Salmo 35.</footer> 

Meditad. Meditad. Meditad Mis Palabras.  
Os bendigo en el Nombre del Padre y del Hijo y del Espíritu Santo.  
Amén.  
__ Hora: 17 y 23._