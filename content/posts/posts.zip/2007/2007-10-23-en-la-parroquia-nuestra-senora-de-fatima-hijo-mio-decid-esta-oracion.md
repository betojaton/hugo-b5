---
title: 'En la Parroquia Nuestra Señora de Fátima.  Hijo Mío: decid ésta oración.'
author: admin

date: 2007-10-23T00:16:44+00:00
url: /2007/en-la-parroquia-nuestra-senora-de-fatima-hijo-mio-decid-esta-oracion/
tags: [Oraciones]

---
Madre del Cielo, vengo a postrarme a tus pies, vengo a suplicarte por los enfermos que están sufriendo, vengo a pedirte quelos alivies y que les des fortaleza para afrontar su dolor.

Madre del Cielo, que cada uno de mis hermanos comprendan que tú estás como Madre y auxilio de los cristianos y que vienes a pedir a tus hijos la conversión del corazón, la entrega del corazón.

Te pido Madre por los que sufren en el cuerpo y en el alma para que tú los socorras con tu Mano celestial, te pido Madre por todos tus hijos para que veamos que tú eres el camino para llegar definitivamente a Jesús, nuestra salvación.

Gracias Madre, gracias madre Nuestra, gracias Madre y Señora por escuchar nuestras súplicas.

**Predícala hijo mío a tus hermanos y dadla para los enfermos.**