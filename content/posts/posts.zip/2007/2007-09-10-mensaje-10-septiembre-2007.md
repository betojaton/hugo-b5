---
title: Mensaje, 10 de Septiembre 2007
author: admin

date: 2007-09-10T23:18:00+00:00
url: /2007/mensaje-10-septiembre-2007/
thumbnail: /images/img-santisimo-nombre-jesus.jpg
tags: [Mensajes 2007]

---
**Hora: 17 y 18.**  
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-corazones-jesus-maria.jpg" alt="img-corazones-jesus-maria" class="alignright size-medium wp-image-4288" /> 

> Hijos míos: Benditos y amados hijos míos; gracias por escuchar a esta Madre; gracias por acudir hacia la Madre y hacia mi Manto Celestial; hijitos, hijitos míos, si supierais, si vierais las espinas que hay en mi Corazón de Madre, veríais verdaderamente lo que os quiero decir, si vierais las innumerables espinas que atraviesan mi purísimo Corazón, comprenderíais en profundo, el dolor que siento como Madre al ver a tantos hijos extraviarse por caminos sinuosos; y os pido a vosotros que seáis mis soldados, valientes, generosos, dóciles, valientes y no cobardes, valientes y entregados; porque vosotros hijitos míos, todos vosotros fuisteis llamados para esta Santa Obra; fuiste llamados y convocados por el amor infinito de Dios Nuestro Señor; hijitos, hijitos míos, veis vosotros a muchos de vuestros hermanos, en muchas naciones, en todas las naciones, veis que están extraviados, que están corrompidos, que están herrados, y no seso de derramar lágrimas porque son almas y corazones que se resisten a ser guiados por el amor del Señor; son tiempos de oscuridad, de confusión y de error, y vosotros debéis dar testimonio y atestiguar ante el mundo, de lo que habéis recibido y gratuitamente; no miréis nunca el pasado y vivid éste presente, vivid estos días, en el amor, en la paz, en la caridad,<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-jesus-monja.jpg" alt="img-jesus-monja" class="alignright size-medium wp-image-4292" /> aunque os cueste, aunque os cueste cada día; avanzad, y mantened la Luz; esforzaos para que la luz no se extinga en vuestro corazón; recordad, recordad hijitos míos la parábola de las vírgenes prudentes, recordadla, meditadla, y veréis profundamente lo que ésta Madre os quiero decir. Abrid vuestras manos, recibid el Rosario de mis manos, recibid mi Inmaculado Corazón, y llevadlo a vuestro corazón, y sabed hijitos míos, en vuestro corazón debe estar solamente el amor; no debéis ennegrecer el corazón con la oscuridad del mundo, con el error del mundo, que sean meditadas mis palabras, que sean profundizadas, y que sean dadas al mundo entero; tenéis todo en vuestras manos, pues bien, luchad, porque las puertas para esta Madre ya están abiertas. 

Meditad.Meditad, Meditad Mis palabras  
_Hora: 17 y 24_