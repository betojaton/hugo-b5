---
title: 'Retiro del apostolado de la oración. Hijo Mío: decid ésta oración.'
author: admin

date: 2007-10-21T00:15:32+00:00
url: /2007/retiro-del-apostolado-de-la-oracion-hijo-mio-decid-esta-oracion/
thumbnail: /images/virgen_angeles-1.png
tags: [Oraciones]

---
<img decoding="async" loading="lazy" class="alignright size-medium wp-image-770" title="virgen_angeles" src="https://mariadelasantafe.org.ar/images/virgen_angeles.png" alt="virgen_angeles" width="268" height="300" />Corazón de Jesús, ven a reinar en nuestras familias,

Corazón de Jesús, ven a reinar en nuestras comunidades.

Corazón de Jesús, ven a reinar en nuestra patria.

Ven a traernos tu luz para disipar las tinieblas, para que reine tu paz, para que reine tu amor.

Corazón de Jesús, ven a instaurar en nosotros tu amor, que tu amor nos conduzca, que tu amor nos sane, que tu amor nos transforme.

Corazón de Jesús, en Ti confío.

**Amén. Amén. Predícala hijo Mío al mundo entero.**

 ****