---
title: Mensaje, 31 de Octubre, 2007
author: admin

date: 2007-10-31T18:27:18+00:00
abstract: |
  <h3>Retiro del Apostolado de la Oración</h3>
  **Me dice Jesús:**
  <img src="https://mariadelasantafe.org.ar/wp-content/uploads/2016/10/img-corazonjesus-23102007-149x149.jpg" alt="img-corazonjesus-23102007" class="alignright size-thumbnail wp-image-3813 img-circle" /> <blockquote>Vicente hermano mío: digo a todos tus hermanos, las llamas de amor de Mi Sacratísimo Corazón no pueden ser apagadas porque arden permanentemente y Mi Corazón desborda en amor hacia mis hermanos, las llamaradas de amor de Mi Sacratísimo Corazón son eternas, porque Mi amor es eterno y Mi Divina Misericordia es infinita.
  Mis hermanos deben descubrir, deben ver la inmensidad de Mi amor, deben percibir la fragancia que expele Mi Sacratísimo Corazón hacia las almas.
  La paz debe ser recibida en cada corazón, Mi paz, Mi auténtica paz.
  Meditad Mi Profundísimo Mensaje.
  Amén. Gloria a Dios Mi Padre.
  <footer>Leed: Mateo C. 7 V. 11</footer></blockquote>
  Predícalo hermano mío al mundo enter­o.
url: /2007/mensaje-31-de-octubre-2007/
thumbnail: /images/img-corazonjesus-23102007-1.jpg
tags: [Mensajes 2007]

---
### Retiro del Apostolado de la Oración  
**Me dice Jesús:**

<img decoding="async" class="alignright size-thumbnail wp-image-3813 img-circle" src="https://mariadelasantafe.org.ar/images/img-corazonjesus-23102007.jpg" alt="img-corazonjesus-23102007" /> 

> Vicente hermano mío: digo a todos tus hermanos, las llamas de amor de Mi Sacratísimo Corazón no pueden ser apagadas porque arden permanentemente y Mi Corazón desborda en amor hacia mis hermanos, las llamaradas de amor de Mi Sacratísimo Corazón son eternas, porque Mi amor es eterno y Mi Divina Misericordia es infinita.  
> Mis hermanos deben descubrir, deben ver la inmensidad de Mi amor, deben percibir la fragancia que expele Mi Sacratísimo Corazón hacia las almas.  
> La paz debe ser recibida en cada corazón, Mi paz, Mi auténtica paz.  
> Meditad Mi Profundísimo Mensaje.  
> Amén. Gloria a Dios Mi Padre.<footer>Leed: Mateo C. 7 V. 11</footer> 

Predícalo hermano mío al mundo enter­o.