---
title: 'Hijo mío: rezad esta oración:'
author: admin

date: 2007-09-08T00:57:22+00:00
url: /2007/hijo-mio-rezad-esta-oracion/
thumbnail: /images/espiritu-santo-1.png
tags: [Oraciones]

---
<img decoding="async" loading="lazy" class="alignright size-medium wp-image-789" title="espiritu-santo" src="https://mariadelasantafe.org.ar/images/espiritu-santo-300x182.png" alt="espiritu-santo" width="300" height="182" />Ven Espíritu Santo, guíame, instrúyeme, ven Espíritu Santo a iluminar y a poner tu luz donde hay confusión, donde hay desesperanza, donde hay tanta oscuridad.

Ven Espíritu Santo, ven a darnos tu luz, guíanos, consuélanos, instrúyenos.

**Amén. Gloria. Predica esta oración hijo mío al mundo entero.**