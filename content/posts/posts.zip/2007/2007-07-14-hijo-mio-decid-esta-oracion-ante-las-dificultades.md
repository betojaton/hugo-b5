---
title: 'Hijo mío: Decid esta oración ante las dificultades:'
author: admin

date: 2007-07-14T00:13:51+00:00
url: /2007/hijo-mio-decid-esta-oracion-ante-las-dificultades/
tags: [Oraciones]

---
Oh Madre mía amadísima te necesito, a ti recurro en esta necesidad, necesito de ti, de tu auxilio, detu protección, guíame Madre mía por el camino que me lleve totalmente a Cristo Jesús, guíame Madre para llegar verdaderamente a comprender os caminos de Dios, mi Padre, Madre Santísima ayúdame hoy y siempre.

**Amén. Amén. Gloria al Altísimo. Predica esta oración hijo mío al mundo entero.**

 ****