---
title: 'Me dice la Santísima Virgen:  Hijo mío: decid esta oración al Sagrado Corazón de Jesús:'
author: admin

date: 2003-11-30T23:57:33+00:00
url: /2003/me-dice-la-santisima-virgen-hijo-mio-decid-esta-oracion-al-sagrado-corazon-de-jesus/
tags: [Oraciones]

---
Sagrado Corazón de Jesús intrúyeme, sagrado Corazón de Jesús guía mis pasos, mis acciones, mis palabras en este día, para que obre según tu voluntad.

Sagrado Corazón de Jesús que mis pies se aparten del mal, que mi lengua se aparte de las palabras oscuras, que mis manos trabajen hoy para la gloria de tu Nombre.

Sagrado Corazón de Jesús en ti confío.

**Amén. Amén. Predica esta oración hijo mío al mundo entero.**