---
title: Jueves Santo, 17 de Abril 2003
author: admin

date: 2003-04-17T12:59:24+00:00
url: /2003/jueves-santo-17-abril-2003/
thumbnail: /images/img-jueves-santo.jpg
tags: [Mensajes 2003]

---
­<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-jueves-santo-1.jpg" alt="Jueves Santo" class="alignright size-full wp-image-4024" />**Me dice la Santísima Virgen:**

> Hijo mío: Digo a todos tus hermanos, cuantos corazones hoy viven en la idolatría, cuantos corazones hoy viven esta día de amor y de Misericordia, en la oscuridad, viven en la sombra de pecado, y no acercan sus corazones a la verdad, al confesionario, cuantas almas caminan a oscuras, cuantos corazones creen que la libertad está en la droga, en la diversión desmedida, en tantos placeres profanos.  
> Deseo que recodéis en este día, que recordéis siempre, que veáis que la auténtica libertad está en Cristo Jesús , Mi Hijo Amadísimo, que la verdadera paz están en Cristo Jesús, Mi Hijo Amadísimo.  
> No hay otros caminos, no hay otros lugares en donde buscar la paz y la libertad, sólo en Cristo Jesús, Mi Hijo Amadísimo está la verdadera y eterna paz.  
> Meditad Mi profundísimo Mensaje.  
> Amén. Gloria a Cristo Jesús.<footer>Leed: Lucas: C 14, V 26 y 27.</footer> 

**Predícalo hijo mío al mundo entero.**

**Me dice Jesús:** 

> Hermanos míos: Descubrid todo Mi amor, descubrid este regalo de Mi Sacratísimo Corazón, Mi eterno amor por todos los hombres, Mi eterno amor que os ofrezco al mundo entero para que la humanidad por completo se vuelque a Mi Divina Misericordia y abandone los ídolos falsos, abandone la carrera alocada hacia el abismo, abandone la lujuria del pecado, de tanta maldad.  
> Llegad hasta Mí, abrid vuestro corazón y desterrad tanta hielo, tanto odio, tanta vanagloria y aceptad Mis palabras que os reconfortan, que os sanan, que os renuevan plenamente.  
> Mis palabras son para todos los hombres del mundo.  
> Meditad Mi profundísimo Mensaje.  
> Amén. Gloria a Dios Mi Padre.<footer>Leed: 1ra Timoteo: C 4, V 6 al 9. &#8211; Juan: C 14, V 17 y 18. &#8211; Lucas: C 9, V 26 y 27.</footer> 

**Predícalo hijo mío al mundo entero.**