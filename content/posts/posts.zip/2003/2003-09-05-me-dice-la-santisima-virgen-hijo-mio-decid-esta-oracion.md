---
title: 'Me dice la Santísima Virgen: Hijo mío decid esta oración:'
author: admin

date: 2003-09-05T23:31:33+00:00
url: /2003/me-dice-la-santisima-virgen-hijo-mio-decid-esta-oracion/
thumbnail: /images/jesus_buen_pastor.jpg
tags: [Oraciones]

---
<img decoding="async" loading="lazy" class="alignright size-medium wp-image-668" title="jesus_buen_pastor" src="https://mariadelasantafe.org.ar/images/jesus_buen_pastor-214x300-1.png" alt="" width="214" height="300" />“ Señor, sana mi corazón enfermo, dolorido, sana mi corazón herido por las ofensas de mis hermanos,  por los desprecios de mis hermanos, sana verdaderamente éste mi corazón para que te vea a ti presente y viva para que te vea a ti Jesús en todos los hombres.

Ayúdame Jesús para caminar, para mirar la luz que brinda tu Sacratísimo Corazón, luz que enriquece, que me guía y que aparta todas las tinieblas.

Que sea fiel Señor a ti, que sea perseverante y que te ame eternamente.&#8221;

**Amén. Amén. Gloria a Cristo Jesús. Predica esta oración hijo mío al mundo entero.**

&nbsp;