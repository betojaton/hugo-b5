---
title: 'Me dice Jesús:'
author: admin

date: 2003-02-25T20:46:50+00:00
url: /2003/me-dice-jesus-3-2/
tags: [Oraciones]

---
Hermano Mío, decid siempre esta oración:

Sagrado Corazón de Jesús ayúdame, Sagrado Corazón de Jesús reina en, mi Corazón.

Sagrado Corazón de Jesús enciende la llama viva de tu amor para que arda permanentemente en mi corazón.

Sagrado Corazón de Jesús fuente de paz, que de lugar en mi corazón a tu paz, que de lugar en mi corazón a tu amor.

Sagrado Corazón de Jesús, amor infinito, Sagrado Corazón de Jesús, en vos confío.

Amén. Amén. Predica esta oración hermano mío al mundo entero.