---
title: Viernes Santo, 18 de Abril 2003
author: admin

date: 2003-04-18T13:13:17+00:00
url: /2003/viernes-santo-18-abril-2003/
tags: [Mensajes 2003]

---
## Por la mañana en la Capilla de las Hermanas Carmelitas

**Me dice la Santísima Virgen:**

> Hijo mío: Acompañad a Jesús que espera la respuesta de todos sus hermanos, acompañad a Jesús y seguid el camino que a todos os propone, caminad y avanzad junto a Cristo Jesús, porque Cristo Jesús os da la auténtica libertad, Cristo Jesús os da la verdadera paz, el verdadero amor.  
> Meditad Mi profundísimo Mensaje.  
> Amén. Gloria a Cristo Jesús.<footer>Leed: Lucas: C 20, V 12 y 13.</footer>