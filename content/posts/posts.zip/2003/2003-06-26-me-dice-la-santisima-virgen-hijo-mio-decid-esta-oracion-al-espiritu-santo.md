---
title: 'Me dice la Santísima Virgen:  Hijo mío: decid esta oración al Espíritu Santo:'
author: admin

date: 2003-06-26T23:56:30+00:00
url: /2003/me-dice-la-santisima-virgen-hijo-mio-decid-esta-oracion-al-espiritu-santo/
tags: [Oraciones]

---
“Espíritu Santo ilumíname, guíame, Espíritu Santo fortaléceme, guía mis caminos, mis acciones, mis pensamientos, Espíritu Santo fortaléceme para afrontar la prueba, Espíritu Santo fortaléceme para dar testimonio del amor, para dar testimonio de tu presencia, Espíritu Santo vive en mi, reina en mi, se dueño pleno de mi ser&#8221;.

**Amén. Amén. Predica esta oración hijo mío al mundo entero.**

 ****