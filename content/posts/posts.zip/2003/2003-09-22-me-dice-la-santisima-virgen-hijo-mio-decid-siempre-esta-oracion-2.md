---
title: 'Me  dice la Santísima Virgen: Hijo mío: orad así al Padre Celestial:'
author: admin

date: 2003-09-22T23:31:17+00:00
url: /2003/me-dice-la-santisima-virgen-hijo-mio-decid-siempre-esta-oracion-2/
thumbnail: /images/santisima_trinidad-1.png
tags: [Oraciones]

---
<img decoding="async" loading="lazy" class="alignright size-full wp-image-779" title="santisima_trinidad" src="https://mariadelasantafe.org.ar/images/santisima_trinidad.png" alt="santisima_trinidad" width="336" height="429" />“Padre Celestial derrama en nosotros las bendiciones que necesitamos, Padre Celestial que la luz de tu amor borre en nosotros la duda, el temor, que la luz profundísima de tu amor enriquezca nuestro corazón y lo haga dócil a tus Divinos designios.

Padre Celestial que no nos apartemos del campo que tu nos has señalado y que te sirvamos fielmente para gloria de tu Nombre.

Padre Celestial enriquece nuestro espíritu, nuestro corazón y que demos gracias siempre a tu amor Misericordioso.&#8221;

**Amén. Gloria al Altísimo. Dad a conocer esta oración hijo mío.**