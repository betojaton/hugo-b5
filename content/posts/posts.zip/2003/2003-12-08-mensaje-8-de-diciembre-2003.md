---
title: Mensaje, 8 de Diciembre, 2003
author: admin

date: 2003-12-08T13:37:30+00:00
url: /2003/mensaje-8-de-diciembre-2003/
tags: [Mensajes 2003]

---
### En la Capilla de las Hermanas Carmelitas Solemnidad de la Inmaculada Concepción.

**Me dice la Santísima Virgen:**

> Hijo mío: Deseo que escuchéis Mi llamado, que estéis atentos porque aquí tenéis a la Madre, porque la Madre está con todos sus hijos, estoy mostrándoos este camino que os conduce a Cristo Jesús, Mi Hijo Amadísimo, el camino de la oración, el camino del sacrificio, el camino de la entrega y de la humildad, la Madre os señala este camino que conduce a la vida eterna, Cristo Jesús, Mi Hijo Amadísimo.  
> Meditad Mi profundísimo Mensaje.  
> Amén. Gloria a Cristo Jesús.<footer>Leed: Isaías: C 19, V 5 &#8211; Lucas: C 17, V 9.</footer> 

Predícalo hijo mío al mundo entero.