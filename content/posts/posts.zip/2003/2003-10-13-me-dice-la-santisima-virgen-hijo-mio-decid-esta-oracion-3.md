---
title: 'Me dice la Santísima Virgen: Hijo mío: decid esta oración:'
author: admin

date: 2003-10-13T23:55:18+00:00
url: /2003/me-dice-la-santisima-virgen-hijo-mio-decid-esta-oracion-3/
tags: [Oraciones]

---
Oh Mi Dios, oh Señor, muéstranos el camino, que sigamos tus enseñanzas, que sigamos la verdad y que no nos cansemos de mostrar a nuestros hermanos todo el amor que tu nos brindas.

Oh Jesús, oh Salvador enséñanos a caminar solo en el amor.

 ****

**Amén. Amén.  Predica esta oración hijo mío al mundo entero.**