---
title: Mensaje, 22 de septiembre, 2003
author: admin

date: 2003-09-22T15:35:10+00:00
abstract: |
  <img src="https://mariadelasantafe.org.ar/wp-content/uploads/2003/09/img-msj-22092003-329x420.jpg" alt="img-msj-22092003" class="alignright size-medium wp-image-3527" />
  
  <blockquote>"Padre Celestial derrama en nosotros las bendiciones que necesitamos, Padre Celestial que la luz de tu amor borre en nosotros la duda, el temor, que la luz profundísima de tu amor enriquezca nuestro corazón y lo haga dócil a tus Divinos designios.
  Padre Celestial que no nos apartemos del campo que tu nos has señalado y que te sirvamos fielmente para gloria de tu Nombre.
  Padre Celestial enriquece nuestro espíritu, nuestro corazón y que demos gracias siempre a tu amor Misericordioso.”
  Amén. Gloria al Altísimo. Dad a conocer esta oración hijo mío.</blockquote>
url: /2003/mensaje-22-septiembre-2003/
thumbnail: /images/img-msj-22092003-1.jpg
tags: [Mensajes 2003]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/img-msj-22092003.jpg" alt="img-msj-22092003" class="alignright size-medium wp-image-3527" />

> &#8220;Padre Celestial derrama en nosotros las bendiciones que necesitamos, Padre Celestial que la luz de tu amor borre en nosotros la duda, el temor, que la luz profundísima de tu amor enriquezca nuestro corazón y lo haga dócil a tus Divinos designios.  
> Padre Celestial que no nos apartemos del campo que tu nos has señalado y que te sirvamos fielmente para gloria de tu Nombre.  
> Padre Celestial enriquece nuestro espíritu, nuestro corazón y que demos gracias siempre a tu amor Misericordioso.”  
> Amén. Gloria al Altísimo. Dad a conocer esta oración hijo mío.