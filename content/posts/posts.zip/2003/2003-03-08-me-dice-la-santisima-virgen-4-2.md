---
title: 'Me dice la Santísima Virgen:'
author: admin

date: 2003-03-08T20:50:13+00:00
url: /2003/me-dice-la-santisima-virgen-4-2/
thumbnail: /images/maria1.jpg
tags: [Oraciones]

---
<img decoding="async" loading="lazy" class="alignright size-medium wp-image-777" title="virgen_corazon" src="https://mariadelasantafe.org.ar/images/virgen_corazon-226x300-1.png" alt="virgen_corazon" width="226" height="300" />Hijo Mío, decid siempre esta oración:

Madre mía ayúdame, oh Virgen Santísima guía mis pasos, guía mi corazón, guía mis pensamientos hacia ti.

Oh Dulce Madre del Redentor acompaña nuestro caminar, acompaña a todos tus hijos que hoy necesitamos de ti, que hoy necesitamos de tu ayuda. Madre y Señora guíanos siempre por las sendas de la verdad, de la unidad, de la paciencia y lleva todas nuestras súplicas hacia el Padre Celestial. Amén. Amén. Predica esta oración hijo mío al mundo entero.