---
title: Mensaje, 1 de septiembre, 2003
author: admin

date: 2003-09-01T14:37:28+00:00
url: /2003/mensaje-1-de-septiembre-2003/
tags: [Mensajes 2003]

---
**Dice Jesús:**

> Hermano Mío: Hablo a esta humanidad sorda y envilecida por tantos males, hablo a la humanidad, a todos los hombres, a todos mis hermanos para que definitivamente dejéis la división, dejéis el odio y tanta avaricia y busquéis lo valedero, lo auténtico, lo irreemplazable, el Reino de los Cielos.  
> Cuantos hoy os sumergís en la búsqueda de placeres, de lujuria, de crímenes, de abortos, de sexo y drogadicción, cuantos caéis en las redes de Satanás, seducidos por falsos ídolos, seducidos por propuestas engañosas, seducidos por los enemigos, por los perseguidores de Mi Santa Iglesia.  
> No Busquéis oro donde hay muerte y barro, no busquéis vida y paz donde sólo hay mentira, engaño y muerte eterna, no busquéis alivio y consuelo donde reina el engaño y la falsedad.  
> Venid a Mí, el Buen Pastor, venid a Mi Santas Iglesia, donde está el camino auténtico a la vida eterna, cuantos hoy de vosotros que recurrís a la hechicería, a adivinos, a predicadores de falsas luces y engañosos caminos.  
> Digo basta, ya basta de idolatría, ya basta de perder constantemente y día a día el camino que Mi Padre Celestial y Padre de todos vosotros os ofrece, creed en Mis palabras, creed en Mí Amor, creed en Mí Divina Misericordia que se derrama en el mundo entero, en todas las naciones, no os olvidéis de Mis promesas, no os olvidéis de Mi Amor Misericordioso y eterno, no os olvidéis que estoy con todos vosotros, acudid pues a la fuente de agua viva y de vida eterna que brota como manantial desde Mi Sacratísimo Corazón para sanaros, para enriqueceros, para fortaleceros, acudid a Mí porque en Mí está la vida eterna y la luz eterna que os guía, que os conduce, que os acerca a la verdad auténtica y única, verdad eterna que está en Mi Santa Iglesia.  
> No borréis pues con vuestros actos lo que habéis escrito con vuestras manos, me tenéis a vuestro lado.  
> Meditad Mi profundísimo Mensaje.  
> Amén. Gloria a Dios Mi Padre.<footer>Leed: Josué: C 5, V 2 al 6. &#8211; Jueces: C 3, V 1 al 9. &#8211; Marcos: C 16, V 13 al 18. &#8211; Jonás: C 1, V 10. &#8211; Lucas: C 19, V 2 al 5. &#8211; Juan: C 19, V 3 y 4. &#8211; Hebreos: C 2, V 13 y 14. &#8211; Colocenses: C 1, V 7. &#8211; Mateo: C 9, V 36 y 37</footer> 

Predícalo hijo mío