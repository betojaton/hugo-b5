---
title: 'Me dice la Santísima Virgen: Hijo mío: decid siempre esta oración:'
author: admin

date: 2003-06-16T23:29:55+00:00
url: /2003/me-dice-la-santisima-virgen-hijo-mio-decid-siempre-esta-oracion/
tags: [Oraciones]

---
“Sagrado Corazón de Jesús, sana mi corazón dolorido, Sagrado Corazón de Jesús fortalece mi corazón, Sagrado Corazón de Jesús enciende en mi la llama de tu amor para que pueda dar tu amor a todos mis hermanos&#8221;.

&nbsp;

**Amén. Amén.** 

 ****

**Predica esta oración hijo mío al mundo entero.** 

 ****

&nbsp;