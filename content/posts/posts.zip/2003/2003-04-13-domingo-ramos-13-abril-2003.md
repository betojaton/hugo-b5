---
title: Domingo de Ramos, 13 de Abril 2003
author: admin

date: 2003-04-13T12:53:27+00:00
abstract: |
  <img src="https://mariadelasantafe.org.ar/wp-content/uploads/2017/04/dib-cara-jesus-corazon-espinas.jpg" alt="dib-cara-jesus-corazon-espinas" class="alignright size-full wp-image-4020" />**Me dice la Santísima Virgen:**
  <blockquote>Hijos míos: Sobrellevad con amor la cruz de cada día, llevad vuestra cruz con paciencia y amor porque la Madre está a vuestro lado y os invita con amor a ofrecer vuestros trabajos, vuestras penas, vuestras cargas por amor al prójimo, a vuestros hermanos, la cruz es el camino para todas las almas, la cruz es el paso de todo cristiano por este mundo, si Cristo Jesús, Mi Hijo Amadísimo llevó y cargó la cruz más pesada ¿acaso no lo haréis vosotros?.
  Dios, Nuestro Señor os ama y no os abandona, al contrario desborda en amor, desborda de Misericordia hacia todos sus hijos del mundo, creed en el amor de Dios, creed  en su presencia auténtica no verdadero que os trae la Madre, que os anuncia la Madre, Cristo Jesús, Mi Hijo Amadísimo, abrid pues el corazón, abrid vuestra alma por entero al llamado del Señor, abrid las puertas al mensaje del salvación que os trae esta Madre hacia todos vosotros.
  Meditad Mi profundísimo Mensaje.
  Amén. Gloria al Altísimo.
  <footer>Leed: Sofonías: C 3, V 7. - Lucas: C 11; V 31 al 35. - Marcos: C 9, V 16. - Salmo C 16, V 2 al 7.</footer></blockquote>
  **Predícalo hijo mío al mundo entero.**
url: /2003/domingo-ramos-13-abril-2003/
thumbnail: /images/dib-cara-jesus-corazon-espinas.jpg
tags: [Mensajes 2003]

---
<img decoding="async" src="https://mariadelasantafe.org.ar/images/dib-cara-jesus-corazon-espinas-1.jpg" alt="dib-cara-jesus-corazon-espinas" class="alignright size-full wp-image-4020" />**Me dice la Santísima Virgen:**

> Hijos míos: Sobrellevad con amor la cruz de cada día, llevad vuestra cruz con paciencia y amor porque la Madre está a vuestro lado y os invita con amor a ofrecer vuestros trabajos, vuestras penas, vuestras cargas por amor al prójimo, a vuestros hermanos, la cruz es el camino para todas las almas, la cruz es el paso de todo cristiano por este mundo, si Cristo Jesús, Mi Hijo Amadísimo llevó y cargó la cruz más pesada ¿acaso no lo haréis vosotros?.  
> Dios, Nuestro Señor os ama y no os abandona, al contrario desborda en amor, desborda de Misericordia hacia todos sus hijos del mundo, creed en el amor de Dios, creed en su presencia auténtica no verdadero que os trae la Madre, que os anuncia la Madre, Cristo Jesús, Mi Hijo Amadísimo, abrid pues el corazón, abrid vuestra alma por entero al llamado del Señor, abrid las puertas al mensaje del salvación que os trae esta Madre hacia todos vosotros.  
> Meditad Mi profundísimo Mensaje.  
> Amén. Gloria al Altísimo.<footer>Leed: Sofonías: C 3, V 7. &#8211; Lucas: C 11; V 31 al 35. &#8211; Marcos: C 9, V 16. &#8211; Salmo C 16, V 2 al 7.</footer> 

**Predícalo hijo mío al mundo entero.**