---
title: 'Me dice la Santísima Virgen: Hijo mío: orad así:'
author: admin

date: 2003-10-29T23:34:09+00:00
url: /2003/me-dice-la-santisima-virgen-hijo-mio-orad-asi/
thumbnail: /images/jesus.jpg
tags: [Oraciones]

---
<img decoding="async" loading="lazy" class="alignright size-medium wp-image-735" title="jesus" src="https://mariadelasantafe.org.ar/images/jesus-300x214-1.png" alt="jesus" width="300" height="214" />“Madre mía ayúdame, fortaléceme, Madre guíame por tu camino para que por medio de tu Inmaculado Corazón  conozca todo  el amor de Cristo Jesús, Tu Hijo Amadísimo&#8221;.

 ****

**Amén. Gloria al altísimo.  Has conocer esta oración hijo mío.**

 ****

&nbsp;