---
title: Mensaje, 8 de Julio, 2003
author: admin

date: 2003-07-08T18:36:44+00:00
url: /2003/mensaje-8-de-julio-2003/
tags: [Mensajes 2003]

---
**Me dice la Santísima Virgen:** 

> Hijo mío: Esta Madre está junto a todos sus hijos, ésta Madre hace descender entre todos los hijos una lluvia de bendiciones, sobre todos los hijos que con devoción y amor escuchan, atienden y piden a ésta Madre, la Madre acompaña a este pueblo bendito, a esta nación santa porque deseo que éste país vuelva completamente su corazón a Dios y se aleje de toda idolatría, de toda maldad, que se aleje y derribe leyes absurdas y perversas que corroen los corazones de tantos de mis hijos. Escuchad a ésta Madre especialmente y dad a conocer Mis mensajes al mundo entero, porque la humanidad debe descubrir que Mi Inmaculado Corazón es el lazo, es la unión, es el puente que conduce a todos mis hijos hacia Cristo Jesús, Mi Hijo Amadísimo. Volved a los brazos de ésta Madre, abandonad los caminos sinuosos, los caminos de mentira, de violencia, de tanta guerra, de tanta difamación.  
> Aprended verdaderamente a vivir en la verdad porque la verdad os hace libres, la verdad os conduce a la vida eterna, la verdad os conduce a Cristo Jesús, Mi Hijo Amadísimo. Desde hace tantos años véngoos pidiéndoos, suplicándoos, llamándoos a todos a la conversión y deseo la respuesta de los corazones, deseo la respuesta de las almas, deseo que todos mis hijos descubran el valor inﬁnito e inconmensurable de cada una de mis palabras que son para ser conocidas, que son para todos los hijos del mundo. No perdáis pues las oportunidades, los medios que os brinda Dios Nuestro Señor, tenéis todo en vuestras manos, tenéis todos los medios y Dios está junto a vosotros, Dios Nuestro Señor está llamándoos insistentemente para que déis una respuesta deﬁnitiva a sus pedidos. La Madre está aquí en ésta tierra bendita y elegida, Santa Fe, la Nueva Jerusalém. Santa Fe, la Nueva Israel, Argentina, la Nueva nación que renacerá, que surgirá con fe, que resurgirá de tantas calumnias, de tantas calamidades para ser una nación verdaderamente a los pies de Dios Nuestro Señor. La Madre está cumpliendo su gran misión, su gran obra en ésta tierra elegida, para que desde aquí surjan verdaderos corazones, verdaderas almas que invoquen el Nombre del Señor y den testimonio ante el mundo entero, del amor, de la Misericordia, de la bondad inﬁnita de Dios Nuestro Señor. No perdáis pues estos días, no perdáis pues estos momentos, no perdáis pues estas horas valiosas, estas horas que tenéis en vuestras manos por la Misericordia eterna de Dios Nuestro Señor.  
> Meditad todos unidos Mi profundísimo Mensaje. Amén. Bendito y Alabado Sea el Nombre del Señor.<footer>Leed: Génesis: C 2, V 3 al 6. Lucas: C 7, V 12 al 14. Mateo: C 9, V 5 al 12. Lucas: C 17, V 9. Mateo: C 12, V 3 al 6.</footer> 

Predícalo hijo mío a las naciones del mundo entero.