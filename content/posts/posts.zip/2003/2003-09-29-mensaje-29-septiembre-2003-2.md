---
title: Mensaje, 29 de Septiembre 2003
author: admin

date: 2003-09-29T14:21:00+00:00
abstract: |
  **Me dice la Santísima Virgen: **
  <blockquote>Hijo mío: Orad así: “Madre mía ayúdame, fortaléceme, Madre guíame por tu camino para que por medio de tu Inmaculado Corazón conozca todo el amor de Cristo Jesús,Tu Hijo Amadísimo.
  Amén.
  Gloria al Altísimo. Haz conocer esta oración hijo mío.</blockquote>
url: /2003/2003/mensaje-29-septiembre-2003-2/
tags: [Mensajes 2003]

---
**Me dice la Santísima Virgen:** 

> Hijo mío: Orad así: “Madre mía ayúdame, fortaléceme, Madre guíame por tu camino para que por medio de tu Inmaculado Corazón conozca todo el amor de Cristo Jesús,Tu Hijo Amadísimo.  
> Amén.  
> Gloria al Altísimo. Haz conocer esta oración hijo mío.